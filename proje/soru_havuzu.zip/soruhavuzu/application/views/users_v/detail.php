<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Kullanıcı Detay ("<?php echo trim($item->username); ?>")
            <a href="<?php echo base_url("index.php/users/index"); ?>" class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-angle-left"></i> Geri Dön</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-custom panel-primary">
            <div class="panel-body">
                <table class="table table-striped">
                    <tr>
                        <td><b>Kullanıcı Adı :</b></td>
                        <td><?php echo $item->username; ?></td>
                    </tr>
                    <tr>
                        <td><b>Ad :</b></td>
                        <td><?php echo $item->name; ?></td>
                    </tr>
                    <tr>
                        <td><b>Soyad :</b></td>
                        <td><?php echo $item->surname; ?></td>
                    </tr>
                    <tr>
                        <td><b>Kayıt Tarihi :</b></td>
                        <td><?php echo date("d-m-Y H:i:s", strtotime($item->registerDate)); ?></td>
                    </tr>
                    <tr>
                        <td><b>Eposta :</b></td>
                        <td><?php echo $item->email; ?></td>
                    </tr>
                    <tr>
                        <td><b>Branş :</b></td>
                        <td><?php echo $item->brans; ?></td>
                    </tr>
                    <tr>
                        <td><b>Okul :</b></td>
                        <td><?php echo $item->okul . " (" . $item->kurum_kodu . ")";; ?></td>
                    </tr>
                    <tr>
                        <td><b>Adres :</b></td>
                        <td><?php echo $item->address; ?></td>
                    </tr>
                    <tr>
                        <td><b>Durumu :</b></td>
                        <td>
                            <?php
                            switch ($item->isActive) {
                                case 0:
                                    echo "<span style='color:red;'>Pasif</span>";
                                    break;
                                case 1:
                                    echo "<span style='color:green;'>Aktif</span>";
                                    break;
                                default:
                                    echo "Eksik Bilgi";
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td><b>Yetki Düzeyi :</b></td>
                        <td>
                            <?php
                            switch ($item->isAdmin) {
                                case 0:
                                    echo "<span style='color:red;'>Kullanıcı</span>";
                                    break;
                                case 1:
                                    echo "<span style='color:green;'>Yönetici</span>";
                                    break;
                                default:
                                    echo "Eksik Bilgi";
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td><b>Sistem Rolü :</b></td>
                        <td><?php echo $item->role_name . " (" . $item->role_description . ")"; ?></td>
                    </tr>
                    <tr>
                        <td><b>Kullanıcı Gizlilik Taahhütnamesi Onay Durumu:</b></td>
                        <td>
                            <?php
                            switch ($item->gizlilik_taahhut_onay) {
                                case 0:
                                    echo "<span style='color:red;'>Onaylanmadı</span>";
                                    break;
                                case 1:
                                    echo "<span style='color:green;'>Onayladı (" . $item->gizlilik_taahhut_onay_tarihi . " tarihinde)</span>";
                                    break;
                                default:
                                    echo "Eksik Bilgi";
                            }
                            ?>
                        </td>
                    </tr>
                </table>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div>
</div>