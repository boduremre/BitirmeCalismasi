<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Kullanıcı Sil ("<?php echo trim($item->username); ?>")
            <a href="<?php echo base_url("index.php/users/index"); ?>"
               class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-angle-left"></i> Geri Dön</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-custom panel-danger">
            <div class="panel-body">
                <table class="table table-striped">
                    <tr>
                        <td><b>Kullanıcı Adı :</b></td>
                        <td><?php echo $item->username; ?></td>
                    </tr>
                    <tr>
                        <td><b>Ad :</b></td>
                        <td><?php echo $item->name; ?></td>
                    </tr>
                    <tr>
                        <td><b>Soyad :</b></td>
                        <td><?php echo $item->surname; ?></td>
                    </tr>
                    <tr>
                        <td><b>Kayıt Tarihi :</b></td>
                        <td><?php echo date("d-m-Y H:i:s", strtotime($item->registerDate)); ?></td>
                    </tr>
                    <tr>
                        <td><b>Eposta :</b></td>
                        <td><?php echo $item->email; ?></td>
                    </tr>
                    <tr>
                        <td><b>Branş :</b></td>
                        <td><?php echo $item->brans; ?></td>
                    </tr>
                    <tr>
                        <td><b>Okul :</b></td>
                        <td><?php echo $item->okul; ?></td>
                    </tr>
                    <tr>
                        <td><b>Adres :</b></td>
                        <td><?php echo $item->address; ?></td>
                    </tr>
                    <tr>
                        <td><b>Durumu :</b></td>
                        <td>
                            <?php
                            switch ($item->isActive) {
                                case 0:
                                    echo "<span style='color:red;'>Pasif</span>";
                                    break;
                                case 1:
                                    echo "<span style='color:green;'>Aktif</span>";
                                    break;
                                default:
                                    echo "Eksik Bilgi";
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td><b>Rol :</b></td>
                        <td>
                            <?php
                            switch ($item->isAdmin) {
                                case 0:
                                    echo "<span style='color:red;'>Kullanıcı</span>";
                                    break;
                                case 1:
                                    echo "<span style='color:green;'>Yönetici</span>";
                                    break;
                                default:
                                    echo "Eksik Bilgi";
                            }
                            ?>
                        </td>
                    </tr>
                </table>
            </div><!-- .widget-body -->
            <div class="panel-footer">
                <p>Kullanıcıyı silmek istediğinizden emin misiniz! (Bu işlem geri alınamaz!)</p>
                <a href="<?php echo base_url(); ?>index.php/users/delete/<?php echo $item->id; ?>"
                   class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>&nbsp; Evet, eminim sil.</a>
                <a href="<?php echo base_url(); ?>index.php/users/index" class="btn btn-primary btn-sm"><i
                            class="fa fa-trash"></i>&nbsp; Hayır, silme.</a>
            </div>
        </div><!-- .widget -->
    </div>
</div>