<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Kullanıcı Düzenle
            <a href="<?php echo base_url("index.php/users/index"); ?>"
               class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-list"></i> Kullanıcılar Listesi</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-custom panel-info">
            <div class="panel-body">
                <?php echo form_open(base_url('index.php/users/update')); ?>
                <input type="hidden" value="<?php echo $item->id; ?>" name="id">
                <div class="form-group">
                    <label for="maxlength-demo-1">Kullanıcı Adı</label>
                    <input type="text" value="<?php echo $item->username; ?>" id="maxlength-demo-1" maxlength="15"
                           class="form-control" name="username" autocomplete="off" data-plugin="maxlength"
                           data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger' }">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-2">Şifre</label>
                    <input type="text" value="<?php echo $item->password; ?>" id="maxlength-demo-2" maxlength="20"
                           class="form-control" name="password" autocomplete="off" data-plugin="maxlength"
                           data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom' }">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-3">Ad</label>
                    <input type="text" value="<?php echo $item->name; ?>" id="maxlength-demo-3" maxlength="25"
                           class="form-control" name="name" autocomplete="off" data-plugin="maxlength"
                           data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom', message: 'used %charsTyped% of %charsTotal% chars.' }">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-3">Soyad</label>
                    <input type="text" value="<?php echo $item->surname; ?>" id="maxlength-demo-3" maxlength="25"
                           class="form-control" name="surname" autocomplete="off" data-plugin="maxlength"
                           data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom', message: 'used %charsTyped% of %charsTotal% chars.' }">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-3">Eposta</label>
                    <input type="email" value="<?php echo $item->email; ?>" id="maxlength-demo-3" maxlength="50"
                           class="form-control" name="email" autocomplete="off" data-plugin="maxlength"
                           data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom', message: 'used %charsTyped% of %charsTotal% chars.' }">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-3">Telefon</label>
                    <input type="tel" value="<?php echo $item->tel; ?>" id="maxlength-demo-3" maxlength="11"
                           class="form-control" name="tel" autocomplete="off" data-plugin="maxlength"
                           data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom', message: 'used %charsTyped% of %charsTotal% chars.' }">
                </div>
                <div class="form-group">
                    <label class="control-label">Branş</label>
                    <select id="bransID" name="bransID" class="form-control" data-plugin="select2" autocomplete="off"
                            style="width: 100%" required>
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($dersler as $row) {
                            if ($item->bransID == $row->id)
                                echo '<option selected value="' . $row->id . '">' . $row->adi . '</option>';
                            else
                                echo '<option value="' . $row->id . '">' . $row->adi . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Okul</label>
                    <select id="kurum_kodu" name="kurum_kodu" class="form-control" data-plugin="select2"
                            autocomplete="off" style="width: 100%" required>
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($okullar as $row) {
                            if ($item->kurum_kodu == $row->kurum_kodu)
                                echo '<option selected value="' . $row->kurum_kodu . '">(' . $row->TownName . ') ' . $row->kurum_kodu . ' - ' . $row->kurum_adi . '</option>';
                            else
                                echo '<option value="' . $row->kurum_kodu . '">(' . $row->TownName . ') ' . $row->kurum_kodu . ' - ' . $row->kurum_adi . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Rol</label>
                    <select id="roleId" name="roleId" class="form-control" data-plugin="select2" autocomplete="off"
                            style="width: 100%" required>
                        <option value="">Seçiniz...</option>
                        <?php

                        foreach ($roller as $row) {
                            if ($item->roleID == $row->id)
                                echo '<option selected value="' . $row->id . '">' . $row->name . '</option>';
                            else
                                echo '<option value="' . $row->id . '">' . $row->name . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Adres</label>
                    <input type="text" class="form-control" autocomplete="off" placeholder="Adres" name="address"
                           id="address" value="<?php echo $item->address; ?>"/>
                </div>
                <div class="form-group">
                    <input type="submit" id="submit_button" name="submit" class="btn btn-primary pull-right"/>
                </div>
                <?php echo form_close(); ?>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div>
    <!-- END column -->
</div>