<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Kullanıcılar Listesi
            <a href="<?php echo base_url("index.php/users/add"); ?>"
               class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-plus"></i> Yeni Ekle</a>
        </h4>
    </div>
    <div class="col-sm-12 col-md-12">
        <div class="panel panel-custom panel-default">
            <div class="panel-body">
                <table class="table table-striped datatable" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>#ID</th>
                        <th>Kullanıcı Adı</th>
                        <th>Şifre</th>
                        <th>Rol</th>
                        <th>Ad</th>
                        <th>Soyad</th>
                        <th>E-posta</th>
                        <th>Kayıt Tarihi</th>
                        <th>İşlemler</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($items as $item) { ?>
                        <tr>
                            <td>#<?php echo $item->id; ?></td>
                            <td><?php echo $item->username; ?></td>
                            <td><?php echo $item->password; ?></td>
                            <td><span data-toggle='tooltip' data-placement='top'
                                      title='<?php echo $item->role_description; ?>'><?php echo $item->role_name; ?></span>
                            </td>
                            <td><?php echo $item->name; ?></td>
                            <td><?php echo $item->surname; ?></td>
                            <td><?php echo $item->email; ?></td>
                            <!--  <td>
                                    <?php
                            if ($item->isActive == 1) {
                                echo '<input id="switch-0-\' . $item->id . \'" type="checkbox" data-switchery data-size="small" checked/>';
                            } else {
                                echo '<input id="switch-0-' . $item->id . '" type="checkbox" data-switchery data-size="small"/>';
                            } ?>

                                </td> -->
                            <td><?php echo date("d.m.Y", strtotime($item->registerDate)); ?></td>
                            <td>
                                <div class="btn-group btn-group-xs" role="group">
                                    <a href="<?php echo base_url(); ?>index.php/users/detail/<?php echo $item->id; ?>"
                                       class="btn btn-primary btn-xs"><i class="fa fa-eye"></i></a>
                                    <a href="<?php echo base_url(); ?>index.php/users/edit/<?php echo $item->id; ?>"
                                       class="btn btn-info btn-xs"><i class="fa fa-edit"></i></a>
                                    <a href="javascript:void()" data-url="<?php echo base_url(); ?>index.php/users/delete/<?php echo $item->id; ?>"
                                       class="btn btn-danger btn-xs remove-btn"><i class="fa fa-trash"></i></a>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>