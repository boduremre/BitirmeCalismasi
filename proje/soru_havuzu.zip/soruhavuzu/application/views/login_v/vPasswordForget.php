<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Düzce ÖDM - Şifremi Unuttum</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Admin, Dashboard, Bootstrap"/>
    <link rel="shortcut icon" sizes="196x196" href="<?php echo base_url('assets'); ?>/images/logo.png">

    <link rel="stylesheet" href="<?php echo base_url('assets'); ?>/libs/bower/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet"
          href="<?php echo base_url(); ?>assets/libs/bower/material-design-iconic-font/dist/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/libs/bower/animate.css/animate.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/core.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/misc-pages.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/iziToast.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300">
</head>
<body class="simple-page">
<!-- <div id="back-to-home">
    <a href="<?php echo base_url(); ?>index.php/login" class="btn btn-outline btn-default" title="Giriş Ekranına Gön"><i
                class="fa fa-sign-in animated zoomIn"></i></a>
</div> -->
<div class="simple-page-wrap">
    <div class="simple-page-logo animated swing">
        <a href="<?php echo base_url('index.php');?>">
            <span><i class="fa fa-gg"></i></span>
            <span>SORU HAVUZU</span>
        </a>
    </div><!-- logo -->
    <div class="simple-page-form animated flipInY" id="reset-password-form">
        <h4 class="form-title m-b-xl text-center">Parolanızı unuttunuz ?</h4>
        <?php if(!empty(validation_errors())){ ?>
        <div class="alert alert-danger" role="alert">
        <?php echo validation_errors(); ?>
        </div>
        <?php } ?>
        <?php echo form_open('login/resetpassword');?>
            <div class="form-group">
                <input id="reset-password-email" type="text" name="email" class="form-control" placeholder="e-posta adresinizi giriniz..." autocomplete="on">
            </div>
            <input type="submit" class="btn btn-primary" value="ŞİFREMİ SIFIRLA" />
        <?php echo form_close();?>
    </div><!-- #reset-password-form -->
    <div class="simple-page-footer">
        <p><a href="<?php echo base_url(); ?>index.php/login">GİRİŞ</a></p>
    </div><!-- .simple-page-footer -->
</div><!-- .simple-page-wrap -->
<script src="<?php echo base_url("assets"); ?>/libs/bower/jquery/dist/jquery.js"></script>
<script src="<?php echo base_url("assets"); ?>/js/iziToast.min.js"></script>
<?php $this->load->view("includes/alert"); ?>
</body>
</html>