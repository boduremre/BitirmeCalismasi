<div class="row">
    <div class="col-md-12">
        <div class="m-b-lg">
            <b>Soru Detay (<?php echo trim($item->no); ?> numaralı soru)</b>
            <div class="btn-group pull-right" role="group">
                <a href="<?php echo base_url("index.php/sorular/index"); ?>"
                   class="btn btn-primary btn-sm">
                    <i class="fa fa-angle-left"></i> Geri Dön</a>&nbsp;
                <a href="<?php echo base_url("index.php/sorular/toword/") . $item->dogrulama_kodu; ?>"
                   class="btn btn-info btn-sm">
                    <i class="fa fa-file-word-o"></i> Word</a>&nbsp;
                <button class="btn btn-success btn-sm" onclick="printDiv('<?php echo trim($item->dogrulama_kodu); ?>')"><i class="fa fa-print"></i> Yazdır</button>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-custom panel-primary">
            <div class="panel-body" id="printableArea">
                <table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0 width=728
                       style='width:545.75pt;margin-left:0pt;border-collapse:collapse;border:none;
 mso-border-alt:solid windowtext .5pt;mso-yfti-tbllook:1184;mso-padding-alt:
 0cm 5.4pt 0cm 5.4pt'>
                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
                        <td width=157 colspan="10" valign=top style='width:118.05pt;border:solid windowtext 1.0pt;border-bottom:
  solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
                            <p class=MsoNormal>
                                <o:p><b>Öğretmen Bilgileri</b></o:p>
                            </p>
                        </td>

                    </tr>
                    <tr style='mso-yfti-irow:2;height:17.0pt'>
                        <td width=157 style='width:118.05pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Adı
  Soyadı:<o:p></o:p></span></b></p>
                        </td>
                        <td width=323 colspan=5 style='width:242.55pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal>
                                <o:p><?php echo trim($item->name) . ' ' . trim($item->surname); ?></o:p>
                            </p>
                        </td>
                        <td width=100 style='width:75.2pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Branşı:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width=147 style='width:109.95pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'><o:p><?php echo trim($item->ders_adi); ?></o:p></span>
                            </p>
                        </td>

                    </tr>
                    <tr style='mso-yfti-irow:3;height:17.0pt'>
                        <td width=157 style='width:118.05pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>E-posta
  Adresi:<span style='color:red'><o:p></o:p></span></span></b></p>
                        </td>
                        <td width=323 colspan=5 style='width:242.55pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal>
                                <o:p><?php echo trim($item->email); ?></o:p>
                            </p>
                        </td>
                        <td width=157 style='width:118.05pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Telefon:<span
                                                style='color:red'><o:p></o:p></span></span></b></p>
                        </td>
                        <td width=323 style='width:242.55pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal>
                                <o:p><?php echo trim($item->tel); ?></o:p>
                            </p>
                        </td>
                    </tr>
                    <tr style='mso-yfti-irow:4'>
                        <td width=157 style='width:118.05pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Okulu:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width=570 colspan=7 style='width:427.7pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                            <p class=MsoNormal align="left" style='text-align:left><span
                                        style=' font-size:10.5pt;mso-bidi-font-size:12.0pt'>
                            <o:p><?php echo trim($item->okul) . ' (' . $item->kurum_kodu . ')'; ?></o:p>
                            </span></p>
                        </td>
                    </tr>
                </table>
                <br>
                <table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0 width=728
                       style='width:545.75pt;margin-left:0pt;border-collapse:collapse;border:none;
 mso-border-alt:solid windowtext .5pt;mso-yfti-tbllook:1184;mso-padding-alt:
 0cm 5.4pt 0cm 5.4pt'>
                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
                        <td width=157 colspan="10" valign=top style='width:118.05pt;border:solid windowtext 1.0pt;border-bottom:
  solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
                            <p class=MsoNormal">
                                <o:p><b>Soru Bilgileri</b></o:p>
                            </p>
                        </td>

                    </tr>
                    <tr style='mso-yfti-irow:1;height:17.0pt'>
                        <td width=157 style='width:118.05pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>S.No ve Kodu:<span
                                                style='color:red'><o:p></o:p></span></span></b></p>
                        </td>
                        <td width=323 colspan=5 style='width:242.55pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal>
                                <o:p><?php echo trim($item->no . '/' . $item->kodu); ?></o:p>
                            </p>
                        </td>
                        <td width=100 style='width:75.2pt;border:solid windowtext 1.0pt;border-left:
  none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Kayıt Tarihi:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width=147 style='width:109.95pt;border:solid windowtext 1.0pt;border-left:
  none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
                            <p class=MsoNormal><span style='font-size:9.5pt;mso-bidi-font-size:10.0pt'><span
                                            style='mso-spacerun:yes'></span><o:p><?php echo date("d/m/Y H:i:s", strtotime($item->kayit_tarihi)); ?></o:p></span>
                            </p>
                        </td>

                    </tr>
                    <tr style='mso-yfti-irow:2;height:17.0pt'>
                        <td width=157 style='width:118.05pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Okul Türü:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width=323 colspan=5 style='width:242.55pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><span style='font-size:small;mso-bidi-font-size:small'><o:p><?php
                                        switch ($item->okulTuru) {
                                            case 1:
                                                echo "<span style='color:green'>İlkokul</span>";
                                                break;
                                            case 2:
                                                echo "<span style='color:#B7950B;'>Ortaokul</span>";
                                                break;
                                            case 3:
                                                echo "<span style='color:#5DADE2;'>Anadolu Lis.</span>";
                                                break;
                                            case 4:
                                                echo "<span style='color:#900C3F;'>Meslek Lis.</span>";
                                                break;
                                            case 5:
                                                echo "<span style='color:red;'>Proje Lis.</span>";
                                                break;
                                            default:
                                                echo "Eksik Bilgi";
                                        }
                                        ?></o:p></span>
                            </p>
                        </td>
                        <td width=100 style='width:75.2pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Sınıf:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width=147 style='width:109.95pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'><o:p><?php echo trim($item->sinifDuzeyi); ?>. Sınıf</o:p></span>
                            </p>
                        </td>

                    </tr>
                    <tr style='mso-yfti-irow:5;height:17.0pt'>
                        <td width=157 style='width:118.05pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Ders:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width=323 colspan=5 style='width:242.55pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal>
                                <o:p><?php echo $item->ders_adi; ?></o:p>
                            </p>
                        </td>
                        <td width=100 style='width:75.2pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:9pt'>Zorluk Düzeyi:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width=147 valign=top style='width:109.95pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal align=center style='text-align:left'><span
                                        style='font-size:10.5pt;mso-bidi-font-size:12.0pt'><o:p>
										<?php
                                        switch ($item->zorlukDerecesi) {
                                            case 1:
                                                echo "<span style='color:green'>Çok Kolay</span>";
                                                break;
                                            case 2:
                                                echo "<span style='color:#B7950B;'>Kolay</span>";
                                                break;
                                            case 3:
                                                echo "<span style='color:#5DADE2;'>Orta</span>";
                                                break;
                                            case 4:
                                                echo "<span style='color:#900C3F;'>Zor</span>";
                                                break;
                                            case 5:
                                                echo "<span style='color:red;'>Çok Zor</span>";
                                                break;
                                            default:
                                                echo "Eksik Bilgi";
                                        }
                                        ?></o:p></span></p>
                        </td>
                    </tr>
                    <tr style='mso-yfti-irow:7;height:17.0pt'>
                        <td width=157 style='width:118.05pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Ünite:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width=570 colspan=7 style='width:427.7pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal>
                                <o:p><?php echo $item->unite_kodu . '-' . $item->unite_icerik; ?></o:p>
                            </p>
                        </td>
                    </tr>
                    <tr style='mso-yfti-irow:7;height:17.0pt'>
                        <td width=157 style='width:118.05pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Konu:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width=570 colspan=7 style='width:427.7pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal>
                                <o:p><?php echo $item->konu_kodu . '-' . $item->konu_icerik; ?></o:p>
                            </p>
                        </td>
                    </tr>
                    <tr style='mso-yfti-irow:8;height:17.0pt'>
                        <td width=157 style='width:118.05pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Kazanım:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width=570 colspan=7 style='width:427.7pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal>
                                <o:p><?php echo $item->kazanim_kodu . '-' . $item->kazanim_icerik; ?></o:p>
                            </p>
                        </td>
                    </tr>
                    <tr style='mso-yfti-irow:11;mso-yfti-lastrow:yes;height:17.0pt'>
                        <td width=157 style='width:118.05pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Onaylayan:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width="75" colspan=2 style='width:75.8pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal>
                                <?php
                                    if($item->onay_durumu==5)
                                        echo strip_tags($onaylayanUser->name . ' ' . $onaylayanUser->surname . ' (' . $onaylayanUser->role_name . ')');
                                    else
                                        echo "&nbsp;";
                                    ?>

                            </p>
                        </td>
                        <td width="50" style='width:50.3pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Durumu:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width=310 colspan=4 style='width:232.6pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class="MsoNormal">
   <span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>
							<?php
                            switch ($item->onay_durumu) {
                                case 0:
                                    echo "<span style='color:#f92672;'>Kaydedildi, Gönderilmeyi Bekliyor</span>";
                                    break;
                                case 1:
                                    echo "<span style='color:#B7950B;'>Aksiyon Bekleniyor</span>";
                                    break;
                                case 2:
                                    echo "<span style='color:#5DADE2;'>Kontrol Ediliyor</span>";
                                    break;
                                case 3:
                                    echo "<span style='color:red;'>Reddedildi</span>";
                                    break;
                                case 4:
                                    echo "<span style='color:#900C3F;'>Düzeltilmeli</span>";
                                    break;
                                case 5:
                                    echo "<span style='color:green;'>Onaylandı (" . date("d/m/Y H:i:s", strtotime($item->onaylama_tarihi)) . ")</span>";
                                    break;
                                default:
                                    echo "Eksik Bilgi";
                            }
                            ?>
							</span>

                            </p>
                        </td>
                    </tr>
                    <tr style='mso-yfti-irow:8;height:17.0pt'>
                        <td width=157 style='width:118.05pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal><b><span style='font-size:10.5pt;mso-bidi-font-size:12.0pt'>Yorum/Neden:<o:p></o:p></span></b>
                            </p>
                        </td>
                        <td width=570 colspan=7 style='width:427.7pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:17.0pt'>
                            <p class=MsoNormal>
                                <o:p><?php echo strip_tags($item->uzman_yorumu); ?></o:p>
                            </p>
                        </td>
                    </tr>
                </table>

                <br>
                <table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0 width=728
                       style='width:545.75pt;margin-left:0pt;border-collapse:collapse;border:
 none;mso-border-alt:solid windowtext .5pt;mso-yfti-tbllook:1184;mso-padding-alt:
 0cm 5.4pt 0cm 5.4pt'>
                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
                        <td width=728 valign=top style='width:545.75pt;border:solid windowtext 1.0pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                            <p class=MsoNormal><b>Resim, Grafik, Tablo vb. ve Madde Kökü (Soru)</b></p>
                        </td>
                    </tr>
                    <tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes;height:252.85pt'>
                        <td width=728 valign=top style='width:545.75pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:252.85pt'>
                            <p class=MsoNormal>

                                <o:p><?php echo $item->madde_koku; ?></o:p>
                            </p>
                        </td>
                    </tr>
                </table>

                <br>

                <table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0 width=728
                       style='width:545.75pt;margin-left:0pt;border-collapse:collapse;border:
 none;mso-border-alt:solid windowtext .5pt;mso-yfti-tbllook:1184;mso-padding-alt:
 0cm 5.4pt 0cm 5.4pt'>
                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
                        <td width=728 valign=top style='width:545.75pt;border:solid windowtext 1.0pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                            <p class=MsoNormal><b>Seçenekler (Şıklar)</b></p>
                        </td>
                    </tr>
                    <tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes;'>
                        <td width=728 valign=top style='width:545.75pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
                            <p>
                                A) <?php echo strip_tags($item->cevap_a); ?><br>
                                B) <?php echo strip_tags($item->cevap_b); ?><br>
                                C) <?php echo strip_tags($item->cevap_c); ?><br>
                                D) <?php echo strip_tags($item->cevap_d); ?><br>
                                <?php if ($item->sinifDuzeyi > 8) {
                                    echo "E) " . $item->cevap_e;
                                } ?>
                            </p>
                        </td>
                    </tr>
                </table>

                <br>
                <table class="MsoTableGrid hidden-print" border=1 cellspacing=0 cellpadding=0 width=728
                       style='margin-left:0pt;border-collapse:collapse;border:none;mso-border-alt:
 solid windowtext .5pt;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
                        <td width=699 colspan=2 valign=top style='width:524.5pt;border:solid windowtext 1.0pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                            <p class=MsoNormal><b>Doğru Cevap</b></p>
                        </td>
                    </tr>
                    <tr style='mso-yfti-irow:2;mso-yfti-lastrow:yes;'>
                        <td width=614 valign=top style='width:460.7pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;'>
                            <o:p><?php echo $item->dogru_cevap; ?></o:p>
                        </td>

                    </tr>
                    <tr colspan="2">
                        <td style="border: none">
                            <p class=MsoNormal align="center" style='text-align:center'>
                                <span style='font-size:7.5pt;mso-bidi-font-size:7.5pt;color:black'>
                                    Bu soru evrakı http://soruhavuzu.emrebodur.com/evraksorgula adresinden <b><?php echo $item->dogrulama_kodu; ?></b> kodu ile teyit edilebilir.
                                </span>
                            </p>
                        </td>
                    </tr>
                </table>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div>
</div>