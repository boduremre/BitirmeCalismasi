<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Soru Sil ("<?php echo trim($item->no); ?>" numaralı soru)
            <a href="<?php echo base_url("index.php/sorular/index"); ?>"
               class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-angle-left"></i> Geri Dön</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-custom panel-danger">
            <div class="panel-body">
                <p><b>Numara :</b> <?php echo $item->no; ?></p>
				<p><b>Doğrulama Kodu :</b> <?php echo $item->dogrulama_kodu; ?></p>
				<p><b>Kayıt Tarihi :</b> <?php echo $item->kayit_tarihi; ?></p>   
                <p><b>Ders :</b> <?php echo $item->dersAdi; ?></p>
                <p><b>Sınıf :</b> <?php echo $item->sinifDuzeyi; ?>. Sınıf</p>
                <p><b>Zorluk Derecesi:</b> <?php 								
								switch ($item->zorlukDerecesi){
								   case 1: echo "Çok Kolay"; break;
								   case 2: echo "Kolay"; break;
								   case 3: echo "Orta"; break;
								   case 4: echo "Zor"; break;
								   case 5: echo "Çok Zor"; break;
								   default: echo "Eksik Bilgi";
								}								
							?>
				<p><b>Kazanım :</b> <?php echo $item->kazanim_no.$item->kazanim_icerik; ?></p>
                <p><b>Onay :</b> <?php
									switch ($item->onay_durumu){
									   case 1: echo "<span style='color:#B7950B;'>Aksiyon Bekleniyor</span>"; break;
									   case 2: echo "<span style='color:#5DADE2;'>Kontrol Ediliyor</span>"; break;
									   case 3: echo "<span style='color:red;'>Reddedildi</span>"; break;
									   case 4: echo "<span style='color:#900C3F;'>Düzeltilmeli</span>"; break;
									   case 5: echo "<span style='color:green;'>Onaylandı</span>"; break;
									   default: echo "Eksik Bilgi";
									}	
								?></p>
            </div><!-- .widget-body -->
            <div class="panel-footer">
                <p>Soruyu silmek istediğinizden emin misiniz! (Bu işlem geri alınamaz!)</p>
                <a href="<?php echo base_url(); ?>index.php/sorular/delete/<?php echo $item->dogrulama_kodu; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>&nbsp; Evet, eminim sil.</a>
                <a href="<?php echo base_url(); ?>index.php/sorular/index" class="btn btn-primary btn-sm"><i class="fa fa-trash"></i>&nbsp; Hayır, silme.</a>
            </div>
        </div><!-- .widget -->
    </div>
</div>