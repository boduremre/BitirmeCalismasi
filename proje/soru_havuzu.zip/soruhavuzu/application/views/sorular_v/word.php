<?php echo $item->madde_koku; ?>
<br>
<?php echo $item->secenekler; ?>