<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            &nbsp;
            <a href="<?php echo base_url("index.php/sorular/add"); ?>"
               class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-plus"></i> Yeni Soru Ekle</a>
        </h4>
    </div>
    <div class="col-sm-12 col-md-12">
        <div class="panel panel-custom panel-default">
            <div class="panel-body">
                <table class="table table-striped datatable" cellspacing="0"
                       width="100%">
                    <thead>
                    <tr>
                        <th>No</th>
                        <th>Kodu</th>
                        <th>Tarih</th>
                        <th>Okul Türü</th>
                        <th>Ders</th>
                        <th>Sınıf</th>
                        <th>Zorluk Derec.</th>
                        <th>Kaz. No</th>
                        <th>Onay</th>
                        <th>İşlemler</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($items as $item) { ?>

                        <tr>
                            <td><?php echo $item->no; ?></td>
                            <td><?php echo $item->kodu; ?></td>
                            <td><?php echo date("d-m-Y H:i", strtotime($item->kayit_tarihi)); ?></td>
                            <td>

                                <?php
                                switch ($item->okulTuru) {
                                    case 1:
                                        echo "<span style='color:green'>İlkokul</span>";
                                        break;
                                    case 2:
                                        echo "<span style='color:#B7950B;'>Ortaokul</span>";
                                        break;
                                    case 3:
                                        echo "<span style='color:#5DADE2;'>Anadolu Lis.</span>";
                                        break;
                                    case 4:
                                        echo "<span style='color:#900C3F;'>Meslek Lis.</span>";
                                        break;
                                    case 5:
                                        echo "<span style='color:red;'>Proje Lis.</span>";
                                        break;
                                    default:
                                        echo "Eksik Bilgi";
                                }
                                ?>
                            </td>
                            <td><?php echo $item->ders_adi; ?></td>
                            <td><?php echo $item->sinifDuzeyi; ?>.Sınıf</td>
                            <td>

                                <?php
                                switch ($item->zorlukDerecesi) {
                                    case 1:
                                        echo "<span style='color:green'>Çok Kolay</span>";
                                        break;
                                    case 2:
                                        echo "<span style='color:#B7950B;'>Kolay</span>";
                                        break;
                                    case 3:
                                        echo "<span style='color:#5DADE2;'>Orta</span>";
                                        break;
                                    case 4:
                                        echo "<span style='color:#900C3F;'>Zor</span>";
                                        break;
                                    case 5:
                                        echo "<span style='color:red;'>Çok Zor</span>";
                                        break;
                                    default:
                                        echo "Eksik Bilgi";
                                }
                                ?>
                            </td>
                            <td><a href="#" data-toggle="tooltip" data-placement="top"
                                   title="<?php echo $item->kazanim_icerik; ?>"><?php echo $item->kazanim_kodu; ?></a>
                            </td>
                            <td>
                                <?php echo form_open('sorular/send'); ?>
                                <input type="hidden" name="dogrulama_kodu"
                                       value="<?php echo $item->dogrulama_kodu; ?>"/>
                                <?php
                                switch ($item->onay_durumu) {
                                    case 0:
                                        echo "<span data-toggle='tooltip' data-placement='top' title='Sorunuz kaydedilmiştir. Gönderilmediği sürece ÖDM personeli tarafından görüntülenemeyecektir.' style='color:#f92672;cursor:pointer;'>Gönderilmeyi Bekliyor</span>&nbsp;(<button type='submit' class='btn btn-xs btn-link'>Gönder</button>)";
                                        break;
                                    case 1:
                                        echo "<span data-toggle='tooltip' data-placement='top' title='Sorunuz gönderilmiştir. En kısa sürede uzmanımız tarafından değerlendirmeye alınacaktır.' style='color:#B7950B;cursor:pointer;'>Aksiyon Bekleniyor</span>";
                                        break;
                                    case 2:
                                        echo "<span data-toggle='tooltip' data-placement='top' title='Sorunuz uzmanımız tarafından kontrol edilmektedir.' style='color:#5DADE2;cursor:pointer;'>Kontrol Ediliyor</span>";
                                        break;
                                    case 3:
                                        echo "<span data-toggle='tooltip' data-placement='top' title='" . strip_tags($item->uzman_yorumu) . "' style='color:red;cursor:pointer;'>Reddedildi</span>";
                                        break;
                                    case 4:
                                        echo "<span data-toggle='tooltip' data-placement='top' title='" . strip_tags($item->uzman_yorumu) . "' style='color:#900C3F;cursor:pointer;'>Düzeltilmeli</span>";
                                        break;
                                    case 5:
                                        echo "<span data-toggle='tooltip' data-placement='top' title='Sorunuz, soru havuzumuza başarıyla eklenmiştir. Teşekkür ederiz.' style='color:green;;cursor:pointer;'>Onaylandı</span>";
                                        break;
                                    default:
                                        echo "Eksik Bilgi";
                                }
                                ?>
                            </td>
                            <?php echo form_close(); ?>
                            <td>
                                <div class="btn-group btn-group-xs" role="group">
                                    <a href="<?php echo base_url(); ?>index.php/sorular/detail/<?php echo $item->dogrulama_kodu; ?>"
                                       class="btn btn-primary btn-xs"><i class="fa fa-eye"></i></a>
                                    <?php if ($item->duzenlenebilir == "1" && $item->onay_durumu == "1" || $item->duzenlenebilir == "1" && $item->onay_durumu == "4" || get_user_data('is_admin') == "1") { ?>
                                        <a href="<?php echo base_url(); ?>index.php/sorular/edit/<?php echo $item->dogrulama_kodu; ?>"
                                           class="btn btn-info btn-xs"><i class="fa fa-edit"></i></a>
                                    <?php } ?>
                                    <?php if ($item->onay_durumu == "1" || get_user_data('is_admin') == "1") { ?>
                                        <a href="javascript:void()"
                                           data-url="<?php echo base_url(); ?>index.php/sorular/delete/<?php echo $item->dogrulama_kodu; ?>"
                                           class="btn btn-danger btn-xs remove-btn"><i class="fa fa-trash"></i></a>
                                    <?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>