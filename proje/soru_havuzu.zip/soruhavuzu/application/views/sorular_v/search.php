<div class="row">
    <div class="col-md-12">
        <div class="m-b-lg">
            <b>Detaylı Soru Arama</b>
            <div class="btn-group pull-right" role="group">
                <a href="<?php echo base_url("index.php/sorular/index"); ?>"
                   class="btn btn-primary btn-sm">
                    <i class="fa fa-angle-left"></i> Geri Dön</a>&nbsp;
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="panel panel-default">
            <div class="panel-body">
                <?php echo form_open('sorular/search_result', 'class="form-inline" id="search-form"'); ?>
                <div class="form-group">
                    <label class="control-label">Soru Hazırlanacak Ders</label>
                    <select id="dersID" name="dersID" class="form-control" data-plugin="select2" style="width: 100%">
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($dersler as $ders) {
                            echo '<option value="' . $ders->id . '">' . $ders->adi . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Sınıf Düzeyi</label>
                    <select id="sinifDuzeyi" name="sinifDuzeyi" class="form-control" data-plugin="select2" style="width: 100%">
                        <option value="">Seçiniz...</option>
                        <?php
                        for ($i = 1; $i < 13; $i++) {
                            echo '<option value="' . $i . '">' . $i . '. Sınıf</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Zorluk Derecesi</label>
                    <select id="zorlukDerecesi" name="zorlukDerecesi" class="form-control" data-plugin="select2" style="width: 100%">
                        <option value="">Seçiniz...</option>
                        <option value="1">
                            Çok Kolay (1)
                        </option>
                        <option value="2">
                            Kolay (2)
                        </option>
                        <option value="3">
                            Orta (3)
                        </option>
                        <option value="4">
                            Zor (4)
                        </option>
                        <option value="5">
                            Çok Zor (5)
                        </option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Onay Durumu</label>
                    <select id="zorlukDerecesi" name="zorlukDerecesi" class="form-control" data-plugin="select2" style="width: 100%">
                        <option value="">Seçiniz...</option>
                        <option value="1">Aksiyon Bekleniyor</option>
                        <option value="2">Kontrol Ediliyor</option>
                        <option value="3">Reddedildi</option>
                        <option value="4">Düzeltilmeli</option>
                        <option value="5">Onaylandı</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Ünite</label>
                    <select id="uniteID" name="uniteID" class="form-control" data-plugin="select2" style="width: 100%">
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($uniteler as $unite) {
                            echo '<option value="' . $unite->id . '">' . $unite->unite_kodu . '-' . $unite->unite_icerik . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Konu/Alt Konu Alanı</label>
                    <select id="konuID" name="konuID" class="form-control" data-plugin="select2" style="width: 100%">
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($konular as $konu) {
                            echo '<option value="' . $konu->id . '">' . $konu->konu_kodu . '-' . $konu->konu_icerik . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Kazanım</label>
                    <select id="kazanimID" name="kazanimID" class="form-control" data-plugin="select2"
                            style="width: 100%">
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($kazanimlar as $kazanim) {
                            echo '<option value="' . $kazanim->id . '">' . $kazanim->kazanim_kodu . '-' . $kazanim->kazanim_icerik . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Detaylı Ara</button>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</div>
<div id="search_results_container">
</div>

