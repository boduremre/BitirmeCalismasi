<div class="row">
    <div class="col-md-12">
        <div class="m-b-lg">
            <b>Soru Düzenle ("<?php //print_r($item);
                echo trim($item->no); ?>" numaralı soru)</b>
            <div class="btn-group pull-right" role="group">
                <a href="<?php echo base_url("index.php/sorular/index"); ?>"
                   class="btn btn-primary btn-sm">
                    <i class="fa fa-angle-left"></i> Geri Dön</a> <a
                        href="<?php echo base_url("index.php/sorular/detail/") . $item->dogrulama_kodu; ?>"
                        class="btn btn-success btn-sm" target="_blank">
                    <i class="fa fa-eye"></i> Görüntüle</a>
            </div>
        </div>
    </div>
</div>
<?php echo form_open('sorular/update', 'name="frmSoruDuzenle"'); ?>
<input type="hidden" name="id" value="<?php echo $item->id; ?>"/>
<input type="hidden" name="dogrulama_kodu" value="<?php echo $item->dogrulama_kodu; ?>"/>
<input type="hidden" name="onay_durumu" value="<?php echo $item->onay_durumu; ?>"/>
<input type="hidden" name="onceki_uzman_yorumu" value="<?php echo strip_tags($item->uzman_yorumu); ?>"/>
<div class="row">
    <div class="col-md-8">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h5 class="panel-title">Madde Kökü, Seçenekler ve Doğru Cevap</h5>
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12 form-group">
                        <label class="control-label">Resim, Grafik, Tablo ve Madde Kökü (Soru)</label>
                        <textarea name="madde_koku" id="madde_koku" cols="30" rows="10" class="form-control ckeditor">
                        <?php echo $item->madde_koku; ?>
                        </textarea>
                    </div>
                    <div class="col-md-12 form-group">
                        <label class="control-label">Seçenekler (Şıklar)</label><br/>
                        <label class="control-label">A)</label>
                        <textarea name="cevap_a" id="cevap_a" required class="ckeditor"><?php echo $item->cevap_a; ?></textarea>
                        <label class="control-label">B)</label>
                        <textarea name="cevap_b" id="cevap_b" required class="ckeditor"><?php echo $item->cevap_b; ?></textarea>
                        <label class="control-label">C)</label>
                        <textarea name="cevap_c" id="cevap_c" required class="ckeditor"><?php echo $item->cevap_c; ?></textarea>
                        <label class="control-label">D)</label>
                        <textarea name="cevap_d" id="cevap_d" required class="ckeditor"><?php echo $item->cevap_d; ?></textarea>
                        <?php if ($item->sinifDuzeyi > 8) { ?>
                            <label class="control-label">E)</label>
                            <textarea name="cevap_e" id="cevap_e" required class="ckeditor"><?php echo $item->cevap_e; ?></textarea>
                        <?php } ?>
                    </div>
                    <div class="col-md-12 form-group">
                        <label class="control-label">Doğru Cevap</label>
                        <select id="dogru_cevap" name="dogru_cevap" class="form-control" data-plugin="select2"
                                style="width: 100% " required>
                            <option value="">Seçiniz...</option>
                            <option <?php echo $item->dogru_cevap == "A" ? "selected" : ""; ?> value="A">A</option>
                            <option <?php echo $item->dogru_cevap == "B" ? "selected" : ""; ?> value="B">B</option>
                            <option <?php echo $item->dogru_cevap == "C" ? "selected" : ""; ?> value="C">C</option>
                            <option <?php echo $item->dogru_cevap == "D" ? "selected" : ""; ?> value="D">D</option>
                            <option <?php echo $item->dogru_cevap == "E" ? "selected" : ""; ?> value="E">E</option>
                        </select>
                    </div>
                </div>

                <button class="btn btn-success pull-right" type="submit" formtarget="frmSoruDuzenle">Kaydet</button>
            </div>
        </div>

    </div>
    <div class="col-md-4">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h5 class="panel-title">Soru Bilgileri</h5>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <label class="control-label">Okul Türü</label>
                    <select id="okulTuru" name="okulTuru" class="form-control" data-plugin="select2" style="width: 100%"
                            required>
                        <option value="">Seçiniz...</option>
                        <option <?php echo $item->okulTuru == 1 ? "selected" : ""; ?> value="1">İlkokul</option>
                        <option <?php echo $item->okulTuru == 2 ? "selected" : ""; ?> value="2">Ortaokul</option>
                        <option <?php echo $item->okulTuru == 3 ? "selected" : ""; ?> value="3">Anadolu Lisesi</option>
                        <option <?php echo $item->okulTuru == 4 ? "selected" : ""; ?> value="4">Meslek Lisesi</option>
                        <option <?php echo $item->okulTuru == 5 ? "selected" : ""; ?> value="5">Proje Lisesi</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Soru Hazırlanacak Ders</label>
                    <select id="dersID" name="dersID" class="form-control" data-plugin="select2" style="width: 100%"
                            required>
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($dersler as $row) {
                            if ($row->id == $item->dersID)
                                echo '<option selected value="' . $row->id . '-' . $row->kisa_kod . '-' . $row->adi . '">' . $row->adi . '</option>';
                            else
                                echo '<option value="' . $row->id . '-' . $row->kisa_kod . '-' . $row->adi . '">' . $row->adi . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Sınıf Düzeyi</label>
                    <select id="sinifDuzeyi" name="sinifDuzeyi" class="form-control" data-plugin="select2"
                            style="width: 100% " required>
                        <option value="">Seçiniz...</option>
                        <option value="<?php echo $item->sinifDuzeyi; ?>" selected>
                            <?php echo $item->sinifDuzeyi; ?>. Sınıf
                        </option>
                        <?php
                        for ($i = 1; $i < 13; $i++) {
                            echo '<option value="' . $i . '">' . $i . '. Sınıf</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Zorluk Derecesi</label>
                    <select id="zorlukDerecesi" name="zorlukDerecesi" class="form-control" data-plugin="select2"
                            style="width: 100 % " required>
                        <option value="">Seçiniz...</option>
                        <option value="1" <?php if ($item->zorlukDerecesi == 1) echo 'selected="selected"'; ?>>Çok Kolay
                            (1)
                        </option>
                        <option value="2" <?php if ($item->zorlukDerecesi == 2) echo 'selected="selected"'; ?>>Kolay
                            (2)
                        </option>
                        <option value="3" <?php if ($item->zorlukDerecesi == 3) echo 'selected="selected"'; ?>>Orta
                            (3)
                        </option>
                        <option value="4" <?php if ($item->zorlukDerecesi == 4) echo 'selected="selected"'; ?>>Zor (4)
                        </option>
                        <option value="5" <?php if ($item->zorlukDerecesi == 5) echo 'selected="selected"'; ?>>Çok Zor
                            (5)
                        </option>
                    </select>
                </div>
            </div>
        </div>
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h5 class="panel-title">Kazanım Bilgileri</h5>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <label class="control-label">Ünite</label>
                    <select id="uniteID" name="uniteID" class="form-control" data-plugin="select2" style="width: 100%"
                            required>
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($uniteler as $unite) {
                            if ($unite->id == $item->uniteID)
                                echo '<option selected value="' . $unite->id . '">' . $unite->unite_kodu . '-' . $unite->unite_icerik . '</option>';
                            else
                                echo '<option value="' . $unite->id . '">' . $unite->unite_kodu . '-' . $unite->unite_icerik . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Konu/Alt Konu Alanı</label>
                    <select id="konuID" name="konuID" class="form-control" data-plugin="select2" style="width: 100%"
                            required>
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($konular as $konu) {
                            if ($konu->id == $item->konuID)
                                echo '<option selected value="' . $konu->id . '">' . $konu->konu_kodu . '-' . $konu->konu_icerik . '</option>';
                            else
                                echo '<option value="' . $konu->id . '">' . $konu->konu_kodu . '-' . $konu->konu_icerik . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Kazanım</label>
                    <select id="kazanimID" name="kazanimID" class="form-control" data-plugin="select2"
                            style="width: 100%"
                            required>
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($kazanimlar as $kazanim) {
                            if ($kazanim->id == $item->kazanimID)
                                echo '<option selected value="' . $kazanim->id . '">' . $kazanim->kazanim_kodu . '-' . $kazanim->kazanim_icerik . '</option>';
                            else
                                echo '<option value="' . $kazanim->id . '">' . $kazanim->kazanim_kodu . '-' . $kazanim->kazanim_icerik . '</option>';
                        }
                        ?>
                    </select>
                </div>
            </div>
        </div>
        <?php echo form_close(); ?>
        <?php if (get_user_data('roleID') == "1" || get_user_data('roleID') == 4) { ?>
            <?php echo form_open('sorular/soru_onay', 'name="frmSoruOnay"'); ?>
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h5 class="panel-title">Soru Onay</h5>
                </div>
                <div class="panel-body">
                    <input type="hidden" name="dogrulama_kodu" value="<?php echo $item->dogrulama_kodu; ?>"/>
                    <div class="form-group">
                        <label class="control-label">Onay Durumu</label>
                        <select id="onay_durumu" name="onay_durumu" class="form-control" data-plugin="select2"
                                style="width: 100%">
                            <option value="">Seçiniz...</option>
                            <option value="1" <?php if ($item->onay_durumu == '1') echo "selected"; ?>>Aksiyon
                                Bekleniyor
                            </option>
                            <option value="2" <?php if ($item->onay_durumu == '2') echo "selected"; ?>>Kontrol
                                Ediliyor
                            </option>
                            <option value="3" <?php if ($item->onay_durumu == '3') echo "selected"; ?>>Reddedildi
                            </option>
                            <option value="4" <?php if ($item->onay_durumu == '4') echo "selected"; ?>>Düzeltilmeli
                            </option>
                            <option value="5" <?php if ($item->onay_durumu == '5') echo "selected"; ?>>Onaylandı
                            </option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Düzeltme ve Red Nedenleri ile varsa yorumlarınızı Yazınız</label>
                        <textarea name="uzman_yorumu" class="m-0 ckeditor"><?php echo $item->uzman_yorumu; ?></textarea>
                    </div>
                </div>
                <div class="panel-footer">
                    <button class="btn btn-success right" type="submit" formtarget="frmSoruOnay">Kaydet</button>
                </div>
            </div>
            <?php echo form_close(); ?>
        <?php } else { ?>
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h5 class="panel-title">Soru Onay</h5>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <label class="control-label">Onay Durumu</label>
                    <select id="onay_durumu" name="onay_durumu" class="form-control" data-plugin="select2"
                            style="width: 100%" disabled>
                        <option value="">Seçiniz...</option>
                        <option value="1" <?php if ($item->onay_durumu == '1') echo "selected"; ?>>Aksiyon Bekleniyor
                        </option>
                        <option value="2" <?php if ($item->onay_durumu == '2') echo "selected"; ?>>Kontrol Ediliyor
                        </option>
                        <option value="3" <?php if ($item->onay_durumu == '3') echo "selected"; ?>>Reddedildi</option>
                        <option value="4" <?php if ($item->onay_durumu == '4') echo "selected"; ?>>Düzeltilmeli</option>
                        <option value="5" <?php if ($item->onay_durumu == '5') echo "selected"; ?>>Onaylandı</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-3">Düzeltme ve Red Nedenleri</label>
                    <textarea disabled name="uzman_yorumu" class="m-0 ckeditor"><?php echo $item->uzman_yorumu; ?></textarea>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>