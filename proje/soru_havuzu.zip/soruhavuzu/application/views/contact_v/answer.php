<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            İletişim Mesajı Oku
            <?php if ($this->session->userdata("is_admin") == "1") { ?>
                <a href="<?php echo base_url("index.php/contact/index"); ?>"
                   class="btn btn-outline btn-primary btn-sm pull-right">
                    <i class="fa fa-angle-left"></i> Geri Dön</a>
            <?php } else { ?>
                <a href="<?php echo base_url("index.php/contact/index"); ?>"
                   class="btn btn-outline btn-primary btn-sm pull-right">
                    <i class="fa fa-angle-left"></i> Geri Dön</a>
            <?php } ?>
        </h4>
    </div>

</div>
<div class="row">
    <div class="col-lg-12">
        <div class="table-responsive">
            <table class="table mail-list">
                <tbody>
                <tr>
                    <td>
                        <div class="mail-item">
                            <table class="mail-container">
                                <tbody>
                                <tr>
                                    <td class="mail-left">
                                        <div class="avatar avatar-lg avatar-circle">
                                            <a href="javascript:void()">
                                                <img src="<?php echo base_url(); ?>assets/images/user_icon_circle.png"/>
                                            </a>
                                            <p style="text-align: center; font-size: small">
                                                <?php echo $item->name . ' ' . $item->surname; ?>
                                            </p>
                                        </div>
                                    </td>
                                    <td class="mail-center">
                                        <div class="mail-item-header">
                                            <h4 class="mail-item-title">
                                                <a href="javascript:void()" class="title-color">
                                                    <?php echo $item->baslik; ?>
                                                </a>
                                            </h4>
                                            <a href="javascript:void()">
                                                <?php
                                                if ($item->konu == 1)
                                                    echo '<span class="label label-warning">Öneri</span>';
                                                if ($item->konu == 2)
                                                    echo '<span class="label label-danger">Şikayet</span>';
                                                if ($item->konu == 3)
                                                    echo '<span class="label label-info">Bilgi Edinme</span>';
                                                if ($item->konu == 4)
                                                    echo '<span class="label label-success">Teşekkür</span>';
                                                if ($item->konu == 5)
                                                    echo '<span class="badge badge-warning">Diğer</span>';
                                                ?>
                                            </a>
                                        </div>
                                        <p class="mail-item-excerpt"><?php echo $item->mesaj; ?></p>
                                    </td>
                                    <td class="mail-right" style="width: 200px !important;padding-left:80px;">
                                        <p class="mail-item-date">
                                            <?php echo date("d.m.Y H:i:s", strtotime($item->kayit_tarihi)); ?>
                                        </p>
                                        <?php if ($this->session->userdata("is_admin") == "1") { ?>
                                            <p class="mail-item-star starred">
                                                <a href="#">
                                                    <i class="zmdi zmdi-star"></i>
                                                </a>
                                            </p>
                                        <?php } ?>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <?php if ($item->cevaplanma_durumu == 1) { ?>
                            <div class="mail-item">
                                <table class="mail-container">
                                    <tbody>
                                    <tr>
                                        <td class="mail-left">
                                            <div class="avatar avatar-lg avatar-circle">
                                                <a href="javascript:void()">
                                                    <img src="<?php echo base_url(); ?>assets/images/206.jpg"/>
                                                </a>
                                                <p style="text-align: center; font-size: small">
                                                    Yönetici
                                                </p>
                                            </div>
                                        </td>
                                        <td class="mail-center">
                                            <div class="mail-item-header">
                                                <h4 class="mail-item-title">
                                                    <a href="javascript:void()" class="title-color">
                                                        <?php echo $item->baslik ?>
                                                    </a>
                                                </h4>
                                                <a href="#"><span class="label label-success">CEVAP</span></a>
                                            </div>
                                            <p class="mail-item-excerpt">
                                                <?php echo $item->cevap_mesaji ?>
                                            </p>
                                        </td>
                                        <td class="mail-right" style="width: 200px !important;padding-left:80px;">
                                            <p class="mail-item-date">
                                                <?php echo date("d.m.Y H:i:s", strtotime($item->cevap_tarihi)); ?>
                                            </p>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        <?php } ?>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php if ($this->session->userdata("roleID") == "1") { ?>
    <?php if ($item->cevaplanma_durumu != 1) { ?>
        <div class="row" id="message-row">
            <div class="col-md-12">
                <div class="panel panel-custom panel-default">
                    <div class="panel-body">
                        <?php echo form_open('contact/answer_save'); ?>
                        <div class="form-group">
                            <label for="maxlength-demo-3">Mesaj</label>
                            <textarea class="form-control m-0 ckeditor" name="icerik" id="cevap_mesaji"></textarea>
                        </div>
                        <div class="form-group">
                            <input type="hidden" id="message_id" name="id" value="<?php echo $item->id; ?>"/>
                            <input type="submit" id="submit_button" name="submit" class="btn btn-primary pull-right"/>
                        </div>
                        <?php echo form_close(); ?>
                    </div><!-- .widget-body -->
                </div><!-- .widget -->
            </div>
            <!-- END column -->
        </div>
    <?php }
} ?>