<div class="wrap p-t-0">
    <footer class="app-footer">
        <div class="clearfix">
            <div class="copyright pull-left">Copyright &copy; <?php echo date("Y"); ?> Tüm hakları saklıdır. | Düzce Ölçme Değerlendirme Merkezi</div>
        </div>
    </footer>
</div>
