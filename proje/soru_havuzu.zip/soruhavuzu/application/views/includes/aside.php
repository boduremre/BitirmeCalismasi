<aside id="menubar" class="menubar light">
    <div class="app-user">
        <div class="media">
            <div class="media-left">
                <div class="avatar avatar-md avatar-circle">
                    <a href="javascript:void(0)">
                        <img class="img-responsive" src="<?php echo base_url("assets"); ?>/images/user_icon_circle.png"/>
                    </a>
                </div><!-- .avatar -->
            </div>
            <div class="media-body">
                <div class="foldable">
                    <h5><a href="javascript:void(0)"
                           class="username"><?php echo $this->session->userdata('name') . ' ' . $this->session->userdata('surname'); ?></a>
                    </h5>
                    <ul>
                        <li class="dropdown">
                            <a href="javascript:void(0)" class="dropdown-toggle usertitle" data-toggle="dropdown"
                               aria-haspopup="true" aria-expanded="false">
                                <small>(<?php echo $this->session->userdata('username'); ?>)</small>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu animated flipInY">
                                <li>
                                    <a class="text-color" href="<?php echo base_url(); ?>index.php/profile">
                                        <span class="m-r-xs"><i class="fa fa-user"></i></span>
                                        <span>Profil Bilgileri</span>
                                    </a>
                                </li>
                                <!--                                <li>-->
                                <!--                                    <a class="text-color" href="-->
                                <?php //echo base_url(); 
                                ?>
                                <!--index.php/dashboard/settings">-->
                                <!--                                        <span class="m-r-xs"><i class="fa fa-gear"></i></span>-->
                                <!--                                        <span>Ayarlar</span>-->
                                <!--                                    </a>-->
                                <!--                                </li>-->
                                <!--<li role="separator" class="divider"></li>
                                <li>
                                    <a class="text-color" href="<?php /*echo  base_url(); */ ?>login/logout">
                                        <span class="m-r-xs"><i class="fa fa-power-off"></i></span>
                                        <span>Güvenli Çıkış</span>
                                    </a>
                                </li>-->
                            </ul>
                        </li>
                    </ul>
                </div>
            </div><!-- .media-body -->
        </div><!-- .media -->
    </div><!-- .app-user -->

    <div class="menubar-scroll">
        <div class="menubar-scroll-inner">
            <ul class="app-menu">
                <li class='<?php echo $menuAktif == "Anasayfa" ? "active" : ""; ?>'>
                    <a href="<?php echo base_url(); ?>index.php">
                        <i class="menu-icon zmdi zmdi-view-dashboard zmdi-hc-lg"></i>
                        <span class="menu-text">Anasayfa</span>
                    </a>
                </li>
                <?php if ($this->session->userdata("roleID") == 1 || $this->session->userdata('username') == 'admin') { ?>

                    <li class="<?php echo $menuAktif == 'Duyuru' ? 'active' : ''; ?>">
                        <a href="<?php echo base_url(); ?>index.php/notify/index">
                            <i class="menu-icon zmdi zmdi-notifications zmdi-hc-lg"></i>
                            <span class="menu-text">Duyurular Modülü</span>
                        </a>
                    </li>

                    <li class="has-submenu <?php echo $menuAktif == 'Kullanıcı' ? 'active' : ''; ?>">
                        <a href="javascript:void(0)" class="submenu-toggle">
                            <i class="menu-icon zmdi zmdi-accounts zmdi-hc-lg"></i>
                            <span class="menu-text">Kullanıcı Modülü</span>
                            <i class="menu-caret zmdi zmdi-hc-sm zmdi-chevron-right"></i>
                        </a>
                        <ul class="submenu" <?php echo $menuAktif == 'Kullanıcı' ? 'style="display: block;"' : ''; ?>>
                            <li class="<?php echo @$subMenuAktif == 'users' ? 'active' : ''; ?>"><a
                                        href="<?php echo base_url(); ?>index.php/users/index"><span class="menu-text">Kullanıcılar</span></a>
                            </li>
                            <li class="<?php echo @$subMenuAktif == 'user_add' ? 'active' : ''; ?>"><a
                                        href="<?php echo base_url(); ?>index.php/users/add"><span class="menu-text">Kullanıcı Ekle</span></a>
                            </li>
                            <li class="<?php echo @$subMenuAktif == 'roles' ? 'active' : ''; ?>"><a
                                        href="<?php echo base_url(); ?>index.php/users/roles"><span class="menu-text">Roller</span></a>
                            </li>
                            <li class="<?php echo @$subMenuAktif == 'role_add' ? 'active' : ''; ?>"><a
                                        href="<?php echo base_url(); ?>index.php/users/role_add"><span class="menu-text">Rol Ekle</span></a>
                            </li>
                        </ul>
                    </li>
                <?php } ?>
                <li class="<?php echo $menuAktif == 'Iletisim' ? 'active' : ''; ?>">
                    <a href="<?php echo base_url(); ?>index.php/contact/index">
                        <i class="menu-icon zmdi zmdi-book zmdi-hc-lg"></i>
                        <span class="menu-text">Destek Merkezi</span>
                    </a>
                </li>
                <li class="menu-separator">
                    <hr>
                </li>
                <li class="<?php echo $menuAktif == 'SoruHavuzu' ? 'active' : ''; ?>">
                    <a href="<?php echo base_url(); ?>index.php/sorular/index">
                        <i class="menu-icon zmdi zmdi-accounts zmdi-hc-lg"></i>
                        <span class="menu-text">Soru Havuzu</span>

                    </a>
                </li>
                <li class="menu-separator">
                    <hr>
                </li>
                <li class="<?php echo $menuAktif == 'Yardim' ? 'active' : ''; ?>">
                    <a href="<?php echo base_url(); ?>index.php/dashboard/help">
                        <i class="menu-icon zmdi zmdi-help-outline zmdi-hc-lg"></i>
                        <span class="menu-text">Yardım</span>
                    </a>
                </li>
                <?php if ($this->session->userdata("roleID") == 1 || $this->session->userdata('username') == 'admin') { ?>
                    <li class="<?php echo $menuAktif == 'Ayarlar' ? 'active' : ''; ?>">
                        <a href="<?php echo base_url(); ?>index.php/settings">
                            <i class="menu-icon zmdi zmdi-settings zmdi-hc-lg"></i>
                            <span class="menu-text">Ayarlar</span>
                        </a>
                    </li>
                <?php } ?>
                <li>
                    <a href="javascript:void()" data-url="<?php echo base_url(); ?>index.php/login/logout" class="logout-btn">
                        <i class="menu-icon zmdi zmdi-power-off zmdi-hc-lg"></i>
                        <span class="menu-text">Güvenli Çıkış</span>
                    </a>
                </li>
            </ul><!-- .app-menu -->
        </div><!-- .menubar-scroll-inner -->
    </div><!-- .menubar-scroll -->
</aside>