<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/material-design-iconic-font/dist/css/material-design-iconic-font.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/animate.css/animate.min.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/fullcalendar/dist/fullcalendar.min.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/perfect-scrollbar/css/perfect-scrollbar.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/css/bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/css/core.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/css/app.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/iziToast/dist/css/iziToast.min.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/sweetalert2/sweetalert2.min.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/datatables/jquery.dataTables.min.css">
<script src="<?php echo base_url("assets"); ?>/libs/breakpoints.js/dist/breakpoints.min.js"></script>
<script>
    Breakpoints();
</script>
</style>