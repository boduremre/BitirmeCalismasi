<!-- build:js /assets/js/core.min.js -->
<script src="<?php echo base_url("assets"); ?>/libs/jquery/dist/jquery.js"></script>
<script src="<?php echo base_url("assets"); ?>/libs/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url("assets"); ?>/libs/jQuery-Storage-API/jquery.storageapi.min.js"></script>
<script src="<?php echo base_url("assets"); ?>/libs/bootstrap-sass/assets/javascripts/bootstrap.js"></script>
<script src="<?php echo base_url("assets"); ?>/libs/jquery-slimscroll/jquery.slimscroll.js"></script>
<script src="<?php echo base_url("assets"); ?>/libs/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
<script src="<?php echo base_url("assets"); ?>/libs//PACE/pace.min.js"></script>
<script src="<?php echo base_url("assets"); ?>/js/app.js"></script>
<script src="<?php echo base_url("assets"); ?>/libs/moment/moment.js"></script>
<script src="<?php echo base_url("assets"); ?>/libs/fullcalendar/dist/fullcalendar.min.js"></script>
<script src='<?php echo base_url("assets"); ?>/libs/fullcalendar/dist/lang-all.js'></script>
<script src="<?php echo base_url("assets"); ?>/js/fullcalendar.js"></script>
<script src='<?php echo base_url("assets"); ?>/libs/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js'></script>
<script src='<?php echo base_url("assets"); ?>/libs/bootstrap-datetimepicker/js/locales/bootstrap-datetimepicker.tr.js'></script>
<script src='<?php echo base_url("assets"); ?>/libs/iziToast/dist/js/iziToast.min.js'></script>
<script src='<?php echo base_url("assets"); ?>/libs/sweetalert2/sweetalert2.min.js'></script>
<script src='<?php echo base_url("assets"); ?>/libs/ckeditor/ckeditor.js'></script>
<script src='<?php echo base_url("assets"); ?>/libs/ckeditor/lang/tr.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML"></script>
<script src='<?php echo base_url("assets"); ?>/js/jquery.inputmask.min.js'></script>
<script src='<?php echo base_url("assets"); ?>/libs/datatables/jquery.dataTables.min.js'></script>
<script src="<?php echo base_url("assets"); ?>/js/custom.js"></script>
<?php $this->load->view("includes/alert"); ?>

