<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Duyuru Detay ("<?php echo trim($item->baslik); ?>" başlıklı haber)
            <a href="<?php echo base_url("index.php/notify/index"); ?>"
               class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-angle-left"></i> Geri Dön</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-custom panel-primary">
            <div class="panel-body">
                <p><b>Başlık :</b> <?php echo $item->baslik; ?></p>
                <p><b>Özet :</b> <?php echo $item->ozet; ?></p>
                <p><b>İçerik :</b><br> <?php echo $item->icerik; ?></p>
                <p><b>Kayıt Tarihi :</b> <?php echo $item->kayit_tarihi; ?></p>
                <p><b>Güncelleme Tarihi :</b> <?php echo $item->guncelleme_tarihi; ?></p>
                <p><b>Anahtar Kelimeler :</b> <?php
                    $keywords = explode(',', $item->anahtar_kelimeler);
                    foreach ($keywords as $keyword) {
                        echo '<span class="badge badge-primary">' . $keyword . '</span>&nbsp;';
                    }
                    ?></p>
                <p><b>Aktif :</b> <input id="isActive" type="checkbox"
                                  data-switchery <?php echo ($item->aktif == 1) ? 'checked' : ''; ?> name="aktif" readonly/></p>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div>
</div>