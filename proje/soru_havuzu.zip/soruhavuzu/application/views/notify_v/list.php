<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Duyurular Listesi
            <a href="<?php echo base_url("index.php/notify/add"); ?>"
               class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-plus"></i> Yeni Duyuru Ekle</a>
        </h4>
    </div>
    <div class="col-sm-12 col-md-12">
        <div class="panel panel-custom panel-default">
            <div class="panel-body">
                <table class="table table-striped datatable" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>#ID</th>
                        <th>Başlık</th>
                        <th>Özet</th>
<!--                        <th>İçerik</th>-->
                        <th>Anahtar Kelimeler</th>
                        <th>Aktif</th>
                        <th>Kayıt Tarihi</th>
                        <th>Güncelleme Tarihi</th>
                        <th>İşlemler</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($items as $item) { ?>
                        <tr>
                            <td>#<?php echo $item->id; ?></td>
                            <td><?php echo $item->baslik; ?></td>
                            <td><?php echo $item->ozet; ?></td>
<!--                            <td>-->
<!--                                --><?php //echo substr($item->icerik, 0, 250); ?>
<!--                                <a href="javascript:;"-->
<!--                                   data-toggle="tooltip"-->
<!--                                   data-placement="bottom"-->
<!--                                   title="--><?php //echo $item->icerik; ?><!--">devamı...</a>-->
<!--                            </td>-->
                            <td>
                                <?php
                                $keywords = explode(',', $item->anahtar_kelimeler);
                                foreach ($keywords as $keyword) {
                                    echo '<span class="badge badge-primary">' . $keyword . '</span>&nbsp;';
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                if ($item->aktif == 1) {
                                    echo '<input class="isActive" data-url="" id="switch-0-\' . $item->id . \'" type="checkbox" data-switchery data-size="small" checked/>';
                                } else {
                                    echo '<input id="switch-0-' . $item->id . '" type="checkbox" data-switchery data-size="small"/>';
                                } ?>

                            </td>
                            <td><?php echo date("d.m.Y H:i:s", strtotime($item->kayit_tarihi)); ?></td>
                            <td>
                                <?php echo date("d.m.Y H:i:s", strtotime($item->guncelleme_tarihi)); ?>
                            </td>
                            <td>
                                <div class="btn-group btn-group-xs" role="group">
                                    <a href="<?php echo base_url(); ?>index.php/notify/detail/<?php echo $item->id; ?>"
                                       class="btn btn-primary btn-xs"><i class="fa fa-eye"></i></a>
                                    <a href="<?php echo base_url(); ?>index.php/notify/edit/<?php echo $item->id; ?>"
                                       class="btn btn-info btn-xs"><i class="fa fa-edit"></i></a>
                                    <a href="javascript:void()" data-url="<?php echo base_url(); ?>index.php/notify/delete/<?php echo $item->id; ?>"
                                       class="btn btn-danger btn-xs remove-btn"><i class="fa fa-trash"></i></a>
                                </div>

                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>