﻿<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sorular extends CI_Controller
{
    public $user_id;
    public $role_id;
    public $is_admin;

    public function __construct()
    {
        parent::__construct();

        if (!get_logged_user())
            redirect(base_url("index.php/login"));

        $this->user_id = $this->session->userdata("id");
        $this->role_id = $this->session->userdata("roleID");
        $this->is_admin = $this->session->userdata("is_admin");

        $this->load->model("sorular_model");
        $this->load->model("user_model");
        $this->load->model("dersler_model");
        $this->load->model("unite_model");
        $this->load->model("konu_model");
        $this->load->model("kazanim_model");
    }

    public function index()
    {
        $viewData = new stdClass();
        $viewData->title = 'Soru Havuzu';
        $viewData->viewFolder = 'sorular_v';
        $viewData->menuAktif = 'SoruHavuzu';

        // Giriş yapan kullanıcı yönetici(roleID=1) veya uzman(roleID=4) rolünde ise
        // tüm soru sayıları getirilir.
        // rolü yönetici(roleID=1) veya uzman(roleID=4) olmayan kullanıcılar
        // sadece kendi sorularını görebilirler.
        if ($this->role_id == 1 || $this->role_id == 4) {
            $viewData->subpage = 'list';
            $items = $this->sorular_model->get_all();
        } else {
            $viewData->subpage = 'list_ogretmen';
            $items = $this->sorular_model->get_all_byUserID(array('userID' => $this->user_id));
        }

        $viewData->items = $items;
        $viewData->user_id = $this->user_id;
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function add()
    {
        $viewData = new stdClass();
        $viewData->title = 'Soru Havuzu - Soru Ekle';
        $viewData->menuAktif = 'SoruHavuzu';
        $viewData->viewFolder = 'sorular_v';
        $viewData->subpage = 'add';
        $user = $this->user_model->get(array('users.id' => $this->user_id));
        $dersler = $this->dersler_model->get_all();
        $uniteler = $this->unite_model->get_all_w(array('dersID' => get_user_data('bransID')));
        $konular = $this->konu_model->get_all_w(array('dersID' => get_user_data('bransID')));
        $kazanimlar = $this->kazanim_model->get_all_w(array('dersID' => get_user_data('bransID')));
        $viewData->user = $user;
        $viewData->dersler = $dersler;
        $viewData->uniteler = $uniteler;
        $viewData->konular = $konular;
        $viewData->kazanimlar = $kazanimlar;
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function search()
    {
        $viewData = new stdClass();
        $viewData->title = 'Soru Havuzu - Soru Ara';
        $viewData->menuAktif = 'SoruHavuzu';
        $viewData->viewFolder = 'sorular_v';
        $viewData->subpage = 'search';
        $viewData->dersler = $this->dersler_model->get_all();
        $viewData->uniteler = $this->unite_model->get_all_w(array('dersID' => get_user_data('bransID')));
        $viewData->konular = $this->konu_model->get_all_w(array('dersID' => get_user_data('bransID')));
        $viewData->kazanimlar = $this->kazanim_model->get_all_w(array('dersID' => get_user_data('bransID')));
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function search_result()
    {
        $form_values = array(
            "sorular.dersID" => $this->input->post("dersID"),
            "sorular.sinifDuzeyi" => $this->input->post("sinifDuzeyi"),
            "sorular.zorlukDerecesi" => $this->input->post("zorlukDerecesi"),
            "sorular.onay_durumu" => $this->input->post("onay_durumu"),
            "sorular.uniteID" => $this->input->post("uniteID"),
            "sorular.konuID" => $this->input->post("konuID"),
            "sorular.kazanimID" => $this->input->post("kazanimID")
        );

        $search_results = $this->sorular_model->get_all_w($form_values);
        if ($search_results) {
            $viewData = new stdClass();
            $viewData->search_results = $search_results;

            $this->load->view("sorular_v/search_result", $viewData);
        }
    }

    public function save()
    {
        $soru_no = rand(100000, 999999);
        $soru_kodu = "21-" . $this->input->post("dersID") . '-' . $this->input->post("sinifDuzeyi") . '-' . $soru_no;

        if ($this->role_id == "1" || $this->role_id == "4")
            $onay_durumu = 5;
        else
            $onay_durumu = 1;

        $form_values = array(
            "userID" => $this->input->post("userID"),
            "dersID" => $this->input->post("dersID"),
            "no" => $soru_no,
            "kodu" => $soru_kodu,
            "sinifDuzeyi" => $this->input->post("sinifDuzeyi"),
            "zorlukDerecesi" => $this->input->post("zorlukDerecesi"),
            "uniteID" => $this->input->post("uniteID"),
            "konuID" => $this->input->post("konuID"),
            "kazanimID" => $this->input->post("kazanimID"),
            "madde_koku" => $this->input->post("madde_koku"),
            "cevap_a" => $this->input->post("cevap_a"),
            "cevap_b" => $this->input->post("cevap_b"),
            "cevap_c" => $this->input->post("cevap_c"),
            "cevap_d" => $this->input->post("cevap_d"),
            "dogru_cevap" => $this->input->post("dogru_cevap"),
            "dogrulama_kodu" => strtolower(GUID()),
            "okulTuru" => $this->input->post("okulTuru"),
            "onay_durumu" => $onay_durumu,
            "yazar_kabul_durumu" => $this->input->post("yazar_kabul_durumu")
        );

        //print_r($form_values); die();

        $insert = $this->sorular_model->add($form_values);
        if ($insert) {
            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Soru Başarıyla Eklendi.",
                "type" => "success"
            );
        } else {
            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Soru Eklenemedi!",
                "type" => "error"
            );
        }

        // İşlemin Sonucunu Session'a yazma işlemi...
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('index.php/sorular/index'));
    }

    public function edit($id)
    {
        $viewData = new stdClass();
        $item = $this->sorular_model->get(array('dogrulama_kodu' => $id));

        if ($item->duzenlenebilir == "1") {
            $viewData->title = 'Soru Havuzu - Soru Düzenle';
            $viewData->viewFolder = 'sorular_v';
            $viewData->menuAktif = 'SoruHavuzu';
            $viewData->item = $item;
            $viewData->userIsAdmin = $this->is_admin;
            $viewData->subpage = 'edit';
            $user = $this->user_model->get(array('users.id' => $this->user_id));
            $dersler = $this->dersler_model->get_all();
            $uniteler = $this->unite_model->get_all_w(array('dersID' => get_user_data('bransID')));
            $konular = $this->konu_model->get_all_w(array('dersID' => get_user_data('bransID')));
            $kazanimlar = $this->kazanim_model->get_all_w(array('dersID' => get_user_data('bransID')));
            $viewData->user = $user;
            $viewData->dersler = $dersler;
            $viewData->uniteler = $uniteler;
            $viewData->konular = $konular;
            $viewData->kazanimlar = $kazanimlar;
            $this->load->view("{$viewData->viewFolder}/index", $viewData);
        } else {
            redirect(base_url('index.php/sorular/index'));
        }
    }

    public function detail($id)
    {
        $viewData = new stdClass();
        $item = $this->sorular_model->get(array('dogrulama_kodu' => $id));
        $onaylayanUser = $this->user_model->get(array('users.id' => $item->onaylayanUserID));
        $viewData->title = 'Soru Havuzu - Soru Detay';
        $viewData->viewFolder = 'sorular_v';
        $viewData->menuAktif = 'SoruHavuzu';
        $viewData->item = $item;
        $viewData->onaylayanUser = $onaylayanUser;
        $viewData->subpage = 'read';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function toword($id)
    {
        $item = $this->sorular_model->get(array('dogrulama_kodu' => $id));

        header("Expires: 0");
        header('Content-Encoding: UTF-8');
        header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        header("Cache-Control:  must-revalidate, post-check=0, pre-check=0");
        header("Content-disposition: attachment; filename=soru-" . $item->dogrulama_kodu . ".doc");

        echo "Soru Kodu: " . $item->kodu . "\n";
        echo "Doğrulama Kodu: " . $item->dogrulama_kodu . "\n";
        echo "Kayıt Tarihi: " . $item->kayit_tarihi . "\n";
        echo "Onay Tarihi: " . $item->onaylama_tarihi . "\n\n\n";
        echo "Ünite: " . $item->unite_kodu . '-' . $item->unite_icerik . "\n";
        echo "Konu: " . $item->konu_kodu . '-' . $item->konu_icerik . "\n";
        echo "Kazanım: " . $item->kazanim_kodu . '-' . $item->kazanim_icerik . "\n";
        echo "\n\nSORU\n\n";
        echo strip_tags($item->madde_koku . "\n\n");
        echo strip_tags("A)" . $item->cevap_a . "\n");
        echo strip_tags("B)" . $item->cevap_b . "\n");
        echo strip_tags("C)" . $item->cevap_c . "\n");
        echo strip_tags("D)" . $item->cevap_d . "\n\n");
        echo strip_tags("Doğru Cevap:" . $item->dogru_cevap . "\n");
        echo "\n\n\n\n\n\n";
        echo "Düzce İl Milli Eğitim Müdürlüğü bünyesinde yürütülmekte olan sınavlarda kullanılmak üzere hazırlamış olduğum madde tamamıyla bana aittir. ";
        echo "Yukarıda yer alan maddenin herhangi bir kaynaktan alınmadığını ve üçüncü şahıslarla paylaşmayacağımı taahhüt ederim. Maddenin gerektiğinde düzeltmeye tabii tutulabileceğini kabul ederim.";
        echo "\n\n\n\n\n\n";
        echo date('d/m/Y');
        echo "\n\nİmza";
        echo "\n";
        echo $item->name . ' ' . $item->surname . "\n";
        echo $item->ders_adi . ' Öğretmeni';
        exit;
    }

    public function deleteConfirm($id)
    {
        $viewData = new stdClass();
        $item = $this->sorular_model->get(array('dogrulama_kodu' => $id));
        $viewData->title = 'Soru Havuzu - Soru Sil';
        $viewData->viewFolder = 'sorular_v';
        $viewData->menuAktif = 'SoruHavuzu';
        $viewData->item = $item;
        $viewData->subpage = 'delete';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function delete($dogrulama_kodu)
    {
        $delete = $this->sorular_model->delete(array('dogrulama_kodu' => $dogrulama_kodu));
        if ($delete) {
            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Soru Silindi.",
                "type" => "success"
            );
        } else {
            $alert = array(
                "title" => "İşlem Başarısız!",
                "text" => "Soru Silinemedi! Tekrar Deneyiniz!",
                "type" => "success"
            );
        }

        // İşlemin Sonucunu Session'a yazma işlemi...
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('index.php/sorular/index'));
    }

    public function update()
    {
        $ders = explode("-", $this->input->post("dersID"));
        $sinifDuzeyi = $this->input->post("sinifDuzeyi");

        $form_values = array(
            "dersID" => $this->input->post("dersID"),
            "sinifDuzeyi" => $this->input->post("sinifDuzeyi"),
            "zorlukDerecesi" => $this->input->post("zorlukDerecesi"),
            "uniteID" => $this->input->post("uniteID"),
            "konuID" => $this->input->post("konuID"),
            "kazanimID" => $this->input->post("kazanimID"),
            "madde_koku" => $this->input->post("madde_koku"),
            "cevap_a" => $this->input->post("cevap_a"),
            "cevap_b" => $this->input->post("cevap_b"),
            "cevap_c" => $this->input->post("cevap_c"),
            "cevap_d" => $this->input->post("cevap_d"),
            "dogru_cevap" => $this->input->post("dogru_cevap"),
            "okulTuru" => $this->input->post("okulTuru"),
            "onay_durumu" => 1,
            "yazar_kabul_durumu" => $this->input->post("yazar_kabul_durumu")
        );

        //print_r($form_values);        

        $update = $this->sorular_model->update($this->input->post("dogrulama_kodu"), $form_values);
        if ($update)
            redirect(base_url('index.php/sorular/index'));
    }

    public function soru_onay()
    {
        $form_values = array(
            "onay_durumu" => $this->input->post("onay_durumu"),
            "uzman_yorumu" => $this->input->post("uzman_yorumu"),
            "onaylayanUserID" => $this->session->userdata('id'),
            "onaylama_tarihi" => date('Y-m-d H:i:s')
        );

        //print_r($form_values);

        $update = $this->sorular_model->update($this->input->post("dogrulama_kodu"), $form_values);
        if ($update) {
            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Soru Onaylandı",
                "type" => "success"
            );

            // İşlemin Sonucunu Session'a yazma işlemi...
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('index.php/sorular/index'));
        }
    }
}
