<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Users extends CI_Controller
{
    public $user_id;

    public function __construct()
    {
        parent::__construct();
        if (!get_logged_user())
            redirect(base_url("index.php/login"));

        $this->user_id = $this->session->userdata("id");
        $this->load->model("user_model");
        $this->load->model("roles_model");
        $this->load->model("dersler_model");
    }

    public function index()
    {
        $viewData = new stdClass();
        $items = $this->user_model->get_all();
        $viewData->items = $items;
        $viewData->title = 'Kullanıcılar Modülü';
        $viewData->menuAktif = 'Kullanıcı';
        $viewData->subMenuAktif = 'users';
        $viewData->viewFolder = 'users_v';
        $viewData->subpage = 'list';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function add()
    {
        $this->load->model("okullar_model");

        $viewData = new stdClass();
        $viewData->title = 'Kullanıcılar Modülü';
        $viewData->menuAktif = 'Kullanıcı';
        $viewData->subMenuAktif = 'user_add';
        $viewData->viewFolder = 'users_v';
        $viewData->subpage = 'add';
        $viewData->dersler = $this->dersler_model->get_all(array('sinif<' => 9));;
        $viewData->okullar = $this->okullar_model->getForHtmlSelect();
        $viewData->roller = $this->roles_model->get_all();
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function save()
    {
        // Kaydedilmek istenen kullanıcıya ait bilgiler sistemde mevcut ise kaydetme
        // email, username, telefon gibi alanlar benzersizdir. 
        // Bu alanlar tek bir kullanıcıya aittir.
        $this->form_validation->set_rules('username', 'username field label', 'trim|required|xss_clean|is_unique[users.username]');
        $this->form_validation->set_rules('email', 'email field label', 'trim|required|xss_clean|is_unique[users.email]');
        $this->form_validation->set_rules('tel', 'tel field label', 'trim|required|xss_clean|is_unique[users.tel]');
        if ($this->form_validation->run() === FALSE) {
            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Kullanıcı Eklenemedi! Eklenmek istenen kullanıcı sistemde tanımlı!",
                "type"  => "error"
            );

            // İşlemin Sonucunu Session'a yazma işlemi...
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('index.php/users/index'));
        }

        $formValues = array(
            "username" => $this->input->post("username"),
            "name" => $this->input->post("name"),
            "surname" => $this->input->post("surname"),
            "email" => $this->input->post("email"),
            "password" => $this->input->post("password"),
            "md5_password" => md5($this->input->post("password")),
            "bransID" => $this->input->post("bransID"),
            "kurum_kodu" => $this->input->post("kurum_kodu"),
            "isAdmin" => $this->input->post("admin_role") == 'on' ? 1 : 0,
            "address" => $this->input->post("address")
        );

        $insert = $this->user_model->addThenGetID($formValues);
        if ($insert > 0) {
            $this->load->model("userroles_model");
            $roleId = $this->input->post("roleId");
            $userId = $insert;

            $insert_user_role = $this->userroles_model->add(
                array(
                    "UserId" => $userId,
                    "RoleId" => $roleId
                )
            );

            if ($insert_user_role) {
                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Kullanıcı Başarıyla Eklendi. Rol Tanımlandı.",
                    "type"  => "success"
                );
            } else {
                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Kullanıcı Başarıyla Eklendi. Rol Tanımlanamadı.",
                    "type"  => "warning"
                );
            }
        } else {
            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Kullanıcı Eklenemedi!",
                "type"  => "error"
            );
        }

        // İşlemin Sonucunu Session'a yazma işlemi...
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('index.php/users/index'));
    }

    public function detail($id)
    {
        $viewData = new stdClass();
        $item = $this->user_model->get(array('users.id' => $id));
        $viewData->title = 'Kullanıcı';
        $viewData->viewFolder = 'users_v';
        $viewData->menuAktif = 'Kullanıcı';
        $viewData->subMenuAktif = 'users';
        $viewData->subpage = 'detail';
        $viewData->item = $item;
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function deleteConfirm($id)
    {
        $viewData = new stdClass();
        $item = $this->user_model->get(array('id' => $id));
        $viewData->title = 'Kullanıcılar Modülü';
        $viewData->viewFolder = 'users_v';
        $viewData->menuAktif = 'Kullanıcı';
        $viewData->item = $item;
        $viewData->subpage = 'delete';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function delete($id)
    {
        $delete = $this->user_model->delete(array('id' => $id));
        if ($delete)
            redirect(base_url('index.php/users/index'));
    }

    public function roles()
    {
        $viewData = new stdClass();
        $roles = $this->roles_model->get_all();
        $viewData->roles = $roles;
        $viewData->title = 'Roller Modülü';
        $viewData->menuAktif = 'Kullanıcı';
        $viewData->subMenuAktif = 'roles';
        $viewData->viewFolder = 'users_v';
        $viewData->subpage = 'roles_list';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function roleadd()
    {
        $viewData = new stdClass();
        $viewData->title = 'Roller Modülü';
        $viewData->menuAktif = 'Kullanıcı';
        $viewData->viewFolder = 'users_v';
        $viewData->subpage = 'roles_add';
        $viewData->subMenuAktif = 'role_add';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function rolesave()
    {
        $this->form_validation->set_rules('name', 'value1 field label', 'trim|required|xss_clean|is_unique[roles.name]');
        if ($this->form_validation->run() === FALSE) {
            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Rol Eklenemedi! Eklenmek istenen rol daha önce tanımlanmış.",
                "type"  => "error"
            );

            // İşlemin Sonucunu Session'a yazma işlemi...
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('index.php/users/roleadd'));
        }

        $insert = $this->roles_model->add(
            array(
                "name" => $this->input->post("name"),
                "description" => $this->input->post("description")
            )
        );

        if ($insert > 0) {
            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Rol Başarıyla Eklendi.",
                "type"  => "success"
            );
        } else {
            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Rol Eklenemedi!",
                "type"  => "error"
            );
        }

        // İşlemin Sonucunu Session'a yazma işlemi...
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('index.php/users/roles'));
    }

    public function role_delete_confirm($id)
    {
        $item = $this->roles_model->get(array('id' => $id));

        // Eğer silinmek istenen rol temel rol ise silinmesini engelliyoruz.
        // Değilse silme onay sayfasına yönlendiriyoruz.
        if ($item->base_role == 1) {
            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Temel Rol Silinemez!",
                "type"  => "error"
            );

            // İşlemin Sonucunu Session'a yazma işlemi...
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('index.php/users/roles'));
        } else {
            $viewData = new stdClass();
            $viewData->title = 'Roller Modülü';
            $viewData->menuAktif = 'Kullanıcı';
            $viewData->viewFolder = 'users_v';
            $viewData->subpage = 'role_delete';
            $viewData->subMenuAktif = 'roles';
            $viewData->item = $item;
            $this->load->view("{$viewData->viewFolder}/index", $viewData);
        }
    }

    public function role_delete($id)
    {
        $delete = $this->roles_model->delete(array('id' => $id));
        if ($delete) {
            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Rol Başarıyla Silindi.",
                "type"  => "success"
            );
        } else {
            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Rol Silinemedi!",
                "type"  => "error"
            );
        }

        // İşlemin Sonucunu Session'a yazma işlemi...
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('index.php/users/roles'));
    }
}
