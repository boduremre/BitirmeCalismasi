<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public $user_id;
    public $role_id;

    public function __construct()
    {
        parent::__construct();
        if (!get_logged_user())
            redirect(base_url("index.php/login"));

        $this->user_id = $this->session->userdata("id");
        $this->role_id = $this->session->userdata("roleID");
    }

    public function index()
    {
        $viewData = new stdClass();
        $viewData->title = 'Anasayfa';
        $viewData->viewFolder = 'dashboard_v';
        $viewData->menuAktif = 'Anasayfa';
        $viewData->subpage = 'content';

        //veritabanı işlemleri
        $this->load->model("dashboard_model");
        $this->load->model("notify_model");

        // Giriş yapan kullanıcı yönetici veya uzman(roleID=4) rolünde ise
        // tüm soru sayıları getirilir.
        // rolü yönetici veya uzman(roleID=4) olmayan kullanıcılar
        // sadece kendi sorularını görebilirler.
        if ($this->role_id == 1 || $this->role_id == 4) {
            $viewData->totalSoru = $this->dashboard_model->getWhereCount(array(), "sorular");
            $viewData->totalBekleyenSoru = $this->dashboard_model->getWhereCount(array('onay_durumu !=' => 5), "sorular");
            $viewData->totalOnaylananSoru = $this->dashboard_model->getWhereCount(array('onay_durumu =' => 5), "sorular");
            $viewData->totalRedSoru = $this->dashboard_model->getWhereCount(array('onay_durumu =' => 3), "sorular");
        }else{
            $viewData->totalSoru = $this->dashboard_model->getWhereCount(array("userID" => $this->user_id), "sorular");
            $viewData->totalBekleyenSoru = $this->dashboard_model->getWhereCount(array('onay_durumu !=' => 5, "userID" => $this->user_id), "sorular");
            $viewData->totalOnaylananSoru = $this->dashboard_model->getWhereCount(array('onay_durumu =' => 5, "userID" => $this->user_id), "sorular");
            $viewData->totalRedSoru = $this->dashboard_model->getWhereCount(array('onay_durumu =' => 3, "userID" => $this->user_id), "sorular");
        }

        $viewData->loginLogs = $this->dashboard_model->getLoginLog($this->user_id);
        $viewData->notifies = $this->notify_model->get_all();
        $viewData->gizlilik_taahhut_onay = $this->session->userdata('gizlilik_taahhut_onay');

        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function help()
    {
        $viewData = new stdClass();
        $viewData->title = 'Yardım Modülü';
        $viewData->menuAktif = 'Yardim';
        $viewData->viewFolder = 'help_v';
        $viewData->subpage = 'content';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }
}
