<?php defined('BASEPATH') or exit('No direct script access allowed');

class Profile extends CI_Controller
{
    public $user_id;
    public $role_id;

    public function __construct()
    {
        parent::__construct();
        if (!get_logged_user())
            redirect(base_url("index.php/login"));

        $this->user_id = $this->session->userdata("id");
        $this->role_id = $this->session->userdata("roleID");
        $this->load->model("user_model");
        $this->load->model("dashboard_model");
    }

    public function index()
    {
        $viewData = new stdClass();
        $viewData->title = 'Profil Bilgileri';
        $viewData->menuAktif = 'Profil';
        $viewData->viewFolder = 'profile_v';
        $viewData->subpage = 'content';
        $viewData->loginLogs = $this->dashboard_model->getLoginLogAll($this->user_id);
        $viewData->user = $this->user_model->get_profile(array('users.id' => $this->user_id));
        $viewData->totalSoru = $this->dashboard_model->getWhereCount(array(), "sorular");
        $viewData->totalBekleyenSoru = $this->dashboard_model->getWhereCount(array('onay_durumu !=' => 5), "sorular");
        $viewData->totalOnaylananSoru = $this->dashboard_model->getWhereCount(array('onay_durumu =' => 5), "sorular");
        $viewData->totalRedSoru = $this->dashboard_model->getWhereCount(array('onay_durumu =' => 3), "sorular");
        $viewData->gizlilik_taahhut_onay = $this->session->userdata('gizlilik_taahhut_onay');

        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function update()
    {
        $update_date = $this->user_model->update(
            array('id' => $this->input->post("id")),
            array(
                "name" => $this->input->post("name"),
                "surname" => $this->input->post("surname"),
                "password" => $this->input->post("password"),
                "md5_password" => md5($this->input->post("password")),
                "email" => $this->input->post("email"),
                "tel" => $this->input->post("tel"),
                "address" => $this->input->post("address")
            )
        );

        $success_msg = "Profil bilgileriniz güncellendi!";
        $error_msg = "Profil bilgileriniz güncellenemedi!";
        RedirectWithMessage($update_date, $success_msg, $error_msg, 'index.php/profile');
    }

    public function update_gizlilik_taahhut()
    {
        $update_date = $this->user_model->update(
            array('id' => $this->input->post("id")),
            array(
                "gizlilik_taahhut_onay" => $this->input->post("gizlilik_taahhut_onay"),
                "gizlilik_taahhut_onay_tarihi" => date('Y-m-d H:i:s')
            )
        );

        $this->session->set_userdata('gizlilik_taahhut_onay', 1);

        $success_msg = "Kullanıcı Gizlilik Taahhütnamesini Kabul Ettiniz!";
        $error_msg = "İşlem esnasında hata meydana geldi!";
        RedirectWithMessage($update_date, $success_msg, $error_msg, 'index.php/profile');
    }
}
