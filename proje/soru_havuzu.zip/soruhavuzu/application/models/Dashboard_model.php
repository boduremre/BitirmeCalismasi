<?php

class Dashboard_model extends CI_Model
{
    //public $tableName = "iletisim";

    public function __construct()
    {
        parent::__construct();
    }

    public function getCount($tableName)
    {
        return $this->db->from($tableName)->count_all_results();
    }

    public function getWhereCount($where = array(), $tableName)
    {
        return $this->db->where($where)->from($tableName)->count_all_results();
    }

    public function getLoginLog($userID)
    {
        // $this->db->order_by("isActive","desc");
        $this->db->limit(5);
        $this->db->order_by("logDate", "desc");
        $this->db->where('userid', $userID);
        $this->db->where('status', 1);
        return $this->db->get("user_logins")->result();
    }

    public function getLoginLogAll($userID)
    {
        // $this->db->order_by("isActive","desc");
        //$this->db->limit(5);
        $this->db->order_by("logDate", "desc");
        $this->db->where('userid', $userID);
        $this->db->where('status', 1);
        return $this->db->get("user_logins")->result();
    }
}
