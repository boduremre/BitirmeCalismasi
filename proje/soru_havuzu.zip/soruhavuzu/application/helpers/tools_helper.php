<?php
function get_logged_user()
{
    $t = &get_instance();
    $user = $t->session->userdata("username");
    if ($user)
        return $user;
    else
        return false;
}

function get_user_data($data_name)
{
    $t = &get_instance();
    $user_data = $t->session->userdata($data_name);
    if ($user_data)
        return $user_data;
    else
        return false;
}

function get_user_role($roleID)
{
    $t = &get_instance();
    $t->load->model("roles_model");
    $user_role = $t->roles_model->get_role_name(array('roles.id' => $roleID));
    if ($user_role)
        return $user_role;
    else
        return "empty";
}

function RedirectWithMessage($control_val, $success_msg = "İşleminiz başarıyla gerçekleştirildi.",
                             $error_msg = "İşleminiz gerçekleştirilemedi!", $redirect_address = 'index.php/dashboard/index')
{
    if ($control_val) {
        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => $success_msg,
            "type" => "success"
        );
    } else {
        $alert = array(
            "title" => "İşlem Başarısız!",
            "text" => $error_msg,
            "type" => "error"
        );
    }

    // İşlemin Sonucunu Session'a yazma işlemi...
    $ci = &get_instance();
    $ci->session->set_flashdata("alert", $alert);
    redirect(base_url($redirect_address));
}

function RedirectWithDefaultMessage($control_val, $redirect_address = 'index.php/dashboard/index')
{
    if ($control_val) {
        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "İşleminiz başarıyla gerçekleştirildi.",
            "type" => "success"
        );
    } else {
        $alert = array(
            "title" => "İşlem Başarısız!",
            "text" => "İşleminiz gerçekleştirilemedi! Tekrar deneyiniz!",
            "type" => "error"
        );
    }

    // İşlemin Sonucunu Session'a yazma işlemi...
    $ci = &get_instance();
    $ci->session->set_flashdata("alert", $alert);

    // belirtilen adrese yönlendir
    redirect(base_url($redirect_address));
}

function turkishcharacters($string)
{
    $string = str_replace('&ccedil;', 'ç', $string);
    $string = str_replace('&yacute;', 'ı', $string);
    $string = str_replace('&Ccedil;', 'Ç', $string);
    $string = str_replace('&Ouml;', 'Ö', $string);
    $string = str_replace('&Yacute;', 'Ü', $string);
    $string = str_replace('&ETH;', 'Ğ', $string);
    $string = str_replace('&THORN;', 'Ş', $string);
    $string = str_replace('&Yacute;', 'İ', $string);
    $string = str_replace('&ouml;', 'ö', $string);
    $string = str_replace('&thorn;', 'ş', $string);
    $string = str_replace('&eth;', 'ğ', $string);
    $string = str_replace('&uuml;', 'ü', $string);
    $string = str_replace('&yacute;', 'ı', $string);
    $string = str_replace('&amp;', '&', $string);

    return $string;
}

function GUID()
{
    if (function_exists('com_create_guid') === true)
        return trim(com_create_guid(), '{}');

    return sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));
}

function replace_tr($text)
{
    $text = trim($text);
    $search = array('Ç', 'ç', 'Ğ', 'ğ', 'ı', 'İ', 'Ö', 'ö', 'Ş', 'ş', 'Ü', 'ü', ' ');
    $replace = array('c', 'c', 'g', 'g', 'i', 'i', 'o', 'o', 's', 's', 'u', 'u', '-');
    $new_text = str_replace($search, $replace, $text);
    return $new_text;
}

/*function is_logged_in()
{
    $is_logged_in = $this->session->userdata('is_logged_in');

    if (isset($is_logged_in) && $is_logged_in = TRUE) {
        redirect(base_url());
    }
}*/

function TurkceTarih($tarih)
{
    $ing_aylar = array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
    $tr_aylar = array("Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık");

    //$ing_gunler = array("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
    //$tr_gunler = array("Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar");

    $tarih = str_replace($ing_aylar, $tr_aylar, $tarih);
    //$tarih = str_replace($ing_gunler, $tr_gunler, $tarih);

    return $tarih;
}

function BakiyeHesapla($islem_tipi, $tutar)
{
    $bakiye = 0;
    if (empty($islem_tipi) || empty($tutar))
        return false;

    if ($islem_tipi == 1)
        $bakiye = $bakiye + $tutar;
    elseif ($islem_tipi == 2)
        $bakiye = $bakiye - $tutar;

    return $bakiye;
}

function showToast($islem, $redirectUrl)
{
    if ($islem) {
        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "İşlem başarılı şekilde gerçekleştirildi.",
            "type" => "success"
        );
    } else {
        $alert = array(
            "title" => "İşlem Başarısız",
            "text" => "İşlem sırasında bir problem oluştu!",
            "type" => "error"
        );
    }

    $t = &get_instance();
    $t->session->set_flashdata("alert", $alert);
    redirect(base_url($redirectUrl));
}

function getUserIP()
{
    // Get real visitor IP behind CloudFlare network
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
        $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote = $_SERVER['REMOTE_ADDR'];

    if (filter_var($client, FILTER_VALIDATE_IP)) {
        $ip = $client;
    } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
        $ip = $forward;
    } else {
        $ip = $remote;
    }

    return $ip;
}

?>