+function ($) {
    "use strict";
    $('.external-event').each(function () {
        $(this).data('event', {
            title: $.trim($(this).text()),
            className: [$(this).data('class')]
        });
    });

    $('.external-event').draggable({
        revert: true,
        revertDuration: 0
    });

    var cal = $('#fullcalendar').fullCalendar({
        theme: true,
        editable: false,
        droppable: false,
        firstDay: 1,
        height: 'auto',
        timezone:'local',
        lang: 'tr',
        buttonText: {
            today: 'Bugün',
            month: 'Aylık',
            week: 'week',
            day: 'gun',
            list: 'liste'
        }
    });

    $.fn.windowCheck = function () {
        var ww = $(window).width();
        if (ww > 768) {
            cal.fullCalendar('changeView', 'month');
        } else if (ww < 768 && ww > 540) {
            cal.fullCalendar('changeView', 'month'); //'basicWeek'
        } else {
            cal.fullCalendar('changeView', 'month'); //'basicDay'
        }
    };

    $(window).on('resize', function (e) {
        $().windowCheck();
    });

    $('.fc-prev-button').append('<i class="fa fa-chevron-left"><i>');
    $('.fc-next-button').append('<i class="fa fa-chevron-right"><i>');

    // add new event category
    $('#new_event_cat_form').on('submit', function (e) {
        e.preventDefault();

        var name = $(this).find('#category_name').val();
        var color = $(this).find('#category_color').val();
        var category = $('<div class="external-event"></div>');

        category.text(name);
        category.addClass(color);
        category.data('event', {
            title: name,
            className: [color]
        });

        category.draggable({
            revert: true,
            revertDuration: 0
        });

        $('#external-events').append(category);

        $('#new_event_cat_modal').modal('hide');
    });

    // add new event
    $('#new_event_form').on('submit', function (e) {
        e.preventDefault();

        var title = $(this).find('#event_title').val();
        var category = $(this).find('#event_category').val();
        var start = $(this).find('#event_start').val();

        cal.fullCalendar('addEventSource', [
            {
                title: title,
                start: start,
                className: [category]
            }
        ])
        $('#new_event_modal').modal('hide');
    });
}(jQuery);