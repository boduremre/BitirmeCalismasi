<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Soru Ekle
            <a href="<?php echo base_url("index.php/sorular/index"); ?>"
               class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-angle-left"></i> Geri Dön</a>

        </h4>
    </div>
</div>

<?php echo form_open('sorular/save'); ?>
<input type="hidden" value="<?php echo $user->id; ?>" id="userID" name="userID"/>
<div class="row">
    <div class="col-md-8">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h5 class="panel-title">Madde Kökü, Seçenekler ve Doğru Cevap</h5>
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12 form-group">
                        <label class="control-label">Resim, Grafik, Tablo ve Madde Kökü (Soru)</label>
                        <textarea name="madde_koku" id="madde_koku" cols="30" rows="10" class="form-control ckeditor">Deneme sorusudur?</textarea>
                    </div>
                    <div class="col-md-12 form-group">
                        <label class="control-label">Seçenekler (Şıklar)</label><br/>
                        <label class="control-label">A)</label>
                        <textarea name="cevap_a" id="cevap_a" required class="ckeditor">cevap_a</textarea>
                        <label class="control-label">B)</label>
                        <textarea name="cevap_b" id="cevap_b" required class="ckeditor">cevap_b</textarea>
                        <label class="control-label">C)</label>
                        <textarea name="cevap_c" id="cevap_c" required class="ckeditor">cevap_c</textarea>
                        <label class="control-label">D)</label>
                        <textarea name="cevap_d" id="cevap_d" required class="ckeditor">cevap_d</textarea>
                    </div>
                    <div class="col-md-12 form-group">
                        <label class="control-label">Doğru Cevap</label>
                        <select id="dogru_cevap" name="dogru_cevap" class="form-control" data-plugin="select2"
                                style="width: 100 % " required>
                            <option value="">Seçiniz...</option>
                            <option value="A" selected>A</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                            <option value="D">D</option>
                        </select>
                    </div>
                </div>

                <button class="btn btn-success pull-right" type="submit">Kaydet</button>
            </div>
        </div>

    </div>
    <div class="col-md-4">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h5 class="panel-title">Soru Bilgileri</h5>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <label class="control-label">Okul Türü</label>
                    <select id="okulTuru" name="okulTuru" class="form-control" data-plugin="select2" style="width: 100%"
                            required>
                        <option value="">Seçiniz...</option>
                        <option value="1">İlkokul</option>
                        <option value="2" selected>Ortaokul</option>
                        <option value="3">Anadolu Lisesi</option>
                        <option value="4">Meslek Lisesi</option>
                        <option value="5">Proje Lisesi</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Soru Hazırlanacak Ders</label>
                    <select id="dersID" name="dersID" class="form-control" data-plugin="select2" style="width: 100%"
                            required>
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($dersler as $ders) {
                            if (get_user_data('bransID') == $ders->id)
                                echo '<option selected value="' . $ders->id . '">' . $ders->adi . '</option>';
                            else
                                echo '<option value="' . $ders->id . '">' . $ders->adi . '</option>';

                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Sınıf Düzeyi</label>
                    <select id="sinifDuzeyi" name="sinifDuzeyi" class="form-control" data-plugin="select2"
                            style="width: 100 % " required>
                        <option value="">Seçiniz...</option>
                        <?php
                        for ($i = 1; $i < 13; $i++) {
                            echo '<option value="' . $i . '">' . $i . '. Sınıf</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Zorluk Derecesi</label>
                    <select id="zorlukDerecesi" name="zorlukDerecesi" class="form-control" data-plugin="select2"
                            style="width: 100 % " required>
                        <option value="">Seçiniz...</option>
                        <option value="1">Çok Kolay (1)</option>
                        <option value="2">Kolay (2)</option>
                        <option value="3">Orta (3)</option>
                        <option value="4">Zor (4)</option>
                        <option value="5">Çok Zor (5)</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h5 class="panel-title">Kazanım Bilgileri</h5>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <label class="control-label">Ünite</label>
                    <select id="uniteID" name="uniteID" class="form-control" data-plugin="select2" style="width: 100%"
                            required>
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($uniteler as $unite) {
                            echo '<option value="' . $unite->id . '">' . $unite->unite_kodu . '-' . $unite->unite_icerik . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Konu/Alt Konu Alanı</label>
                    <select id="konuID" name="konuID" class="form-control" data-plugin="select2" style="width: 100%"
                            required>
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($konular as $konu) {
                            echo '<option value="' . $konu->id . '">' . $konu->konu_kodu . '-' . $konu->konu_icerik . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Kazanım</label>
                    <select id="kazanimID" name="kazanimID" class="form-control" data-plugin="select2"
                            style="width: 100%"
                            required>
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($kazanimlar as $kazanim) {
                            echo '<option value="' . $kazanim->id . '">' . $kazanim->kazanim_kodu . '-' . $kazanim->kazanim_icerik . '</option>';
                        }
                        ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="panel panel-primary">
            <div class="panel-heading">
                <h5 class="panel-title">Kabul Metni</h5>
            </div>
            <div class="panel-body">
                <p style="text-align: justify;">Düzce İl Milli Eğitim Müdürlüğü bünyesinde yürütülmekte olan sınavlarda
                    kullanılmak üzere hazırlamış olduğum madde tamamıyla bana aittir. Yukarıda yer alan maddenin
                    herhangi bir kaynaktan alınmadığını ve üçüncü şahıslarla paylaşmayacağımı <b>taahhüt ederim.</b> Maddenin
                    gerektiğinde düzeltmeye tabii tutulabileceğini kabul ederim.</p>
            </div>
            <div class="panel-footer">
                <div class="form-group">
                    <input type="checkbox" id="yazar_kabul_durumu" name="yazar_kabul_durumu" value="1" required/>
                    <label class="control-label">Kabul ederim.</label>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo form_close(); ?>