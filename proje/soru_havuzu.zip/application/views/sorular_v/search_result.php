<?php if (isset($search_results)) { ?>
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="panel panel-custom panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title"><b>Arama Sonuçları</b></h4>
                </div>
                <div class="panel-body">
                    <table id="search_result_datatable" class="table table-striped" cellspacing="0" width="100%">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>Kodu</th>
                            <th>Tarih</th>
                            <th>Okul Türü</th>
                            <th>Ders</th>
                            <th>Sınıf</th>
                            <th>Zorluk Derec.</th>
                            <th>Kaz. No</th>
                            <th>Onay</th>
                            <th>Yazar</th>
                            <th>İşlemler</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($search_results as $item) { ?>

                            <tr>
                                <td><?php echo $item->no; ?></td>
                                <td><?php echo $item->kodu; ?></td>
                                <td><?php echo date("d-m-Y H:i", strtotime($item->kayit_tarihi)); ?></td>
                                <td>

                                    <?php
                                    switch ($item->okulTuru) {
                                        case 1:
                                            echo "<span style='color:green'>İlkokul</span>";
                                            break;
                                        case 2:
                                            echo "<span style='color:#B7950B;'>Ortaokul</span>";
                                            break;
                                        case 3:
                                            echo "<span style='color:#5DADE2;'>Anadolu Lis.</span>";
                                            break;
                                        case 4:
                                            echo "<span style='color:#900C3F;'>Meslek Lis.</span>";
                                            break;
                                        case 5:
                                            echo "<span style='color:red;'>Proje Lis.</span>";
                                            break;
                                        default:
                                            echo "Eksik Bilgi";
                                    }
                                    ?>
                                </td>
                                <td><?php echo $item->ders_adi; ?></td>
                                <td><?php echo $item->sinifDuzeyi; ?>.Sınıf</td>
                                <td>

                                    <?php
                                    switch ($item->zorlukDerecesi) {
                                        case 1:
                                            echo "<span style='color:green'>Çok Kolay</span>";
                                            break;
                                        case 2:
                                            echo "<span style='color:#B7950B;'>Kolay</span>";
                                            break;
                                        case 3:
                                            echo "<span style='color:#5DADE2;'>Orta</span>";
                                            break;
                                        case 4:
                                            echo "<span style='color:#900C3F;'>Zor</span>";
                                            break;
                                        case 5:
                                            echo "<span style='color:red;'>Çok Zor</span>";
                                            break;
                                        default:
                                            echo "Eksik Bilgi";
                                    }
                                    ?>
                                </td>
                                <td><a href="#" data-toggle="tooltip" data-placement="top"
                                       title="<?php echo $item->kazanim_icerik; ?>"><?php echo $item->kazanim_kodu; ?></a>
                                </td>
                                <td>
                                    <?php echo form_open('sorular/send'); ?>
                                    <input type="hidden" name="dogrulama_kodu"
                                           value="<?php echo $item->dogrulama_kodu; ?>"/>
                                    <?php
                                    switch ($item->onay_durumu) {
                                        case 0:
                                            echo "<span data-toggle='tooltip' data-placement='top' title='Sorunuz kaydedilmiştir. Gönderilmediği sürece ÖDM personeli tarafından görüntülenemeyecektir.' style='color:#f92672;cursor:pointer;'>Gönderilmeyi Bekliyor</span>&nbsp;(<button type='submit' class='btn btn-xs btn-link'>Gönder</button>)";
                                            break;
                                        case 1:
                                            echo "<span data-toggle='tooltip' data-placement='top' title='Sorunuz gönderilmiştir. En kısa sürede uzman tarafından değerlendirmeye alınmalıdır.' style='color:#B7950B;cursor:pointer;'>Aksiyon Bekleniyor</span>";
                                            break;
                                        case 2:
                                            echo "<span data-toggle='tooltip' data-placement='top' title='Soru uzman tarafından kontrol edilmektedir.' style='color:#5DADE2;cursor:pointer;'>Kontrol Ediliyor</span>";
                                            break;
                                        case 3:
                                            echo "<span data-toggle='tooltip' data-placement='top' title='" . strip_tags($item->uzman_yorumu) . "' style='color:red;cursor:pointer;'>Reddedildi</span>";
                                            break;
                                        case 4:
                                            echo "<span data-toggle='tooltip' data-placement='top' title='" . strip_tags($item->uzman_yorumu) . "' style='color:#900C3F;cursor:pointer;'>Düzeltilmeli</span>";
                                            break;
                                        case 5:
                                            echo "<span data-toggle='tooltip' data-placement='top' title='Soru havuza başarıyla eklenmiştir.' style='color:green;;cursor:pointer;'>Onaylandı</span>";
                                            break;
                                        default:
                                            echo "Eksik Bilgi";
                                    }
                                    ?>
                                </td>
                                <?php echo form_close(); ?>
                                <td>
                                    <?php //echo $item->name.' '.$item->surname.'('.$item->username.')';
                                    echo $item->name . ' ' . $item->surname;
                                    ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-xs" role="group">
                                        <a href="<?php echo base_url(); ?>index.php/sorular/detail/<?php echo $item->dogrulama_kodu; ?>"
                                           class="btn btn-primary btn-xs" target="_blank"><i class="fa fa-eye"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php } else { ?>
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="panel panel-custom panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title"><b>Arama Sonuçları</b></h4>
                </div>
                <div class="panel-body">
                    <div class="alert alert-danger" role="alert"><strong>Oh snap!</strong> <span>Change a few things up and try submitting again.</span>
                        <a href="#" class="alert-link">alert link</a></div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>