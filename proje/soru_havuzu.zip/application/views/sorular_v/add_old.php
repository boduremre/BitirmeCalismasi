<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Soru Ekle
            <a href="<?php echo base_url("index.php/sorular/index"); ?>"
               class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-angle-left"></i> Geri Dön</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-inverse">

            <div class="panel-body">
                <div class="stepwizard">
                    <div class="stepwizard-row setup-panel">
                        <div class="stepwizard-step col-xs-3">
                            <a href="#step-1" type="button" class="btn btn-success btn-circle">1</a>
                            <p><small>Giriş</small></p>
                        </div>
                        <div class="stepwizard-step col-xs-3">
                            <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">2</a>
                            <p><small>Temel Bilgiler</small></p>
                        </div>
                        <div class="stepwizard-step col-xs-3">
                            <a href="#step-3" type="button" class="btn btn-default btn-circle" disabled="disabled">3</a>
                            <p><small>Madde Kökü, Seçenekler ve Doğru Cevap</small></p>
                        </div>
                        <div class="stepwizard-step col-xs-3">
                            <a href="#step-4" type="button" class="btn btn-default btn-circle" disabled="disabled">4</a>
                            <p><small>Özet</small></p>
                        </div>
                    </div>
                </div>

                <?php echo form_open('sorular/save','id="formstepwizard"'); ?>                      
                    <input type="hidden" value="<?php echo $user->id; ?>" id="userID" name="userID"/>
                    <div class="panel panel-primary setup-content" id="step-1">
                        <div class="panel-heading">
                            <h3 class="panel-title">Giriş</h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class=" col-md-3 form-group pull-right">
                                    <label class="control-label">Tarih ve Saat</label>
                                    <input name="kayit_tarihi" type="text" required="required" class="form-control"
                                           readonly="readonly"
                                           value="<?php echo date("d-m-Y H:i:s", strtotime('1 hour')); ?>"/>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 form-group">
                                    <label class="control-label">Kullanıcı Adı</label>
                                    <input maxlength="100" type="text" required="required" class="form-control"
                                           placeholder="Kullanıcı Adı" value="<?php echo $user->username; ?>"
                                           readonly="readonly"/>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label class="control-label">Ad</label>
                                    <input maxlength="100" type="text" required="required" class="form-control" name="name" id="name"
                                           placeholder="Ad" value="<?php echo $user->name; ?>" readonly="readonly"/>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label class="control-label">Soyad</label>
                                    <input maxlength="100" type="text" required="required" class="form-control" name="surname" id="surname"
                                           placeholder="Soyad" readonly="readonly"
                                           value="<?php echo $user->surname; ?>"/>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 form-group">
                                    <label class="control-label">Eposta</label>
                                    <input maxlength="100" type="text" required="required" class="form-control"
                                           placeholder="Eposta" readonly="readonly"
                                           value="<?php echo $user->email; ?>"/>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label class="control-label">Branş</label>
                                    <input maxlength="100" type="text" required="required" class="form-control"
                                           placeholder="Branş" readonly="readonly" value="<?php echo $user->brans; ?>"/>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label class="control-label">Okul</label>
                                    <input maxlength="100" type="text" required="required" class="form-control"
                                           placeholder="Okul" readonly="readonly" value="<?php echo $user->okul; ?>"/>
                                </div>
                                <button class="btn btn-primary nextBtn pull-right" type="button">İleri</button>
                            </div>
                        </div>
                    </div>

                    <div class="panel panel-primary setup-content" id="step-2">
                        <div class="panel-heading">
                            <h3 class="panel-title">Temel Bilgiler</h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">
								<div class="col-md-3 form-group">
                                    <label class="control-label">Okul Türü</label>
                                    <select id="okulTuru" name="okulTuru" class="form-control" data-plugin="select2"
                                            style="width: 100%" required>
                                        <option value="">Seçiniz...</option>
                                        <option value="1">İlkokul</option>
                                        <option value="2">Ortaokul</option>
                                        <option value="3">Anadolu Lisesi</option>
                                        <option value="4">Meslek Lisesi</option>
                                        <option value="5">Proje Lisesi</option>
                                    </select>
                                </div>
                                <div class="col-md-3 form-group">
                                    <label class="control-label">Soru Hazırlanacak Ders</label>
                                    <select id="dersID" name="dersID" class="form-control" data-plugin="select2"
                                            style="width: 100%" required>
                                        <option value="">Seçiniz...</option>
                                        <?php
                                        foreach ($dersler as $row) {
                                            echo '<option value="' . $row->id . '-' . $row->kisa_kod . '-' . $row->adi . '">' . $row->adi . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-3 form-group">
                                    <label class="control-label">Sınıf Düzeyi</label>
                                    <select id="sinifDuzeyi" name="sinifDuzeyi" class="form - control"
                                            data-plugin="select2" style="width: 100 % " required>
                                        <option value="">Seçiniz...</option>
                                        <?php
                                        for ($i = 1; $i < 13; $i++) {
                                            echo '<option value="' . $i . '">' . $i . '. Sınıf</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-3 form-group">
                                    <label class="control-label">Zorluk Derecesi</label>
                                    <select id="zorlukDerecesi" name="zorlukDerecesi" class="form - control"
                                            data-plugin="select2" style="width: 100 % " required>
                                        <option value="">Seçiniz...</option>
                                        <option value="1">Çok Kolay (1)</option>
                                        <option value="2">Kolay (2)</option>
                                        <option value="3">Orta (3)</option>
                                        <option value="4">Zor (4)</option>
                                        <option value="5">Çok Zor (5)</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label class="control-label">Ünite</label>
                                    <input maxlength="100" type="text" class="form-control"
                                           placeholder="Ünite" name="unite" id="unite"/>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label class="control-label">Konu/Alt Konu Alanı</label>
                                    <input maxlength="100" type="text" class="form-control"
                                           placeholder="Konu / Alt Konu Alanı" name="konuAltKonuAlani"
                                           id="konuAltKonuAlani"/>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label class="control-label">Kazanım Kodu</label>
                                    <div class="input-group">
                                        <input type="text" name="kazanim_no" id="kazanim_no" class="form-control">
                                        <span class="input-group-btn">
                                            <button class="btn btn-primary" type="button"><span
                                                        class="glyphicon glyphicon - list" aria-hidden="true">
                                                </span> Liste</button>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label class="control-label">Kazanım İçeriği</label>
                                    <input name="kazanim_icerik" id="kazanim_icerik" maxlength="100" type="text"
                                           required="required" class="form-control"
                                           placeholder="Kazanım İçeriği"/>
                                </div>
                            </div>
                            <button class="btn btn-primary nextBtn pull-right" type="button">ileri</button>
                        </div>
                    </div>

                    <div class="panel panel-primary setup-content" id="step-3">
                        <div class="panel-heading">
                            <h3 class="panel-title">Madde Kökü, Seçenekler ve Doğru Cevap</h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12 form-group">
                                    <label class="control-label">Resim, Grafik, Tablo ve Madde Kökü (Soru)</label>
                                    <textarea name="madde_koku" id="madde_koku" cols="30" rows="10"
                                              class="form - control"></textarea>
                                </div>
                                <div class="col-md-12 form-group">
                                    <label class="control-label">Seçenekler (Şıklar)</label><br />
                                    <label class="control-label">A)</label>
                                    <input maxlength="100" type="text" class="form-control"
                                           placeholder="A)" name="cevap_a" id="cevap_a" required/>
								    <label class="control-label">B)</label>
                                    <input maxlength="100" type="text" class="form-control"
                                           placeholder="B)" name="cevap_b" id="cevap_b" required/>
										   <label class="control-label">C)</label>
                                    <input maxlength="100" type="text" class="form-control"
                                           placeholder="C)" name="cevap_c" id="cevap_c" required/>
										   <label class="control-label">D)</label>
                                    <input maxlength="100" type="text" class="form-control"
                                           placeholder="D)" name="cevap_d" id="cevap_d" required/>								
									<label class="control-label">E)</label>
                                    <input maxlength="100" type="text" class="form-control"
                                           placeholder="E)" name="cevap_e" id="cevap_e"/>
                                </div>
                                <div class="col-md-12 form-group">
                                    <label class="control-label">Doğru Cevap</label>
                                    <select id="dogru_cevap" name="dogru_cevap" class="form - control"
                                            data-plugin="select2" style="width: 100 % " required>
                                        <option value="">Seçiniz...</option>
                                        <option value="A">A</option>
                                        <option value="B">B</option>
                                        <option value="C">C</option>
                                        <option value="D">D</option>
                                        <option value="E">E</option>
                                    </select>
                                </div>
                            </div>

                            <button class="btn btn-primary nextBtn pull-right" type="button">İleri</button>
                        </div>
                    </div>

                    <div class="panel panel-primary setup-content" id="step-4">
                        <div class="panel-heading">
                            <h3 class="panel-title">Son</h3>
                        </div>
                        <div class="panel-body">
                            <p>Gerekli bilgileri girdiğinizden eminseniz kaydet butonuna basınız!</p>                            
                            <button class="btn btn-success pull-right" type="submit">Kaydet</button>                            
                        </div>
                    </div>
                <?php echo form_close(); ?>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div>
    <!-- END column -->
</div>