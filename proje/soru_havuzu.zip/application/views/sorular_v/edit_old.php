<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Soru Düzenle ("<?php //print_r($item);
            echo trim($item->no); ?>" numaralı soru)
            <a href="<?php echo base_url("index.php/sorular/index"); ?>"
               class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-angle-left"></i> Geri Dön</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-custom panel-primary">
            <div class="panel-body">
                <form action="<?php echo base_url(); ?>index.php/sorular/update" method="post">
				<input type="hidden" name="id" value="<?php echo $item->id; ?>" />
				<input type="hidden" name="dogrulama_kodu" value="<?php echo $item->dogrulama_kodu; ?>" />
					<div class="row">
                                <div class="col-md-4 form-group">
                                    <label class="control-label">Soru Hazırlanacak Ders</label>
                                    <select id="dersID" name="dersID" class="form-control" data-plugin="select2"
                                            style="width: 100%" required>
											<?php                                        
                                            echo '<option value="' . $item->dersID . '-' . $item->dersAdi . '-' . $item->dersAdi . '" selected>' . $item->dersAdi . '</option>';
                                        
                                        ?>

                                        <?php
                                        foreach ($dersler as $row) {
                                            echo '<option value="' . $row->id . '-' . $row->kisa_kod . '-' . $row->adi . '">' . $row->adi . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label class="control-label">Sınıf Düzeyi</label>
                                    <select id="sinifDuzeyi" name="sinifDuzeyi" class="form - control"
                                            data-plugin="select2" style="width: 100 % " required>
                                        <option value="<?php echo $item->sinifDuzeyi; ?>" selected><?php echo $item->sinifDuzeyi; ?>. Sınıf</option>
                                        <?php
                                        for ($i = 1; $i < 13; $i++) {
                                            echo '<option value="' . $i . '">' . $i . '. Sınıf</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label class="control-label">Zorluk Derecesi</label>
                                    <select id="zorlukDerecesi" name="zorlukDerecesi" class="form - control"
                                            data-plugin="select2" style="width: 100 % " required>
                                        <option value="">Seçiniz...</option>
                                        <option value="1" <?php if($item->zorlukDerecesi == 1) echo 'selected="selected"'; ?>>Çok Kolay (1)</option>
                                        <option value="2" <?php if($item->zorlukDerecesi == 2) echo 'selected="selected"'; ?>>Kolay (2)</option>
                                        <option value="3" <?php if($item->zorlukDerecesi == 3) echo 'selected="selected"'; ?>>Orta (3)</option>
                                        <option value="4" <?php if($item->zorlukDerecesi == 4) echo 'selected="selected"'; ?>>Zor (4)</option>
                                        <option value="5" <?php if($item->zorlukDerecesi == 5) echo 'selected="selected"'; ?>>Çok Zor (5)</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label class="control-label">Ünite</label>
                                    <input maxlength="100" type="text" class="form-control"
                                           placeholder="Ünite" name="unite" id="unite" value="<?php echo $item->unite; ?>"/>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label class="control-label">Konu/Alt Konu Alanı</label>
                                    <input maxlength="100" type="text" class="form-control"
                                           placeholder="Konu / Alt Konu Alanı" name="konuAltKonuAlani"
                                           id="konuAltKonuAlani" value="<?php echo $item->konuAltKonuAlani; ?>"/>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label class="control-label">Kazanım Kodu</label>
                                    <div class="input-group">
                                        <input type="text" name="kazanim_no" id="kazanim_no" class="form-control"
                                               required="required" value="<?php echo $item->kazanim_no; ?>" />
                                         <span class="input-group-btn">
                                            <a class="btn btn-primary" href="http://duzceodm.meb.gov.tr/www/2018-2019-kazanimlar-ornek-yillik-planlar-ve-dokumanlar/icerik/10" target="_blank">
											<span class="glyphicon glyphicon-list" aria-hidden="true"></span> Liste</a>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label class="control-label">Kazanım İçeriği</label>
                                    <input name="kazanim_icerik" id="kazanim_icerik" maxlength="100" type="text"
                                           required="required" class="form-control"
                                           placeholder="Kazanım İçeriği" value="<?php echo $item->kazanim_icerik; ?>"/>
                                </div>
							</div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Madde Kökü</label>
                        <textarea name="madde_koku" class="m-0"><?php echo $item->madde_koku; ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Seçenekler</label>
                        <textarea name="secenekler" class="m-0"><?php echo $item->secenekler; ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Doğru Cevap</label>
                        <input type="text" id="maxlength-demo-3" maxlength="100" class="form-control"
                               name="dogru_cevap"
                               value="<?php echo $item->dogru_cevap; ?>"
                               data-plugin="maxlength"
                               data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger'}">
                    </div>
                    <?php if ($userIsAdmin == "1") { ?>
                        <div class="form-group">
                            <label class="control-label">Onay Durumu</label>
                            <select id="onay_durumu" name="onay_durumu" class="form-control" data-plugin="select2"
                                    style="width: 100%">									
                                <option value="">Seçiniz...</option>
                                <option value="1" <?php if($item->onay_durumu == '1') echo "selected"; ?>>Aksiyon Bekleniyor</option>
                                <option value="2" <?php if($item->onay_durumu == '2') echo "selected"; ?>>Kontrol Ediliyor</option>
                                <option value="3" <?php if($item->onay_durumu == '3') echo "selected"; ?>>Reddedildi</option>
                                <option value="4" <?php if($item->onay_durumu == '4') echo "selected"; ?>>Düzeltilmeli</option>
                                <option value="5" <?php if($item->onay_durumu == '5') echo "selected"; ?>>Onaylandı</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="maxlength-demo-3">Düzeltme ve Red Nedenleri ile varsa yorumlarınızı Yazınız</label>
                            <textarea name="uzman_yorumu" class="m-0"><?php echo $item->uzman_yorumu; ?></textarea>
                        </div>
                    <?php } ?>

                    <div class="form-group pull-right">
                        <input type="submit" id="submit_button" name="submit" class="btn btn-primary" value="Kaydet"/>
                        <a href="<?php echo base_url("index.php/sorular/index"); ?>" class="btn btn-danger">İptal</a>
                    </div>
                </form>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div>
    <!-- END column -->
</div>