<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Duyuru Düzenle ("<?php echo trim($item->baslik); ?>" başlıklı duyuru)
            <a href="<?php echo base_url("index.php/notify/index"); ?>"
               class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-angle-left"></i> Geri Dön</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-custom panel-primary">
            <div class="panel-body">
                <?php echo form_open('notify/update'); ?>
                <input type="hidden" value="<?php echo $item->id; ?>" name="id">
                <div class="form-group">
                    <label for="maxlength-demo-1">Başlık</label>
                    <input type="text" id="maxlength-demo-1" maxlength="150" class="form-control" name="baslik"
                           data-plugin="maxlength"
                           value="<?php echo $item->baslik; ?>"
                           data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-warning', limitReachedClass: 'label label-danger' }">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-2">Özet</label>
                    <input type="text" id="maxlength-demo-2" maxlength="200" class="form-control" name="ozet"
                           data-plugin="maxlength"
                           value="<?php echo $item->ozet; ?>"
                           data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger'}">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-3">İçerik</label>
                    <textarea name="icerik" class="m-0 ckeditor"><?php echo $item->icerik; ?></textarea>
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-3">Anahtar Kelimeler <strong>(Kelimeler Arasında Virgül İşareti
                            Ekleyiniz)</strong></label>
                    <input type="text" id="maxlength-demo-3" maxlength="100" class="form-control"
                           name="anahtar_kelimeler"
                           value="<?php echo $item->anahtar_kelimeler; ?>"
                           data-plugin="maxlength"
                           data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger'}">
                </div>
                <div class="form-group">
                    <label for="isActive">Aktif</label>
                    <input id="isActive" type="checkbox"
                           data-switchery <?php echo ($item->aktif == 1) ? 'checked' : ''; ?> name="aktif"/>
                </div>
                <div class="form-group">
                    <input type="submit" id="submit_button" name="submit" class="btn btn-primary pull-right"/>
                </div>
                <?php echo form_close(); ?>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div>
    <!-- END column -->
</div>