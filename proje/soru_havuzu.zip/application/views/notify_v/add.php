<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            &nbsp;
            <a href="<?php echo base_url("index.php/notify/index"); ?>" class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-angle-left"></i> Geri Dön</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-inverse">
            <div class="panel-heading">
                <h4 class="panel-title">Duyuru Ekle</h4>
            </div>
            <div class="panel-body">
                <?php echo form_open('notify/save');?>
                    <div class="form-group">
                        <label for="maxlength-demo-1">Başlık</label>
                        <input type="text" id="maxlength-demo-1" maxlength="100" class="form-control" name="baslik"
                               data-plugin="maxlength"
                               autocomplete="off"
                               data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-important' }">
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-2">Özet</label>
                        <input type="text" id="maxlength-demo-2" maxlength="255" class="form-control" name="ozet"
                               data-plugin="maxlength"
                               autocomplete="off"
                               data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-warning', limitReachedClass: 'label label-danger', placement: 'bottom' }">
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">İçerik</label>
                        <textarea class="form-control m-0 ckeditor" name="icerik" autocomplete="off"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Anahtar Kelimeler <strong>(Kelimeler Arasında Virgül İşareti
                                Ekleyiniz)</strong></label>
                        <input type="text" id="maxlength-demo-3" maxlength="25" class="form-control"
                               name="anahtar_kelimeler"
                               data-plugin="maxlength"
                               autocomplete="off"
                               data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom' }">
                    </div>
                    <div class="form-group">
                        <label for="isActive">Aktif</label>
                        <input id="isActive" type="checkbox" data-switchery checked name="aktif"/>
                    </div>
                    <div class="form-group">
                        <input type="submit" id="submit_button" name="submit" class="btn btn-primary pull-right"/>
                    </div>
                <?php echo form_close();?>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div>
    <!-- END column -->
</div>