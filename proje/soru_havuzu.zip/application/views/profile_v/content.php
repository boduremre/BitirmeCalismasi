<div class="row">
    <?php if ($gizlilik_taahhut_onay == 0){ ?>
        <div class="col-md-12 col-sm-12">
            <div class="alert alert-warning" role="alert"><strong>Dikkat!</strong> <span>Kullanıcı Gizlilik Taahhütnamesi beyan ve kabul işlemini gerçekleştirmelisiniz!</span>
                İşlemi gerçekleştirmek için <a href="<?php echo base_url(); ?>index.php/profile#taahhutname" class="alert-link">tıklayınız.</a></div>
        </div>
    <?php } ?>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="profile-header">
            <div class="profile-cover">
                <div class="cover-user m-b-lg">
                    <div>
                        <?php if ($user->roleID == 1) { ?>
                            <span class="cover-icon"
                                  title="Yetki: Yönetici"
                                  data-toggle="tooltip"
                                  data-placement="left">
                        <i class="fa fa-user-secret"></i></span>
                        <?php } else { ?>
                            <span class="cover-icon"
                                  title="Yetki: Kullanıcı"
                                  data-toggle="tooltip"
                                  data-placement="left">
                        <i class="fa fa-user"></i></span>
                        <?php } ?>
                    </div>
                    <div>
                        <div class="avatar avatar-xl avatar-circle">
                            <a href="javascript:void(0)">
                                <img class="img-responsive"
                                     src="<?php echo base_url('assets'); ?>/images/user_icon_circle.png"
                                     alt="avatar"/>
                            </a>
                        </div><!-- .avatar -->
                    </div>
                    <div>
                        <?php if ($user->isActive == 1) { ?>
                            <span class="cover-icon"
                                  title="Onaylanmış Kullanıcı"
                                  data-toggle="tooltip"
                                  data-placement="right">
                        <i class="fa fa-check"></i></span>
                        <?php } else { ?>
                            <span class="cover-icon"
                                  title="Onaylanmamış Kullanıcı"
                                  data-toggle="tooltip"
                                  data-placement="right">
                        <i class="fa fa-close"></i></span>
                        <?php } ?>
                    </div>
                </div>
                <div class="text-center">
                    <h4 class="profile-info-name m-b-lg">
                        <a href="javascript:void(0)" class="title-color">
                            <?php echo $user->name . ' ' . $user->surname . '<br/>'; ?>
                            (<?php echo $user->username ?>)
                        </a>
                    </h4>
                    <div>
                        <a href="javascript:void(0)" class="m-r-xl theme-color"><i
                                    class="fa fa-envelope m-r-xs"></i> <?php echo $user->email; ?></a>
                        <a href="javascript:void(0)" class="theme-color"><i
                                    class="fa fa-map-marker m-r-xs"></i><?php echo $user->address; ?></a>
                    </div>
                </div>
            </div><!-- .profile-cover -->
        </div><!-- .profile-header -->
    </div>
</div>
<br />
<div class="row">
    <div class="col-md-8">
        <div id="profile-tabs" class="nav-tabs-horizontal white m-b-lg">
            <!-- tabs list -->
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active">
                    <a href="#profile-stream" aria-controls="stream" role="tab" data-toggle="tab">Bilgiler</a>
                </li>
                <li role="presentation">
                    <a href="#profile-photos" aria-controls="photos" role="tab" data-toggle="tab">Ziyaretler</a>
                </li>
                <li role="presentation">
                    <a href="#taahhutname" aria-controls="photos" role="tab" data-toggle="tab">Taahhütname</a>
                </li>
            </ul><!-- .nav-tabs -->

            <!-- Tab panes -->
            <div class="tab-content p-md">
                <div role="tabpanel" class="tab-pane in active fade" id="profile-stream">
                    <?php echo form_open('profile/update'); ?>
                    <div class="form-group">
                        <label for="maxlength-demo-1">Kullanıcı Adı</label>
                        <input type="text"
                               class="form-control"
                               name="username"
                               value="<?php echo $user->username; ?>"
                               readonly
                               disabled/>
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-2">Ad</label>
                        <input type="text" id="maxlength-demo-2" maxlength="50" class="form-control" name="name"
                               value="<?php echo $user->name; ?>"
                               data-plugin="maxlength"
                               data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'right' }">
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Soyad</label>
                        <input type="text" class="form-control m-0" name="surname"
                               value="<?php echo $user->surname; ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Şifre</label>
                        <input type="text" class="form-control m-0" name="password"
                               value="<?php echo $user->password; ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Eposta</label>
                        <input type="email" class="form-control m-0" name="email"
                               value="<?php echo $user->email; ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Telefon</label>
                        <input type="tel" class="form-control m-0 phone" name="tel" value="<?php echo $user->tel; ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Branş</label>
                        <input type="text" class="form-control m-0" name="brans" value="<?php echo $user->brans; ?>"
                               readonly/>
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Okul</label>
                        <input type="text" class="form-control m-0" name="okul" readonly
                               value="<?php echo $user->okul . ' (' . $user->kurum_kodu . ')'; ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Adres</label>
                        <input type="text" class="form-control m-0" name="address"
                               value="<?php echo $user->address; ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-3">Kayıt Tarihi</label>
                        <input type="text" class="form-control m-0" name="registerDate"
                               value="<?php echo date('d.m.Y H:i:s', strtotime($user->registerDate)); ?>" readonly
                               disabled/>
                    </div>
                    <!--                        <div class="form-group">-->
                    <!--                            <label for="isActive">Aktif</label>-->
                    <!--                            <input id="isActive" type="checkbox" data-switchery -->
                    <?php //echo $user->isActive == 1 ? 'checked' : ''; ?><!-- name="isActive" readonly disabled/>-->
                    <!--                        </div>-->
                    <div class="form-group">
                        <input type="hidden" name="id" value="<?php echo $user->id; ?>">
                        <input type="submit" id="submit_button" name="submit"
                               class="btn btn-primary"/>
                    </div>
                    <?php echo form_close(); ?>
                </div><!-- .tab-pane -->
                <div role="tabpanel" class="tab-pane in fade" id="profile-photos">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Tarih Saat</th>
                            <th>IP Adresi</th>
                            <th class="visible-md visible-lg">Tarayıcı ve İşletim Sistemi</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        foreach ($loginLogs as $item) { ?>
                            <tr>
                                <td><?php echo date("d.m.Y H:i:s", strtotime('+1 hours', strtotime($item->logDate))); ?></td>
                                <td><?php echo $item->ip; ?></td>
                                <td class="visible-md visible-lg">
                                    <?php

                                    if (strpos($item->browser, "Chrome") !== false) {
                                        echo "Google Chrome";
                                    } else if (strpos($item->browser, "Firefox") !== false) {
                                        echo "Mozilla Firefox";
                                    } else if (strpos($item->browser, "Safari") !== false) {
                                        echo "Safari";
                                    }
                                    echo ' - ' . $item->platform;
                                    ?>
                                </td>
                            </tr>
                            <?php
                        } ?>
                        </tbody>
                    </table>
                </div><!-- .tab-pane -->
                <div role="tabpanel" class="tab-pane in fade" id="taahhutname">
                    <h4 style="text-align: center">Kullanıcı Gizlilik Taahhütnamesi</h4>
                    <br>
                    <p style="text-align: justify"><b>Madde 1-</b> Lorem ipsum dolor sit amet, consectetur adipiscing
                        elit. Morbi feugiat felis et
                        augue vehicula, id faucibus lectus accumsan. Nulla facilisi. Praesent pretium, urna a efficitur
                        aliquam, odio felis placerat eros, et varius nisl mauris in enim. In id ipsum non mauris
                        suscipit vestibulum. Donec feugiat sem felis, nec ultricies tellus porttitor at. Etiam posuere
                        lorem tellus, ut fermentum risus pharetra vel. Nunc pulvinar mauris nunc, faucibus imperdiet mi
                        rhoncus et. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
                    <p style="text-align: justify"><b>Madde 2-</b>Integer mi lorem, imperdiet id felis a, consectetur
                        condimentum ipsum. Nunc
                        aliquet tortor a nibh pharetra facilisis sed et sem. Sed dui nunc, pellentesque pulvinar purus
                        sed, egestas fermentum erat. Maecenas in nisi eget odio dignissim faucibus. Aenean molestie nisi
                        congue nunc condimentum tempor. Nulla maximus sem eu convallis malesuada. Aliquam semper nulla
                        eget ultrices sollicitudin.</p>
                    <p style="text-align: justify"><b>Madde 3-</b>Ut ante eros, fermentum varius odio in, aliquet
                        condimentum mauris. Fusce elit
                        ipsum, varius eu orci a, ullamcorper faucibus sapien. Cras ullamcorper tincidunt faucibus. Proin
                        id auctor urna. Integer mollis pretium leo, ac commodo ante iaculis vitae. Nulla fringilla
                        sapien est, vel finibus justo fringilla id. Duis vitae ante dolor. Nam eu ex sagittis, suscipit
                        dolor at, fermentum eros. Nulla hendrerit massa eget feugiat faucibus. Morbi at nulla vel neque
                        pharetra lobortis vel lacinia nulla. Praesent vehicula, sem vitae tincidunt semper, sem ante
                        gravida arcu, eu bibendum justo metus sed urna.</p>
                    <p style="text-align: justify"><b>Madde 4-</b>Donec eros elit, fermentum at odio sit amet, maximus
                        pulvinar ipsum. Praesent
                        fermentum turpis sed leo fringilla, ut iaculis odio tincidunt. Pellentesque ut sapien
                        sollicitudin, pharetra nisi at, lacinia sapien.</p>
                    <p style="text-align: justify"><b>Madde 5-</b>Nunc at tortor lacus. Proin porttitor, elit quis
                        pellentesque pharetra, ante
                        libero feugiat lorem, eu porttitor mauris dui ac arcu. Nulla fringilla vestibulum justo id
                        vestibulum. Nulla quis est quis nibh convallis tristique vel semper dolor. Maecenas hendrerit
                        sodales neque. Maecenas nec turpis eget quam volutpat condimentum at ut neque. Aliquam faucibus
                        diam tortor. Maecenas elit nunc, pharetra at erat vitae, lobortis tempor metus. Nullam finibus
                        ex urna, a egestas massa pellentesque vitae.</p>
                    <p style="text-align: justify"><b>Madde 6-</b>Aliquam euismod, magna nec rhoncus interdum, velit
                        tortor malesuada nisl, in laoreet mauris purus eu lacus. Aliquam consequat ut justo quis ornare.
                        Cras ut urna ac purus cursus vestibulum. Nullam volutpat cursus orci, vitae tempor ante suscipit
                        vel. Sed eu diam purus. Morbi in mi libero. Proin quis pellentesque erat, eu aliquam quam.</p>
                    <p style="text-align: justify"><b>Madde 7-</b>Duis feugiat id ligula ut venenatis. Lorem ipsum dolor
                        sit amet, consectetur
                        adipiscing elit. Donec vehicula sed urna vitae tempus. Sed quis molestie eros. In posuere nisl
                        ac risus bibendum consequat. Mauris et arcu quis nisl dignissim congue in sit amet tellus.
                        Aenean fringilla ipsum quis auctor malesuada. Pellentesque leo ligula, eleifend sit amet metus
                        ut, fermentum tincidunt lectus. Vestibulum ultricies, ante ac iaculis varius, tellus ante
                        interdum nulla, laoreet rhoncus erat turpis ut mauris. Ut et molestie metus.</p>
                    <p style="text-align: justify"><b>Madde 8-</b>Nunc ullamcorper magna nec cursus eleifend. Duis
                        elementum, nulla vitae placerat
                        maximus, justo velit lobortis orci, ut molestie ante tellus et ante. Nam suscipit nulla tortor,
                        non malesuada turpis iaculis in. Maecenas placerat nisi ut pharetra dignissim. Proin facilisis
                        venenatis augue a finibus. Cras fringilla varius felis. Nulla hendrerit ligula eu velit lobortis
                        mattis. Pellentesque aliquam dictum nulla, at vestibulum eros imperdiet vel. Cras at porta
                        tellus. Quisque luctus, diam eu porttitor convallis, neque dui placerat lectus, suscipit
                        ultrices augue diam et lorem. Curabitur efficitur pellentesque aliquet. Ut ut lectus sit amet
                        purus facilisis finibus.</p>
                    <p style="text-align: justify"><b>Madde 9-</b>Vestibulum fermentum, sapien et tempor semper, turpis
                        purus suscipit nulla, ac
                        condimentum ex orci id ipsum. Donec luctus nibh a eros faucibus lacinia. Sed sagittis sapien
                        rutrum sem pretium scelerisque. Nunc vestibulum leo dui, ultrices accumsan felis interdum in.
                        Nunc tempus malesuada sapien eget mollis. Praesent ligula eros, blandit et viverra non, tempor
                        quis odio. Suspendisse in vestibulum leo. Etiam molestie tellus at ipsum dapibus, nec
                        consectetur arcu maximus. Sed et odio a justo sodales eleifend eu sed massa. Morbi venenatis
                        nibh non sem viverra, vitae porttitor sapien tincidunt. Quisque accumsan massa eros, ultrices
                        tincidunt sapien commodo sit amet. Sed tempus bibendum dapibus. Aliquam pharetra, lectus a
                        aliquam vehicula, mauris felis rutrum nisi, et suscipit magna tellus a odio. Sed sodales libero
                        in leo dignissim ullamcorper.</p>
                    <p style="text-align: justify">yukarıdaki maddeleri taahhüt eder, bu taahhütlerimi yerine getirmemem
                        veya kasıtlı olarak
                        taahhütlerimi ihlal etmem halinde; kurum açısından oluşacak zararı karşılayacağımı, yasaların
                        öngördüğü mali, cezai ve hukuki tüm sorumlulukların bana ait olduğunu beyan ve kabul ederim.</p>
                    <?php echo form_open('profile/update_gizlilik_taahhut'); ?>
                    <div class="form-group">
                        <input type="hidden" name="id" value="<?php echo $user->id; ?>">
                        <input type="hidden" name="gizlilik_taahhut_onay" value="1">
                        <input type="submit"
                               value="<?php echo $user->gizlilik_taahhut_onay == 1 ?  date("d-m-Y H:i", strtotime($user->gizlilik_taahhut_onay_tarihi))." tarihinde beyan ve kabul ettiniz." : "Beyan ve kabul ederim."; ?>" <?php echo $user->gizlilik_taahhut_onay == 1 ? "disabled" : ""; ?>
                               class="btn <?php echo $user->gizlilik_taahhut_onay == 1 ? "btn-success" : "btn-danger"; ?>"/>
                    </div>
                    <?php echo form_close(); ?>
                </div><!-- .tab-pane -->
            </div><!-- .tab-content -->

        </div><!-- #profile-components -->
    </div><!-- END column -->

    <div class="col-md-4">
        <div class="row">
            <div class="col-md-12 col-sm-6">
                <div class="widget navigation-widget">
                    <div class="widget-header p-h-lg p-v-md">
                        <h4 class="widget-title">Soru Bilgileri</h4>
                    </div>
                    <hr class="widget-separator m-0">
                    <ul class="list-group">
                        <li class="list-group-item"><span
                                    class="badge badge-primary"><?php echo $totalBekleyenSoru; ?></span>Onay Bekleyen
                            Soru Sayısı
                        </li>
                        <li class="list-group-item"><span
                                    class="badge badge-warning"><?php echo $totalBekleyenSoru; ?></span>Düzeltilmesi
                            Gereken Soru Sayısı
                        </li>
                        <li class="list-group-item"><span class="badge badge-danger"><?php echo $totalRedSoru; ?></span>Red
                            Edilen Soru Sayısı
                        </li>
                        <li class="list-group-item"><span
                                    class="badge badge-success"><?php echo $totalOnaylananSoru; ?></span>Onaylanan Soru
                            Sayısı
                        </li>
                    </ul>
                </div><!-- .widget -->
            </div><!-- END column -->

            <div class="col-md-12 col-sm-6">
                <div class="widget navigation-widget">
                    <div class="widget-header p-h-lg p-v-md">
                        <h4 class="widget-title">Ödeme Bilgileri</h4>
                    </div>
                    <hr class="widget-separator m-0">
                    <div class="widget-body p-t-lg">
                        <div class="clearfix m-b-md">
                            <h3 class="pull-left text-success m-0 fw-500">
                                <span class="counter" data-plugin="counterUp">125</span> TL
                            </h3>
                            <div class="pull-right watermark"><i class="fa fa-2x fa-dollar"></i></div>
                        </div>
                        <p class="m-b-0 text-muted">
                            Sisteme gönderdiğiniz ve kabul edilen <b><?php echo $totalOnaylananSoru; ?></b> adet sorunun
                            karşılığı olan ek ders ücreti yukarıda gösterilmiştir. Yanlışlık olduğunuz düşünüyorsanız
                            yetkili personel ile iletişime geçiniz.
                        </p>
                    </div>
                </div><!-- .widget -->
            </div><!-- END column -->
        </div><!-- .row -->

    </div><!-- END column -->
</div><!-- .row -->