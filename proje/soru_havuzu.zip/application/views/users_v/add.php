<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Kullanıcı Ekle
            <a href="<?php echo base_url("index.php/users/index"); ?>" class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-list"></i> Kullanıcılar Listesi</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-custom panel-info">
            <div class="panel-body">
                <?php echo form_open(base_url('index.php/users/save')); ?>
                <div class="form-group">
                    <label for="maxlength-demo-1">Kullanıcı Adı</label>
                    <input type="text" id="maxlength-demo-1" maxlength="15" class="form-control" name="username" autocomplete="off" data-plugin="maxlength" data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger' }">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-2">Şifre</label>
                    <input type="text" id="maxlength-demo-2" maxlength="20" class="form-control" name="password" autocomplete="off" data-plugin="maxlength" data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom' }">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-2">Şifre (Tekrar)</label>
                    <input type="text" id="maxlength-demo-2" maxlength="20" class="form-control" name="password2" autocomplete="off" data-plugin="maxlength" data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom' }">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-3">Ad</label>
                    <input type="text" id="maxlength-demo-3" maxlength="25" class="form-control" name="name" autocomplete="off" data-plugin="maxlength" data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom', message: 'used %charsTyped% of %charsTotal% chars.' }">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-3">Soyad</label>
                    <input type="text" id="maxlength-demo-3" maxlength="25" class="form-control" name="surname" autocomplete="off" data-plugin="maxlength" data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom', message: 'used %charsTyped% of %charsTotal% chars.' }">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-3">Eposta</label>
                    <input type="email" id="maxlength-demo-3" maxlength="50" class="form-control" name="email" autocomplete="off" data-plugin="maxlength" data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom', message: 'used %charsTyped% of %charsTotal% chars.' }">
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-3">Telefon</label>
                    <input type="tel" id="maxlength-demo-3" maxlength="11" class="form-control" name="tel" autocomplete="off" data-plugin="maxlength" data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom', message: 'used %charsTyped% of %charsTotal% chars.' }">
                </div>
                <div class="form-group">
                    <label class="control-label">Branş</label>
                    <select id="bransID" name="bransID" class="form-control" data-plugin="select2" autocomplete="off" style="width: 100%" required>
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($dersler as $row) {
                            echo '<option value="' . $row->id . '">' . $row->adi . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Okul</label>
                    <select id="kurum_kodu" name="kurum_kodu" class="form-control" data-plugin="select2" autocomplete="off" style="width: 100%" required>
                        <option value="">Seçiniz...</option>
                        <?php
                        foreach ($okullar as $row) {
                            echo '<option value="' . $row->kurum_kodu . '">(' . $row->TownName . ') ' . $row->kurum_kodu . ' - ' . $row->kurum_adi . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Rol</label>
                    <select id="roleId" name="roleId" class="form-control" data-plugin="select2" autocomplete="off" style="width: 100%" required>
                        <option value="">Seçiniz...</option>
                        <?php

                        foreach ($roller as $row) {
                            echo '<option value="' . $row->id . '">' . $row->name . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="control-label">Adres</label>
                    <input type="text" class="form-control" autocomplete="off" placeholder="Adres" name="address" id="address" />
                </div>
                <div class="form-group">
                    <!--<label for="isActive">Aktif Kullanıcı</label>
                    <input id="isActive" type="checkbox" data-switchery checked name="isActive"/>-->

                    <label for="admin_role">Yönetici</label>
                    <input id="admin_role" type="checkbox" data-switchery name="admin_role" data-color="green" />

                </div>
                <div class="form-group">
                    <input type="submit" id="submit_button" name="submit" class="btn btn-primary pull-right" />
                </div>
                <?php echo form_close(); ?>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div>
    <!-- END column -->
</div>