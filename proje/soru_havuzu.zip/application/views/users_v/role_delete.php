<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Rol Sil ("<?php echo trim($item->name); ?>" isimli rol)
            <a href="<?php echo base_url("index.php/users/roles"); ?>" class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-angle-left"></i> Geri Dön</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-custom panel-danger">
            <div class="panel-body">
                <p><b>Adı :</b> <?php echo $item->name; ?></p>
                <p><b>Açıklama :</b> <?php echo $item->description; ?></p>
                <p><b>Kayıt Tarihi :</b> <?php echo $item->createDate; ?></p>
                <p><b>Temel Rol :</b> <?php echo ($item->base_role == 1) ? 'Evet' : 'Hayır'; ?></p>
            </div><!-- .widget-body -->
            <div class="panel-footer">
                <p>Rolü silmek istediğinizden emin misiniz! (Bu işlem geri alınamaz!)</p>
                <a href="<?php echo base_url(); ?>index.php/users/role_delete/<?php echo $item->id; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>&nbsp; Evet, eminim sil.</a>
                <a href="<?php echo base_url(); ?>index.php/users/roles" class="btn btn-primary btn-sm"><i class="fa fa-trash"></i>&nbsp; Hayır, silme.</a>
            </div>
        </div><!-- .widget -->
    </div>
</div>