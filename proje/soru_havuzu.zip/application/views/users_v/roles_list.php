<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Roller Listesi
            <a href="<?php echo base_url("index.php/users/role_add"); ?>" class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-plus"></i>&nbsp;Rol Ekle</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-custom panel-default">
            <div class="panel-body">
                <table class="table table-striped datatable" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>#ID</th>
                            <th>Rol Adı</th>
                            <th>Açıklama</th>
                            <th>Eklenme Tarihi</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($roles as $role) { ?>
                            <tr>
                                <td>#<?php echo $role->id; ?></td>
                                <td><?php echo $role->name; ?></td>
                                <td><?php echo $role->description; ?></td>
                                <td><?php echo date("d.m.Y", strtotime($role->createDate)); ?></td>
                                <td>
                                    <?php if ($role->base_role != 1) { ?>
                                        <a href="#" class="btn btn-info btn-xs"><i class="fa fa-edit"></i>
                                        </a>
                                        <a href="#" data-url="<?php echo base_url(); ?>index.php/users/role_delete/<?php echo $role->id; ?>" class="btn btn-danger btn-xs remove-btn" <?php echo $role->base_role == 1 ? 'disabled' : ''; ?>><i class="fa fa-trash"></i></a>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>