<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Rol Ekle
            <a href="<?php echo base_url("index.php/users/roles"); ?>"
               class="btn btn-outline btn-primary btn-sm pull-right">
                <i class="fa fa-list"></i> Rol Listesi</a>
        </h4>
    </div>
    <div class="col-md-12">
        <div class="panel panel-custom panel-primary">
            <div class="panel-body">
            <?php echo form_open('users/role_save');?>
                    <div class="form-group">
                        <label for="maxlength-demo-1">Rol Adı</label>
                        <input type="text" id="maxlength-demo-1" maxlength="15" class="form-control" autocomplete="off"
                               name="name" required
                               data-plugin="maxlength"
                               placeholder="Rol adı giriniz. (En fazla 15 karakter.)"
                               data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-warning', limitReachedClass: 'label label-danger' }">
                    </div>
                    <div class="form-group">
                        <label for="maxlength-demo-4">Açıklama</label>
                        <textarea required name="description" id="maxlength-demo-4" maxlength="140" autocomplete="off"
                                  class="form-control" data-plugin="maxlength"
                                  data-options="{ alwaysShow: true, threshold: 10, warningClass: 'label label-success', limitReachedClass: 'label label-danger', placement: 'bottom', message: '%charsTotal% karakterden %charsTyped% karakter kullanıldı.' }"
                                  placeholder="maksimum 140 karakter"></textarea>
                    </div>
                    <div class="form-group">
                        <input type="submit" id="submit_button" name="submit"
                               class="btn btn-primary pull-right"/>
                    </div>
                    <?php echo form_close();?>
            </div>
        </div>
    </div>
</div>