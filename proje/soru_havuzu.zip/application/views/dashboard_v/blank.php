<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="panel panel-inverse">
            <div class="panel-heading">
                <h4 class="panel-title">Ayarlar</h4>
            </div>
            <div class="panel-body">
			</div>
		</div>
	</div>
</div>