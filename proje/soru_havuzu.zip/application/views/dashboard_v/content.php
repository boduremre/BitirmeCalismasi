<div class="row">
    <?php if ($gizlilik_taahhut_onay == 0){ ?>
        <div class="col-md-12 col-sm-12">
            <div class="alert alert-warning" role="alert"><strong>Dikkat!</strong> <span>Kullanıcı Gizlilik Taahhütnamesi beyan ve kabul işlemini gerçekleştirmelisiniz!</span>
                İşlemi gerçekleştirmek için <a href="<?php echo base_url(); ?>index.php/profile#taahhutname" class="alert-link">tıklayınız.</a></div>
        </div>
    <?php } ?>
</div>
<div class="row">
    <div class="col-md-12 col-sm-12">
        <div class="widget p-md clearfix">
            <div class="pull-left">
                <h3 class="widget-title" style="margin-bottom:0px">Hoşgeldiniz,
                    Sn. <?php
                    echo $this->session->userdata('name') . ' ' . $this->session->userdata('surname');
                    if ($this->session->userdata("roleID") == 1)
                        echo " <span style='font-size: small'>(Yönetici)</span>";
                    else
                        echo " <span style='font-size: small'>(".get_user_role($this->session->userdata("roleID")).")</span>";

                    ?>
                </h3>
            </div>
            <span class="pull-right fz-lg fw-500 ">
                <?php //print_r($this->session->userdata()); echo $this->config->config["sess_expiration"]; 
                ?>
                <?php echo $this->session->userdata('user_okul'); ?>
            </span>
        </div>
    </div>

</div>
<div class="row">
    <div class="col-md-3 col-sm-6">
        <div class="widget stats-widget">
            <div class="widget-body clearfix">
                <div class="pull-left">
                    <h3 class="widget-title text-primary"><span class="counter"
                                                                data-plugin="counterUp"><?php echo $totalSoru; ?></span>
                    </h3>
                    <small class="text-color">Toplam Soru Sayısı</small>
                </div>
                <span class="pull-right big-icon watermark"><i class="fa fa-question-circle"></i></span>
            </div>
            <footer class="widget-footer bg-primary">
                <small>Sistemdeki toplam soru sayısı</small>
                <span class="small-chart pull-right" data-plugin="sparkline"
                      data-options="[4,3,5,2,1], { type: 'bar', barColor: '#ffffff', barWidth: 5, barSpacing: 2 }"></span>
            </footer>
        </div><!-- .widget -->
    </div>
    <div class="col-md-3 col-sm-6">
        <div class="widget stats-widget">
            <div class="widget-body clearfix">
                <div class="pull-left">
                    <h3 class="widget-title text-warning"><span class="counter"
                                                                data-plugin="counterUp"><?php echo $totalBekleyenSoru; ?></span>
                    </h3>
                    <small class="text-color">Onay Bekleyen Soru Sayısı</small>
                </div>
                <span class="pull-right big-icon watermark"><i class="fa fa-exclamation-circle"></i></span>
            </div>
            <footer class="widget-footer bg-warning">
                <small>Onay bekleyen soru sayısı</small>
                <span class="small-chart pull-right" data-plugin="sparkline"
                      data-options="[2,4,3,4,3], { type: 'bar', barColor: '#ffffff', barWidth: 5, barSpacing: 2 }"></span>
            </footer>
        </div><!-- .widget -->
    </div>
    <div class="col-md-3 col-sm-6">
        <div class="widget stats-widget">
            <div class="widget-body clearfix">
                <div class="pull-left">
                    <h3 class="widget-title text-danger"><span class="counter"
                                                               data-plugin="counterUp"><?php echo $totalRedSoru; ?></span>
                    </h3>
                    <small class="text-color">Red Edilen Soru Sayısı</small>
                </div>
                <span class="pull-right big-icon watermark"><i class="fa fa-times"></i></span>
            </div>
            <footer class="widget-footer bg-danger">
                <small>Red edilen soru sayısı</small>
                <span class="small-chart pull-right" data-plugin="sparkline"
                      data-options="[1,2,3,5,4], { type: 'bar', barColor: '#ffffff', barWidth: 5, barSpacing: 2 }"></span>
            </footer>
        </div><!-- .widget -->
    </div>


    <div class="col-md-3 col-sm-6">
        <div class="widget stats-widget">
            <div class="widget-body clearfix">
                <div class="pull-left">
                    <h3 class="widget-title text-success"><span class="counter"
                                                                data-plugin="counterUp"><?php echo $totalOnaylananSoru; ?></span>
                    </h3>
                    <small class="text-color">Kabul Edilen Soru Sayısı</small>
                </div>
                <span class="pull-right big-icon watermark"><i class="fa fa-check"></i></span>
            </div>
            <footer class="widget-footer bg-success">
                <small>Kabul edilen soru sayısı</small>
                <span class="small-chart pull-right" data-plugin="sparkline"
                      data-options="[5,4,3,5,2],{ type: 'bar', barColor: '#ffffff', barWidth: 5, barSpacing: 2 }"></span>
            </footer>
        </div><!-- .widget -->
    </div>
</div><!-- .row -->
<div class="row">
    <div class="col-md-7">
        <div class="widget">
            <header class="widget-header">
                <h4 class="widget-title">Duyurular</h4>
            </header>
            <hr class="widget-separator"/>
            <div class="widget-body">
                <div class="streamline">
                    <?php
                    foreach ($notifies as $notify) { ?>
                        <div class="sl-item sl-warning">
                            <div class="sl-content">
                                <small class="text-muted">
                                    <?php echo date("d.m.Y H:i:s", strtotime($notify->kayit_tarihi)); ?>
                                </small>
                                <p>
                                    <?php echo $notify->ozet; ?>
                                </p>
                            </div>
                        </div>
                        <?php
                    } ?>

                </div>
                <table class="table">
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div><!-- .widget -->
        <div class="widget">
            <header class="widget-header">
                <h4 class="widget-title">Son Ziyaretler</h4>
            </header>
            <hr class="widget-separator"/>
            <div class="widget-body">
                <table class="table">
                    <thead>
                    <tr>
                        <th>Tarih Saat</th>
                        <th>IP Adresi</th>
                        <th class="visible-md visible-lg">Tarayıcı ve İşletim Sistemi</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    foreach ($loginLogs as $item) { ?>
                        <tr>
                            <td><?php echo date("d.m.Y H:i:s", strtotime('+1 hours', strtotime($item->logDate))); ?></td>
                            <td><?php echo $item->ip; ?></td>
                            <td class="visible-md visible-lg">
                                <?php

                                if (strpos($item->browser, "Chrome") !== false) {
                                    echo "Google Chrome";
                                } else if (strpos($item->browser, "Firefox") !== false) {
                                    echo "Mozilla Firefox";
                                } else if (strpos($item->browser, "Safari") !== false) {
                                    echo "Safari";
                                }
                                echo ' - ' . $item->platform;
                                ?>
                            </td>
                        </tr>
                        <?php
                    } ?>
                    </tbody>
                </table>
            </div>
        </div><!-- .widget -->
    </div><!-- END column -->

    <div class="col-md-5">
        <div class="widget">
            <div class="widget-body p-b-0">
                <div id="fullcalendar" style=""></div>
            </div>
        </div><!-- .widget -->
    </div>
</div><!-- .row -->