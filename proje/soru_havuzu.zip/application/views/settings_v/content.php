<div class="row">
    <div class="col-sm-9 col-md-9">
        <div class="panel panel-inverse">
            <div class="panel-heading">
                <h4 class="panel-title">Ayarlar</h4>
            </div>
            <div class="panel-body">
                <?php echo form_open('settings/update', 'name="frmAyarGuncelle" class="form-horizontal"'); ?>
                <input type="hidden" name="id" value="<?php echo $site_bilgileri[0]->id; ?>"/>
                <div class="form-group">
                    <label for="site_adi" class="col-sm-4 control-label">Site Adı</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" id="site_adi" name="site_adi"
                               value="<?php echo $site_bilgileri[0]->site_adi; ?>">
                    </div><!-- END column -->
                </div><!-- .form-group -->
                <div class="form-group">
                    <label for="site_slogani" class="col-sm-4 control-label">Site Sloganı</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" id="site_slogani" name="site_slogani"
                               value="<?php echo $site_bilgileri[0]->site_slogani; ?>">
                    </div><!-- END column -->
                </div><!-- .form-group -->
                <div class="form-group">
                    <label for="firma_adi" class="col-sm-4 control-label">Firma/Şirket/Kurum</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" id="firma_adi" name="firma_adi"
                               value="<?php echo $site_bilgileri[0]->firma_adi; ?>">
                    </div><!-- END column -->
                </div><!-- .form-group -->
                <div class="form-group">
                    <label for="firma_sorumlusu" class="col-sm-4 control-label">Firma/Şirket/Kurum Yetkili</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" id="firma_sorumlusu" name="firma_sorumlusu"
                               value="<?php echo $site_bilgileri[0]->firma_sorumlusu; ?>">
                    </div><!-- END column -->
                </div><!-- .form-group -->
                <div class="form-group">
                    <label for="firma_gsm" class="col-sm-4 control-label">Cep Telefonu (Yetkili)</label>
                    <div class="col-sm-6">
                        <input type="tel" class="form-control" id="firma_gsm" name="firma_gsm"
                               value="<?php echo $site_bilgileri[0]->firma_gsm; ?>">
                    </div><!-- END column -->
                </div><!-- .form-group -->
                <div class="form-group">
                    <label for="firma_eposta" class="col-sm-4 control-label">Eposta</label>
                    <div class="col-sm-6">
                        <input type="email" class="form-control" id="firma_eposta" name="firma_eposta"
                               value="<?php echo $site_bilgileri[0]->firma_eposta; ?>">
                    </div><!-- END column -->
                </div><!-- .form-group -->
                <div class="form-group">
                    <label for="firma_tel1" class="col-sm-4 control-label">Telefon</label>
                    <div class="col-sm-6">
                        <input type="tel" class="form-control" id="firma_tel1" name="firma_tel1"
                               value="<?php echo $site_bilgileri[0]->firma_tel1; ?>">
                    </div><!-- END column -->
                </div><!-- .form-group -->
                <div class="form-group">
                    <label for="firma_adres" class="col-sm-4 control-label">Adres</label>
                    <div class="col-sm-6">
                        <textarea id="firma_adres"
                                  name="firma_adres"
                                  class="form-control"><?php echo $site_bilgileri[0]->firma_adres; ?></textarea>
                    </div><!-- END column -->
                </div><!-- .form-group -->
                <div class="form-group">
                    <label for="site_aktif" class="col-sm-4 control-label">Site Durumu</label>
                    <div class="col-sm-6">
                        <select id="site_aktif" name="site_aktif" class="form-control">
                            <option value="0">Seçiniz...</option>
                            <option value="1" <?php echo $site_bilgileri[0]->site_aktif == 1 ? "selected" : ""; ?>>
                                Aktif
                            </option>
                            <option value="-1" <?php echo $site_bilgileri[0]->site_aktif == -1 ? "selected" : ""; ?>>
                                Pasif
                            </option>
                        </select>
                    </div><!-- END column -->
                </div><!-- .form-group -->
                <div class="row">
                    <div class="col-sm-10 ">
                        <button type="submit" class="btn btn-success pull-right">Güncelle</button>
                    </div>
                </div>
                <?php echo form_close(); ?>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div>
    <!-- END column -->
    <div class="col-sm-3 col-md-3">
        <div class="panel panel-inverse">
            <div class="panel-heading">
                <h4 class="panel-title">Temp Klasörü</h4>
            </div>
            <div class="panel-body">
                <p>Temp klasörünü <a
                            href="<?php echo base_url(); ?>index.php/settings/tmpDirDelete">temizle</a>...</p>
                <p style="color:red; font-size: small;"><span>DİKKAT: </span>Bu işlem geri alınamaz!</p>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
        <div class="panel panel-inverse">
            <div class="panel-heading">
                <h4 class="panel-title">Uploads Klasörü</h4>
            </div>
            <div class="panel-body">
                <p>Uploads klasörünü <a
                            href="<?php echo base_url(); ?>index.php/settings/uploadsDirDelete">temizle</a>...</p>
                <p style="color:red; font-size: small;"><span>DİKKAT: </span>Bu işlem geri alınamaz!</p>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div><!-- END column -->
</div>