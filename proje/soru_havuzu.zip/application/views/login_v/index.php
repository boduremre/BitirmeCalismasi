<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Düzce ÖDM - Giriş</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Admin, Dashboard, Bootstrap"/>
    <link rel="shortcut icon" sizes="196x196" href="<?php echo base_url(); ?>assets/images/logo.png">

    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/libs/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet"
          href="<?php echo base_url(); ?>assets/libs/material-design-iconic-font/dist/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/libs/animate.css/animate.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/core.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/misc-pages.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/libs/iziToast/dist/css/iziToast.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300">
</head>
<body class="simple-page">
<div class="simple-page-wrap">
    <div class="simple-page-logo animated swing">
        <a href="<?php echo base_url(); ?>">
            <span><i class="fa fa-gg"></i></span>
            <span>SORU HAVUZU</span>
        </a>
    </div><!-- logo -->
    <div class="simple-page-form animated flipInY" id="login-form">
        <h4 class="form-title m-b-xl text-center">Hesabınızla Giriş Yapın</h4>
        <?php if(!empty(validation_errors())){ ?>
        <div class="alert alert-danger" role="alert">
        <?php echo validation_errors(); ?>
        </div>
        <?php } ?>
        <?php echo form_open('login/dologin');?>
            <div class="form-group">
                <input id="sign-in-email" name="username" type="text" class="form-control" placeholder="Kullanıcı Adı"
                        autocomplete="off">
            </div>

            <div class="form-group">
                <input id="sign-in-password" name="password" type="password" class="form-control" placeholder="Şifre"
                        autocomplete="off">
            </div>

            <div class="form-group m-b-xl">
                <div class="checkbox checkbox-primary">
                    <input type="checkbox" id="keep_me_logged_in" name="keep_me_logged_in"/>
                    <label for="keep_me_logged_in">Beni Hatırla</label>
                </div>
            </div>
            <input type="submit" class="btn btn-primary" value="GİRİŞ" />
        <?php echo form_close();?>
    </div><!-- #login-form -->

    <div class="simple-page-footer">
        <p><a href="<?php echo base_url(); ?>index.php/login/forget_password">Parolanızı mı unuttunuz?</a></p>
        <!-- <p>
		<small>Hesabınız yok mu?</small>
		<a href="<?php echo base_url(); ?>">HESAP OLUŞTUR</a>
	</p>-->
    </div><!-- .simple-page-footer -->
</div><!-- .simple-page-wrap -->
<script src="<?php echo base_url("assets"); ?>/libs/jquery/dist/jquery.js"></script>
<script src="<?php echo base_url("assets"); ?>/libs/iziToast/dist/js/iziToast.min.js"></script>
<?php $this->load->view("includes/alert"); ?>
</body>
</html>