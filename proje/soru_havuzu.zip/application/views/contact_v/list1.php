<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="panel panel-inverse">
            <div class="panel-heading">
                <h4 class="panel-title">Destek Merkezi Taleplerim</h4>
            </div>
            <div class="panel-body">
                <table class="table table-striped datatable" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Konu</th>
                            <!--                        <th>Mesaj</th>-->
                            <th>Başlık</th>
                            <th>Kayıt Tarihi</th>
                            <th>İletildi</th>
                            <!--                        <th>Cevap Tarihi</th>-->
                            <th>Cevaplandı</th>
                            <!--                        <th>Cevap Mesajı</th>-->
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item) { ?>
                            <tr>
                                <td style="text-align: center">
                                    <!--                                <option value="1">Öneri</option>-->
                                    <!--                                <option value="2">Şikayet</option>-->
                                    <!--                                <option value="3">Bilgi Edinme</option>-->
                                    <!--                                <option value="4">Teşekkür</option>-->
                                    <?php
                                    if ($item->konu == 1)
                                        echo '<span class="label label-primary">Öneri</span>';
                                    if ($item->konu == 2)
                                        echo '<span class="label label-danger">Şikayet</span>';
                                    if ($item->konu == 3)
                                        echo '<span class="label label-info">Bilgi Edinme</span>';
                                    if ($item->konu == 4)
                                        echo '<span class="label label-success">Teşekkür</span>';
                                    if ($item->konu == 5)
                                        echo '<span class="badge badge-warning">Diğer</span>';
                                    ?>
                                </td>
                                <!--                            <td>-->
                                <!--                                --><?php
                                                                        //                                if (strlen($item->mesaj) > 120) {
                                                                        //                                    echo substr($item->mesaj, 0, 120);
                                                                        //                                    echo '<a href="javascript:;"
                                                                        //                                   data-toggle="tooltip"
                                                                        //                                   data-placement="bottom"
                                                                        /*                                   title="<?php echo $item->mesaj; ?>">devamı...</a>';*/
                                                                        //                                } else
                                                                        //                                    echo $item->mesaj;
                                                                        //                                
                                                                        ?>
                                <!--                            </td>-->
                                <td><?php echo $item->baslik; ?></td>
                                <td><?php echo date("d.m.Y H:i:s", strtotime($item->kayit_tarihi)); ?></td>
                                <td>
                                    <?php
                                    if ($item->okundu_bilgisi == 1) {
                                        echo '<input id="switch-0-\' . $item->id . \'" type="checkbox" data-switchery data-size="small" checked readonly/>';
                                    } else {
                                        echo '<input id="switch-0-' . $item->id . '" type="checkbox" data-switchery data-size="small" readonly/>';
                                    } ?>
                                </td>
                                <!--                            <td>-->
                                <!--                                --><?php
                                                                        //                                if ($item->cevap_tarihi == '0000-00-00')
                                                                        //                                    echo '<span class="badge badge-warning">Cevaplanmadı</span>';
                                                                        //                                else
                                                                        //                                    echo date("d.m.Y", strtotime($item->cevap_tarihi));
                                                                        //                                
                                                                        ?>
                                <!--                            </td>-->
                                <td>
                                    <?php
                                    if ($item->cevaplanma_durumu == 1) {
                                        echo '<input id="switch-0-\' . $item->id . \'" type="checkbox" data-switchery data-size="small" checked readonly/>';
                                    } else {
                                        echo '<input id="switch-0-' . $item->id . '" type="checkbox" data-switchery data-size="small" readonly/>';
                                    } ?>
                                </td>
                                <!--                            <td>-->
                                <!--                                --><?php
                                                                        //                                if ($item->cevap_mesaji == '')
                                                                        //                                    echo '<button data-message-id="' . $item->id . '" id="mesaj_cevapla" type="button" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i>&nbsp;Cevapla</button>';
                                                                        //                                else {
                                                                        //                                    if (strlen($item->mesaj) > 120) {
                                                                        //                                        echo substr($item->cevap_mesaji, 0, 120);
                                                                        //                                        echo '  <a href="javascript:;"
                                                                        //                                           data-toggle="tooltip"
                                                                        //                                           data-placement="bottom"
                                                                        //                                           title="' . $item->cevap_mesaji . '">devamı...</a>';
                                                                        //                                    }else
                                                                        //                                        echo $item->cevap_mesaji;
                                                                        //                                }
                                                                        //                                
                                                                        ?>
                                <!--                            </td>-->
                                <!--                            <td>-->
                                <!--                                <input-->
                                <!--                                        data-url="-->
                                <?php //echo base_url("index.php/dashboard/isspammessagesetter/$item->id"); 
                                ?>
                                <!--"-->
                                <!--                                        class="isActive"-->
                                <!--                                        type="checkbox"-->
                                <!--                                        data-switchery-->
                                <!--                                        data-size="small"-->
                                <!--                                        data-color="#10c469"-->
                                <!--                                        readonly-->
                                <!--                                --><?php //echo ($item->spam_mesaj == 1) ? "checked" : ""; 
                                                                        ?>
                                <!---->
                                <!--                            </td>-->
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="<?php echo base_url(); ?>index.php/contact/detail/<?php echo $item->id; ?>" class="btn btn-primary btn-sm" data-toggle="tooltip" title="Oku">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                        <!--                                    <a href="-->
                                        <?php //echo base_url(); 
                                        ?>
                                        <!--index.php/dashboard/contactmodulemessagedelete/-->
                                        <?php //echo $item->id; 
                                        ?>
                                        <?php if ($item->cevaplanma_durumu == 0) { ?>
                                        <a href="<?php echo base_url(); ?>index.php/contact/delete/<?php echo $item->id; ?>"
                                           class="btn btn-danger btn-xs" data-toggle="tooltip" title="Sil">
                                            <i class="fa fa-trash"></i>
                                            <?php } ?>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer">
                <a href="<?php echo base_url(); ?>index.php/contact/add" class="btn btn-primary" data-toggle="tooltip" title="Talep Ekle">
                    <i class="fa fa-pencil"></i> Talep Ekle
                </a>
            </div>
        </div>
    </div>
</div>