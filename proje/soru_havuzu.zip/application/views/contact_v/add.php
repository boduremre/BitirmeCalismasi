<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            İletişim Mesajı Oku
            <?php if ($this->session->userdata("is_admin") == "1") { ?>
                <a href="<?php echo base_url("index.php/contact/index"); ?>" class="btn btn-outline btn-primary btn-sm pull-right">
                    <i class="fa fa-angle-left"></i> Geri Dön</a>
            <?php } else { ?>
                <a href="<?php echo base_url("index.php/contact/index"); ?>" class="btn btn-outline btn-primary btn-sm pull-right">
                    <i class="fa fa-angle-left"></i> Geri Dön</a>
            <?php } ?>
        </h4>
    </div>

</div>
<div class="row" id="message-row">
    <div class="col-md-12">
        <div class="panel panel-custom panel-default">
            <div class="panel-body">
                <?php echo form_open('contact/save'); ?>
                <div class="form-group">
                    <label class="control-label">Konu</label>
                    <select id="konu" name="konu" class="form-control" data-plugin="select2" style="width: 100%" required>
                        <option value="">Seçiniz...</option>
                        <option value="1">Öneri</option>
                        <option value="2">Şikayet</option>
                        <option value="3">Bilgi Edinme</option>
                        <option value="4">Teşekkür</option>
                        <option value="5">Diğer</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-1">Başlık</label>
                    <input type="text" class="form-control" name="baslik" />
                </div>
                <div class="form-group">
                    <label for="maxlength-demo-3">Mesaj</label>
                    <textarea class="form-control m-0 ckeditorClass" name="icerik" id="icerik"></textarea>
                </div>
                <div class="form-group">
                    <input type="submit" id="submit_button" name="submit" class="btn btn-primary pull-right" />
                </div>
                <?php echo form_close(); ?>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div>
</div>