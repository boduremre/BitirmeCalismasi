<?php

class User_model extends CI_Model
{
    public $tableName = "users";

    public function __construct()
    {
        parent::__construct();
    }

    public function get($where = array())
    {
        //        echo $this->db->last_query();
        $this->db->select('users.*, roles.name as role_name, roles.description as role_description, okullar.KURUM_ADI as okul, dersler.adi as brans');
        $this->db->join('roles', 'users.roleID = roles.id');
        $this->db->join('okullar', 'users.kurum_kodu = okullar.KURUM_KODU');
        $this->db->join('dersler', 'users.bransID = dersler.id');
        return $this->db->where($where)->get($this->tableName)->row();
    }

    public function get_profile($where = array())
    {
        //echo $this->db->last_query();
        $this->db->select('users.*, okullar.KURUM_ADI as okul, dersler.adi as brans');
        $this->db->join('okullar', 'users.kurum_kodu = okullar.KURUM_KODU');
        $this->db->join('dersler', 'users.bransID = dersler.id');
        return $this->db->where($where)->get($this->tableName)->row();
    }

    /** Tüm Kayıtları bana getirecek olan metot.. */
    public function get_all($where = array(), $order = "id ASC")
    {
        $this->db->select('users.*, roles.name as role_name, roles.description as role_description');
        $this->db->join('roles', 'users.roleID = roles.id');
        return $this->db->where($where)->order_by($order)->get($this->tableName)->result();
    }

    public function add($data = array())
    {
        return $this->db->insert($this->tableName, $data);
    }

    public function addThenGetID($data = array())
    {
        $this->db->insert($this->tableName, $data);
        return $this->db->insert_id();
    }

    public function update($where = array(), $data = array())
    {
        return $this->db->where($where)->update($this->tableName, $data);
    }

    public function delete($where = array())
    {
        return $this->db->where($where)->delete($this->tableName);
    }
}
