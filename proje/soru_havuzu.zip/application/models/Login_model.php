<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model
{

    public function login($data = array())
    {
        $tableName = "users";
        $this->db->select("users.*, okullar.KURUM_ADI");
        $this->db->join('okullar', 'users.KURUM_KODU = okullar.KURUM_KODU');;
        $this->db->where('username', $data['username']); //bu method ile username değeri formdaki username ile eşleşen,
        $this->db->where('md5_password', $data['md5_password']); //password değeri formdaki password field ile eşleşen satırları,
        $this->db->where('isActive', 1);
        $query = $this->db->get($tableName); //users tablosundan çekiyoruz.

        if ($query->num_rows() == 1)
            return $query->result_array();
        else
            return array();
    }

    public function insertUserLogins($data = array())
    {
        return $this->db->insert('user_logins', $data);
    }
}
