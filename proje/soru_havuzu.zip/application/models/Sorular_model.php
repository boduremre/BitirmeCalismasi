<?php

class Sorular_model extends CI_Model
{
    public $tableName = "sorular";

    public function __construct()
    {
        parent::__construct();
    }

    public function get($where = array())
    {
        $this->db->select('users.name, users.surname, users.email, users.kurum_kodu, users.tel, okullar.KURUM_ADI as okul,  sorular.*, dersler.adi as ders_adi');
        $this->db->select('uniteler.unite_kodu, uniteler.unite_icerik');
        $this->db->select('konular.konu_kodu, konular.konu_icerik');
        $this->db->select('kazanimlar.kazanim_icerik, kazanimlar.kazanim_kodu');
        $this->db->join('users', 'users.id = sorular.userID');
        $this->db->join('dersler', 'dersler.id = sorular.dersID');
        $this->db->join('okullar', 'okullar.KURUM_KODU = users.kurum_kodu');
        $this->db->join('uniteler', 'uniteler.id = sorular.uniteID');
        $this->db->join('konular', 'konular.id = sorular.konuID');
        $this->db->join('kazanimlar', 'kazanimlar.id = sorular.kazanimID');
        $this->db->from($this->tableName);
        $this->db->where($where);
        $this->db->where('onay_durumu !=', "0");
        return $this->db->get()->row();
    }

    public function get_all()
    {
        $this->db->select('users.name, users.surname, sorular.*, dersler.adi as ders_adi, kazanimlar.kazanim_icerik, kazanimlar.kazanim_kodu');
        $this->db->from($this->tableName);
        $this->db->where('onay_durumu !=', "0");
        $this->db->join('users', 'users.id = sorular.userID');
        $this->db->join('dersler', 'dersler.id = sorular.dersID');
        $this->db->join('kazanimlar', 'kazanimlar.id = sorular.kazanimID');
        $this->db->order_by('kayit_tarihi DESC');
        return $this->db->get()->result();
    }

    public function get_all_w($where = array(), $order = "sorular.id DESC")
    {
        $this->db->select('users.name, users.surname, sorular.*, dersler.adi as ders_adi, kazanimlar.kazanim_icerik, kazanimlar.kazanim_kodu');
        $this->db->join('users', 'users.id = sorular.userID');
        $this->db->join('dersler', 'dersler.id = sorular.dersID');
        $this->db->join('kazanimlar', 'kazanimlar.id = sorular.kazanimID');
        return $this->db->where($where)->order_by($order)->get($this->tableName)->result();
    }

    public function get_all_byUserID($where = array())
    {
        $this->db->select('users.name, users.surname, sorular.*, dersler.adi as ders_adi, kazanimlar.kazanim_icerik, kazanimlar.kazanim_kodu');
        $this->db->from($this->tableName);
        $this->db->join('users', 'users.id = sorular.userID');
        $this->db->join('dersler', 'dersler.id = sorular.dersID');
        $this->db->join('kazanimlar', 'kazanimlar.id = sorular.kazanimID');
        $this->db->order_by('kayit_tarihi DESC');
        return $this->db->where($where)->get()->result();
    }

    // veritabanına ekle
    public function add($data = array())
    {
        return $this->db->insert($this->tableName, $data);
    }

    public function update($dogrulama_kodu, $data = array())
    {
        //print_r($data);

        return $this->db->update('sorular', $data, array('dogrulama_kodu' => $dogrulama_kodu));
    }

    public function delete($where = array())
    {
        return $this->db->where($where)->delete($this->tableName);
    }


    public function sendupdate($dogrulama_kodu, $data = array())
    {
        //print_r($data);

        return $this->db->update('sorular', $data, array('dogrulama_kodu' => $dogrulama_kodu));
    }
}
