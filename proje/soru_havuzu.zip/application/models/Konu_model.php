<?php

class Konu_model extends CI_Model
{
    public $tableName = "konular";

    public function __construct()
    {
        parent::__construct();
    }

    public function get($where = array())
    {
        $this->db->select('*');
        $this->db->from($this->tableName);
        $this->db->join('users', 'users.id = sorular.userID');
        $this->db->where($where);

        return $this->db->get()->row();
    }

    public function get_all()
    {
        $this->db->select('*');
        $this->db->from($this->tableName);
		$this->db->where('onay_durumu !=',"0");
        $this->db->join('users', 'users.id = sorular.userID');
		$this->db->order_by('kayit_tarihi DESC');
        return $this->db->get()->result();
    }

    public function get_all_w($where = array(), $order = "uniteID ASC, konu_kodu ASC")
    {
        return $this->db->where($where)->order_by($order)->get($this->tableName)->result();
    }

    public function get_all_byUserID($userID)
    {
        $this->db->select('*')->from($this->tableName)->join('users', 'users.id = sorular.userID');
        return $this->db->where($userID)->get()->result();
    }

    public function add($data = array())
    {
        return $this->db->insert($this->tableName, $data);
    }

    public function update($dogrulama_kodu, $data = array())
    {
		//print_r($data);
        
		return $this->db->update('sorular', $data, array('dogrulama_kodu' => $dogrulama_kodu));
    }

    public function delete($where = array())
    {
        return $this->db->where($where)->delete($this->tableName);
    }
	
	
	public function sendupdate($dogrulama_kodu, $data = array())
    {
		//print_r($data);
        
		return $this->db->update('sorular', $data, array('dogrulama_kodu' => $dogrulama_kodu));
    }
}
