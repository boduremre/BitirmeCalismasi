<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Okullar_model extends CI_Model
{
    public $tableName = "okullar";

    public function get()
    {
        $this->db->select('okullar.id,okullar.kurum_kodu, okullar.kurum_adi, okullar.eposta, okullar.telefon, okullar.mudur, okullar.mudur, okullar.ilce_id, city.CityName as il_adi, town.TownName as ilce_adi');
        $this->db->from('okullar');
        $this->db->join('city', 'okullar.IL_ID = city.CityID');
        $this->db->join('town', 'okullar.ILCE_ID = town.TownID');
        $this->db->order_by('ilce_adi', 'ASC');
        $this->db->order_by('kurum_kodu', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function getByCityTownID($CityID, $TownID)
    {
        $this->db->select('okullar.id,okullar.kurum_kodu, okullar.kurum_adi, okullar.eposta, okullar.telefon, okullar.mudur, okullar.mudur, okullar.ilce_id, city.CityName as il_adi, town.TownName as ilce_adi');
        $this->db->from('okullar');
        $this->db->where('okullar.IL_ID', $CityID);
        $this->db->where('okullar.ILCE_ID', $TownID);
        $this->db->join('city', 'okullar.IL_ID = city.CityID');
        $this->db->join('town', 'okullar.ILCE_ID = town.TownID');
        $this->db->order_by('ilce_adi', 'ASC');
        $this->db->order_by('kurum_kodu', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function getByID($ID)
    {
        $this->db->select('okullar.ID, okullar.kurum_adi, okullar.kurum_kodu, okullar.il_id, okullar.ilce_id, okullar.adres, okullar.eposta, okullar.eposta2,okullar.telefon, okullar.web,city.CityName as il_adi, town.TownName as ilce_adi');
        $this->db->from($this->tableName);
        $this->db->where('okullar.id', $ID);
        $this->db->join('city', 'okullar.IL_ID = city.CityID');
        $this->db->join('town', 'okullar.ILCE_ID = town.TownID');
        return $this->db->get()->row();
    }

    public function getBySinavID($sinavID)
    {
        $this->db->select('okullar.kurum_adi, okullar.kurum_kodu, city.CityName, town.TownName');
        $this->db->from($this->tableName);
        $this->db->where('sinav_id', $sinavID);
        $this->db->join('okullar', 'okullar_sinavlar.kurum_kodu = okullar.kurum_kodu');
        $this->db->join('city', 'okullar.IL_ID = city.CityID');
        $this->db->join('town', 'okullar.ILCE_ID = town.TownID');
        $this->db->join('sinavlar', 'okullar_sinavlar.sinav_id = sinavlar.id');
        $this->db->order_by('TownName', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function getForHtmlSelect()
    {
        $this->db->select('kurum_kodu, kurum_adi, town.TownName');
        $this->db->from($this->tableName);
        $this->db->join('town', 'okullar.ILCE_ID = town.TownID');
        $this->db->order_by('TownName', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function update($id, $data = array())
    {
        return $this->db->update($this->tableName, $data, array('id' => $id));
    }

    public function delete($where = array())
    {
        return $this->db->where($where)->delete($this->tableName);
    }
}