<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Settings extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!get_logged_user())
            redirect(base_url("index.php/login"));

        $this->load->model("setting_model");
    }

    public function index()
    {
        $viewData = new stdClass();
        $viewData->title = 'Ayarlar';
        $viewData->menuAktif = 'Ayarlar';
        $viewData->viewFolder = 'settings_v';
        $viewData->subpage = 'content';

        // ayarlar veri tabanından getiriliyor.
        $viewData->site_bilgileri = $this->setting_model->get_all();
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function update()
    {
        $form_values = array(
            "site_adi" => $this->input->post("site_adi"),
            "site_slogani" => $this->input->post("site_slogani"),
            "firma_adi" => $this->input->post("firma_adi"),
            "firma_sorumlusu" => $this->input->post("firma_sorumlusu"),
            "firma_gsm" => $this->input->post("firma_gsm"),
            "firma_eposta" => $this->input->post("firma_eposta"),
            "firma_tel1" => $this->input->post("firma_tel1"),
            "firma_adres" => $this->input->post("firma_adres"),
            "site_aktif" => $this->input->post("site_aktif")
        );

        $this->load->model("setting_model");
        $update_settings = $this->setting_model->update(array('id' => $this->input->post("id")), $form_values);
        RedirectWithMessage($update_settings, "Ayarlar başarılı bir şekilde güncellendi!", "Ayarlar Güncellenemedi!", 'index.php/settings');
    }

    /**
     * @desc: Belirtilen dizin içeriğini temizler.
     * @link : https://stackoverflow.com/questions/16761264/delete-all-files-in-one-directory-with-codeigniter
     */
    public function tmpDirDelete()
    {
        $this->load->helper('file');
        $files = glob($_SERVER['DOCUMENT_ROOT'] . '/soruhavuzu/tmp/*');

        foreach ($files as $file) {
            if (is_file($file))
                unlink($file); // delete file
        }

        $files2 = glob($_SERVER['DOCUMENT_ROOT'] . '/soruhavuzu/tmp/*');
        RedirectWithMessage(count($files2) == 0, "tmp Klasörü Temizlendi!", "tmp Klasörü Temizlenemedi!", 'index.php/settings');
    }

    /**
     * @desc: Belirtilen dizin içeriğini temizler.
     * @link : https://stackoverflow.com/questions/16761264/delete-all-files-in-one-directory-with-codeigniter
     */
    public function uploadsDirDelete()
    {
        $this->load->helper('file');
        $files = glob($_SERVER['DOCUMENT_ROOT'] . '/soruhavuzu/uploads/*');

        foreach ($files as $file) {
            if (is_file($file))
                unlink($file); // delete file
        }

        $files2 = glob($_SERVER['DOCUMENT_ROOT'] . '/soruhavuzu/uploads/*');
        RedirectWithMessage(count($files2) == 0, "Uploads Klasörü Temizlendi!", "Uploads Klasörü Temizlenemedi!", 'index.php/settings');
    }
}
