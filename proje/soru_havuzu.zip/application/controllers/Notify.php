<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notify extends CI_Controller
{
    public $user_id;

    public function __construct()
    {
        parent::__construct();
        if (!get_logged_user())
            redirect(base_url("index.php/login"));

        $this->user_id = $this->session->userdata("id");
        $this->load->model("user_model");
        $this->load->model("notify_model");
    }

    public function index()
    {
        $viewData = new stdClass();
        $items = $this->notify_model->get_all();
        $viewData->items = $items;
        $viewData->title = 'Duyurular Modülü';
        $viewData->menuAktif = 'Duyuru';
        $viewData->viewFolder = 'notify_v';
        $viewData->subpage = 'list';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function add()
    {
        $viewData = new stdClass();
        $viewData->title = 'Duyurular Modülü - Duyuru Ekle';
        $viewData->menuAktif = 'Duyuru';
        $viewData->viewFolder = 'notify_v';
        $viewData->subpage = 'add';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function edit($id)
    {
        $viewData = new stdClass();
        $item = $this->notify_model->get(array('id' => $id));
        $viewData->title = 'Duyurular Modülü - Duyuru Düzenle';
        $viewData->viewFolder = 'notify_v';
        $viewData->menuAktif = 'Duyuru';
        $viewData->item = $item;
        $viewData->subpage = 'edit';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function detail($id)
    {
        $viewData = new stdClass();
        $item = $this->notify_model->get(array('id' => $id));
        $viewData->title = 'Duyurular Modülü - Duyuru Oku';
        $viewData->viewFolder = 'notify_v';
        $viewData->menuAktif = 'Duyuru';
        $viewData->item = $item;
        $viewData->subpage = 'read';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function deleteconfirm($id)
    {
        $viewData = new stdClass();
        $item = $this->notify_model->get(array('id' => $id));
        $viewData->title = 'Duyurular Modülü - Duyuru Sil';
        $viewData->viewFolder = 'notify_v';
        $viewData->menuAktif = 'Duyuru';
        $viewData->item = $item;
        $viewData->subpage = 'delete';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function delete($id)
    {
        $delete = $this->notify_model->delete(array('id' => $id));
        if ($delete)
            redirect(base_url('index.php/notify/index'));
    }

    public function update()
    {
        $form_values = array(
            "baslik" => $this->input->post("baslik"),
            "ozet" => $this->input->post("ozet"),
            "icerik" => $this->input->post("icerik"),
            "anahtar_kelimeler" => $this->input->post("anahtar_kelimeler"),
            "aktif" => $this->input->post("aktif") == 'on' ? 1 : 0,
            "guncelleme_tarihi" => date('Y-m-d H:i:s')
        );

        $update = $this->notify_model->update(array('id' => $this->input->post("id")), $form_values);
        if ($update) {
            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Duyuru Başarıyla Güncellendi.",
                "type"  => "success"
            );
        }else{
            $alert = array(
                "title" => "İşlem Başarısız!",
                "text" => "Duyuru Güncellenemedi.",
                "type"  => "error"
            );
        }

        // İşlemin Sonucunu Session'a yazma işlemi...
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('index.php/notify/index'));
    }

    public function save()
    {
        $form_values = array(
            "baslik" => $this->input->post("baslik"),
            "ozet" => $this->input->post("ozet"),
            "icerik" => $this->input->post("icerik"),
            "anahtar_kelimeler" => $this->input->post("anahtar_kelimeler"),
            "aktif" => $this->input->post("aktif") == 'on' ? 1 : 0
        );

        $insert = $this->notify_model->add($form_values);
        if ($insert) {
            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Duyuru Başarıyla Eklendi.",
                "type"  => "success"
            );
        }else{
            $alert = array(
                "title" => "İşlem Başarısız!",
                "text" => "Duyuru Eklenemedi.",
                "type"  => "error"
            );
        }

        // İşlemin Sonucunu Session'a yazma işlemi...
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('index.php/notify/index'));
    }
}
