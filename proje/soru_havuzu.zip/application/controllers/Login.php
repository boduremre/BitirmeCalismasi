<?php defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{
    public $viewFolder = "login_v";

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('security');
    }

    public function index()
    {
        if (get_logged_user())
            redirect(base_url('index.php'));

        $this->load->view("{$this->viewFolder}/index");
    }

    public function forget_password()
    {
        if (get_logged_user())
            redirect(base_url());

        $this->load->view("{$this->viewFolder}/vPasswordForget");
    }

    public function send_password()
    {
        if (get_logged_user())
            redirect(base_url());

        $this->load->view("{$this->viewFolder}/vPasswordForget");
    }

    /**
     * @link https://www.cloudways.com/blog/send-email-codeigniter-smtp/
     */
    public function resetpassword()
    {
        if (get_logged_user())
            redirect(base_url('index.php'));

        $this->load->library('form_validation');

        $this->form_validation->set_rules('email', 'E-posta adresi', 'trim|required|valid_email');

        $this->form_validation->set_message(
            array(
                "required" => "{field} alanı doldurulmalıdır.",
                "valid_email" => "Lütfen geçerli bir e-posta adresi giriniz."
            )
        );

        if ($this->form_validation->run() == FALSE) {
            $this->load->view("{$this->viewFolder}/vPasswordForget");
        } else {
            $this->load->model("user_model");
            $user_mail = $this->input->post('email', TRUE);

            $data = array(
                'email' => $user_mail
            );

            $result = $this->user_model->get($data);

            if (empty($result) == FALSE) {
                $this->load->library('email');
                $config = array();
                $config['protocol'] = 'smtp';
                $config['smtp_host'] = 'smtp.emrebodur.com';
                $config['smtp_user'] = 'noreply@emrebodur.com';
                $config['smtp_pass'] = 'Qx83cmAh';
                $config['smtp_port'] = 587;
                $this->email->initialize($config);
                $this->email->set_newline("\r\n");

                $this->email->from('info@emrebodur.com', 'Soru Havuzu');
                $this->email->to($user_mail);

                $this->email->subject('Şifre Hatırlatma');
                $message = "Sn. " . $result->name . " " . $result->surname . "" . "\nKullanıcı Adı:" . $result->username . "\nŞifre:" . $result->password;
                $this->email->message($message);

                if ($this->email->send()) {
                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Şifreniz e-posta adresinize gönderildi. E-postanızı kontrol ediniz!",
                        "type" => "success"
                    );
                } else {
                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Şifreniz e-posta adresinize gönderilemedi! Tekrar deneyiniz.",
                        "type" => "error"
                    );
                }
            } else if (empty($result) == TRUE) {
                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Girilen e-posta adresine ait bir kullanıcı bulunamadı!",
                    "type" => "error"
                );
            } else {
                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Bilinmeyen bir hata meydana geldi! Daha sonra tekrar deneyin.",
                    "type" => "error"
                );
            }

            // İşlemin Sonucunu Session'a yazma işlemi...
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('index.php/login/send_password'));
        }
    }

    public function dologin()
    {
        if (get_logged_user())
            redirect(base_url('index.php'));

        $this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Kullanıcı Adı', 'trim|required');
        $this->form_validation->set_rules('password', 'Şifre', 'trim|required|max_length[8]|min_length[4]');

        $this->form_validation->set_message(
            array(
                "required" => "<b>{field}</b> alanı doldurulmalıdır.",
                "valid_email" => "Lütfen geçerli bir e-posta adresi giriniz.",
                "min_length" => "<b>{field}</b> en az 4 karakterden oluşmalıdır.",
                "max_length" => "<b>{field}</b> en fazla 8 karakterden oluşmalıdır.",
            )
        );

        if ($this->form_validation->run() == FALSE) {
            $this->load->view("{$this->viewFolder}/index");
        } else {
            $data = array(
                'username' => $this->input->post('username', TRUE),
                'md5_password' => md5($this->input->post('password', TRUE))
            );

            $result = $this->login_model->login($data);

            if (empty($result) == FALSE) {
                $admin_data = array(
                    'id' => $result[0]['id'],
                    'username' => $this->input->post('username'),
                    'name' => $result[0]['name'],
                    'surname' => $result[0]['surname'],
                    'is_admin' => $result[0]['isAdmin'],
                    'bransID' => $result[0]['bransID'],
                    'roleID' => $result[0]['roleID'],
                    'gizlilik_taahhut_onay' => $result[0]['gizlilik_taahhut_onay'],
                    'user_okul' => $result[0]['KURUM_ADI'] . ' (' . $result[0]['kurum_kodu'] . ')',
                    "logDate" => date("Y-m-d H:i:s"),
                    'is_logged_in' => TRUE
                );

                $this->login_model->insertUserLogins(array(
                    "userId" => $result[0]['id'],
                    "status" => 1, // giriş işlemi
                    "logDate" => date("Y-m-d H:i:s"),
                    "ip" => getUserIP(), //$this->input->ip_address(),
                    "platform" => $this->agent->platform(),
                    "browser" => $this->agent->browser() . ' ' . $this->agent->version()
                ));

                $this->session->set_userdata($admin_data);
                $alert = array(
                    "title" => "Hoşgeldiniz!",
                    "text" => "Sn. " . $result[0]['name'] . ' ' . $result[0]['surname'],
                    "type" => "success"
                );

                // İşlemin Sonucunu Session'a yazma işlemi...
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('index.php'));
            } else

                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Kullanıcı adı veya şifreniz hatalı!",
                    "type" => "error"
                );

            // İşlemin Sonucunu Session'a yazma işlemi...
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('index.php/login'));
            die();
        }
    }


    public function logout()
    {
        if (!get_logged_user())
            redirect(base_url('index.php/login'));

        $this->login_model->insertUserLogins(array(
            "userId" => $this->session->userdata('id'),
            "status" => 2, // giriş işlemi
            "logDate" => date("Y-m-d H:i:s"),
            "ip" => getUserIP(), //$this->input->ip_address(),
            "platform" => $this->agent->platform(),
            "browser" => $this->agent->browser() . ' ' . $this->agent->version()
        ));

        $this->session->sess_destroy();
        $this->session->unset_userdata(array('id', 'username', 'name', 'surname', 'is_admin', 'is_logged_in', 'bransID', 'roleID', 'gizlilik_taahhut_onay', 'user_okul', 'logDate'));

        redirect(base_url('index.php/login'));
    }
}