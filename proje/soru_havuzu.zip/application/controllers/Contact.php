<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Contact extends CI_Controller
{
    public $user_id;
    public $roleID;

    public function __construct()
    {
        parent::__construct();
        if (!get_logged_user())
            redirect(base_url("index.php/login"));

        $this->user_id = $this->session->userdata("id");
        $this->roleID = $this->session->userdata("roleID");
        $this->load->model("user_model");
        $this->load->model("contact_model");
        $this->load->model("dashboard_model");
    }

    public function index()
    {
        if ($this->roleID == 1) {
            $viewData = new stdClass();
            $items = $this->contact_model->get_all();
            $viewData->items = $items;
            $viewData->title = 'Ziyaretçi Defteri Modülü';
            $viewData->menuAktif = 'Iletisim';
            $viewData->viewFolder = 'contact_v';
            $viewData->subpage = 'list';
            $this->load->view("{$viewData->viewFolder}/index", $viewData);
        } else {
            redirect(base_url('index.php/contact/user_index'));
        }
    }

    public function user_index()
    {
        $viewData = new stdClass();
        $items = $this->contact_model->getAllByUserID(array('userID' => $this->user_id));
        $viewData->items = $items;
        $viewData->title = 'Destek Merkezi Modülü';
        $viewData->menuAktif = 'Iletisim';
        $viewData->viewFolder = 'contact_v';
        $viewData->subpage = 'list1';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function detail($id)
    {
        $viewData = new stdClass();
        $item = $this->contact_model->get(array('iletisim.id' => $id));
        $viewData->item = $item;
        $viewData->title = 'Ziyaretçi Defteri Modülü';
        $viewData->menuAktif = 'Iletisim';
        $viewData->viewFolder = 'contact_v';
        $viewData->subpage = 'answer';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function add()
    {
        $viewData = new stdClass();
        $viewData->title = 'Ziyaretçi Defteri Modülü';
        $viewData->menuAktif = 'Iletisim';
        $viewData->viewFolder = 'contact_v';
        $viewData->subpage = 'add';
        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }

    public function save()
    {
        $form_values = array(
            "mesaj" => $this->input->post("icerik"),
            "baslik" => $this->input->post("baslik"),
            "konu" => $this->input->post("konu"),
            "okundu_bilgisi" => 1,
            "userID" => $this->user_id,
        );

        $insert = $this->contact_model->add($form_values);
        if ($this->roleID == 1) {
            RedirectWithDefaultMessage($insert,'index.php/contact/index');
        } else {
            RedirectWithDefaultMessage($insert,'index.php/contact/user_index');
        }

    }

    public function answer_save()
    {
        $form_values = array(
            "cevap_mesaji" => $this->input->post("icerik"),
            "cevaplanma_durumu" => 1,
            "cevap_tarihi" => date('Y-m-d H:i:s')
        );

        $update = $this->contact_model->update(array("id" => $this->input->post("id")), $form_values);
        RedirectWithMessage($update, "Destek Talebi Başarıyla Cevaplandı.", "Destek Talebi Cevaplanamadı!", 'index.php/contact/index');
    }

    public function delete($id)
    {
        if (isset($id)) {
            $delete = $this->contact_model->delete(array("id" => $id));
            if ($this->roleID == 1) {
                RedirectWithMessage($delete,"Destek Talebi Başarıyla Silindi.", "Destek Talebi Silinemedi!", 'index.php/contact/index');
            } else {
                RedirectWithDefaultMessage($delete,'index.php/contact/user_index');
            }
        }
    }
}
