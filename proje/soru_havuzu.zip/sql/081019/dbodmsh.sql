-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 08 Eki 2019, 09:52:41
-- Sunucu sürümü: 10.1.38-MariaDB
-- PHP Sürümü: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `dbodmsh`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `city`
--

CREATE TABLE `city` (
  `CityID` int(11) NOT NULL,
  `CountryID` int(11) NOT NULL,
  `CityName` varchar(100) NOT NULL,
  `PlateNo` int(2) NOT NULL,
  `PhoneCode` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `city`
--

INSERT INTO `city` (`CityID`, `CountryID`, `CityName`, `PlateNo`, `PhoneCode`) VALUES
(1, 212, 'ADANA', 1, '322'),
(2, 212, 'ADIYAMAN', 2, '416'),
(3, 212, 'AFYONKARAHİSAR', 3, '272'),
(4, 212, 'AĞRI', 4, '472'),
(5, 212, 'AKSARAY', 68, '382'),
(6, 212, 'AMASYA', 5, '358'),
(7, 212, 'ANKARA', 6, '312'),
(8, 212, 'ANTALYA', 7, '242'),
(9, 212, 'ARDAHAN', 75, '478'),
(10, 212, 'ARTVİN', 8, '466'),
(11, 212, 'AYDIN', 9, '256'),
(12, 212, 'BALIKESİR', 10, '266'),
(13, 212, 'BARTIN', 74, '378'),
(14, 212, 'BATMAN', 72, '488'),
(15, 212, 'BAYBURT', 69, '458'),
(16, 212, 'BİLECİK', 11, '228'),
(17, 212, 'BİNGÖL', 12, '426'),
(18, 212, 'BİTLİS', 13, '434'),
(19, 212, 'BOLU', 14, '374'),
(20, 212, 'BURDUR', 15, '248'),
(21, 212, 'BURSA', 16, '224'),
(22, 212, 'ÇANAKKALE', 17, '286'),
(23, 212, 'ÇANKIRI', 18, '376'),
(24, 212, 'ÇORUM', 19, '364'),
(25, 212, 'DENİZLİ', 20, '258'),
(26, 212, 'DİYARBAKIR', 21, '412'),
(27, 212, 'DÜZCE', 81, '380'),
(28, 212, 'EDİRNE', 22, '284'),
(29, 212, 'ELAZIĞ', 23, '424'),
(30, 212, 'ERZİNCAN', 24, '446'),
(31, 212, 'ERZURUM', 25, '442'),
(32, 212, 'ESKİŞEHİR', 26, '222'),
(33, 212, 'GAZİANTEP', 27, '342'),
(34, 212, 'GİRESUN', 28, '454'),
(35, 212, 'GÜMÜŞHANE', 29, '456'),
(36, 212, 'HAKKARİ', 30, '438'),
(37, 212, 'HATAY', 31, '326'),
(38, 212, 'IĞDIR', 76, '476'),
(39, 212, 'ISPARTA', 32, '246'),
(40, 212, 'İSTANBUL', 34, '212-216'),
(41, 212, 'İZMİR', 35, '232'),
(42, 212, 'KAHRAMANMARAŞ', 46, '344'),
(43, 212, 'KARABÜK', 78, '370'),
(44, 212, 'KARAMAN', 70, '338'),
(45, 212, 'KARS', 36, '474'),
(46, 212, 'KASTAMONU', 37, '366'),
(47, 212, 'KAYSERİ', 38, '352'),
(48, 212, 'KIRIKKALE', 71, '318'),
(49, 212, 'KIRKLARELİ', 39, '288'),
(50, 212, 'KIRŞEHİR', 40, '386'),
(51, 212, 'KİLİS', 79, '348'),
(52, 212, 'KOCAELİ', 41, '262'),
(53, 212, 'KONYA', 42, '332'),
(54, 212, 'KÜTAHYA', 43, '274'),
(55, 212, 'MALATYA', 44, '422'),
(56, 212, 'MANİSA', 45, '236'),
(57, 212, 'MARDİN', 47, '482'),
(58, 212, 'MERSİN', 33, '324'),
(59, 212, 'MUĞLA', 48, '252'),
(60, 212, 'MUŞ', 49, '436'),
(61, 212, 'NEVŞEHİR', 50, '384'),
(62, 212, 'NİĞDE', 51, '388'),
(63, 212, 'ORDU', 52, '452'),
(64, 212, 'OSMANİYE', 80, '328'),
(65, 212, 'RİZE', 53, '464'),
(66, 212, 'SAKARYA', 54, '264'),
(67, 212, 'SAMSUN', 55, '362'),
(68, 212, 'SİİRT', 56, '484'),
(69, 212, 'SİNOP', 57, '368'),
(70, 212, 'SİVAS', 58, '346'),
(71, 212, 'ŞANLIURFA', 63, '414'),
(72, 212, 'ŞIRNAK', 73, '486'),
(73, 212, 'TEKİRDAĞ', 59, '282'),
(74, 212, 'TOKAT', 60, '356'),
(75, 212, 'TRABZON', 61, '462'),
(76, 212, 'TUNCELİ', 62, '428'),
(77, 212, 'UŞAK', 64, '276'),
(78, 212, 'VAN', 65, '432'),
(79, 212, 'YALOVA', 77, '226'),
(80, 212, 'YOZGAT', 66, '354'),
(81, 212, 'ZONGULDAK', 67, '372');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ci_session`
--

CREATE TABLE `ci_session` (
  `id` varchar(128) COLLATE utf8_turkish_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8_turkish_ci NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `ci_session`
--

INSERT INTO `ci_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('i6qcsmajun3cie4clcv09n8f8t2nqgcf', '::1', 1570477159, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303437373135393b),
('cf6mdcr3p52ph78r5eq0nqmokd3on6kl', '::1', 1570477503, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303437373530333b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('pnvdlmvfp9u1i8c2ftu1uq0bngthr93m', '::1', 1570477844, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303437373834343b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('b0cb0vbkiladq3ghse807q0943chuq8l', '::1', 1570478390, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303437383339303b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('d6jl37vseo0fb8lbtajfl3r36n3vqa2p', '::1', 1570478693, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303437383639333b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('n99cpe3qdq34pvqjjsrispre0d82lrg5', '::1', 1570479143, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303437393134333b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('fu9q5n1iua9124tg33pt4aila8novul7', '::1', 1570479143, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303437393134333b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('vsnuaftmaaugulsf6b4mn2jjo4o3pet0', '::1', 1570512900, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531323930303b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('k9mgksovkuro4p0s8cq2o3om0em4vs84', '::1', 1570513230, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531333233303b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('lnuore8dvv37mf0vh7dbangcvjmeb9s1', '::1', 1570513566, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531333536363b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('eg6tvchu052559qcko83t4tliek8nhcm', '::1', 1570514249, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531343234393b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('knjvl4hb1nuuobkis48s3focu8a6ds00', '::1', 1570514600, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531343630303b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('foc45u97fr5l6rf6rimjs8ekqvvndf6b', '::1', 1570514910, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531343931303b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('jn6hjde79nf42r5hg1i3jtjg8t1honpj', '::1', 1570515535, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531353533353b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('ppa76nm756pqriehoaeac94jm57kcglv', '::1', 1570515911, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531353931313b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('tpkpgfhfakji84aru5t1kkgrlm8epklf', '::1', 1570516251, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531363235313b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('tv5hq205o7tsi56tcff7obcqevesjmeo', '::1', 1570516561, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531363536313b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('b7vhj45vj3or24u9qhbk3meo3fk8svn1', '::1', 1570516931, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531363933313b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('gven4f95o14jrsvsfob49gv7dl781pcl', '::1', 1570517304, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531373330343b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('brdqhrdkhb6q3vvqpt8vrl8ooskmbqc4', '::1', 1570517662, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531373636323b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('hlrr7cj5nhb5iljhvpqhn8ik03055vgv', '::1', 1570518367, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531383336373b69647c733a313a2232223b757365726e616d657c733a343a22656d7265223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2230223b69735f6c6f676765645f696e7c623a313b),
('n3rpffrus25pbp3rtvgoof926qr4591e', '::1', 1570518727, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531383732373b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('alnoi43i9k64bu8264otua948iec8er7', '::1', 1570519078, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531393037383b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('0mndq5h8ce4iasqctf0iob8rfg11u6hb', '::1', 1570519466, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303531393436363b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('8020hlhj9sb2novl7du95srgearl6ujb', '::1', 1570520232, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303532303233323b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b),
('mm42svpe2tn600vqbai1hcl9boa6tm16', '::1', 1570520232, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537303532303233323b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b69735f6c6f676765645f696e7c623a313b);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `count`
--

CREATE TABLE `count` (
  `id` int(10) NOT NULL,
  `total` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `count`
--

INSERT INTO `count` (`id`, `total`, `date`, `ip`) VALUES
(5, 7, '2019-05-21', '::1');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `country`
--

CREATE TABLE `country` (
  `CountryID` int(11) NOT NULL,
  `BinaryCode` varchar(2) NOT NULL,
  `TripleCode` varchar(3) NOT NULL,
  `CountryName` varchar(100) NOT NULL,
  `PhoneCode` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `country`
--

INSERT INTO `country` (`CountryID`, `BinaryCode`, `TripleCode`, `CountryName`, `PhoneCode`) VALUES
(1, 'AF', 'AFG', 'Afghanistan', '93'),
(2, 'AL', 'ALB', 'Albania', '355'),
(3, 'DZ', 'DZA', 'Algeria', '213'),
(4, 'AS', 'ASM', 'American Samoa', '684'),
(5, 'AD', 'AND', 'Andorra', '376'),
(6, 'AO', 'AGO', 'Angola', '244'),
(7, 'AI', 'AIA', 'Anguilla', '264'),
(8, 'AQ', 'ATA', 'Antarctica', '672'),
(9, 'AG', 'ATG', 'Antigua and Barbuda', '268'),
(10, 'AR', 'ARG', 'Argentina', '54'),
(11, 'AM', 'ARM', 'Armenia', '374'),
(12, 'AW', 'ABW', 'Aruba', '297'),
(13, 'AU', 'AUS', 'Australia', '61'),
(14, 'AT', 'AUT', 'Austria', '43'),
(15, 'AZ', 'AZE', 'Azerbaijan', '994'),
(16, 'BS', 'BHS', 'Bahamas', '242'),
(17, 'BH', 'BHR', 'Bahrain', '973'),
(18, 'BD', 'BGD', 'Bangladesh', '880'),
(19, 'BB', 'BRB', 'Barbados', '246'),
(20, 'BY', 'BLR', 'Belarus', '375'),
(21, 'BE', 'BEL', 'Belgium', '32'),
(22, 'BZ', 'BLZ', 'Belize', '501'),
(23, 'BJ', 'BEN', 'Benin', '229'),
(24, 'BM', 'BMU', 'Bermuda', '441'),
(25, 'BT', 'BTN', 'Bhutan', '975'),
(26, 'BO', 'BOL', 'Bolivia', '591'),
(27, 'BA', 'BIH', 'Bosnia and Herzegovina', '387'),
(28, 'BW', 'BWA', 'Botswana', '267'),
(29, 'BR', 'BRA', 'Brazil', '55'),
(30, 'VG', 'VGB', 'British Virgin Islands', '284'),
(31, 'BN', 'BRN', 'Brunei', '673'),
(32, 'BG', 'BGR', 'Bulgaria', '359'),
(33, 'BF', 'BFA', 'Burkina Faso', '226'),
(34, 'BI', 'BDI', 'Burundi', '257'),
(35, 'KH', 'KHM', 'Cambodia', '855'),
(36, 'CM', 'CMR', 'Cameroon', '237'),
(37, 'CA', 'CAN', 'Canada', '1'),
(38, 'CV', 'CPV', 'Cape Verde', '238'),
(39, 'KY', 'CYM', 'Cayman Islands', '345'),
(40, 'CF', 'CAF', 'Central African Republic', '236'),
(41, 'TD', 'TCD', 'Chad', '235'),
(42, 'CL', 'CHL', 'Chile', '56'),
(43, 'CN', 'CHN', 'China', '86'),
(44, 'CX', 'CXR', 'Christmas Island', '61'),
(45, 'CC', 'CCK', 'Cocos [Keeling] Islands', '61'),
(46, 'CO', 'COL', 'Colombia', '57'),
(47, 'KM', 'COM', 'Comoros', '269'),
(48, 'CD', 'COD', 'Congo [DRC]', '242'),
(49, 'CG', 'COG', 'Congo [Republic]', '682'),
(50, 'CK', 'COK', 'Cook Islands', '506'),
(51, 'CR', 'CRI', 'Costa Rica', '385'),
(52, 'HR', 'HRV', 'Croatia', '53'),
(53, 'CU', 'CUB', 'Cuba', '599'),
(54, 'CY', 'CYP', 'Cyprus', '357'),
(55, 'CZ', 'CZE', 'Czech Republic', '420'),
(56, 'DK', 'DNK', 'Denmark', '45'),
(57, 'DJ', 'DJI', 'Djibouti', '253'),
(58, 'DM', 'DMA', 'Dominica', '767'),
(59, 'DO', 'DOM', 'Dominican Republic', '809'),
(60, 'TL', 'TLS', 'East Timor', '56'),
(61, 'EC', 'ECU', 'Ecuador', '593'),
(62, 'EG', 'EGY', 'Egypt', '20'),
(63, 'SV', 'SLV', 'El Salvador', '503'),
(64, 'GQ', 'GNQ', 'Equatorial Guinea', '240'),
(65, 'ER', 'ERI', 'Eritrea', '291'),
(66, 'EE', 'EST', 'Estonia', '372'),
(67, 'ET', 'ETH', 'Ethiopia', '251'),
(68, 'FK', 'FLK', 'Falkland Islands', '500'),
(69, 'FO', 'FRO', 'Faroe Islands', '298'),
(70, 'FJ', 'FJI', 'Fiji', '679'),
(71, 'FI', 'FIN', 'Finland', '358'),
(72, 'FR', 'FRA', 'France', '33'),
(73, 'GF', 'GUF', 'French Guiana', '596'),
(74, 'PF', 'PYF', 'French Polynesia', '594'),
(75, 'TF', 'ATF', 'French Southern Territories', '689'),
(76, 'GA', 'GAB', 'Gabon', '241'),
(77, 'GM', 'GMB', 'Gambia', '220'),
(78, 'GE', 'GEO', 'Georgia', '995'),
(79, 'DE', 'DEU', 'Germany', '49'),
(80, 'GH', 'GHA', 'Ghana', '233'),
(81, 'GI', 'GIB', 'Gibraltar', '350'),
(82, 'GR', 'GRC', 'Greece', '30'),
(83, 'GL', 'GRL', 'Greenland', '299'),
(84, 'GD', 'GRD', 'Grenada', '473'),
(85, 'GP', 'GLP', 'Guadeloupe', '590'),
(86, 'GU', 'GUM', 'Guam', '671'),
(87, 'GT', 'GTM', 'Guatemala', '502'),
(88, 'GN', 'GIN', 'Guinea', '594'),
(89, 'GW', 'GNB', 'Guinea-Bissau', '245'),
(90, 'GY', 'GUY', 'Guyana', '592'),
(91, 'HT', 'HTI', 'Haiti', '509'),
(92, 'HN', 'HND', 'Honduras', '504'),
(93, 'HK', 'HKG', 'Hong Kong', '852'),
(94, 'HU', 'HUN', 'Hungary', '36'),
(95, 'IS', 'ISL', 'Iceland', '354'),
(96, 'IN', 'IND', 'India', '91'),
(97, 'ID', 'IDN', 'Indonesia', '62'),
(98, 'IR', 'IRN', 'Iran', '98'),
(99, 'IQ', 'IRQ', 'Iraq', '964'),
(100, 'IE', 'IRL', 'Ireland', '353'),
(101, 'IM', 'IMN', 'Isle of Man', '44'),
(102, 'IL', 'ISR', 'Israel', '972'),
(103, 'IT', 'ITA', 'Italy', '39'),
(104, 'CI', 'CIV', 'Ivory Coast', '225'),
(105, 'JM', 'JAM', 'Jamaica', '876'),
(106, 'JP', 'JPN', 'Japan', '81'),
(107, 'JO', 'JOR', 'Jordan', '962'),
(108, 'KZ', 'KAZ', 'Kazakhstan', '7'),
(109, 'KE', 'KEN', 'Kenya', '254'),
(110, 'KI', 'KIR', 'Kiribati', '686'),
(111, 'XK', 'XKX', 'Kosovo', '381'),
(112, 'KW', 'KWT', 'Kuwait', '965'),
(113, 'KG', 'KGZ', 'Kyrgyzstan', '996'),
(114, 'LA', 'LAO', 'Laos', '856'),
(115, 'LV', 'LVA', 'Latvia', '371'),
(116, 'LB', 'LBN', 'Lebanon', '961'),
(117, 'LS', 'LSO', 'Lesotho', '266'),
(118, 'LR', 'LBR', 'Liberia', '231'),
(119, 'LY', 'LBY', 'Libya', '218'),
(120, 'LI', 'LIE', 'Liechtenstein', '423'),
(121, 'LT', 'LTU', 'Lithuania', '370'),
(122, 'LU', 'LUX', 'Luxembourg', '352'),
(123, 'MO', 'MAC', 'Macau', '853'),
(124, 'MK', 'MKD', 'Macedonia', '389'),
(125, 'MG', 'MDG', 'Madagascar', '261'),
(126, 'MW', 'MWI', 'Malawi', '265'),
(127, 'MY', 'MYS', 'Malaysia', '60'),
(128, 'MV', 'MDV', 'Maldives', '960'),
(129, 'ML', 'MLI', 'Mali', '223'),
(130, 'MT', 'MLT', 'Malta', '356'),
(131, 'MH', 'MHL', 'Marshall Islands', '692'),
(132, 'MQ', 'MTQ', 'Martinique', '670'),
(133, 'MR', 'MRT', 'Mauritania', '222'),
(134, 'MU', 'MUS', 'Mauritius', '230'),
(135, 'YT', 'MYT', 'Mayotte', '269'),
(136, 'MX', 'MEX', 'Mexico', '52'),
(137, 'FM', 'FSM', 'Micronesia', '691'),
(138, 'MD', 'MDA', 'Moldova', '373'),
(139, 'MC', 'MCO', 'Monaco', '377'),
(140, 'MN', 'MNG', 'Mongolia', '976'),
(141, 'MS', 'MSR', 'Montserrat', '664'),
(142, 'MA', 'MAR', 'Morocco', '212'),
(143, 'MZ', 'MOZ', 'Mozambique', '258'),
(144, 'MM', 'MMR', 'Myanmar [Burma]', '95'),
(145, 'NA', 'NAM', 'Namibia', '264'),
(146, 'NR', 'NRU', 'Nauru', '674'),
(147, 'NP', 'NPL', 'Nepal', '977'),
(148, 'NL', 'NLD', 'Netherlands', '31'),
(149, 'AN', 'ANT', 'Netherlands Antilles', '599'),
(150, 'NC', 'NCL', 'New Caledonia', '687'),
(151, 'NZ', 'NZL', 'New Zealand', '64'),
(152, 'NI', 'NIC', 'Nicaragua', '505'),
(153, 'NE', 'NER', 'Niger', '227'),
(154, 'NG', 'NGA', 'Nigeria', '234'),
(155, 'NU', 'NIU', 'Niue', '683'),
(156, 'NF', 'NFK', 'Norfolk Island', '672'),
(157, 'KP', 'PRK', 'North Korea', '850'),
(158, 'NO', 'NOR', 'Norway', '47'),
(159, 'OM', 'OMN', 'Oman', '968'),
(160, 'PK', 'PAK', 'Pakistan', '92'),
(161, 'PW', 'PLW', 'Palau', '680'),
(162, 'PA', 'PAN', 'Panama', '507'),
(163, 'PG', 'PNG', 'Papua New Guinea', '675'),
(164, 'PY', 'PRY', 'Paraguay', '595'),
(165, 'PE', 'PER', 'Peru', '51'),
(166, 'PH', 'PHL', 'Philippines', '63'),
(167, 'PN', 'PCN', 'Pitcairn Islands', '48'),
(168, 'PL', 'POL', 'Poland', '351'),
(169, 'PT', 'PRT', 'Portugal', '239'),
(170, 'PR', 'PRI', 'Puerto Rico', '787'),
(171, 'QA', 'QAT', 'Qatar', '974'),
(172, 'RE', 'REU', 'R', '262'),
(173, 'RO', 'ROU', 'Romania', '40'),
(174, 'RU', 'RUS', 'Russia', '7'),
(175, 'RW', 'RWA', 'Rwanda', '250'),
(176, 'SH', 'SHN', 'Saint Helena', '290'),
(177, 'KN', 'KNA', 'Saint Kitts and Nevis', '869'),
(178, 'LC', 'LCA', 'Saint Lucia', '758'),
(179, 'PM', 'SPM', 'Saint Pierre and Miquelon', '508'),
(180, 'VC', 'VCT', 'Saint Vincent and the Grenadines', '784'),
(181, 'SM', 'SMR', 'San Marino', '378'),
(182, 'ST', 'STP', 'Sao Tome and Principe', '239'),
(183, 'SA', 'SAU', 'Saudi Arabia', '966'),
(184, 'SN', 'SEN', 'Senegal', '221'),
(185, 'RS', 'SRB', 'Serbia', '381'),
(186, 'SC', 'SYC', 'Seychelles', '248'),
(187, 'SL', 'SLE', 'Sierra Leone', '232'),
(188, 'SG', 'SGP', 'Singapore', '65'),
(189, 'SK', 'SVK', 'Slovakia', '421'),
(190, 'SI', 'SVN', 'Slovenia', '386'),
(191, 'SB', 'SLB', 'Solomon Islands', '677'),
(192, 'SO', 'SOM', 'Somalia', '252'),
(193, 'ZA', 'ZAF', 'South Africa', '27'),
(194, 'KR', 'KOR', 'South Korea', '82'),
(195, 'ES', 'ESP', 'Spain', '34'),
(196, 'LK', 'LKA', 'Sri Lanka', '94'),
(197, 'SD', 'SDN', 'Sudan', '249'),
(198, 'SR', 'SUR', 'Suriname', '597'),
(199, 'SZ', 'SWZ', 'Swaziland', '268'),
(200, 'SE', 'SWE', 'Sweden', '46'),
(201, 'CH', 'CHE', 'Switzerland', '41'),
(202, 'SY', 'SYR', 'Syria', '963'),
(203, 'TW', 'TWN', 'Taiwan', '886'),
(204, 'TJ', 'TJK', 'Tajikistan', '992'),
(205, 'TZ', 'TZA', 'Tanzania', '255'),
(206, 'TH', 'THA', 'Thailand', '66'),
(207, 'TG', 'TGO', 'Togo', '228'),
(208, 'TK', 'TKL', 'Tokelau', '690'),
(209, 'TO', 'TON', 'Tonga', '676'),
(210, 'TT', 'TTO', 'Trinidad and Tobago', '868'),
(211, 'TN', 'TUN', 'Tunisia', '216'),
(212, 'TR', 'TUR', 'Turkey', '90'),
(213, 'TM', 'TKM', 'Turkmenistan', '993'),
(214, 'TC', 'TCA', 'Turks and Caicos Islands', '649'),
(215, 'TV', 'TUV', 'Tuvalu', '688'),
(216, 'VI', 'VIR', 'U.S. Virgin Islands', '340'),
(217, 'UG', 'UGA', 'Uganda', '256'),
(218, 'UA', 'UKR', 'Ukraine', '380'),
(219, 'AE', 'ARE', 'United Arab Emirates', '971'),
(220, 'GB', 'GBR', 'United Kingdom', '44'),
(221, 'US', 'USA', 'United States', '1'),
(222, 'UY', 'URY', 'Uruguay', '598'),
(223, 'UZ', 'UZB', 'Uzbekistan', '998'),
(224, 'VU', 'VUT', 'Vanuatu', '678'),
(225, 'VA', 'VAT', 'Vatican City', '39'),
(226, 'VE', 'VEN', 'Venezuela', '58'),
(227, 'VN', 'VNM', 'Vietnam', '84'),
(228, 'WF', 'WLF', 'Wallis and Futuna', '681'),
(229, 'YE', 'YEM', 'Yemen', '967'),
(230, 'ZM', 'ZMB', 'Zambia', '260'),
(231, 'ZW', 'ZWE', 'Zimbabwe', '263'),
(232, 'CY', 'CYP', 'KKTC', '90');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `currency`
--

CREATE TABLE `currency` (
  `id` int(11) NOT NULL,
  `country` varchar(100) COLLATE utf8_turkish_ci DEFAULT NULL,
  `currency` varchar(100) COLLATE utf8_turkish_ci DEFAULT NULL,
  `code` varchar(100) COLLATE utf8_turkish_ci DEFAULT NULL,
  `symbol` varchar(100) COLLATE utf8_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `currency`
--

INSERT INTO `currency` (`id`, `country`, `currency`, `code`, `symbol`) VALUES
(1, 'Albania', 'Leke', 'ALL', 'Lek'),
(2, 'America', 'Dollars', 'USD', '$'),
(3, 'Afghanistan', 'Afghanis', 'AFN', '؋'),
(4, 'Argentina', 'Pesos', 'ARS', '$'),
(5, 'Aruba', 'Guilders', 'AWG', 'ƒ'),
(6, 'Australia', 'Dollars', 'AUD', '$'),
(7, 'Azerbaijan', 'New Manats', 'AZN', 'ман'),
(8, 'Bahamas', 'Dollars', 'BSD', '$'),
(9, 'Barbados', 'Dollars', 'BBD', '$'),
(10, 'Belarus', 'Rubles', 'BYR', 'p.'),
(11, 'Belgium', 'Euro', 'EUR', '€'),
(12, 'Beliz', 'Dollars', 'BZD', 'BZ$'),
(13, 'Bermuda', 'Dollars', 'BMD', '$'),
(14, 'Bolivia', 'Bolivianos', 'BOB', '$b'),
(15, 'Bosnia and Herzegovina', 'Convertible Marka', 'BAM', 'KM'),
(16, 'Botswana', 'Pula', 'BWP', 'P'),
(17, 'Bulgaria', 'Leva', 'BGN', 'лв'),
(18, 'Brazil', 'Reais', 'BRL', 'R$'),
(19, 'Britain (United Kingdom)', 'Pounds', 'GBP', '£'),
(20, 'Brunei Darussalam', 'Dollars', 'BND', '$'),
(21, 'Cambodia', 'Riels', 'KHR', '៛'),
(22, 'Canada', 'Dollars', 'CAD', '$'),
(23, 'Cayman Islands', 'Dollars', 'KYD', '$'),
(24, 'Chile', 'Pesos', 'CLP', '$'),
(25, 'China', 'Yuan Renminbi', 'CNY', '¥'),
(26, 'Colombia', 'Pesos', 'COP', '$'),
(27, 'Costa Rica', 'Colón', 'CRC', '₡'),
(28, 'Croatia', 'Kuna', 'HRK', 'kn'),
(29, 'Cuba', 'Pesos', 'CUP', '₱'),
(30, 'Cyprus', 'Euro', 'EUR', '€'),
(31, 'Czech Republic', 'Koruny', 'CZK', 'Kč'),
(32, 'Denmark', 'Kroner', 'DKK', 'kr'),
(33, 'Dominican Republic', 'Pesos', 'DOP ', 'RD$'),
(34, 'East Caribbean', 'Dollars', 'XCD', '$'),
(35, 'Egypt', 'Pounds', 'EGP', '£'),
(36, 'El Salvador', 'Colones', 'SVC', '$'),
(37, 'England (United Kingdom)', 'Pounds', 'GBP', '£'),
(38, 'Euro', 'Euro', 'EUR', '€'),
(39, 'Falkland Islands', 'Pounds', 'FKP', '£'),
(40, 'Fiji', 'Dollars', 'FJD', '$'),
(41, 'France', 'Euro', 'EUR', '€'),
(42, 'Ghana', 'Cedis', 'GHC', '¢'),
(43, 'Gibraltar', 'Pounds', 'GIP', '£'),
(44, 'Greece', 'Euro', 'EUR', '€'),
(45, 'Guatemala', 'Quetzales', 'GTQ', 'Q'),
(46, 'Guernsey', 'Pounds', 'GGP', '£'),
(47, 'Guyana', 'Dollars', 'GYD', '$'),
(48, 'Holland (Netherlands)', 'Euro', 'EUR', '€'),
(49, 'Honduras', 'Lempiras', 'HNL', 'L'),
(50, 'Hong Kong', 'Dollars', 'HKD', '$'),
(51, 'Hungary', 'Forint', 'HUF', 'Ft'),
(52, 'Iceland', 'Kronur', 'ISK', 'kr'),
(53, 'India', 'Rupees', 'INR', 'Rp'),
(54, 'Indonesia', 'Rupiahs', 'IDR', 'Rp'),
(55, 'Iran', 'Rials', 'IRR', '﷼'),
(56, 'Ireland', 'Euro', 'EUR', '€'),
(57, 'Isle of Man', 'Pounds', 'IMP', '£'),
(58, 'Israel', 'New Shekels', 'ILS', '₪'),
(59, 'Italy', 'Euro', 'EUR', '€'),
(60, 'Jamaica', 'Dollars', 'JMD', 'J$'),
(61, 'Japan', 'Yen', 'JPY', '¥'),
(62, 'Jersey', 'Pounds', 'JEP', '£'),
(63, 'Kazakhstan', 'Tenge', 'KZT', 'лв'),
(64, 'Korea (North)', 'Won', 'KPW', '₩'),
(65, 'Korea (South)', 'Won', 'KRW', '₩'),
(66, 'Kyrgyzstan', 'Soms', 'KGS', 'лв'),
(67, 'Laos', 'Kips', 'LAK', '₭'),
(68, 'Latvia', 'Lati', 'LVL', 'Ls'),
(69, 'Lebanon', 'Pounds', 'LBP', '£'),
(70, 'Liberia', 'Dollars', 'LRD', '$'),
(71, 'Liechtenstein', 'Switzerland Francs', 'CHF', 'CHF'),
(72, 'Lithuania', 'Litai', 'LTL', 'Lt'),
(73, 'Luxembourg', 'Euro', 'EUR', '€'),
(74, 'Macedonia', 'Denars', 'MKD', 'ден'),
(75, 'Malaysia', 'Ringgits', 'MYR', 'RM'),
(76, 'Malta', 'Euro', 'EUR', '€'),
(77, 'Mauritius', 'Rupees', 'MUR', '₨'),
(78, 'Mexico', 'Pesos', 'MXN', '$'),
(79, 'Mongolia', 'Tugriks', 'MNT', '₮'),
(80, 'Mozambique', 'Meticais', 'MZN', 'MT'),
(81, 'Namibia', 'Dollars', 'NAD', '$'),
(82, 'Nepal', 'Rupees', 'NPR', '₨'),
(83, 'Netherlands Antilles', 'Guilders', 'ANG', 'ƒ'),
(84, 'Netherlands', 'Euro', 'EUR', '€'),
(85, 'New Zealand', 'Dollars', 'NZD', '$'),
(86, 'Nicaragua', 'Cordobas', 'NIO', 'C$'),
(87, 'Nigeria', 'Nairas', 'NGN', '₦'),
(88, 'North Korea', 'Won', 'KPW', '₩'),
(89, 'Norway', 'Krone', 'NOK', 'kr'),
(90, 'Oman', 'Rials', 'OMR', '﷼'),
(91, 'Pakistan', 'Rupees', 'PKR', '₨'),
(92, 'Panama', 'Balboa', 'PAB', 'B/.'),
(93, 'Paraguay', 'Guarani', 'PYG', 'Gs'),
(94, 'Peru', 'Nuevos Soles', 'PEN', 'S/.'),
(95, 'Philippines', 'Pesos', 'PHP', 'Php'),
(96, 'Poland', 'Zlotych', 'PLN', 'zł'),
(97, 'Qatar', 'Rials', 'QAR', '﷼'),
(98, 'Romania', 'New Lei', 'RON', 'lei'),
(99, 'Russia', 'Rubles', 'RUB', 'руб'),
(100, 'Saint Helena', 'Pounds', 'SHP', '£'),
(101, 'Saudi Arabia', 'Riyals', 'SAR', '﷼'),
(102, 'Serbia', 'Dinars', 'RSD', 'Дин.'),
(103, 'Seychelles', 'Rupees', 'SCR', '₨'),
(104, 'Singapore', 'Dollars', 'SGD', '$'),
(105, 'Slovenia', 'Euro', 'EUR', '€'),
(106, 'Solomon Islands', 'Dollars', 'SBD', '$'),
(107, 'Somalia', 'Shillings', 'SOS', 'S'),
(108, 'South Africa', 'Rand', 'ZAR', 'R'),
(109, 'South Korea', 'Won', 'KRW', '₩'),
(110, 'Spain', 'Euro', 'EUR', '€'),
(111, 'Sri Lanka', 'Rupees', 'LKR', '₨'),
(112, 'Sweden', 'Kronor', 'SEK', 'kr'),
(113, 'Switzerland', 'Francs', 'CHF', 'CHF'),
(114, 'Suriname', 'Dollars', 'SRD', '$'),
(115, 'Syria', 'Pounds', 'SYP', '£'),
(116, 'Taiwan', 'New Dollars', 'TWD', 'NT$'),
(117, 'Thailand', 'Baht', 'THB', '฿'),
(118, 'Trinidad and Tobago', 'Dollars', 'TTD', 'TT$'),
(119, 'Turkey', 'Lira', 'TRY', 'TL'),
(120, 'Turkey', 'Lira', 'TRY', '₺'),
(121, 'Tuvalu', 'Dollars', 'TVD', '$'),
(122, 'Ukraine', 'Hryvnia', 'UAH', '₴'),
(123, 'United Kingdom', 'Pounds', 'GBP', '£'),
(124, 'United States of America', 'Dollars', 'USD', '$'),
(125, 'Uruguay', 'Pesos', 'UYU', '$U'),
(126, 'Uzbekistan', 'Sums', 'UZS', 'лв'),
(127, 'Vatican City', 'Euro', 'EUR', '€'),
(128, 'Venezuela', 'Bolivares Fuertes', 'VEF', 'Bs'),
(129, 'Vietnam', 'Dong', 'VND', '₫'),
(130, 'Yemen', 'Rials', 'YER', '﷼'),
(131, 'Zimbabwe', 'Zimbabwe Dollars', 'ZWD', 'Z$');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `duyurular`
--

CREATE TABLE `duyurular` (
  `id` int(11) NOT NULL,
  `baslik` varchar(255) NOT NULL,
  `icerik` text NOT NULL,
  `ozet` varchar(255) NOT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT '1',
  `kayit_tarihi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `guncelleme_tarihi` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `anahtar_kelimeler` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `haberler`
--

CREATE TABLE `haberler` (
  `id` int(11) NOT NULL,
  `baslik` varchar(255) NOT NULL,
  `icerik` text NOT NULL,
  `ozet` varchar(255) NOT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT '1',
  `kayit_tarihi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `guncelleme_tarihi` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `anahtar_kelimeler` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `haberler`
--

INSERT INTO `haberler` (`id`, `baslik`, `icerik`, `ozet`, `aktif`, `kayit_tarihi`, `guncelleme_tarihi`, `anahtar_kelimeler`) VALUES
(1, 'Logista yeni arayüzü ile yayında', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab atque beatae commodi, consectetur consequuntur corporis ea ipsum iure maxime molestiae nostrum odit, praesentium reprehenderit rerum sequi tempora vel? Illo, maxime.', 'Lorem ipsum dolor sit amet', 1, '2019-05-02 05:51:55', '0000-00-00 00:00:00', 'logista,haberler,logista web sitesi,'),
(2, 'Logista\'nın başarısı', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab atque beatae commodi, consectetur consequuntur corporis ea ipsum iure maxime molestiae nostrum odit, praesentium reprehenderit rerum sequi tempora vel? Illo, maxime.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab atque beatae commodi, consectetur consequuntur corporis ea ipsum iure maxime molestiae nostrum odit, praesentium reprehenderit rerum sequi tempora velllo, maxime. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab atque beatae commodi, consectetur consequuntur corporis ea ipsum iure maxime molestiae nostrum odit, praesentium reprehenderit rerum sequi tempora vel? Illo, maxime. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab atque beatae commodi, consectetur consequuntur corporis ea ipsum iure maxime molestiae nostrum odit, praesentium reprehenderit rerum sequi tempora vel? Illo, maxime.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab atque beatae commodi, consectetur consequuntur corporis ea ipsum iure maxime molestiae nostrum odit, praesentium reprehenderit rerum sequi tempora velllo, maxime. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab atque beatae commodi, consectetur consequuntur corporis ea ipsum iure maxime molestiae nostrum odit, praesentium reprehenderit rerum sequi tempora vel? Illo, maxime. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab atque beatae commodi, consectetur consequuntur corporis ea ipsum iure maxime molestiae nostrum odit, praesentium reprehenderit rerum sequi tempora vel? Illo, maxime.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab atque beatae commodi, consectetur consequuntur corporis ea ipsum iure maxime molestiae nostrum odit, praesentium reprehenderit rerum sequi tempora velllo, maxime. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab atque beatae commodi, consectetur consequuntur corporis ea ipsum iure maxime molestiae nostrum odit, praesentium reprehenderit rerum sequi tempora vel? Illo, maxime.', 'Lorem ipsum dolor sit amet', 1, '2019-05-02 07:59:17', '2019-05-13 09:50:18', 'logista,haberler,logista web sitesi'),
(3, 'Haber başlığı', '<p>haber içeriği</p>', 'Haber özeti', 1, '2019-05-10 07:36:43', '0000-00-00 00:00:00', 'logista,logista.com.tr');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iletisim`
--

CREATE TABLE `iletisim` (
  `id` int(11) NOT NULL,
  `konu` varchar(255) NOT NULL,
  `mesaj` text NOT NULL,
  `ad` varchar(255) NOT NULL,
  `soyad` varchar(255) NOT NULL,
  `eposta` varchar(255) NOT NULL,
  `kayit_tarihi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cevap_tarihi` date NOT NULL,
  `cevaplanma_durumu` tinyint(1) NOT NULL DEFAULT '0',
  `cevap_mesaji` text NOT NULL,
  `spam_mesaj` tinyint(1) NOT NULL DEFAULT '0',
  `okundu_bilgisi` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `iletisim`
--

INSERT INTO `iletisim` (`id`, `konu`, `mesaj`, `ad`, `soyad`, `eposta`, `kayit_tarihi`, `cevap_tarihi`, `cevaplanma_durumu`, `cevap_mesaji`, `spam_mesaj`, `okundu_bilgisi`) VALUES
(1, '4', 'Teşekkür', 'Emre', 'Bodur', 'emrebodurbto@gmail.com', '2019-05-02 07:43:46', '0000-00-00', 0, '', 0, 0),
(3, '1', 'Öneri', 'Emre', 'Bodur', 'emrebodurbto@gmail.com', '2019-05-13 10:53:37', '0000-00-00', 0, '', 0, 0),
(4, '2', 'Şikayet', 'Elif', 'Bodur', 'elifkarakusbodur@gmail.com', '2019-05-13 10:53:40', '0000-00-00', 0, '', 0, 0),
(5, '3', 'Bilgi Edinme', 'Ahmet Tuna', 'Bodur', 'ahmettunabodur@gmail.com', '2019-05-13 10:53:42', '0000-00-00', 0, '', 0, 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(128) COLLATE utf8_turkish_ci NOT NULL,
  `description` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `createDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`, `createDate`) VALUES
(1, 'Admin', 'Yönetici', '2019-04-22 10:19:11'),
(2, 'User', 'Kullanıcı', '2019-04-22 10:19:25');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `site_bilgileri`
--

CREATE TABLE `site_bilgileri` (
  `id` int(11) NOT NULL,
  `site_adi` varchar(255) NOT NULL,
  `site_slogani` varchar(255) NOT NULL,
  `site_adresi` varchar(255) NOT NULL,
  `site_aktif` tinyint(1) NOT NULL DEFAULT '1',
  `firma_adi` varchar(255) NOT NULL,
  `firma_tel1` varchar(255) NOT NULL,
  `firma_tel2` varchar(255) NOT NULL,
  `firma_gsm` varchar(255) NOT NULL,
  `firma_eposta` varchar(255) NOT NULL,
  `site_eposta` varchar(255) NOT NULL,
  `firma_sorumlusu` varchar(255) NOT NULL,
  `firma_adres` text NOT NULL,
  `anahtar_kelimeler` varchar(255) NOT NULL,
  `facebook_url` varchar(255) NOT NULL,
  `twitter_url` varchar(255) NOT NULL,
  `instagram_url` varchar(255) NOT NULL,
  `firma_fax` varchar(255) NOT NULL,
  `google_site_verification_code` text NOT NULL,
  `google_analytics_code` varchar(255) NOT NULL,
  `license_number` text,
  `license_start_date` text,
  `license_end_date` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `site_bilgileri`
--

INSERT INTO `site_bilgileri` (`id`, `site_adi`, `site_slogani`, `site_adresi`, `site_aktif`, `firma_adi`, `firma_tel1`, `firma_tel2`, `firma_gsm`, `firma_eposta`, `site_eposta`, `firma_sorumlusu`, `firma_adres`, `anahtar_kelimeler`, `facebook_url`, `twitter_url`, `instagram_url`, `firma_fax`, `google_site_verification_code`, `google_analytics_code`, `license_number`, `license_start_date`, `license_end_date`) VALUES
(1, 'Düzce ÖDM Soru Havuzu', 'Soru Havuzu', 'soruhavuzu.emrebodur.com', 1, 'Düzce ÖDM', '2128763020', '2128764520 ', '5325245804 ', 'info@logista.com.tr ', 'noreply@logista.com.tr ', 'Emre Bodur', 'Kuyumcuzade Bulvarı No:23<br/> \r\nMerkez / Düzce\r\n', 'logista kurye ve lojistik hizmetleri, logista, logista.com.tr, logista lojistik, logista kurye', 'https://www.facebook.com/logistatr/', 'https://twitter.com/logistakurye', 'https://www.instagram.com/logistakurye/', '2128764041', 'p6gXJxCfgBz8cJx18wsl9j0kFlGKpaZApdm8PAFhCTs', 'UA-97394039-2', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sorular`
--

CREATE TABLE `sorular` (
  `id` int(11) NOT NULL,
  `no` text NOT NULL,
  `dersAdi` text NOT NULL,
  `sinifDuzeyi` int(11) NOT NULL,
  `zorlukDerecesi` int(11) NOT NULL,
  `kazanim_no` text NOT NULL,
  `kazanim_icerik` text NOT NULL,
  `madde_koku` text NOT NULL,
  `secenekler` text NOT NULL,
  `dogru_cevap` text NOT NULL,
  `dogrulama_kodu` text NOT NULL,
  `onay_durumu` tinyint(4) NOT NULL DEFAULT '0',
  `kayit_tarihi` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `sorular`
--

INSERT INTO `sorular` (`id`, `no`, `dersAdi`, `sinifDuzeyi`, `zorlukDerecesi`, `kazanim_no`, `kazanim_icerik`, `madde_koku`, `secenekler`, `dogru_cevap`, `dogrulama_kodu`, `onay_durumu`, `kayit_tarihi`, `userID`) VALUES
(1, 'BT-5.1.1.1-3-EMRE.BODUR-5698', 'Bilişim Teknolojileri', 5, 3, '5.1.1.1.', 'Bilişim teknolojilerinin temellerini bilir.', '<p>Örnek Soru</p><p><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABAAAAAQACAYAAAB/HSuDAAAgAElEQVR4nOzdfZBkV3nn+d9z7s2sl65uSa1Wd0vBsgpJwbJahYKlNISiSpZlYLGDZRyswiPPEqyXBcw6PBrAgDx+ozK0mGBFGrxYMIxtZMNgm9EwmMGyrPFg2SPTWQx2l1/YHXt2tpN1sKyHYVitlsBNdVXe8+wfmVVd3aruesm8efLe/H4iFGFLXXmfpror8/zOc55jAgAAY7HaOTsvt3vc/HtM9lJJt0k6JkkufcOkL0t6UtJvLi0vnk9X59qLXPq7Jn33oMZ5uaKkr7vp35rUkfR7Lv+L5eW7UpUJAAAOyFIXAABAna121oLkL5PshyXdL+nafXzZ1136aZN/fGn5rlhyidtWO2snXGqb9HpJ+R6/PEr6C7l/UmYfX1pe/MYYSgQAAEMgAAAAoASrnbXg0qtN+mlJdx/yZf6xpB9eWl7cGGFpu1rtrN2hfvfBCw/x5efVr7W9tLz4lZEWBgAARoYAAACAEVrtrEnSve7eNrOXjeAlf3ZpefHdI3idK1rtrOWS/k9JLxjypTbk/ksyew8dAQAATJ6QugAAAOqic2btBXI9LukPRrT4l6T7RvQ6V3Obhl/8S1JTZg9K+svVM2sPDoIFAAAwIQgAAAAY0mpnLax21n7ETP9Gpgc02vfXl6521mZH+Hq7WRrx6x2X6VFJndXO2TtH/NoAAOCQCAAAABhCp7N2s6TPS/qoBhP9R2xe0ktLeN2dvquk132ZZF/qdNZ+onOGbgAAAFIjAAAA4BBWO2ta7aw9YNKfSnp5mc9y6d6yXrvTWZPkpb2+pFmT3memp1c7a4cZMAgAAEaEAAAAgANa7azNS/pFSY9rf9f6DcXkryjxtW9x1y1lvf4O90r6007n7PeP4VkAAGAXBAAAABzAar/l/wuS3jK+p9pSp3N2oaTXfqXZ2C4FOm6yz6521t63euYsRwIAABgzAgAAAPZp9czaKyX9sco/k3+5eZPdU8oru39vKa97ZUHST8jsydXO2vExPxsAgKlGAAAAwB5WO2vqdM4+KNNTkk4kKuO/HvULrnbWZr3k+QVX8SpJX1ztrL040fMBAJg6BAAAAFxFp3+X/aOSPSopWdu6u16z2lkb9avea2alzzC4ihdJ6qyeWUsVQgAAMFUIAAAAuILVztqCpM9KenBsp+SvwEw3a+RHD+y/Ge3rHcpxmZ7qdM6+IXUhAADUHQEAAAC7WO2snZT0tEmvSV3LDn9nVC+0ematKWlSJvI3JT3WObP2U6PvcgAAAFsIAAAAuMyOSf8vS1zK5X5gtbM2mvdu072SbhrJa42AyYKZv1euD43s9wgAAC7BGywAADusdtZuV3/x/6LUteziNkl3j+i1/rsRvc4ImWR6q9w/sdpZa6auBgCAuiEAAABgYPXM2l2S/kDSC1LXciXuetOwr7HaWTsm6f4RlFMOs9dL+vRqZ202dSkAANQJAQAAAJJWO2t3y/R5SSdT13I1Zv7Aamdt2Mn9r5O0MIp6SvT9kj632lmbT10IAAB1QQAAAJh6nc7afZI+LynllXj7ZAuS3njYr+70z9f//dHVU6pXSXpicBsDAAAYEgEAAGCqrXbW7jPpCU3+jvg2l9522DPyJr1a0u0jLqlML5f01ODYAgAAGAIBAABgaq121u5VxRb/kmTSCyW94aBfN5iu/+6RF1S+eyQ9sdo5W6nvEwAAk4YAAAAwlVY7a0uSnlTFFv87vPugu+Lu/gOST9rVhvt1r2SfWz3DTAAAAA6LAAAAMHVWO2svU7UX/1L/poJ97+avdtaOmVlbshJLKt3LZfoMtwMAAHA4BAAAgKmyembtTnd/SpUY+Lent6+eOXvvXr9otbMml39I/aMDVfd9kj512BkIAABMMwIAAMDUWO2svUimp8zseOpaRiSX2eOrnbO37fHr3m6yN4yjoDF5rVy/utpZy1MXAgBAlVS6DxAAgP1a7ay9QO5fkNnNqWspwdck/R1J/3ppeXH7Xw4WyD8lqaV6hv4flvS2peXFmLoQAACqgAAAAFB7nc7aCZOeUbWuvzuonlz/3E1fMCm6dFzSD1q9f8+S9LOS3r0z+AAAALsjAAAA1NpqZ23Bpd81aSl1LSiBu2T29yV9mBAAAICrq2M7IAAAkqTOmbO5XJ9i8V9jZpLr5+V6IHUpAABMOgIAAEAtrXbWgpl9VKbXpK4FJTPlkj7ROXP2vtSlAAAwyQgAAAC1s9pZk+Q/I+nNqWvBmJhmZfaZ1c7aHalLAQBgUhEAAADq6A2StVIXgfGy/uDDJ1Y7azelrgUAgEnEEEAAQK10zpx9uZk9JamZuhYkc1bS9ywtL347dSEAAEwSOgAAALWx2lm73cw+LRb/0+4uSZ9c7azlqQsBAGCSEAAAAGphtbN2UtIT6reBA6916ZH+PAgAACARAAAAaqDTWZuV9GlJt6SuBZPDpHfInUGQAAAMEAAAACqt0zkrkz4i6d7UtWAifWS1s3Zf6iIAAJgEBAAAgEoz2dslvTF1HZhQZk1Jn17trNEdAgCYetwCAACorNUzZ18lsyclMewNV+XSn5n0XdwMAACYZnQAAAAqabWzdovMPiUW/9gHk14i12OrnTU++wAAphZvggCAyul0zubu+rSY+I+DMD0g6UdTlwEAQCoEAACAyjFZz0yfTF0HKudrkv5F6iIAAEiFAAAAUDlLy4uS9L9IeqdLMXE5qAB3fVXy71laXjyXuhYAAFJhCCAAoLJWz5yVpHfJ9IhkhNrYlbu+ZvLvWbrnLhb/AICpRgAAAKi01c6aJL1LUjtxKZhALn3NJHb+AQAQRwAAABU3OA7wc5LeKY4DYCfXV1n8AwBwER0AAIBa2NEJ8IgIuCF9rX/mn7Z/AAC2EAAAAGqj0w8B3mHSB1LXgnRcPmj7Z/EPAMBO7JAAAGpjeXlRcn1Q0kPiOMCU8q+ajMU/AAC7oAMAAFA7q501yfUuGYMBp8zXxJl/AACuiA4AAEDtLC0vyk0/J/lDqWvBmLi+Khb/AABcFQEAAKCWli/eDsBxgLpzfVWmV7D4BwDg6jgCAACotdUzZyWzd0kcB6gp2v4BANgnOgAAALW2dM9dUr8T4J2iE6BmnLZ/AAAOgAAAAFB7S/3jAB+U9A9ECFALLv+aZLT9AwBwABwBAABMjcHtAO+Q6QOpa8FQviY5V/0BAHBAdAAAAKbG0vKiXP5BMRiwulxfZfEPAMDh0AEAAJg6q501SXqXXI/ICMMr5OuSf/fS8l3/LnUhAABUEQEAAGAqDUKAd8j1Ad4NK+Hrkr9iafmuv0hdCAAAVcWuBwBgKm0PBjSOA1QAi38AAEaAPQ8AwFQbdAL8hKT3JS4Fu/umpO9eWl5k8Q8AwJDoAAAATLV+J4D/Suo6cAXuZ1j8AwAwGgQAAADInpO0kboK7MLsm6lLAACgLggAAACQepKeTV0EdvWN1AUAAFAXBAAAgKm3tLwYnQBgUv2H1AUAAFAXBAAAAEgydponk4sjAAAAjAgBAAAAfSw0J5ERzAAAMCoEAAAA9LHQnEwEMwAAjAgBAAAAfSw0JxPfFwAARoQAAAAASS7/j6lrwGVcG5K+lboMAADqggAAAABJJu6bnzjm5136duoyAACoCwIAAAD6mAEwYVz27PLyYkxdBwAAdUEAAABAHx0Ak4fvCQAAI0QAAACAJMmfTV0BLmUEAAAAjBQBAAAAkiR7TlIvdRXYyQkAAAAYIQIAAAAkyfVtSeupy8AlCAAAABghAgAAACQt3bMoseCcMPb/pK4AAIA6IQAAAOAiAoDJwvcDAIARIgAAAGDAXQwCnCwEAAAAjBABAAAAA2YsOCcKgQwAACNFAAAAwDauApwoRgAAAMAoEQAAALDN/mPqCnCRcwQAAICRIgAAAGALLecTxcT3AwCAUSIAAABgCy3nk+Rb7t5LXQQAAHVCAAAAwEUEAJPjW2ZGAAAAwAgRAAAAcBEBwOR4dml5MXUNAADUCgEAAAAXPZe6APQ58xgAABg5AgAAALZxDeCkMCOMAQBg1AgAAAC46Lyk9dRFQBLHMQAAGDkCAAAAtrhtSH4+dRmQxHEMAABGjgAAAICBpXsWe5J9O3UdkFz6f1PXAABA3RAAAABwKXaeJ4DxfQAAYOQIAAAAuBQLz0ngfB8AABg1AgAAAHZw6Vupa4Ak4/sAAMCoEQAAALCDyVl4TgY6AAAAGDECAAAALmEEAJOBYYwAAIwYAQAAADs4C89JQRADAMCIEQAAALCDSf9f6hqgKOl86iIAAKgbAgAAAC5FB0B6UU4AAADAqBEAAABwKRae6UWX1lMXAQBA3RAAAACwgxMATIJoRgAAAMCoEQAAAHCpjdQFQOtLy4upawAAoHYIAAAA2MFoPU/O+0MAAQDAiBEAAACwk6cuACIAAACgFAQAAADsZNw/n5pJz6WuAQCAOiIAAADgUl9JXcDUc+d7AABACQgAAADYyf1rkr6RuoypZnY2dQkAANQRAQAAADss3XNXdNe/Sl3HNHPpmdQ1AABQRwQAAABcxky/m7qGKfYtk86kLgIAgDoiAAAA4Pl+R9JG6iKmkct/b2l58XzqOgAAqCMCAAAALrO0vPh1SX+Yuo5pZK5Ppa4BAIC6IgAAAGB3n0xdwBR6Tma/nboIAADqigAAAIDd/aa4j36sXP5PlpYX11PXAQBAXREAAACwi6XlxW9L+iep65gi0aTHUhcBAECdEQAAAHBlH/XUFUyPP5LsbOoiAACoMwIAAACuYGl58cvGMMCxcOkjS8uLqcsAAKDWCAAAALi6D6UuYAr8tbn+WeoiAACoOwIAAACuwqXfknQudR0195Glexj+BwBA2QgAAAC4iuXlxZ6kn09dR41926V/lLoIAACmAQEAAAB78o9L/o3UVdTUx5aXF59NXQQAANOAAAAAgD0sLd91XjJmAYzeuuR0VwAAMCYEAAAA7M8/lPRc6iJq5teWlu/6auoiAACYFgQAAADsw9Ly4nOSPpy6jhrpSXpf6iIAAJgmBAAAAOzfz4sugFH5jaXlxa+kLgIAgGlCAAAAwD4t9YfV0QUwvA13f2/qIgAAmDYEAAAAHAxdAMP7teV77vp3qYsAAGDaEAAAAHAAgy4AJtcf3rokdv8BAEiAAAAAgIP7BUnfTF1ERf0KZ/8BAEiDAAAAgAMa3AjwSOo6Kui8s/sPAEAyBAAAAByK/0NJ3GF/ML+wvLz416mLAABgWhEAAABwCEvLd52X9J7UdVTIs5LaqYsAAGCaEQAAAHB4H3f5v01dREU8MhigCAAAEiEAAADgkJaWF3vm9pPy1JVMvK9K+nDqIgAAmHYEAAAADOe3ZH4mdRET7t1Ly4vnUxcBAMC0IwAAAGAIS/csRskekiumrmVC/ZmkX0tdBAAAIAAAAGAU/rXM/1nqIiZQdOmhpeVFwhEAACYAAQAAAENaWl6UZD8paT11LZPEpX8h6fdS1wEAAPoIAAAAGIGl5cWviEF3O21Iemh5eTF1HQAAYIAAAACA0XmvpG+kLmJCfMykv0hdBAAAuMhSFwAAQJ2sdtZ+RNJHU9eR2LOS/rOl5cVvpi4EAABcRAcAAACj9TFJX05dREouPcziHwCAyUMAAADACC0tL/Yk/Zg0tdcC/oVJ/yh1EQAA4PkIAAAAGLGl5cXfl/TPU9cxdi5J+rGl5cWNxJUAAIBdEAAAAFAKf6ek86mrGCvTb0n6l6nLAAAAuyMAAACgBEvLd/2VXI+krmN8/Lykdy5x7R8AABOLAAAAgLKY3i/pK6nLGA/7uaXlxXOpqwAAAFdGAAAAQEmWlhfX3f0DMRaKMcrdU5c0Uu6uGAu5x3V3/0DqegAAwNXlqQsAAKDWzL5lCnKP6vV6klwhZAohk5mlru7AYoyKsSeXFCwohEyS9czE4D8AACYcAQAAACUzM5llMguSXL3epjY3L8hCUBYyhZAPfs3kBQJbu/xF7CnGqBAy5Vkus7Cz3g1JvYRlAgCAfSAAAACgRCbF7f/bTJKp0ZhRnjdVFD31ig15b0NmphAyZSEf7KorSSDg7nKPKmKhWPQUPcosKM8aajRnJjKkAAAA+0MAAABAudZ3+5dmpjxvKMtyxVioV2yqKHoqiv5G+tYxgSxkl++2j1z0qFgU2zv9W7Is10w2U/rzAQDAeBAAAACQkJkpy/q7/u5xOwjoDw4s1JNkMoXsYnfAsIvxrbb+/oK/kPt2k8L2bn+W5Sz6AQCoGQIAAAAmwNacgGbI5HlUr+ip19uU5HL5pd0BFhSyfN/dAf22fleMvX5rfyye92uyLFeeNQ612+/u0czi3r8SAACkRAAAAMCEMQtq5E3lWWMwJ2Dzkl366FGxtzGYumfKsmx7fsDW4t3dB4P7CsWikOv5VxCOarffzHpLy4sEAAAATDgCAAAAyuRa1yHX1rvNCXj+7v3F7oBNXVCwIKkfElzJMLv9AACguggAAAAo0wjW11tzAvpBwNacgM1df+2VFv6c7QcAAAQAAABUSAhBzTAjz5v9IKC3uWt7/xZ2+wEAwBYCAAAAKsjMLs4JiP2BgVtzAvq7/bmyrDGuRf+uVx0CAIDJQgAAAECJXN6zUZwDuAIz67f2h1zRo0xitx8AAOyKAAAAgBKZ20aJ6/+LzzFTZln5DwIAAJUVUhcAAAAAAADKRwAAAACGxQwAAAAqgAAAAIAyTcdR/N3vHgQAABOFAAAAgHKdT10AAACARAAAAAAAAMBUIAAAAADD4ggAAAAVQAAAAACGxRBAAAAqgAAAAIBybaQuAAAAQCIAAACgbL3UBQAAAEgEAAAAAAAATAUCAAAAMCxmAAAAUAEEAAAAlMhTFzAe3AIAAEAFEAAAAFAik86nrgEAAEAiAAAAAAAAYCoQAAAAgKG4OzcdAABQAQQAAABgKGa2kboGAACwNwIAAADKxeIYAABMBAIAAADKxYR8AAAwEQgAAADAcHxKLjsEAKDiCAAAAMBwzNZTlwAAAPZGAAAAQLmiVO8dcq/57w8AgLogAAAAoFw9ybgmDwAAJEcAAAAAAADAFCAAAAAAQzE3rjoEAKACCAAAAMBwzDniAABABRAAAABQIndtuDymrgMAACBPXQAAAHVmpihZ6jIAAADoAAAAoEzuMcQYVRQ9xVjIvR5X5rm7Lv6+4uzTTz/TTF0TAAC4OjoAAAAokVmIZpK7KcZCveKCJCmETFnIZVad7oD+or9QEQuZ+r+HEDKZ2bOveMV3MwgQAIAJRwAAAEC5oqRoZsqyXCFkcnf1ig1tbl6QWVCW5cpCJrMwUYGAu8s9qoiFYtGTS8qyXI28ITOaCAEAqBoCAAAAytWTfHsOgJnJzNQMs/Lc1Ss2VfQ21dOGJFMWMoUsUxYySTbWQKB/PMFVFMX2Tr/kykKuPG9u7faPrR4AADBaBAAAACRiZmrkTeVZQ0XsqdfbVBF7KmJPm1K/OyBkClmuUFJ3wFZb/9aC3wcXFpiZ8ryhPMvZ7QcAoCYIAAAASMzMlGcNZSFX9Kheb2MwMDCqV0Sp2JQkZaF/hCDLDt8d0G/rd8XY67f2x+KS/x5CpjxrHHS3f/3AhQAAgLEjAAAAoHT7W0ibmTLLlDXnBhP2N9UbLP4lXewO6O2/O2Dr1oH+Dn9PsSjkuvQmgv58gqF2++NhvggAAIwXAQAAACVaWl7cWO2s9Q76dSEEhTCjPG9uBwE7rxC8vDtg61aBkGUyWX94X1Eoxp6i774+P+RuPwAAqCgCAAAAJlj/LH5TWdboXyPY29h1Qb91jl97RA0j2O0HAAAVRQAAAEAFXHqNYNweGLhfJe/2cwQAAIAKIAAAAKBC+tcIZmo2LwYBvaInXXauX5JMpmwwyb/kKwUZAggAQAUQAAAAUL4DzwDYD7OgRmNrTkBvMCcgcrYfAADsigAAAICSubxn+7wJ4DD6cwIayrJ8+/8HAAC4HAEAAAA1wcIfAABcDeN/AQDAsL6TugAAALA3AgAAAEpmslpPyX/++EEAADCJCAAAACiZMyUfAABMAAIAAAAAAACmAAEAAAAY1kbqAgAAwN4IAAAAwFBM6qWuAQAA7I0AAACA8jEDAAAAJEcAAABAyUyq9S0AAACgGggAAADAsAg4AACoAAIAAAAwLI44AABQAQQAAACUzhmSBwAAkiMAAACgdMY1eQAAIDkCAAAAAAAApgABAAAAGBYdDgAAVAABAAAAGBIzDgAAqAICAAAAyseUfAAAkBwBAAAAAAAAU4AAAAAADMli6goAAMDeCAAAAMCwOOIAAEAFEAAAAFAyZ0o+AACYAAQAAACUzCSm5AMAgOQIAAAAAAAAmAIEAAAAYFgccQAAoAIIAAAAKF/dp+TX/fcHAEAtEAAAAFA6Z0o+AABIjgAAAAAAAIApQAAAAECJnn76GbkrT11HmdxdTz/9TK1/jwAA1AEBAAAAJXrFK75b7h6Loqdeb1MxRrl76rKG4u6KHtUrNlUUPRWxNyuuOgQAYOKR1gMAULIQwroU5O7qFZuKsZCZKQu5QshkZqlL3JO7K8ZCRSwkd4WQKcvyrdqfvffeu1OXCAAA9kAAAABA6bwnmcxMjbwpd1cRe+r1NhQ9KoSsv6AOmczCRAQC7i73qCIWirFQjFFZlinPGhNTIwAAOBgCAAAAxszMlGcNZSGXe1Svt6leb0M9SSZTyLIk3QFbwUSMhWJRyOUyC8qzhpqNnEU/AAAVRwAAAEAiZiazTI1GUK6mit7mxXP1Rf9IfbCgkOWldAdsneWPRU9FLOQet/9bluXKsobC/p55fmRFAQCA0hAAAABQOotX/a9m/Z3/xozyvKmi6AcB2wv0nd0BIdvuENj62v3qt/VvneXv7/RfWkdQPlj4s9sPAED9EAAAAFC+9f3+QjNTnjeVZQ3FWGwPDZQkV79Fv4g9berCvroDdg7vi7G36w0EWciV5fve7QcAABVFAAAAwAQyM2VZfw7A1pyAIl56097O7gDJlA26A4KFHcP7it1ent1+AACmEAEAAAATbGtOQLN5MQjoFT1Jl+/kX+wOuJoydvvdfWMkLwQAAEpFAAAAQEWYBTW25wT0BnMCrjpeYPB1g1sHStrtN7Orpw4AAGAiEAAAAFAylzZGuezuzwloKMvy580J2CkLg0n+gbP9AACAAAAAgNKZtPc2/WFe95I5Aa5esaEYo7IsV57lMgtlPBYAAFQUAQAAABXXnxNgaobZNAXscrMAAACYPGwNAACA4ZidT10CAADYGwEAAADlY0geAABIjgAAAIDycU0eAABIjgAAAAAAAIApQAAAAACGRYcDAAAVQAAAAACGVco1hwAAYLQIAAAAKN/fpC4AAACAAAAAAAAAgClAAAAAAIbFNYcAAFQAAQAAABgWQwABAKgAAgAAAMrHAhkAACRHAAAAQPlokQcAAMkRAAAAAAAAMAUIAAAAwJB8PXUFAABgbwQAAABgSBZTVwAAAPZGAAAAQPnOpy4AAACAAAAAAAAAgClAAAAAAIbFLQcAAFQAAQAAABiO+0bqEgAAwN4IAAAAKB8LZAAAkBwBAAAA5WNKPgAASI4AAAAADMcsdQUAAGAfCAAAAMAw1t1TlwAAAPaDAAAAgPLVeUp+pAEAAIBqIAAAAKB8DAEEAADJEQAAAAAAADAFCAAAAMAw6ny8AQCAWiEAAACgZO6uGKO8ZtPy3F3ukQAAAICKyFMXAABA3ZnZuiTFWCh6lJkpC7msYtPzBgt+xRglk4Jllfs9AAAwzQgAAAAombuimSnLcgV3xVhoY3NdclfIcmUhk1mYyMW0D+otYk/urixkyrLGRNYKAACujgAAAIAx2g4CQib3qF5vUxd6GzIzhdAPA0JIt7Pe3+V3xdhTEQvFWCiETHnWuFJdMUWdAADg4AgAAABIwMxklqnZzBRjVK/YUFFsqig2JUkhZMpCrizrdweU6eIuf6E42OmXpDxrqNGcUQhXfr5L6/QCAABQDQQAAACUzOzqk/JDCGqGWXne7wjoFZv9eQGx0GZPMguD1vt8JEcFLu7y91v7Yyx21BrUyJuDZ7G0BwCgTggAAAAo38Z+fpFZUKMxozxvqij6QcDW4L1eEdUrNiWZsqzfHXCQowLuruhRsei39rtf2rmfhVx53pjYWQQAAGB4BAAAAEwYM1OeN5VlDRWxp15vc8eC3VUUPRVFv6mgf1QgUxjcKrBz8e4eVRQXW/uf9xyZsryhfNBZAAAA6o0AAACACWVmyrOGspArxmL7aMBOW0cFpI3t6wUl7brLv2WPoX4Hq1Fal3yo1wAAAONBAAAAQOlc0uEX2rvdHFDssqPv7oNjArvLsou7/SNr83fFpXvuGs1rAQCAUhEAAABQOlsfyas87+aAi7cGXPlrgvIsV5Y1ONsPAMCUIwAAAKCC+jcHzMjzhnpFf07Azlb8Ubb5AwCAeiAAAACgwrau7cuzhorBrQFZ3lAY31C/3QcNAACAiUMAAABADWzdHDD+B2skxxsAAED5uPMHAICSuVgkAwCA9AgAAAAom9MmDwAA0iMAAAAAAABgChAAAACAw3OONwAAUBUEAAAAlMzqPCmfGwYBAKgMAgAAAMrGpHwAADABCAAAAAAAAJgCBAAAAODQXNpIXQMAANgfAgAAAHBoJu+lrgEAAOwPAQAAAOVjBgAAAEiOAAAAgPLV9xYAAABQGQQAAABgCNwDCABAVRAAAACAQ3P5+dQ1AACA/SEAAACgfAzKAwAAyREAAABQMq7KAwAAk4AAAAAAAACAKUAAAAAADs1kdDcAAFARBAAAAODQXM58AwAAKoIAAACAkpm0nroGAAAAAgAAAAAAAKYAAQAAADg0k8XUNQAAgP0hAAAAAMPgeAMAABVBAAAAQPmiJIblAQCApAgAAAAoXxz8AwAAkAwBAAAAAAAAU4AAAAAAHJrLmQEAAEBFEAAAAFA2d3lNjwCYLHUJAABgn/LUBQAAUHcujx6953KZBZlVf7UELF0AACAASURBVNHs7nKPkozNBAAAKoIAAACAkvUX/YoxRvWKTbm7spAphKwyYUB/we+KsZDLFSxs1V/LzgYAAOqIAAAAgDEJISiEptxdvWJTmxcuyEIYhAG5zGyiAoGtBX+MhYpYKISgPGtc3sXA9YYAAFQEAQAAAGNmZmrkTeVZQ0Wx2e8K6G3IbBAGZLlCgqMC7i7JVRSFithTjIXMTFnW0Exz7kr1bIy1SAAAcGgEAAAAlC9ql51yM1OeN5VlDRWxp16vHwao2JQkZSFXyDJlg+6AMri7okfFoqciFoNz/VIImZqN2UodUwAAAFdHAAAAFdJttyRp3uUvMOkWyV4o6T+RdKL/jx9z2YJJTV286WXdpXWTviXpWZd/Q7L/W66/MvOvSPZXks7f+tDDKX5L0yLqKrcAmJnyrKEs5IqxUK/YHLTd91TEnjZ1oX/mPsu3w4DDLsq3d/ljoTjY6d8pzxrKssbEHUfAcLrvX5HMjkm6ZfDPzZJulHRS0rWSjrl81mTNwZf01O/u+Lak5yQ9K+nfS/41ub4qs69I+utbH3qYDhAAqBDe2QFggnXbrWOS3yXZy9z1X5r5nZLdLGl2hI9Zl/QVSX8m1x/LtOrSn9z20MOc7R6R1c5akPQf1A9q9iXGQr3e5vMW6FI/MAgh3/cgwa2J/UUsVBS97V3+i68XBgv/Q3UafHBpefGdB/0ilKvbbs1Lunvwz9+SdKekF2q0mz/fknRO8i9LWpPsrKQ/IRQAgMlFAAAAE6TbXlmQ7F53vcJM98n9TpmNt1vLJZm+LekPJT0l6XckfYUOgcM7TAAgDRbu8n4QMDgWsJsQ+scEsiyT1N+5d/f+Of6iP8Cv/429VBZyZXljuHkDrp9dumfx3Yf7YoxKt70SJLtT0msk/16XvWzQCTRu65L+SNLTkn7fpT+6jUAAACYGAQAAJNRtr0iymyS9Vu5/W2b3SppPXNalXFHmX5bscUn/VIQBB7baORsk+/fqt1sfytbNAb3epnZbzG8xCzJJ0a904sCU5w3lWS6zcIVfc4C65D+7vHwXAUACg0X/SyT9t5Lul/yWCfxo96yk35P0OUm/c+tDDz+XuB4AmGoT9y4BANOg226dkPSApB+UtKTqzGSJkv7QpV826Tdvfejh9dQFVUWns/Z/mfSCYV/H3VUUPfWKjcF5/v0JFpTnje3rBkeFAGD8zr1/5biZvd5db5L5nVadj3PnJf2ey39dst++7aGHz6cuCACmTWXeMQCg6rrtVi7pVe56k5lerdGe40/Av+GyXzLpI7c+9PDXU1cz6UYVAGxxd8VYaLO38bwz/TtlWa48a/Q7A0oY6kcAMD7ddut2SW+T9HpNWqfQwT3n0j816TGXzt720MNX/kMMABgZAgAAKFm33Top6c2Sflj9ydt1c17SxyW1b33o4b9KW8rkGnUAsGUrCNi6OUDacavAYJp/yd69tLz4s2U/ZFoNjgndJemnJb1G1ekWOog/kfRRl36DrgAAKBcBAACUoP+hXXdI9mOSXqfK7/bvy4bkH5Psvbc+9PBfpy5m0pQVAOwUYyF339fNACP0k0vLi//zuB42Tbrt1h2S3iPp+3XxWs8a82+69DGTPcrPEAAoBwEAAIxQt92SpLsl/0nJXqOp+ND+PN+Wqy3TB2996OFvpy5mUqx21v4PSbelrqMEBAAjdq7dusmkhyW9QfXc8d/Lukv/2PpdRedSFwMAdUIAAAAj0G235K57ZN4y2StT1zMh/krSO9UfFpi4lPQIALCXc+2V3GRvlbwl2bHU9UyADUm/Iem9ks7xcwQAhjeNO1MAMDLddkvd9spLJT1l5l9g8X+JmyV9RtKT3Xbr5rSlAJPtXHvlbsnWJH2Axf+2pvpdEH8p6bFuu/XCtOUAQPXRAQAAh3SuvXKLyd4j6e+KQHUP/i3J/oHcf+nWH/+fpnLad107AFx62/Ly4i+krqOquu3WvKSHXXq7TWe7/0Gcl/zDkj1y60MPP5u6GACoIgIAADigbrt1TP2J3G/VdAz3G5Uo17+U6U3TOOBrtbP2l5JenLqOUSMAOLxuu/USSZ+UdLsIEQ/im5Jakn7p1oce7qUuBgCqhAAAAPap214Jkv2QpPdJOp26ngqKkoLLvyHpTSb77Wk607vaWftzSXemrmPUCAAOrttuBUkPuvSI9dvcWfwfgkv/m0lvk/T70/SzBACGwRsOAOxDt73yEsmekfSrYvF/WEHyaLKTJvucy9vn2iu0PGOqdNut4+rPxviQSbPunrqkyjLpDkmfd/mvd9utm1LXAwBVQAAAAFfRbbfmu+1W26UvSbondT3Vt914Fkz2LpOe7rZX+OBeYdaf1I59GLT8f0nSa/v/xmXGZ7EhBZO9TtK/6bZbPzrorgAAXAE/JAHgCrrt1itd+l8lvctkzdT11ERQ/yjAgN0j6Y+77dZSqoIwtKkc6ngQ/dtCWj8kqSPplh3/KXIac2Sudekjkp7ptlu3py4GACYV7zoAcJlue+WYy9omvVkEpWWIuhgEbP3vuy7p77n0K7fV9Czvamfti5LuTl1HCf7HpeXFX0pdxKTqvn8ll9kjkt4uKbgkkw/mYVg0fsaUYV3Sw5J+jiGBAHAp3nQAYKDbbulce+WVkv25SW8RPyPLtHPxL/VvU3jMpEeYC4C6ONduHZPZZyW9Q4M/7yapf+qfxX+JZtUf1vqFbrtVu5s3AGAYvPEAgPpn/V36kMl+V9LNqeupueDuV2ob/3GT/Wm33arjTnldscN6mUHL/wMm/e+SXnP5fzcZn7/G425Ja91268Hu+1f43xwARAAAADrXXrlT0pdMeqv4uTgWe+x83qH+Od63jKseDIUhgDuca7dySR+S9Li4MWQSzEt61GVPdtstvh8Aph4fdAFMrW67Fbrt1oPm9iX1F50YF9tzBE1Trl/stls/0223xlHROLBQrrluu9WU9Osuf2vqWnApM32fS39+rr3y6tS1AEBKBAAAptKOu7gflWk2dT1Tx33v959+RvAeyd/Rba+UXdEYOK3yNTa4fu4xkx6w/c1Y5vaEMTPppLk90W232uf6YQ0ATB0CAABTZ3C+fE3bd3Fj7MwOsPixtqQfKK0WYDTeI+n1qYvAHkxB0rsk/UG33Xph6nIAYNwIAABMjX7L/8qD7npGDPqrkiDpV5nmPaHc11OXkFq3vXK/Sz91wC/jM1hCJi1J+uNuu/V9qWsBgHHizQfAVOi2W/OSf0KyR81E62fl2IK7P95tt6p7XMMP0vVQIQfq5qifbrt1s2S/vK+mf0yak5I/ca7d+qnBEQ4AqD1+2AGovXPtlVskdSSjPbfCzOxO77dZVxVDAGvmXH/R+MuSjqeuBYdluUnvlfSZbrt1LHU1AFA2AgAAtdZtr7zcZF+S9JLUtWBblPYxBHAXJn97t9166agLAg7DpDdIeuUhvzyIQYCT5LWSf7Hbbr0odSEAUCYCAAC11G23dK7detBdT0k6kboeXCJof1PSd2G5pI+co113kkzl7Qbd9spxSY8M+zruPoJqMBp2u6Qvdtsrr0pdCQCUhQ9QAGpncBf3RyU9amac96+fuyW9LnUR2DaVRxtcamn4cDHYlM9QmEDHJXuy22492G23UtcCACNHAACgVs69v3Vc0hOSfoShXBMlaoTtzia9p3IDAY1p+XVxrr1ym8neMqKX4yjA5Mnd9aikR7vtlTx1MQAwSgQAAGrjXLt1s5m+IIn2zQnhcqm/uAka7XvOzS69cYSvNwbs9NaFST8taZQB1FYIwJ+RCWH9BPlByT7XbbcWEpcDACNDAACgFrrt1stM+qKk21PXAklmmjl2NOaN5tbif/SPkP9k5boAUHndduu2km4UCZJCY34uNo7MEwRMjldLeqbbbr0gdSEAMAoEAAAq7dz7W+q2W6+R9LSk06nrgdQ8Mh+P3Xg6ziwcVbG5WeL7jL1AzAKYBNN2tOGdkkprC+9d2ND88eNh4fSpmM/OEARMhpe69IVue+WO1IUAwLAIAABUVre9IjN/s6TPSqJFM7F8ZiYunD4V56+/PoQ8D5vfOV/6M931Y932SjXey7y20/KnZpHabbdOSPqhMp/hRRGKjY2YN5vhyA03hCM3nIgh5xh6aibdLNkz3Xbr3tS1AMAwqvGhCQAu031/S5L9jGS/qBJ347C3kOfxyInr45GTN4S82dx+X9k8/53Sn22mOyR7eekPGgWbzmn5NfNmSfNlP2Tr746ZqTE3F47eeFpz110bLfCxLbHjkp7qtlv3py4EAA6LdxIAldNtt4JMH5L0HvFzLB0zzV57TTx64+nQmJ8PZhfvXfAYY29jY1zfm783pucc2tNP/yvFWMwWRU8xxsrf/e7uKmKhGAsVRW8qum+67VYu6YfH8azN9fVL/oyYmWaOHg1HbzwdmwsLU9NxMaHm3fV4t916c7e9kroWADgwPjgDqJRuu9WU/BOS3pq6lmnWPHIkHrvpRs0eO3bJwn9L78IFaXyL3Fd3262bxvWww3jFK+5TCNl6CJncozY3L2hz84KKoleZMMA9qtfb1MbmBfWKTZmZQsiUZflzqWsbk1dKumUcD4qbm8FjfN5CP2RZmD9+XTh642nmAyRkplzSL0v24912K3U5AHAgBAAAKqPbbs1L+nRJE7ixD1mzGRdOnYxzx68LIcuu+Ot6Fy6MsSo1VZFhgGamLMvVaMwohFy9YlPrF/5GGxvfUa+3KffJ6Q5wd8VYaHPzgtYvnNfGxrpkUiNvqpE3FWz7I0RdZxtc7n8Y58Ou9ncoazTCkRtuCPMnro9X+3uI0j3i7u/rtlt8ngZQGfzAAlAJ3XbrmMufkPT9qWuZRhaC5o5fFxdOnQz5zMyuu/47FRfGftz9vx/3Aw9he1p+PwjI1GzMaqY5J8m02esvtC9sfEebvQ3FWIw9DHB39YpNbWysb9ficjUbM2o255RnDe31va+jbnvlWo35Z89ef4fMTM35+XD0xtOaueZY1BR+XyaBmf2EpA+dez8hAIBq4IcVgInXff/KcUlPWVWGvdVMc2EhHr3pRs0sLOy58JcG58M3N8dQ2Y5nSnd02607x/rQg3tey/ZWG32jMaOZmXnlWWPQar+hCxvf0YUL57WxuV7aUYHtXf7ehi5cOK/1C3+jzc0Lil4ozxuanTmiZmNWIWRTufC/yO6XNDvOJxab+wvRLATNXXNN/1jA3CzHAtJ40EyPDeZEAMBEIwAAMNHOtVdOyOx3JS2lrmXaZM1m/1q/49eFcIDp4x5j9BjH+v5iktz1g+N85iiZmYIFNRozmp05ojxvSjK5XEXR08bmutYv/I0uDI4KxCGOCrjvfM3zg9fcUPSoELa6EubVyJv7WvS7vNaLzsEZ77H/2So2D3ayIsvzcOTEif61gRwLSOENkj5BCABg0hEAAJhY3XbrhMk+L+mu1LVMk0va/Xdc67dfsZfmSLiZ7q/DWVwzUyNvanZmXo185pJFeH+3/oIubB0V2LygYo+jAv1d/tjf5d/4Tn/mwKCrQOp/XZY1NNOc10xzTlmWH2i332Tre/+qSjsh9/vG/VAvil0HAV7NzmsDZ44dq3UwM6FeJ+nx/rBaAJhMlf+gBKCeuu3WaUnPSHpJ6lqmSfPIfDx64+m433b/3cSiSLXweLFLL0707P04UDJiZsrz/sK82ZjdOXRP0mAqf7GpjY3vbA/pK4pNufuOXf4LurBxXhc2zvd3+WOx4/WDGvnMoM1/Rgfp8pgyr5ZZkgWdH2z9v81C0Ny1g2MBM9wWMGb3S/oUIQCAScW7PYCJM1j8Py3p9tS1TIuQ53Hh5A1x/vjxELJsqPcGL2KyFliTXpPq2XtyHWoy4tbNAc3mnJrNOYWwW3u3q4j9Bf/6hb/Zscu/+bzugCz0X2umOac8n86hfgf0t1M9+IANAM+TNRrhyMkbwvz1x6MR8IwTIQCAicW7AYCJwuJ/zMw0e82xePTG0yGfnQ2jmCTu7imvhUu2WCubmSkLmWYGi/csO0jOYsqzhmZn5tVsziqb+qF++9Ntt2YlvTJZASOYpWFmah45Eo7eeFrNI0foBhif+11OCABg4hAAAJgY3XbrhOS/Kxb/Y5HPzMSjp0/F2WuuOXS7/8Rxf9m5/q0RtbY1rG92cHPAFX/d9mDBeTUaMzIb/du+77jesIZeJunaVA8f5b0PIcs0d/y6sHDyhhjynCBgDKx/ewQhAICJQgAAYCJ0263jkj4v2aRf5VZ5Fkxzx6+LR07eELJGY+TvA2YJ31vMmmZ2b7LnX8XoL/EbnOO/7OYAScqyXDODIwN5Vm6bv+1yvWFtuH9vyseP+vtmZspnZ8PR06cDQwLH5n7JP8ntAAAmBQEAgOS67da1kp4SA/9K15ibi0dvvHGoIX97mYCzxv9V6gJ2ZV7aTvnOmwP6Q/1mFWjzH0q33ZLM0rX/S7IQSjlOY8H6QwJPn4pZs0kQUDp7QNKvEgIAmATJP6UBmG7ddmvBpSfUb7VFSSzLNH/i+jh/4vqhh/ztJf0d5H7f4O72qWNmLPpHxOXHJL00ZQ1l/13Nms2wcOpkmL322jiK+R+4MpdeL+mjdbiqFEC18UMIQDLddmvW3T9r0j2pa6mz5pEj8ejp02rOz4/lrH/Ir3wmfTzsdkknExcxTVIOfSyNyZYkpbvRIoRoZQxtuPw5Zpo9djQcPX2KKwNLZJJc/mZJH+i2V/j8DSAZfgABSOJcu9WU63FL3GJbZ5ZlOnLDiTh3/LoQyt1IvOy5IVgIqRcShEpj4oe83rACvivlw7NmU+Pcld+6MnDuuuvoBiiJyeTS293t4WntUgKQHgEAgLE7124Fkx6T6ftT11JXzYUj8diNp9WYmxv7hP/+oLGZsT5zF8upC7icyS6krgEHspTy4Sn+DpmZZo4uhGM3no75LN0AZTBJMv8ZSe86115JXA2AaUQAAGCsuv3F/4fUPw+JEbMs05GTN8T548dDymF8jdm5ZM8euDt1AZfzmrbK11G3vTIredLz/yn/DoU8D0duuCHMHacboAzWjwEeMemNqWsBMH0IAACMTbfdkstbkh5MXUsdNY8Mdv1nZ5P/bM/n58bavryLO7vt1mzKAlBl9mLJjqV6emg0YmjkSf8em5lmFhbC0RtPi9kApQiS/eK5duv+1IUAmC7JPyQCmA79xb9+1GQ/k7qWurEsbJ/1n4Ar+CRJIYTQnJ9PuWhYkHR7wudPi57kNexs8LtSPn1mYWFibnPI8lz92QDcFFCC3KRPdtut+1IXAmB6TMYnRQDT4AGTHhU/d0aqMT8fj55Oc9Z/LzPHjqYuIWkL9+VMquUuqpnV8PdlfyvZk0NQ88iRifo52Z8N0L8pIGs2a/j9Tmpe0me77dZLUhcCYDpM1BsMgHrqtlsvl/QJ8TNnZCwEzV9/fZy//ngIWZa6nF2FPA/NhSMpFwuLCZ+9m/XUBWDfki3GZq+9JlqYrDBvS9ZohIVTJ8PsNdcQAozWtZKe7LZbt6QuBED98WEcQKkGuxqfkcR57BHJZ2fi0dOn1DwyP3G7/juZmWavuSbZLACX7kzyYFRat91qKtHxkdBoxEnb/b9c/+/1sbBw+lQMeU4QMDo3Sf5kt906kboQAPU20W8yAKrtXLt1s6Qn1d/dwLDMNHfdtfHIDTeEkOepq9mXkGVh9tjRJIsEk+7otlvV+B+qqlxR9TvacIv6MyTGbu7aaybm7P9e8mYzHD19KjQXFur2/U/IXizpiW67NZ+6EgD1RQAAoBTd9spxSU9Iuil1LXWQNRrx6KlTcebo0Yne9d9NwpqPSXphigdPjf63tW5DAO9I8dCs2Yj5BNzgcRAWguavuzYcueFEtKxSpU+yuyX9OuElgLLw0xrAyPWvX7PPWKIP0nUzc3QhLpw+FbJmo5I/sy0ENY+m2SV0+STdBMAMgArwRO3/M8eOVWb3/xJmaszNhaOnT8d8bpZugNF4reQ/3223UtcBoIYq+WESwOTqtltB0mOS7ktcSuX1r/e7Ic5ee23ldv0vN7OQpKNa1m+pnRQsjirApP9i7M/MstiYm6v0Z7KQZeHIiRNh7rrruC5wFNwelPQOQgAAo1bpNxsAk6XbbsnlD0t6Xepaqi6fnR1c7zdb+cW/1L8RoDE3l2IB/J8neOb0cI/y1EWMzrn+YmvsodHMwkI1d/8v078ucCEcPXVKodEg8BpG/4/DI5J+IG0hAOqGAADAKL3RZD+Vuoiq6w/6OzGx1/sdVnPhSIrHvijFQ6eGWZRpI3UZI+Oeqz8EcKyaR5L83ShN1mzo6KmTDAgcXi73T3TbrbtTFwKgPggAAIxEt916uaSPip8rhxbyXAunqznobz/y2dlgWTbuBcFt3fbKpPyZZDE06Uw3acw3AOSzszHk9ZugZyFo7rprw/yJ66OF2v32xsdsXtJnu/1bdQBgaPxEBjC0c+2VF0v6tKRm6lqqqjE/H4+ePqW82aztz2UzU2N+btyPPSlZmgEEl3NnCOCEM1mC3f/63vhmZmrOz4ejp08pazYJwA7vtOSfO9deOZa6EADVV9sPmgDGo9tunTDZE5KOp66lksw0d/y6OH/98TANu2TN+bEvdoIStHSjqny8f1ZMqvrwv/0Iea6FUyfDzLGjhACHZnea7FPn2itcDwhgKLV/0wFQnm671ZT0uKTbUtdSRaGRx6OnTsaZhYVatvzvJms2g2VhzIsAv3m8z5sqUVIvdRGjY7eO82n5zOzUtMebmWavuSYcueHE1PyeS/Bqk32AmwEADIOfwAAOZfAB5FFJL09cSiU15ufj0VOnQlbjlv/dmJkas+M+BmA3j/mB0yQuLS/WaVf35nE+rDE39iMxSZmZGnNz4ejpU5EjAYf2VpfekroIANU1VR88AYzUW8WHkIObspb/3eRzs+N+5H867gfuyowZAJPvheN8WGP8fxcmQsjzsHDq5P/P3r3GWHKed2L/P29dz7V7+jbNIUWTQ5oajRiGobk0V+JSXJGrcGVCUQRBURRZyyhareO7ZdOGV6s+4BJagawIgpYgBMNxDMNYOPZi4S/BfjIBO9AM8oGTIIgXMZw+kijxJnI4Qw6nL+dS75MPp3tu7J7pc/pUvXWq/j+AIED2qXqmp6pOvc/7vM9rohaXBExCgOd3Gu8SEY2tmm+fRHQo3aTzCQDfdh3HrDG+Z5sVK/nfSxDnO+jRnAd1NJu6SSfXa8X4vjVe+br/H5SIIJ6fM/WlRYsKPw8nFAL65+vJGvubENHYKvvFQ0ST6SaduwD8GQA2IhqDX4tt8+iqKXOX/4MSY0ye5b8C3JLXuSqoTDO4sagu5XUyP45R9YHvlbsEmCAo07WUA1kSyF92kw53BiCisVT+RZSIDq77XGcewF+CHf/HEs+1bWNpyZjqTva9jx9HOZ5Nb2HTrKxo33UEU7Sws+d6LvK9B4rNCwK0jq6YoF5nEmA89wD4k27S4ZcLER0YHxhEdCDdpGMg+BMAJ13HMivEGDSWl2w8N1fpkv+9+FGegx+ZV2gRNlsv02C5hHQ1z7Plew8UnxiD+uKCqR2ZZxJgPJ9W1Q6TnER0UEwAENENrSdrAPA0gE85DmVmeEFgW6tHbRX2+J6EF4a5nUtV6wIpQplsibbLKyM5lteZjO9bMRXtAnodIoKo1TLNoyvcKnAMIvKvAHzadRxENBv4dCWiGxLIZwD8S9dxzIqgXrfNoyvG+D6fsfsQY4zx/Vxm+kQEmvPs7rVefPFvYlV1GUImVIEXX/ybslznuV0jXhiCVUH786PItFaPglsFHpjBaCnA3a4DIaLiK8uXNhFlZP25tZMA/hh8XhxIPD9f6S3+DkpE4EX5VQEIZCW3k+1BFWY47N81HA5gbYpZTgaoWqTpAGk6hKpuq2pZBmm5XSN+jtf+rDK+j+bRFRM2GmW5vrLWBvQ/rD+3Nu86ECIqNr6hEtG+usnaPET+EkARyqcLTYxBY2XZxu0W1/sfkJ/jMgDkOLu7l8ce+9hmEER/53k+rFr0B9voD7Z3B9EuQ7shVYW1KQaDHvr9UczG+PA8H8YY+9hjj7gOcUr0aF5nynMJzCwTEdQWjrAvwIHJXRD503U2BSSi6+ADgoj21H2uYwD5YwHuch1L0ZkgQPPoURvEMZ+pY/CCPAdB+W3vtn8Iui0i8L0AYRDDMz6G6QDbvQ30+lsYDvuw1jpPCKgqVBXDdIB+fxvbvU0Mhn0Y4yEIIvh+OcvXNccqES8I8jrVzLvUF2BlmX0BDkCAJwT4V2wKSET74T7eRLQ3wb8EmwrdkF+LbWNx0bCh1/i8MM9BkCzneLIbEpGdGXQPqhbDYR+DYR9Af/T/jA9jfBhjchlsjwb9FqlNYdMh7E5Vv+8FiMIaqnB5S07bmxrftxAp/y90yvw4Ns3Vo3bjrbPGDgauwym6bwD4PwH8b64DIaLi4RcQEb3PerL2OEZd/+k6onbLNpaWuN5/UiJGPC+X0l7NaXA3LhHZmVmPEYV1eJ5/efZ9sIXt3gb6/W0M0wGmvdReVZGmQ/QHo1n+3SoEBRD4EeKogSCIbjT4L83OBgrkUiXiBUEpKyjy4Pm+aR1dQVCrcUnA9fkYNQU87joQIioevrUS0VW6Sec2gfwp+Hy4rvrCgo3n5rje/xBEJLdS6Lxmdyc1SgQYhEGMOKrD9y7/XlI7xGDQGw3Sd8rxJ2kkeGkt/7CPXn8nubDThwBQeMZHFNYQhTX4/oEHqf2xgiiw3CoAWP5/KGIM6kuLJmq3mAS4vgUA/76brNVdB0JExcIXfCK6pJt0YgB/jpxmwmaRGIPm0RUbNhsc/E+BF+S2Es19AkDkQINlEYMg2JmB90MILl9ndme5QK+/hV5v84aNBK+c5e9dMctvbTo6FwS+HyKO6gjDGMZ4VZ6dzqV7eo7XfGmJCGrz86a+sMAkwPXdp8AL7AdARFfitxARAQC6SQeq+h0RecB1LEVlC37/nwAAIABJREFUAt82lpeN5/tMnk5JfrOhWoStscYqlxcZDc49L0BqhxgOr14GoBgN7kcz+IAx3k7vAANr09F6/p2B/rWM8eB7QdUH/Jd0k44PoJnHuVgBMD1hs2GM79mNs28btcwF7EUgTwI4BeB/dhwKERUEX2KJaId+UUR+yXUUReXHkW0ePWo8n3nTacrv9ykzu5Xl7s4BUVhDGIxm6fcyKu/vodffurRM4FqeFyAK64jCGjzP5+B/hwJtzemdyPAZMlV+HJvm0ZVRc0Xaz/Prydq9roMgomJgAoCI0E06dwPyPddxFFXYaNjG8rKpQif0vOU3GCpEBcCh7O4cEAbxaABvDva7EzEI/BBx1EB446Z+49qc5sFcEaApObwTiTFWuAPA1HlBgObRFeNFEZMAe4sF8u+7SWfmn4NEdHj8EiKquG7SaQL658ip/HXWxHNztrZwhOv9MyKeB+TyuxXn17cqpjI42d05IAx3dw7Yu6TcGO9SssD3w4xm+8drRFhguVSIGJ9VF1kxnofmyrIJ6nUmAfZ2J4A/6iZrfPcnqjg+BIgqbKcx0PcAOek6liKqLy7YeK7NwX+GRMSYfLYCDHeaXDojgu1pH3O0c0B0aeeAS8sFIpb5jym3BABlR0RQX1zgDgH7+wwgv+46CCJyiwkAomr7qgJfdB1E0YgIGivLNqjX+YzMQY6DIudVAFnZ3TkgCusIggiGVebjymWrNOPv3b+BpkdEEM/NmdqRI0wC7O3ZbtJ50HUQROQO3xCIKqqbdO4F8B3ODV5NPM82j67YII45858T4+UyKDLIaZDnUv7X7MG2NpwB+ewA4LECIA8igqjVNI2lJZvPEqOZEgL4d92k435rVCJyggkAogoarfvHn6ECA6JxmMC3raMrxgtDPhtzlOOsqNMlAKWk421tWFzKCoASCuo101xZtsIGrtc6DuCPukmHvxiiCuKNT1Qxl9f944TjUArFi0I0V1YM1+jmT/KpAEBeg7x9z67T7wFA0yL5JAByu9Zplx9Fpnl0xUo+vUZmyacBZT8AogpiAoCoep4E1/1fxa/Ftrm8zJdzR/L7veczyNtfaTrml1Eu1SH5JbvoSl4QmNbRFWMCn0mAq8i3uknnftdREFG+mAAgqpBu0jkJ4HnXcRRJ0KjbxtKSYYmoO8bz8vnlK8JczkOzKPsEgIgVwweNK8b30Vw5Ci/kY+AKMYA/6yadedeBEFF++EVEVBE7W6D9GUrcCX1cUatp6wsLbPbnmHhePuvIhT0Apk1RmmUNmY8KOfh3z3jGNFeW4ccxKwEuuxPQF9aTNddxEFFO+GVEVAE76/6/DeAex6EURjzXtvH8PAf/BSDG5NV4wWkCQERK0jCvlGpZn8B4ZsjnjXtiDBrLSyao15gE2KGQLwjkSddxEFE+mAAgqoZPA/gl10EURe3IvI3abQ7+C0SMyeNl3PV3Xlm2zCujHCoAuAdgUYgI6ouLJmw0mAQAsPNN+Hw36bA5MFEFuH4ZIqKMdZPOrQD+ELzfAQC1hSMIm00O/gtERJBTDwZue0n7yXxwLp5hBUiBiAhqC0dM1GoyCTDSBPDvdpYLElGJcUBAVGLdpOMD+BMAS65jKYL64qKNmk1w8F88klMfQJouEfYAOCjDHgCFIyKI5+dN1G4xCTByH6Df6rIfAFGp8cuIqNx+F8AjroMogsbSog0bdT7zCsqYXLZH48zW9JVk4KTZVwAY7kNfRCKCeG7OxHNt/v0AAOTXAfmk6yiIKDt8GSYqqW7SeRBAx3UczomgsbxkgzoH/0WW0xIA19fANkozYKZxiRH2ACgoEUHUbpt4fo735+g5+UfdpLPqOhAiyobrlyEiykA36bQB/ClyKGsttNHgH0GtxmddweWUAHBKVV2HQPtQSB5NANkDoMBEBHG7bWrz80wCAKsYJQHK/2AmqiDe2EQls7N277sA7nQcilsiaCwtIYhZ9T0LxAhfumeRohSDWsnhfYgVALMhbDVN7QiTAAA+qcAvuw6CiKaPCQCi8vksgCddB+HU7uC/xsH/rBBjODiaRcKtDQ8qp60u6ZBEBGGTSQAAENVnu8+tnXQdBxFNFxMARCWynqzdCsgfuI7DqUtl/xz8zxKR8m+RJiIcLFcYEwCzg0mAHSJ1FW4NSFQ2TAAQlUQ36RiB/BGABdexOLM7+GfZ/8wRU/6tGVW19EkO2p8IlwDMkt0kQFzxngACuRfAM67jIKLpYQKAqDx+E8BjroNwqbG0aDn4n1EcHFHZmfJXuZSNiCBqNbk7APRr3efWHnEdBRFNBxMARCXQTTr3APim6zhcaiwtWXb7n13CwdFMUtVt1zHMCpHyV7mU0SgJ0DLxXLvCSQAxEPnjbtKZdx0JER0eX5aJZlw3WYsB/AmAyk591xcXbVDn4H+WiZT/r6+MA0CR0uzekHkig0sAZpeIIGq3TdRuleV6n8RtAJ7vJh3XcRDRIZX/jYuoxEZb/snTAO51HYsrtYUjNmzU+SybdYLSD44+8tGf2wZQ5QFEgWm2hy9PoqSyRATx3JwJm80q/11+EcDnXAdBRIfDl2aimSYPAfo111G4Upuft2GjwedYCeQzO85ydXKjRJUSlSYiqB2ZN2Gj7joUl15YTzrHXAdBRJPjizPRjOomnTaAPwaqWVYatds2bDVNGcuqqyifHgAchGWgFL0bFJJpcojPqfIQEdQWFhDUalV9niwJ8AfdpMMxBNGM4s1LNKNU8W0Ad7qOw4Ww2bTxXJuD/zLJpwKgFIPVYtG+6wimQbJemsH1/6UiIqgvLRo/ilyH4soTgH7FdRBENBkmAIhmUDfpfFIEX3YdhwtBvY7akXkO/ssn8+8jVRRhsFqEGOh9sk1k8HlVPiKCxvISvDCoaCWAJN2kc9x1FEQ0PiYAiGZMN+ksAPhDVPD+9ePY1hcX+DJdQpLDNgAi4rwCQJVNAIsp42ujANceTZ8Yg8bysjF+JQs82gD+mEsBiGYPb1qiGbKz/c7zACrXgMcLQ9tYWuTMf5ll/3fL2fepK839uJHp0fncKi3jeWgsL1sxlXylfhjAb7oOgojGU8mnFdEM+yyAz7sOIm/G99FYXjIVfcGqjBw6pTvbBeDFF/964cUX/2Yh8+3mcqSqsDb1/+qv/roMN2amM/RMXJabF/imsbxsK5noUTzTTTonXYdBRAdXhi9tokpYTzorAF5Axe7bUYnlkjWe5zoUyl7WCQCXFQDnABxL0wGGwz6sTaE6e8kAVcUwHWA4HMDaFCLm4mOPPVKGZQ1ZXxuVem5XkR+FprG0WIZ7YTyCugJ/1E06lVwHQTSL+IVENAO6SQcyGvyvuI4lV6MmS9YLAj6rqiD72TNnFQCPPvoIHn30Y3/recGmMT6G6RC9/hb6gx7SdFjYZMDOLD8Gwz56/S0Mhj0YMfA8H57nl2gFQMbXhvB9qwr8ODa1hSOVSwII8CCA33EdBxEdDL+QiGbD5zAq/6+U+sKC9aOIzymaDlVnCYBdIgJjDMIgQhTGEBH0B9vY7m2g19/CcDiAqnWWEFBVqCrSdIj+YBu93ib6g9GvLQxihEEMY7wylrRvZnlwKVGmhPYnIggbDRO1W5VLAgDodJPO3a6DIKIb44s1UcF1k84xjGb/KyWen7Nho85nVIVI1rOkIs4TAFcSMQj8EHHUQOCHULUYDHvY7m3uzLbns1RgNMtvMRz2LyUj+oNtqCqCIEIU1hH44d6DfpWyNFbMugKAKkJEEM/NmaBeq1oSIMZoV4DQdSBEdH1cr0NUYKOu//oCIEuuY8lT2GjYqNXi4L9ystsKUAErGc/yTkpE4PshPC9AaoeXqgCGw/5OZzqB53nwjD+12ffd0v7UprD26iUIvhfA8wKYAzTdFMHg0MEUQyGvDZpNIoL6woK5OHzLpv1+lb7L7gf0dwD8G9eBENH+qvRQIppFnwPk066DyJMfRba2cITb/dFU7VxNRagA2DcGEYHvBYjC2qVS+5HLJfmXlwr0Ye14E4yjWf4Bev2tS7P8aTqAqu5UI0SjaoQgOtDgv1QyXx6S+Q4XVDA7DWwhlWtgK9/grgBExVaxb3ii2dFNOqsAnncdR56M79n60iIH/5QFi2LM8t5wICgi8DwfYRAjCmvwzNXFepeb8m1iu7eJwaCHdI+lArtr+QeD3k7iYBODYQ/Wppd+xjM+wrCGKKzB94Myru0/EBXJtgdA9ltcUgEZzzPN5aWqbQ+4uxSAVcZEBcWbk6iARqX/eB5V6vovgsbSMrjdX4Vl+5I8vOOpp2dqvbqIQMRDGHqj2ft0gDS9uuJe1WKYWmDnv4+WCZid0v50r8NCIPD8AL7nQw696kJLMbAV4KLrGKicvDA09cUFu3n27SpNuj0A4GsAnnMdCBG9X5UeRkSz5LPQanX9bywuWi/kdn9VlvEcWRFm/ye2u3NAHDXg+yH2+22ldnipeeD7jiHeqKog2m3qd/jbTVGsxoqTUyYAKDNhvW7iuXYpkmUHpuh0kzUuBSAqIL5sExVMN+ksAXi+Sl2j47m29Wsxn0eUoWIM8BQ7ff0mJCI7OwfUEfjRgUr2Pc8f9RUIY3ieX9ky/+uTTdUbL88gmlTUbpugVqGdAQR1QP6QSwGIiocv3EQFsj4q/f8OgFXHoeQmqNVs1G5z3T9lTAqRAAAwlWUIo50DAkRhHWEQvW82/3KioHGpoSDvseva5K+HsiQiqC8uGOP71UkCAB8B8MuugyCiqzEBQFQgAjwB4Auu48iL8X3UFxc4+Kc8FCUBMFWjhoGXdw643DywDt8POeg/KMUmDtCgkegwdncGqFRTQMU3u0nnuOswiOgyJgCICqKbdNoAXkBV7ksRNJaXrFRtuzFyQhUXXMeQpSt3DsizzF+0EFsrHtodv/u0RUmTRFQsXhCY+uJCdZJNgiaAP+gmHX7ZExUEb0aiAlhPOlDFswBudR1LXuoLC9YL2PSP8iFSjARA6eb9pFSz5oW4Rqj8glrNRK1Wme6dG3kMwJOugyCiEb58ExWAAA+L4Kuu48hL2GzaoF7j84fyVJTZ3VLMmJcUEwCUCxFBPD9nvCiqUhLg292kc8x1EETEBACRc92kUwfwB6jI/eiFoa0dmee6f8qX6juuQ6DCYwKAciMiaCwuoELL4OYVeL47anZMRA5V5qlDVGDfAHDCdRB5EBHUlxY5+Kc9KTS7g4twcJeNQ21rWDBMElGujO+b+uJiZaoARPEZAJ9xHQdR1TEBQORQN+ncC+BrruPIS21xwXo+twSmfWQ4/gdwPtOjV5VOZ1vDgmCSiHLnx5GJ2hXpBzDK/T/fTToLjiMhqjQmAIgc6SZrPkal/6HrWPIQNhs2rHHdPzlTiNldLUnX/JLK7BpRVT77aE8ignhuznhhJV4FAOAYgGe5FIDIHX4hEbnzqwAecB1EHkwQ2Nr8vKnU3sdUNIVIAAj3mi+yDK8RJgBofzvL42yFlsd9GcAjroMgqip+IRE50E06xxXyjOs4ciGoWqMjKqZCJADKJttVG7njMhFyxvN9U1s4UpUEoQHwvZ0myESUM76RE+Vsp+ztBQGarmPJQ21u3nphyGcN3Zhqlg3lzmV47MoSKdWSBl4j5FRQr5ugXq9KEuAEoL/PpQBE+eNLOVH+Pg/gcddB5MGPIxu2mnzO0IFkOpusBakAEC4BKCrVDBMAJSuVoGyICOoLR4zxPNeh5ER+F8DdrqMgqhq+mBPlqJt0lgB8x3UceRBjUF9YQIXWNFJxDSFajAQASjVjXi6imSUAMt3ikkpFjEFtcaEqicJQR0sBuD0QUY6YACDK17cArLoOIg+1I/PW+D6fMeScAtuAbLqOg4pNIFwCQIUQRJGJWs1KJAEEeAjQr7iOg6hK+HJOlJNusvawQr/sOo48BLWaDep1Pl9oPJrNLKkAFxWl2q++SMr0e80yAVCJwRxNiQjiuXlj/IpMjCu+1U06x1yHQVQVfEEnykE36cSAfE8gpb/nxBjUFo4Ylv5TgZy786mnXcdQVlk2bsyVAheQVUJDmQCg8YgR1KuyFEBkHsB32BCQKB+lH4wQFYP+DoCTrqPIQ+3IvK1OAyOaEWddB3AF9gAoKAE2wb8fKhC/QksBAHwOFWmQTOQaEwBEGVt/bu0uQH7fdRx58OOYpf80MVXNqt61SAmAqrzMz5w7nnp6qMhqtwg2AaTJxHNzxvh+VZ4bL3STTiW2SCZyiS/qRBlaTzqAyAsA6q5jydxo+yJ2/afC0WIlAEpFS1baLsCbWRxXM+pvQeW3s6zOdRh5OQ7g666DICo7JgCIsvUFAR5zHUQeavNz7PpPhSSazaCOAIiWrWSeySIqnCCOTdColyrZdh1fW0/W7nYdBFGZ8WWdKCPdZG0BwLddx5EHLwxt2GzyeUKHk9UsqeCtbA48AdXSNM0rKSaLqJBq8/NGTCW+ZkNAXlhPOpX4wxK5wJuLKDPyjACrrqPIQ42l/1RsxRnUSam2zSsdVc2mAiC7/hZUEcbzEM/PVaIKQICHBfqk6ziIyooJAKIMdJPOgwC+6jqOPITNpvWCgM8SKrLiJACo0ETkp5kcmC0AaArCRsN4UViJJAAgz3aTzorrKIjKiC/tRFPWTdZ8hb4AoPQzPmIMavNzhrP/dFgZN0ljAiAjAilbRQOvFSosEUH9SGUaAi4B+q1u0nEdB1HpMAFANHXySwK5z3UUeajNz9uKrEmk7GW5Np6DuuyUqqeBQnmtUKF5YWjCZrMqVQBPAviI6yiIyoZv7kRTtP5c5xgUz7iOIw9eGNqgUeczhApNgb6qZrS3+ySkbF3zy+YN1wEQ3Ug8165KQ0AD4HvryVroOhCiMqnE04MoD+tJByJIIJh3HUseakfm2fiPZoCeFZFSzVJTdgTCBAAVnvE8xHPtilQB4B6B/KrrIIjKhAkAoikR4OMKfN51HHkI6nXrhSGfH1R4AnnzjqeersqLsgtl+92eU0x/q0b2AKRpC5tNYwK/bPfffjrdpHOL6yCIyoIv8ERT0E06IYDnpQr3lAhq83Oc/afpyqgJoLKkO2ulWtKgQF8g56Z/YK3KQI1yIiKozVei4BAA2gC+vZ6suY6DqBTKP1ghysdvAjjpOog8RK2mNb7PZwdNlVqbya4ZUpAEwIsv/s3Ciy/+9f1akv3gVRXWWgyG/WN/9Vd/XZrnwZ1PPW1Vp980Uq1lAoCmzo9j48dRVa6tzwF4zHUQRGVQmi9tIle6SedWAN9wHUcexBhE7bbrMKiEbGqzWqf/WkbHHcujj37sHCB/Oxz25weDHobDAay1WW9/OFWqijQdYjDoI02HgACBH7722GOPlGoAIjL9a0at9ZVVADRlIoK4OlUAEOD5btKJXcdBNOuYACA6hG6yBkC/DaDpOpY8RO2WNaYarYcpXzYdZnRd6evZHHd8jz76se3Aj37s+yFEBIPBNnr9LQwGPaQ2LVwyYHeWfzjso9ffQn+wDYXC9wP4fgAjpX0UZFI1ommaxWGp4rwgMEG9XpHkkpzAqOKSiA6htN/eRPmQTwDyGddR5EE8z0atFp8ZlAk7zKoAQApRAXCJwIoIPM9HGNYQ+CGsWvT7W9jubaLf30aaDpwlA3Zn+fuDHnr9TfT6m7DWIvBDhEEM3wuu7f9Rqh4AOzK5ZrK7xqnKRATxXKUq876+U3lJRBPiyzzRhHbK0L6LitxHcbvNxn+UmQwHR8VKAFwxYL6UCAhiRGENnvGQ2tHge7u3MaoOGPYzXSpweZZ/gF5/C9u9DfQH27B2CM8LEEcNhGEMY7z97v8yzjy+msVBUyYAKCNeEJiw0SjjvbiXpgLf6SYd13EQzaxSNCMicuQ3AZxwHUQejO/bsNmoRKKD3EgHg0yOW8BdAN73ki4iEPEQhh6sjgbjaTqAtSmsTTFEf5QsMD6M8a43GD8QVYVVC5sOd5YeXA7JGA++F4xzjtJVAKjqa1kkO21G1zgRAMRzbfQ3NlyHkQsBPo1RQ8C/ch0L0SziCz3RBHbKz77uOo68RO0WZ/8pM6oKO8hkdrQvmH5H98NQ6Nb1/r8RgzCIEEcN+H4IYHTfqSqG6QD9wfal6oDhcHDg3eV0J7HQ748+3+9vYZhe/rznBYjC+qgSwfMrfb+LZLNsJKskFxEAGN83YbMyVQBGge+yISDRZFgBQDSZBBVp/Gc8z4YNzv5TdjRNrVqbxTX2zh1PPb2ZwXEzJyII/BC+FyBNhxim/auWAexWBwyGgIiB5/nwjAcRAxGBqkLVIt1jlv/yOQx8LzjcgL9YfQunJbMEgKpWOrlC2YrbbfQvVqYK4CSAXwXwP7mOhWjW8KWeaEzdpPNxAJ91HUdeIq79p4xlWP7/SiYHzpGIwPdHs/NhEEP26Lw/mt0fderv9TZ31vKP/n3lLP8uz4waEEZhDb7/vqZ+YwaImUyw3MCbgPanfVBNrVFrqzJDSw4Y369SLwAA6HSTzjHXQRDNGiYAiMbQTTohKtT4TzyPa/8pc2l/6mOtXUVrADix3YaBUVhDGNZgjLfnzykU1qZ4/9S8wPcCxFEdYRjvVAswsbeXO556ehuQs1kcO8NrnQjAaMlehTQBJOvPrbmOg2im8MWeaDy/DOBu10HkJWo1OUigzA372VQASAkqAK41agboXd45wLv+Sj4jBkEQIY7qCIJozwoC2lMm1w4TAJQ1LwhMUK9VqQrg8yLysOsgiGYJ3wSIDqibdFYBVGbfGRFB1GzyGUGZUtXMBkWq+EkmBy4AEYHZTQREdfhecNX/v7JawPcOWeZ/faVswqXQTBIAQyYAKAdRq+06hDwZhX53/bk19jUjOiC+3BMdwM5+s98CMO84lNyEzaYVw0cEZUvT1GqaZnOhif44k+MWzOVZ/salf4dBfOjtAg96+qxP4IKoZFYBcGUzR6IseGFg/CiqTBWAQO4Vka+6joNoVpTyi5to2hR4AMCXXMeRp6hViU0OyLEsZ0QF2QziDkMgwY1/asJji2Q9218dkk31iKbWaJpWZmBGbohI1XoBAMAz68nakusgiGYBEwBEN9BN1oxUqPEfAAT1ujW+X5k/L7mT8ZrowiUAFBq6jmHKSvmcyHIHCS4DoDz4cWyM71cp2bQgkGdcB0E0C0r5xU00ZV8C8KDrIPJUwZkDckEVw14vq6P3FXgjq4NPSlCu2XmFlrIHgACZLR9Je0wAUPYqWgXwlW7Suc91EERFxwQA0XV0k04bkG+6jiNPfhRZLwj4bKDMKWDTjHYAAHBOUMg96uuuA5gmQVm3Fciuf8Sw12MfAMpFWK+bivXy8QF8Zz3pVOoPTTQu3iBE16XfAHDMdRR5itotriGmXKT9AaCa1ffQj+946ukilr+W7Xu3bEsadp1VaCYJpLTfNwCKeG1SyYgxiFrNql1rDwv0c66DICqysr2IEE1NN1m7C8Cvuo4jTybwrR/HfC5QLtJ+ZuX/gBZ2B4CylcyX7c+zQ7YF8mZWR8+49wXRJWGzCVQuqS/PdpO1UlVbEU0TX/SJ9tBN1qDAtwEp6cvt3qIWZ/8pPxmu/wdEmADIRykrAO546mkgwz4AmV77RFcwnmfCRr1qVQC3AvJ7roMgKiomAIj2JI8L5AnXUeRJjLFho8FnAuVCVTHMthnay1ke/BBKlQBQLWcTwB0/yurATABQnqJW5ZoBAsDvdJO121wHQVREfNknusZ60gkBfNt1HHmLWk3O/lNuNE2tpmmW30E/yvDYh1GqAbOIlLnMNtOdANgIkPLiBYHxa3HVqgDqgDzrOgiiImICgOgaAvwygJOu48iVyGidIFFOcpgB/VHWJ5hQ2QbMpUpoXOOHWR1YrTV2OKzagIwciltt1yG48Nlu0nnYdRBERcMEANEVuklnBcA3XMeRt7DRsMbz+Dyg3OSQAChql7WyJQBKmznUjK8hLgOgPHlRaLwwrFrSyQD4djdZ810HQlQkfOEnuoICHQALruPIW9Qq7Ts8FVQOg5/Hsj7BJBRatgRA2f48lwjwT7I8fsoEAOVIRBC1K9kL4H4ovuQ6CKIiYQKAaMd60rlHgK+6jiNvQa1mPd/ns4ByY9PU2sEw42tOfyHb409GIGXLtpXtzwMA6CYdH8AnsjxHxk0wid4nqNWM8f2qVQEAIs90n+tUcg0E0V740k8EYD1Zg4wa/1WuTCxqtyq4RzC5lM8e6PLwelLIF74ixnQYJZ1S1PsArGZ5BjscGpum1RuMkTMiUtWKv2MQfN11EERFwQQAEQABnkBBS4az5EWh9cOQzwHKVU5rn+sCPJTHiQ7q9PdfAkpWMq/lS2jskMfzOAv7AFDewkbDiKng177i17vJ2nHXYRAVQQWfAERX6yZrISCJ6zhciFttzv5TvlQx3M5t0PNP8zrRgYy2zAtdhzFNUtIlAArN5dphAoDyJsYgbDarV3kiiAF5tpusuY6EyDkmAIggvwzghOso8mZ83/q1mM8AypUqbDro53XdPb5erJe9Zgl3fp93HcC0dZPOkkDuz+Nc6XYPqiW8KqjQolazqsn/zwDCbQGp8vjyT5XWTTpLqOC2f8Bo7b9U8wWAHEr7fSC/8c5xQO7M7Ww3oMC8lO97t4xLAD6OnPrBpIOBgWr1ZmPJKeN5JqzXq3jd7WwL2Cnbc5hoLLwBqOK0ktv+iTE2rDd4/1Puci55NgLNtJP7OKScg+XSVQCo6n+Z5/m4GwC5UNEtAQHgfoDbAlK1cQBAlbWedE6ggtv+AaPyPzGc/af85b/mWTLdy31MZUw2lurP1E06RkRybQjLPgDkgvF949fiKlYBQIFnukmnlP1LiA6CCQCqpPWkAwESQErVkOtARBA2+b1H+VPVnLYAvMoj3aRTkPtcSzVY3jF/+tSZMr1LnABwa54nTJkAIAdEZNQIuIIEuAXAU67jIHKlTF/aRAcmwCcAfNJ1HC6EjYY1nsd7n3JnBwOr1uZ97c0DeCDnc+5NpYwJgBjl2tow9yXS+feuAAAgAElEQVQjw37fsBEgueBFofHCsJJVAIB+bT3p5JrsIyoKDgKocrrJmg8gQUWv/6jF2X9yw+Fa52IsA5BSVgCEKFdvg/yvFVWk/UFFB2HkkohUuBeANAV4xnUURC5UcgBEVSdPQnGP6yhcCGo16wUB73tywuFa54I0ApSjriPIRjkSG91kLVbgIRfnZh8AciWo1Yzx/aomoL7YTdZy2fKTqEg4EKBK6SadNoCnUdH+d9XN9JNzqi4HOfetP7dWhEHqkusAsiErriOYDnnA1U4N7ANArohIlSsDDSBJN1njeIgqhRc8VYw+BeCY6yhc8KLQemHIe56csGlqNU1dXX+hiDiZ2b1GSQbK71OOP5eqs6Uiw14P7ANAroSNhhFT2deDRxR4wnUQRHmq7N1O1dNNOrcA8puu43AlbrUhUtHSB3KuAHudF6EPQDkGytfSkvy5ct7+70pqrbFpWtUybHJMjEHYbFb2+hPIs91krSC7xRBljwkAqgyFPgOgknVuxvetX4t5v5Mzw77zEuePuzz56VNnTGkGytdQ6Mz3NugmnXkATtcCcxkAuRS1mkB1JwlOAPJV10EQ5YUDAqqEbtK5VyBfch2HK1G7xdl/ckfV+eBGgROjKiBnQojOOzx/ZkSw6jqGw9OHAfguI2AjQHLJeJ4JG/XKVgEA6OwkAolKjwkAKr1u0jGo8LZ/YgzCRqOSf3YqBlW1aX/g9BoUwED1EXcR6BIgpSwxVZUS9FWRR11HMOz12QeAnIpalW4UvKTQ33cdBFEeOCig0lPo4wCcre10LWo1LWf/yaW073z9/4jA4SCvDIPkvYng2OlTZ1yHMbFu0gGARxyHATsYGFWt8gwsOWZ83wS1WmWvQYH8ajfp3OY6DqKsMQFApdZNOr5AnnUdhzMiCJuVbHtABVKABoC7HtmpCHKhtAkA6Gz/2VSxCuBu13EAQFqce4UqSESqvl1wHcA3XQdBlDUmAKjsngS0EC92LoSNhjWex/ucnCrO2ma5TVWPOzq5y/4DmVLBEoDYdRyTEtGHUZD3odR9s0yqOC8MjReGla0CAPD5btJx2hCUKGuF+MIjysJ6stYE8DRQ3fL3iq/nowJQ1eIsARh5xNF5P+DovJnbecLOcILD/fr/XQWqlqGKYhUADIBnd5YGEZUSEwBUWgL5GspcdnsDQb1mvcDnPU5O2eHQqrWFuQ5F5B87OvWtjs6bl5lMABRl/f+utM9GgOReUKsZ4/tVrgL4OIAnXAdBlJXCvJQRTVM36awC+G3XcbjE2X8qgoLN/kPd9QEodQJAobe5jmFCtwK403UQu9RaY4fDKg+8qABEhO8QwLfWn1tzujUoUVaYAKCy6gBouw7CFS+KrBeGvL/JueKs/x+RUVXQXQ5OfZuDc+ZGIDOZ4FDgIRTsXaho9wxVU9ioGzGFujXydreIPOk6CKIsVPrOpnJaTzonFPoV13G4FLdb4NZ/5JqqFrWr+SN5nuz0qTNNAEt5ntOB210HMAmBy60h91bQe4YqRoxB2GxWvRrl6W7S4VZKVDpMAFCprCdrEOBbAqls2ZbxfevHMe9tck/VpoNBAa9FzbUPgKoeAxDmeU4HXO2uMLGirf/fNWQfACqIqNUEqj2ZcAzAr7sOgmjaCvhiRnQY8hCAT7uOwqWIs/9UEGl/4DqEfcjDeXZ4FpGZGxxP4LbTp864jmFct6CAiQs7GBioVn3mlQrAeJ4JG/WqX4u/1006K66DIJomJgCoNNaTNSPAt1zH4ZIYY8N6nfc1FcKwuHuarwJ6Iq+TqWphmsxlaBXArJXKPuw6gP0UrXkmVRebAaIN4OuugyCaJg4UqDQE8gSgD7mOw6Wo1ULFm/bQhCwEF+M2pll4XOxBjOQ2+BPBz+Z1LodCVZ21RoCutoS8oeHOvZOKwUY0a3kVKhPP901Qq1W9CuCr3aRTuGohoklxpEClsJ50fEC/CVS49F0EYbPhOgqaQQrgrfmb8ericZxvLk/nmKoYFriZmUI/lt/ZpAoVABBxsrvCREZLQLS4FQC9PlIxeHXpDry6dAe2wrrrkKiqRBC1K18FEAN42nUQRNPCBACVggCfB+Ru13G4FDYa1nge7+mK6vsR3q0vTPTZjbiNdxpLgAjemrsZ55rLh64EUGutpmlhr0eBPLSedDKP7/T3XwLcbDvogMzSn/OYFjgxM0jtaOAfNaFi8MaRn4GV8S9XBXC2dRRa5eQ4HZoXhsYLw6pXAXyhm6zd4zoIomko7MsZ0UF1k04IZmZH3Xqpki7Gbby8chfOTzBwT42Hn85/4HKn550kwGErAYpd/g8AuFXyaAAnEgO4LfPzFMOHXAdwUAp9SAr6DmSNh3N33W+2rij97wcx3po7Nvb9vR3U8Xb7Jvxk6Q4MTWU3x6FDElYBAIBRyNPdZM11HESHVsgvP6JxKPBlFLCTc56CWs16QcD7uWJGs3ureHXxOKzx0Qtq6AW1sT7/xpFbMfSv2aFuCpUARS7/vyyXniF3AajKyCu3xoqHJUCOS0AOzno+3jn5IAbtxff9v3caS9iI22Md70JjARDBVtzCyysf5FICmlhQqxnj+5WuAhDgU4A86DoOosPigIFmWjdZqwu7szIzX0GpeHh18Tjebq9eNXv/duvogQbtCuBcawUX47m9f+CKSoBJkgAzUAEAheQxCJyZQfEUnDh96sxMvFdojk0gD8p6Pt750M/vOfgHAIjg9SM/g74fHeh4Ay+4alnQ0A/xk+WfxTuNxak2+6RqEBFWGo7GTU/nuY0sURZm4ouaaH/yFYz2cq4sLwqtF4a8lyvm7NxN2KjNXR7877hYm8dmdOOE0Hu1IzjbPva+z19lwuUAqjoTCQBAH8qhnPM/y/oEhaFoYwaex91kbUkKlpix5gaD/92f83y8snj8huX8CuDNuZuhxrv6v4vBT+c/MFalENGusNEw3GkIj6HAW4gSHUTl72KaXetJpw7g913H4VrcakGuN4ijUgoH23v/DxG8tnAbtvd5wVcA7zQW8frCz1x/8H/F8cZdDqBpatXa4n+/KI4Dku2AVbU6zUkFBsBJ12HckMpHUKBlGaOy/xsP/ncNghg/Xv7ZfSsBFMDb7VVcrM3ve4xw2JskVKo4MQZhs1HpZQAYjZ06rAKgWVb8FzSifQjwVQCrruNwyfi+9Ws13scVFA829/1/1vPxk+WfxbnmMlIxUIwGBdtBjNcWb7+66d8B2WtmEq9nOBOz/4CIGAAfyer4p0+dAaRiu5OoFr5Ltgr+kesYrqSeDx2zw/8giPHyygdxrrmCVLxL93jPj/Hawm14u7W67z0eDrdhtOpjOJpU1OKSQ0A/DuAR11EQTaowGXCicXSTtSaAp1zH4VrE2f/KigbbgOq+L/nWeHhr/ha8NXcMQTqAFYPU+GMP/EUtVs+9jPbWOwf+zGyU/1/yjwD8RRYHVui8QG7N4tiFJfKfuw7hetaf60CAPJo/HpjX38bCfzqFd++8D72lYwf+3Ogevxlvzd2EYNiHNd6B7vG4v3/ykOhGjOeZsNGw/Y2NCk8+CAB01pO1v77zqX/tOhiisVX45qXZJl8FcPA3pRISY2zYYEfnqhK1CIf7LAO46gcNBn6E1AvGH/xbi5vP/mCswT8ApP3BWD/v2EOZlXKqnAQQ3vDnyuXe06fOuI5hXyKoA7jPdRzXEmsx9/dnEP/05Qk+bDAI4gPf49Fga4IIiS5jFQAA4BEpYDNRooNgAoBmTjfpxAB+23UcroXNJsSwG09VCbJ9kRe1OHbuh2j03hvrc7PTAHBER2v0918sfQgiWriBZuYUdwEobqtwxQMoaFJGoGh3/2/Eb70yqu7JSMwEAB2SF/jGj2OuIwG+wV4ANIs4eKBZ9BVUfPYf3I6HAET9jF7kVXH0/E/Q3L4w/kdnpQHgDhHxAWS0r7P8XDbHLTCBD6C4fQCkWOX/1xIA7fX/C+G7Z7M5gSpCJgDosES4/TCAnV4AmfWRIcrKzLykEQGXZv8rv/Y/rNet8TzevxWXyUyeKhbe+ynam+cm+ng6mKny/x2aVVO4+zM6btEV+c/9UdcB3IioYu7vX4K3dXHqx/bTATybTv24VD1+FBkvCCpeBSAG0K+zCoBmDQcQNFMU+AKAajXV2gMz7wSMunlPu1S41ruIpQuvY9LWkrNU/n+ZTH0G5/SpM20Ad037uDPiH7gOYC/dpBMq9AHXcRyEGQ4w9/dngCkP1qPB1sT3NtGVhFUAO+RxFLCvCNH1MAFAM6ObrPkC/J7rOFzz49h6QcB7l+CnA5gpDhCMHeKm8y8faoAwYw0AAQCquG+numia7kNB15rn4IHT3y9kI8ATAllwHcRBBRvvovnj/3eqSb5ocIDGoUQHFNTrRjyv4lUAMID+vusgiMbBQQTNks+gujNqlzDjTrsEQHSQnQAOaPnd1xCkkw/gZ60B4C4RtAG9e8qHzaivQPEpcByCVddxvJ/O3Frd+ms/RHDx/NSOFw65/p+mR9iPaId8ej1ZO+E6CqKDYgKAZkI36RhAKp9h9YLA+lHE+5YumVZDr7i3gbmNtw91DLXW2jSdyetTIdNuDlf4teZZEcAvZqm9zNzfiUDR+uHfTq0KgBUANG1hozn2FrMl5ANS+f5UNDtm8kWNKukTAO51HYRrUbsF4RctXWEqL/SqWH731UOvDbaD4eFjcURUpzY4PH3qJYMKVwAAALRYCZCdJl0zVwEAAMHFd9DaePvwZdaqCIe9KUREdJnxjAmbjaovA4AAX+gmnVtcx0F0EEwAUOGtJ2sAtPKZVfE8G9TrvGfpKtN4oa/3LqLW3zj0cdLB7JX/XyLy4PrUOjnLSQBLUzrYTBLgYdcxXOMYgNtcBzGp+bd/cugqgCDtQ7Ty4zTKQNTi0kQAMYDfcB0E0UFwMEGz4H6FfNx1EK5FrSZn/+l9Dr0TwM62f9O4smaxAeAVjkH1tikd65EpHWd2idx36vsvFWZxsI4qMmb2ncfbvIjW1juHOkY47HEHAMqE53kmqNWYXQK+0k06866DILqRmf0ypOoQyFOVf2kRQdhouI6CCshPhzCHmNULhz3Ue+9NJZZ0MNMJACMi0ynbV/3YVI4z20KR6W+vOLnpLfFwIR30Mb9x9lDJvoDr/ykr3BJw1zygX3EdBNGNMAFAhdZNOscBfNp1HK6FjYY1nsf7ld5HoAgOsQygvXluKrOCqmrTwWCmr1FV/MPDHuP0qTM+RIpW/u6G4lHXIewSTCm540jaH6DWu4ggnXyZDdf/U5a8MDReGLIKAPJr60mnqlvA0oyY6Zc1qgDFr6G6e2lfwm126HomTgCoHrqseJcdDqe6X7kLIvhI99B9APQeACvTiGfmCR47feqM6yjQTTqxQme6iWw6GACqaB7ifmUCgLIkrALYdasAn3MdBNH1MAFAhbWerM1D8GXXcbgW1GrW833eq7SvSWcFg2HvUNUDV5rx8v9ddyv0kNk2+cR0QimFewBddR0EgHsEUncdxKGoGk1T29y6MOnnD1U9QHQQQa1mjO+5DqMIfqv73JrrGIj2xUEFFZZAvgyg7ToO16J2i3vs0nUFw8le7Ou9i1NrCmbLkQCIBXKomWJV/NNpBVMCPiCPuQ4CM7r937XSwQBxfwNi0wk+rfDTUtyjVGAigqjZ4jIA4D4VecR1EET7YQKACqmbdEKF/prrOFzzwtB6Ycj7lK5r0pm9aWz9t6skFQDAqFv8RE6fOrMgMvnnS+oXXAcA4OddBzAN6WAAA0U02Br7s55ND9UslOigwmbDcNICEOC3Dr+kjCgbHFhQUT0hkNscx+Bc1Gpx6z+6oUln9iYZSOxFVcuUADjEYFE/AfYsudZjp0+dcfY7Gb2AaymSMrv32CT3Lcv/KS9iDKJmk9km4JMA7nQdBNFemACgwlkfZUx/w3Ucronn2aBe4z1KNzRRAkB14qUDe7B2MJzWsVx7sJusTXTfKfBfTTuYElgC8JC70+sxQG51d/7psf3RfT5JMz+P5f+UIzYuBgD4Cv0V10EQ7YWDCyqi++D0hbEYolaTs/90IJ4dvwO/UQujk6wlfj87HAKl+T7RY4DcMu6nTp96qQ6Vx7OIqAT+a3enlvtRkmszHQ6hOtlafj8tTYKOZoDxfRPUa5WvAhDgyW6yVvleVlQ8pfhSpPLoJh0I8Cuo+rUpgrDZrPbvgMZixmwM5tnh1BoAlqj8H4AYQO8f+2OKR0Qwn0FAZfDp06fOuHqe/UNH550+VWPT1Hp2/MG8N1HjQKLJRS1uCQjIPCBfdB0F0bU4wKCiWQLweddBuBY2G9YY3p50cOMOCmSKDcFKsgPAlcYfNIr8NxnEURa3wF0n/gccnTcTdjCAjFntAwBmgqQB0WF4YWi8MKx8FQCAX+kmHb7QUaHwgqSi+TKA2d6veQqiJjPn06AAtsI6Xlk8jncai7BTm/MuFgHgj50AGH8QsZ9yVQAAgIw1aDx96kwd0E9lFU1J/Ld5n3DnpXv8ao4Cm/ReG/f5MEv6Xog3jnwAb87djFS4B31RiMhoG2M6qaqPuA6C6EpMAFBhrD+35gP6L1zH4VpQq1kv8HlvHpICeGvuGH68fBc2anP46ZFb8cPVkzjfWIItYW+FcdcFW5neJZaWpwHgrvu6yZo/xs9/clTqSftS/eyp77+U724AihOAlmr97ajZ5vjPr0l3Cimyvh/h9SO34kerH8K7jSWcb63gR6snsBGxAV1RBLWaMZ7HKgABmwFSoXCQQYUhIo8r5LjrOFzjurnDUwCvLd6O880VXLkf8dAP8eaRD+AHqx/GueYK0ikOgl3zx9zmy5rpzJSpqrXDYXl+kSNNhZw86A+r4r/PMphSEFkRybdJooo+MMlgucjSwQB2guVhZdoGcDuI8drCz+CHRz+EC41F6BXP8aEX4pWlO3GhxnxcEYgIQr7TQCBPdJNOKXYjoXIo20sbzbb/sVyvauPzwsB6Ucj78pDON5dxsTZ/1eD/SqkX4K35m/GD1Q/jbHsVwykNhl0ad0s/a7ypLImwaTr2DgSzQA5YOn761JljIvhE1vGURK6JEgF+Ps/z5cEOhxh6wXgfUp35bQAvL+e6HS+vnMB79YV9n+8QwRtHbsXQjFPEQ1mJmo39/66qIwT0n7sOgmgXBxpUCOtJ5zjAl+io1eLWf1OwdcASUOv5eLt9E36w+mG8OXczBuO+WBfIuCW+Chl/ILGHEjYA3HWgwaOqfgkARxoH88lT3z9zLL/TjdfLYRaotaYv/lgl1Z4dwkyx6WeeFMBG1MJPlu7cWc61f2L3qs8ZD9thLfsA6YbEGBM1G7N5AU6RQp7sJp18l0ER7YMJACoEGWVGK/0SLZ6HoF7nPTkF7Y1zY81Kq/FwvrWCH6yexOtHbkXPjzFrc9pjl/iKoB/Ehz6vHZZu/f+u+9eTznV/4PSpM76IcFbn4EIRfDmPE3WTThPAgZdxzJJteGN9T/jpYOYWQiiAC7V5vLzyQbyydAe24tZYs8jBcBu13kZ2AdJYQjY2hgC3KPCE6ziIACYAqADWk04IyJdcx+Fa1Gxazv5PR3P7Xdxydh1Rf2O88nQxuNBYxI+OnsCri8exGTZmJhHgp4OxS/F7weFnyErYAHDXSQFuVEryOIDK9y0Z0z8/fepMHsneuwEcPsNVMAqgP2aTu1lqAGjF4HxjCT9cPYnXF29HL6yPNfAXtZi7eBa3vvn/wZvRqocyMr5nglqt8n8hAvyL7g0Sy0R5qPSMKxWDjDKiOZaFFpAIwmbDdRSlIQAavYuov/n32AobeLu9is1ojBkkEWzU5rARtxH3N7Fw8U00t94p9CyasSkECh0jyu3w8DtulngJQIzRIPL/uM7P/EZOsZTJrQA+A+AvsjyJQu+XQt+xk7FBhDQe776dhQTA0Ph4p7mEdxrLSL3xX03Fpjhy8S0cufhWqbc8nFUigqjVxGBry3Uorj0G4E4A664DoWpjBQA5p9z6D2G9bo03Xlkn3ZgAqPc3cMvZLm469yMYm455AMF21MBri7ePthBsLhd25wADhdjxJli2wuahKxzS8i4BAK7TCPD0qTP3KvDxPIMpkd86fepMpjeSQP5Blsd3ZdC6TvO7fXjjPvdyogB6fow3dnZmebt900SD/7h3Ebf/9O+wfOF1Dv4LzIsi4wVB1asADKDcNYacK+abLFXGerJ2XCCVf4nm1n/ZEgDtrXdw9PyPJ+5YP/AjvDl/C35w04fx5twxDLzi9fIZt9FX6vnYDiavAlBVq2la2u8RVb3eIPK3hd+hk3oQ0IcyPseBdnGYNf355bE/Y7RYCYDdxn6vLN2BHx09gXcbS9AJtjYEAH/Yxy1nu6Xa5rCsRARRm+86gHyJzQDJNb68kFMy2haq0ktR/DiyJvB5L+bATw8/O2SNj/Oto/jB6km8unAbNqcwiz4tk3T6vlibm/h8JW4ACAAQ2buL/OlTZ44D+HzO4ZTNN06feimTA3eTtXmMymxLRQH0jhwd+3NSkG060531/T86+iG8snQHNuP2obeHM5rCFOTPRzcW1OtGWOx4C0b9Y4icqfxdSO50k47P5n/c+i8ritG60otxG2dbq3hl8TheXTo+vf2IRXCxfgQ/Wb4TL698EO/UF2EdLw+Y5PwXa/MTJzBseRsA7jreTTrz1/5HVf06Kp64PDz5uKpkVAUg9wAo3QzboLUAG47f11Adfr8ogL4f4c25m0fVU0c+MNp9ZEox9YMafnj0BF4/civON5awFdRhIYVJytLVRARRs1n1ZQCAKnePIaf4AkMuPYZRQ6jKMr5v/ThmIm6K+n6Es+2bsB3WR2X6Wb/8iqAX1vHThVvxlj2GuY1zmN84i3DYy/a811AAdoIy2r4fYTuoozbYHPuzJV//DwChQu8B8L/v/ofT33/phIp80WFMZWFE0Dl96sw/+chHf27ax75v2gcsgu3lD0z0PEuNl0E016cANuI5nG8ujdeAdQKDIMYgiHGhsQgAEGsRDbdQ334PSxdeL2EryNkWNpvYfveC6zCcUsHj3WTt2B1P/evXXMdC1cSBB7n0P7gOwLWo1eTs/5RdqB/Be/UjGPhR9oP/a4yWB6zgh0c/hJ8s3YkLtXnYnF4/U+PDygQv+iJ4d+fFeVxlXwIAAAK5ai25Qp6REs4uO/KYAp/I4LilawBojYftpck2yxn40ZSjuc65vABnW6v4weqH8eri7VMp8x+XGoPtsIFzraMYekGu56YbM8aYsNGodBWAQHyAiWRyhwkAcqL73NoSRtv/VZYYg7DR4D04ZRfjyde0T40INuMWXl+8/VLTwJ4fZ1qWuj3mftlXulA/gnSC5EEVEgAKvTQ9ffrUSw+J4DMu4ykbgSanT52ZWjXierIGlLACYHv5A1B/ssHsdlDP9NmjELwXz+GVxeOjbv5zN2Ho51B9dSMi2IjbbmOg99vZErDqFPhn3WSN74DkBC88ckPk8xjts11ZYaNhZcLOx7S3ofHRC2quw7hK6gU43zqKHx09gR8v34XzjSUMMyjJPUwzPzUe3mmOWQWgWokEgAD3dZM1nPr+Sz4g3wW/N6dM7gHwS1M7GqQN6F3TOl4RKASbN90+8eeHXjBKEE6RAtgOanhz7mZ0b/owXls6jo3anPtB/zUKkRCm9/HC0PhRVPEqAJwE5EHXcVA18UWGctcdzdD8M9dxuBYyAz51Gw7KTQ9MBNtRA28e+QB+cNPdeGXxdlyozSOdQuPAvhfiQn3hUMc431wZq4mgArBpsbYXy4bcBUhTRH4JJZxZLohnTn3/pdUpHetewHE3zinrLa4irR3i+0IEb7dWD10FsNvQ7+2dhObLKx/E+dYK0gKX2W9FTdiifidUHLc/BsB3YXKkVF+SNCvkHlT8RTqo1aznc+u/aZuV2R4Vg43aPF5fvB3dm+7Gq4u34936EaTGG/slPRWD1xdvgx5yzJN6Ad4ZoxeApqmFahWuYbO9eNOnADzjOpASmxfgu6dPnZnGsUr13aIANm754KETmxtxG+ebK2M/XxRAL4jxdusoXl75IH549EM4O3cM/aBW3GTrFazxsBUy2V5Efi02xvcqXQUA4LPrydp0y3OIDoC7AJALv4iKJ5+Y+Z4+haAXxPDSwfv+u4qMBsgFfGFV4+FibR4Xa/OAKuL+Bhq991DvXUTU34Sne78fjbpst/Hm3M0YBNNZTXOudRRzG2/ve84r2WEVZv9Hv+fNm47/AQCOIrIk8jkA/wHAXxzySFPfUsCl7eVbMKxP4ftCBG/NHUMviLF44Q2EaX/PH1OMlgxshU1sRk1sxO3Rev4iU4VAITr6B9ekOTajJhq999zERvsSEYTNFrbfecd1KC4tCORTAP5X14FQtRTvbZhKrZt0fAAvA5isnXEJeEFgm6tHDbv/T9fuK5/s8d8UAojAioE1HlLjY2h8pJ6PoRdi4AUYeCEGfoSh54+OUoC/H1GLYNhDOOjBT/swaqFiMPACbIeNUYfrKce5cOENLF94/YY/19/YsJtvnyt9Im9z9Xa8d/vdhbgeKuAsoD/3kY/e/+NJPtxNOlDgP43W1s4+NR7O3vuPYeMpTxCqIhpsIhpsw0+HgACpeBj4IXpBDanxi3G9q46egWkfwbCPIO3DTweX/vHsEJ5NYWwKgYUosPO0v/ow4MtuUam19t1XXzPQLNtUFp3+R0B+4Y6nnnYdCFUIKwAoX4qPQ6o7+AeAsNXi1n8Z2Os3Kpf+rYAqjFrADgH09j2OFYO+H6Lvx+gFtdE/YQ1DM/3B9o2oGPSD2qjcNifnWyuY2zyHcLj/7wioxg4Ag8Yc3rvtZDEGQ9WwBMifnj710qMf+ej9E1xg2gbkzumH5cbGzXdOf/APACLohQ30wsb0jz0pVYTDbcT9UWIiGmwhHG7DTweHHrzz7i0u2dkSsH/xYumTyfuTTwBYBfCG60ioOpgAoFyp4Ber/GUsxiCs13MdvJkAACAASURBVCv8RVd8Ri3iwTbiwTawNSpN3C2L3Q7rl0pje0Fctl5jAEZJh58s3YFbzv4A0XB7358r+xIA64d494P3Axns2EDX9TAgyelTL/3WRz56/7ifPSlAwevVb2xn2Qk2binVZgZXMXaIWm8Dtd5F1PobiAdbELUcrFdQ1Gqif/Gi6zBc8gH9HIB/6zoQqg4mACg360mnKcCnXMfhUthsWjElHDWWnAAI0gGCrXfR2np31AHfeKM1slF7tE42g3J8V4Z+hB+v/CxuOvcyGtsX9nwpL3MFgIrBOx+8H2lcoBnSavl1QP4fAP/LWJ9S3DvrI0gVg/duvxtbR3+mNM8TADv9TTbR2L6ARu8C4v7WqDKLKs/zfePHsR1ub1f43Uh+sZt0/i2XAVBemACgHOmnAGm7jsKlqMkBRRkIAM+maF2REOgFNVyM57ARt0d7bs/4y7s1Pl5dPI7FC29g8b033jeuKusWgArgwp33YjC35DqUKjMKfO/0qZfe+MhH7/+PB/6U4L/IMKbMpWGMd++6H4P24bb0LApjh6hvv4fm9gU0ti/At+VNGtIhiCBqNTHc3r/irALuU9UTAP7OdSBUDUwAUG4E+O9cx+BSUK9b43kVznCXlwCIB1uIB1tYfO8NpMbDZtTCZtzCZtTCwAtnMyEggv+fvTuPsSvLD/v+PXd9e+0Li0tXk2z2Oj0jVc+oVdWZSI5seSTLgjx2FMM2nIEjGIgRJ4ExiaOBh5jAcQJXIEdA/nAAG1Bgw3ACI46B2DEMQ3EMsWPLamm0TG9kcSdrr3r7eu89+eMVOexuLlX17nv3vnt/H4CzkMV7f6x6dzm/8zu/s19apOXmOXNw5/ELvNY6CHw/cZ9lDdQuvk179mzUoaSeAkdr9b9d+43f+rm19975V8f8W18ZalBDooHu1DyVyz+Ctt2owzk1pQPcbrO/i0m7RrbblFl+cSxWJmMYlhUEnpe458oxGaD+DPDXog5EpMMYvpGKcbSx/t15DfcUauzXZ55WYWE+sFw3rQ+31NJAz3JpuoV+UsAtxKfL9gmYfo/Fw7vk21W07wfVBw8T9Vl+NPhPXOn1+KsDv7C6tvIvn/dFG+tXHeAQGKs9tbVhUHvpDVqLL4/f505r3F6bXKdGrlMj22lg6mRWBonh69RqQeuwnKjnygl9qjWvX/6vvvfifXiFGJBUAIgRUX8iCc2ZTst07MBynDQ/2FJLAY7XwfE6TDb2Hy8XeLTHdsvJo8eg0Zxv2jyYuUipecDM7q2owwmVNkwqr/wInZlUb1ASVwXgn75/7YNvAf9gdW3lGV+mr4Aaq8F/tzhN9fJX8LOFqEM5Hq2x/O7jGf5cpy5l/SI0Tj5Pq1whxVsCXlGKd4DfjDoQkXySABBDd2P9uwB/Ouo4ouQWi+M3uyOG4snlAtP1XQKlaDkF6tkJ6pmJeDcTVIpqfoa6nTeKHY27vzn2ZWS+k6H86lfxilNRhyKezUHz91Bcfv/aB399dW3lKTNk6u3Rh3U6gWlRv/AarcXl+O8kojXZboNCq0K+XcXx2mN/zYt4ki0BAfhFJAEgRiDNF5kYGXUOeC/qKKKiDAM7m5VrTTyVoTX5To2F8n0ubv2AC7ufMlnfxYjxzFpw1Kys/PqP4Y1xp/xuaYaDt78ug/9xoDCA7wH/+P1rHzytS17sGwBqoDV7jv2v/CStMxfjO/jXGrfbZL58n4ubP+DC7nWm6zu4MvgXQ+YWx6QaZnj+w431qzG9MYgkkQoAMXQK/iQpTjb1t/4zUvvvF8engGy3SbbbZK7ygGpumoPiAj0rho3BlKI7tcD+xBzZrdsUHnyK0etGHdWxaKVonLtC49wr8R2EiWf542j9wfvXPvjW6trKv3ri92NbAaCBXnGa+vKb9AqT8a3w0ZpCu8J0bYdMtyGDfTFyhmwJeA7Ne8C/jjoQkWxyfxdDtbF+FeD/A96NOJTIlJbOBIZlpfVhJgYUoDgszLFfOoOOcR5JeT1ymzfJbd7E8HpRh/NMvfwE1UtfxitMRh2KGIAGT8HfBr6z8P4/qYN6ACxGHdeTNODlJ6iff5Xu1EJ8B/6A02uxcHiPrAz8RcR6rVbQ2N2L78Nu+P7nS9/+3n8WdRAi2eQ+L4ZqY/27y2h1HZXOahM7lw3yMzNGnF/8xHho2xkezlyMZzXAE5TXI7t1m9zmTcxeJ+pwHgssh/qFV4+6/Kf53TJZNNy3mrX1me//P78al7usBnqlGRpnL9OdnI/1wB+tKTUPWDi8hyFb9okY0FpT29xK85aAD4GXL337e+NRUifGUioHZWKU1J9M6+AfwC1I8z8Rjkyvzfnd69ydu4JnxXdDDW3ZNM+9QnPpIpm9h2S3b2PXDiPLNgeWTfPMyzTPXEJbdkRRiGFRcM7PFn714O2vk7/3Ke7hVnSfNcOkM7tEc/FlvPzEWNz7Jxr7LJTvyWyQiA2lFE6hQLtcjjqUqCyBfg/49agDEcmV2oGZGA2N/qZK6auFYduB6crWfyI8tt/jzMEd7s1djv/gwjBpz5+nPXcOq1kjs3ufzP4DjE5r6HcEDfjZAs3FZdpz59M48P8Qrf8vlPrLQCbqYIZOKbzCJJXXvorZqpHbvEVm7wGGP/xGmhpFrzRNe+4c7Zmlsfqsud0W8+X7KX1CizhzCnnalTRvCaj+FJIAEEMk930xNBvrVy8At0hpA8Ds9FTgFgqp/LeL4Xow8zL17BiuYdcaq17GPdzGLe9gNSqokF7wNOC7OTrTi7Rnl/AKU/FPkoTP0+hfUairq2sr7WvXPnhLwd8FvhZ1YKOmfA/3YAt3/yFOZS/UZEBg2XRLM3SnFuhMLRA445ljObu3QaFdjToMIZ6qeXAQdOuNtL5DPQReuvTt78V3OyAx1qQCQAzTnyClg39lGDi5XCr/7WL4Jhr745kAUAqvOIVXnKJx/lWU38OuHWLXy1iNKlarhtlpQeA/NzutAW1a+Jk8Xn6CXnGKbmkGP5NP46D/kRvAt9bW3vmNR7+xtrbyB+9f+2AN+KvAXwPiu3YkZNq0+rPyc+fA97Hrhzi1A6x6GatZxey0QQcv+JwptGXjZfL4uSK9wgS9wjRerggxbsh5HJbfJS+DfxFjbqFAt96IOoyoLAGryG4AYkgkASCG4qj7/zejjiMqTj4vW/+Jocl0G/3SyHEe7CqFthy6Uwv9DumPBAGG18XodVBeDxX4j/9ImxaBZRPYLtpyxvvfHxoNqL8D/Jerayv1z//p6tqKB/z196998M+15u8pxWsjDzFqpklvYpbexOwPf8/3MbwORq/b37VCB/3fVwptWAS2Q2A7aNNO5Ocs05Fu/yLeDNs2TNcN/E4nre9S30QSAGJI5P4vhmJj/eoScIeUJpmKS2cCU7b+G4qeaWMGPsajF/YU0sCNpS8RGKm8vMQP7QF/Efg/VtdWXvjF71/7IIfmV7XiP5GHf7pN1baZrzyMOoxIdS0X2+vIi3CMdZvNoLm3n8p3KY2+q1AvX/r299L7siOGJpUXlRiJP05KB/9WJiOD/yHamTjHrYXXqeSmUrtpVaBMtGxll3bvAyurayvHGvwDrK6tNFH8koI/DaS2xbYAzxyfZoVh8wyL7clz3Fp4jaZbjDoc8Rx2Nmso00zlAFihLgDvRB2HSCZ5gxTDktryf7dYiDqExGrbWerZCTzLYWt6mTvzr1LLTqYuEXBYmJMEQHoFwK+g+cnVtZW7J/3Lq2srrK6t/EPgq6B/L/zwxDioZybpmqlpCQH0B/67pTPcWnyDcmEOlMFeaTF1z49xopTCLeSjDiNC+heijkAkk1Q+idBtrF+dRusHKDWerZEHYFhWUDyzaKgErhmNmgYeTr9MPfe55ndaY3sdpuq7lJoHmAleGqCBam6arakLiVyXLF6oDnwLzT9afe94s/7P8/61D3LA/6I1f1Y+Tunj9Nqc29vA9rtRhzI0GuhaGcqFWSq5abRhfu4LNOf2Nsh3apHEJ14s8P2g+uBhWjPeH2t4/fK3vxd1HCJhUlmiLYbuZ9I4+AdwCgVk8D8cnaPZ/y9Qip6dYWfqPHsTZyg1Dyk1Dsj0monJcGr6Jbt7pSWquVRub5d6Gm4r+IXVtZXvh3XM1bWV5vvXPvjzSvH7wH+PVAWmStfOcHvhVeYqD5lo7CfmfgkQKIN6doJyboaWW3j2PVMp9kqL5HZrifr3J4lhmoadywW9ZjOF9yd9RaHeAD6MOhKRLJIAEKHT8POpfJAqhZPPRR1FYu0XF1848A0Mi3JhjnJ+FtvrUGqVKbTKuL3WWL7caaDl5KnkZ6jlpqTsP6U0fF/Bz66urYTetW11bSUA/ub7v/Fbt0H9ryhSmbxNq8Cw2J66wH5xgcnGHqXmIbbfizqsUwmUQcMtUstN0shMEHx+tv8Z2k6epluUKoAYc4sFes1m1GFEQBn0e2pJAkCEahzfiUWM3Vi/mgG9q1CpWwjv5PNBbmZaRmhD0Laz3Jl/9XQz31pj+T3ynSq5do1sp4EV9GJ583s0099yCjQzBRqZEp6RzG3IxLH9G+Abq2srQ2/a9/61D34K+MdA6u7f4ojWZLrN/v2yU8ftNmO7rEqj6NgZmm7/XtlyCuhT7r6b6dS5sHs9ls8FAVpr6lvbgd/rpfEd699c+vb3fjzqIESyyL1OhOrG+nd/RqH+adRxRKGwuBBYjpPGh9PQHRTm2J1YOkqGD0hrbL9Lptsk023i9Fo4XufxOthh3xQfNZzyDJue5dCzXLp2ho6VoWNn+925ZcAv+r4P/OQoBv+PvH/tg58B/glSISgApQNsr0Om28Lx2ji9Nrbfwfa6j7diHebd6tH9MlBG/155dJ9sOznaTjacrVC1xgp6nN+5jpPgfgjjrlOvB62DwzS+YwXA2Uvf/t5W1IGI5JAHvAiVgp+POoYomI4jg/8hmq7vUmyV2Zk8Rz0zMdgAWSl6lkvPcqnlpn74+0eVAlbQw/Q9zMDDDHyMwMfQPoYOUDpAaY2i/2L8JK0MNKCVQiuDQBkEyiQwTHzDxDcsfNPCM2w80wonmSGSrEx/zf9It+tbXVv5Z+9f++C/AdZHeV4RT1oZdO0sXTv7hT8zAh/L72E+vmf6/Xum7t83ldYY9O+ZaI36XL/9/j1ToZU6ul8aBMZn75meaeOZNoEyh5IYVUHAXPUhk/W9L8Qn4sXJ5WgfltE6dT8nA/hjwN+JOhCRHJIAEKHZWL9qAX806jiiIFv/DZ/t91jav8XO5Ln+Fk5hUwrPcvBI19ZYIpa6oP/M6to7tyM6/69oWFHwH0V0fjEGAsOka5gwpm0jVBBwbu8GuW4j6lDEMSjDMOx8PujW62nMnv88kgAQIUrjRSSG523gQtRBjJoyDOxsVq6lEVDAfPkBbjeNzYBESnjAX1hde+efRRXA6tpKoODPo/nnUcUgxLDNVh/K4H/MpHiy5Sc21q+m9h8vwieDFhGmPxZ1AFFw8vlAnbLxkDg5hWa6th11GEIMgfaAXwL+ftSRrK6tdFF8E/j1qGMRImym7zFZ34s6DHFChmUZluvGsyvlcBWAn4g6CJEcMmoRodHwc1HHEAWnIEnZUcu3a5C+dYAi2TxQv6TRv7a6thJ1LACsrq006ZeeShJAJEquU8OQNf9jRymFk9oqAP2zUUcgkkMSACIUG+vfXVLwlajjGDUrkwkMy5TraMQM7WMGXtRhCBES7aH5pdW1lV9bW3sn6mA+Y3VtpQ78HGhZDiASw/Y6UYcgTsnOZg1lGimsAlA/s7F+Vd43RSjkgyRCov4IKWwq6RYKKNmyTQhxeh5afQvFr0UdyLP0KwHUL2h0ZH0JhAiTdPwfX0opnHwqqwAuaHgr6iBEMkgCQIQldaVJyjQDK5uRaygCWil8w4w6DCEG1QX+3Op7K38/LmX/z7K6ttJWWv0C8H9GHYsQg+qZstvLOHML+ahDiISCn4k6BpEMMngRA9tYv+oAPxV1HKPmFvIy+x+RhlsCJbevodEapQNUEGAE/uNfyvdQXg98DwL/+b90Cis0T6YL+hdX11b+YdSBHNfqeytdDb8IemxijkwQvPAaUV7vqb/6fy7XzzA13SIaeX6PK8OyDCubTeFFor9xY/1q1EGIBEhdybYYineByaiDGLWUlqCNlIYvvKL1TJvdybNRhDO+tMbQPrbX7f/yu1h+DzPoYQb9fgr9QX6AoQMUAY8qZJ/8/rcOD71OvW598afyFKr/H9ow+79Mi8CyCWyHwMnguzn8TB4vV8R3c5CunTTawDej3OrvtNbWVrrvX/vgz9HfrvDPRh3PyGiN8j2sVg2zVcdsNzE7LYxeB8Pr9gfvvocKfJTWx2xS+qyvObq+1NH1Y5oEpoW2bALLIbDd/i83i+9k8TM5AjeLVgZIUvpYPNNmZ2KJ+cqDz9zNHv1E5LsYf24hj9dqRR3GiKl3Vf99uxx1JGK8SQJAhOEbUQcwanY2K83/RqCWnaSSn8HttTCCgJ7lUM9OEkj5/7NpjeN1yHSbuL0mbq+F22tjBt7AL7Xa9y2lNc8euDz5xf3/UoH/wi8NTAsvP0l3YpbO1DxefiLJA5k68M3VtZV/EXUgp7W6tuJdu/Zb31IoD/iPo45nWJTv4ZR3cco7ONUDzHa9P7gfOv34v1TggwcvuuO509OeMTltde0sHTtL28nRsnMEprzmPZVSlIvzNDNF8u0qRhDgmTZtJ8dLO59EHZ04BiuTMQzLCgLPS9O7mKO1/ingH0UdiBhv8mQQA9nolyL90ajjGLX0bkMzWr5h0cyUaGZKwzuJ1hi6X+qudIBCo1Fow8BXZvxn1bTG8drk2zVynRrZbqP/bxnOuQKGsHTM8D2c6h5OdY/8vY/x3Rzt+fO05i8QuNmwTxeluoafW1tb+VdRBzKotbV3vPevffAXgCbwn0YdT2i0xq7uk9u+g3uwdawEVhwo37Ncr4PrdSi2+pODGuhaLi23QMMt0nSL8U8IHFUr9auR+t97rQyCo19h34+7dpaunah7TGoopXAKedrlStShjJRS6htIAkAMKMZvtWIcbKxfXQLukKJkkmFZQfHMoiHr/4evmp1kc+blwQ+kNWbg4/ZaOL0WjtfB8TrYfhfT72EcrVf/fCmoRuGbNm0nSyNTopadikf1gdZku3WKrQr5VgXb747kZl7f3vG8Tmdk17pWBq358zTOXUlCIqAK/Ozq2spvRB1ImK5d+y1Dwd8C9ZejjmUgWuOUdyjc+wSrXh67lyO3WAyyU5PPTc5pFC0nRz07SS07iWfa0Sc3jxKYpeYh2U4d12s/NYH56H4cGCaeadOzXLqWS9fK0LEzdO1Mf03/gP8eI/C5/PD3xu7nn1aB7wfVBw/TVAEAcBd4+dK3v5fCHggiLKkZtImh+SlS9jlypPnfyGR6zf5a2pN+v7XG7bXIdupkuw0y3eaJB8mK/lZRht/FbnUptirMVR6yM3GWam46khdnp9dionFAsXWI7fdGfn6tg5Fe60oH5LbvkNl9QOPCqzTPXIx+wHI6B8DPra6tvB91IGFbW3sneP/aB/85EAD/RdTxnIbRaVG8+fu4h1tjO/DTx6jOUWhy3Qa5boO5ygNaTp5qbppaLprEphH4LBzeo9g6fOH3/fH9OPCwAo9M77NrvwOl6FhZ2m6elpOn6RbwTfvEMWW6zbH9DKSRYZqGncsFvWYzTUmACxr9BvAHUQcixleqBm5iKH466gBGSoGTT+f2M1GwvS65Tu1YSwBMv0e+XSXfrpLr1DCHUAZvBj6Lh3cBRTU/HfLRn0EHFFsVJuu7ZLuNSF9OdTCcJQAvYgQehds/wDncpnJlBW27ow7h1DQcKPjp1bWV34o6lmFZXVvh2m988FeUog381ajjObajWf+J67+D4XWjjmYgOjhZck7BZ5IBtdwU5fwcHTszmiSb1pzdv0muUw/lcIbWZHtNsr0mU+weLX/I0MiUqGdKtNz8i3eO0ZqJxl4o8YjRcQt5es1m1GGMlEL9ESQBIAYgiU5xahvrVw1gE5iPOpZRsXO5ID87k6ZMc+R6ps292cv07Mxn/+BorWihVaHUPCDXaaCO05wuBF3T4dbiG0N9UVaBz2Rjn6n6TiSz/U9TefDQ074faeLYy+Qpv/4ufnYsEnEHWvONtfdWfjPqQEbh/WsfAPx3oH859q8XWpPdvkPx5u+P7L4xTHY2G+TnZgd6Nmn62+PtFxdouYWh3t9y7Rrn9m6M7FPiGRb17ATV3DQtJ//Ff5vWTDb2mC/fj/snV3yO1pra5lbamgH+i0vf/l66JuBEqOQ+J05tY/3qjwIfRB3HKBXm5wMr46bpIRMLAYp6dpK2k0WjsP0emW6TTLeBEcHLuwZuLH2JwAh/LKyCgMnGLtO1HazAC/34g6jcu48eSRf05/OdDAdvvUeQyUUdyvPsAN9YXVv57agDGaVHSQANvxznF4zs1m2KN5Oz1tvKuF5hfj6UG5IGWk6BvdLi0BIBU7Ud5isPQj/ucXiGRdMt0LUz+IaF6XvkO1Up/x9j7WotaJfL6Xk30zRRzF369vfSVfogQiNLAMSpafipND0sDcsKTNdJzwMmRgw0pdYhpdZh1KEAoJXqd6MO9aCaUvOA2epmbGb8n6S1jsXgH8Dstpn66N9y8KX30NbJ1/mOwA7wh1fXVn4v6kBGbXVthfevffAdhUZr9ctxbNngHG4fzfwnhw50aO9z/eUBdc7v3aCRKbE7sRR6p/zAiO5RagUepVYZ0raFfII5+RztSqXfMygNFDmteRf49ahDEeNJBjNiEH846gBGySkUpPmfAKDt5MNLAGhNptvgwu6nnDm8G8vB/5FYlSNYrRrFm78Xxxe+Hd1f85+6wf8jq2srgPoO6L8RdSyfZ3RaTFz/7USU/T9pGMk5BRTaVZa3P2G+fB8jxC0Rm04hYT8BESXDNA07m01bV/xUvYOLcEkCQJzKxvrVnILVqOMYJScf63JjMSIa2C8uhHIsI/CZrzzgws6nZLvxruTTWsfueZHZe4B7sBl1GE/QB8BPr62tfD/qSKK2uraCQn0H+BuxydFoTWnjdzG82CbZTk/roSXoFJqp+i7LWx9RaJVDSbr17Az17GQI0QnR5xYKUYcwUkrxUxvrV6MOQ4yp2L3QibHxLpCaEbGdywWGacr1knIaKOdnabrFAQ+kybZrvLT9MVP13fEoRQ7ilwBQQPH2D8APb2ZyAAegfnpVBv+Prb63AprvqJhUArgHWzjlnajDGIpRLM+xgx5L+7c4c3Abwx8837A9eY7eKbbqE+JpTNcxDMtKUxXAV4DZqIMQ4yl2L3RiPOiUlR6lLbMsnq6am2Zn8txgTbF0wGz1Ief3buD447P1mEbH8sXK7LTIbd+ONgity2id6K3+Tmv1vRW0Ut/R6P8x0koArcnf+3g8km2noU+2DeBpKaDUKrO88zG5dm2gY/mmzf3ZS5IEEKFQSuGk613N0vD1qIMQ40kSAOJUFPyhqGMYFWn+JzSwWzrD1tSFgQb/ttfhwu51pms74zcQ0fFMAADkHm5AiOuTT0J5PSY/+rc3Vt97Rwb/z7DWXw7wXyvF/xRVDO7hNlZzsAFrnI26Qaft9zi3d4OZyuZASwK6dpa781doOmOxraeIOSefG+r2lTH0H0QdgBhPMqgRJ7axfnWafulRKkjzv3Rr2xnuzl3hoLR4+hcLrSm0yry08wnZcd1qKjYLub/I7LZxD7dHfl7le0x+/Ju45Z3ljfWrsqvOc6yurQQa/VfQ/O2Rn1xrslu3x/O6Oy4NesRJOgXM1LY4v3cDa4BqJs90uDf3CjsTSwRh764iUiVtzQAV/CHpAyBOQ+604uS0XgWcqMMYFWn+l06eYbE9eY4786/RdgeYndIBc5UHLO3fwoxoljoMWoe3zdgwuAdboz2h7zPxyb/Dqe4DTB/9Es+xtvZOgOIvAb82yvOqwMep7I3ylFEZ+cBHAblOnZe2PyHXrg5wIMVhcYFbC69TyU3LDgHi1JxCqqpJrgDnog5CjB9JAIiTUyo1JUd2LhsYRoQbFouR0kDPdNiZOMvNxTcoF+YGKie0vC4Xdm8wPS6N/p5j1CXGJzXS8u4gYOLTD3DLu49+xwAujy6A8bW6thKA/iU0//uozmm26qj4rmAJT4TXqBV4nNvbYKY62JIAz3LYmrrA7aNEQDD2d04xapbrpqkZoAFa+gCIE5OBjTiNn4g6gFFxCoW0rSdLJQ003AKb08vcXHydw+I82jAHOKAm164elfw3QoszUvEe/6NC6Ep+LFpTuvE7ZA6/UHFwcTQBjL/VtXc8FH8O+GejOJ/yE7jt31NEXaWjgNnqFmf3b2IOcj0qRdfOsDX9ErfOvMFeaZGeacf9FiRiot8MME1VAOono45AjB9JAIgT2Vi/Oq3Rb0cdxygYlhlYrivXSIJ1LZe94iK3Ft/g/twr1HJTMOgaVK2Zrm1zbm8DKxjRoHQkhrfPeBi0OYKxj9YUb/4e2b0HX/wjeGX4ASTH6tpKF/hTwL8e9rl0WrrMx6RKp3CU/MyEkPz0TIf90hluLr7J/dlLVHNT+NInQLyAk09TAiA9k3IiPHIXFSf1dTXwCGk8OHlp/pc0GuhYGfaLC9yef5VbC6+zP3GGnuWGcnwj8Fjav8VsdTN5havxGFs8k58Zcq8OrSnc/Yjs9p2n/rGSJQAntrq20kTz88BvD/M8vpuL+8c3cWy/y/nd60w09sJJTChFM1Nic3qZjTNv8WD6ZarZKfxBKrVEYqWpGaCGyxvrV6UPgDiRWDd1ErH070cdwKhI879kCJRB0y3QyJRouMX+YH8IiR2n1+Ls/i0crxP6seMg7j0AeoWpoR4/93CD3IMbz0nsaFkCcAqr762Ur1374GdB/78KdWUY59CWjZ/JY7UTshznGbQmIEYTO4bWLBzeI9NtsjN5Dh3S3IE2TOq5Seq5SZQOyHQaFNpVcp0agfvQCgAAIABJREFUbq+VvOSrOBWnkKfXakUdxtD1P+/668A/iDYSMU5i86AQ8Xe01Ugqmo1Y2UygTFOujzHkK4OGW2CvtMjduVe4sfQlHsxeolyYo2dnwh/8a02hWebCzqeJHfzHnQa6k/NDO35m5y6FOx++YGChLsp2TKeztrayBeobwMOhnEApulPD+3zER/w6HSpgsrHP+d3Btgp8Fq0MWpkiu5NnuTP/Khtn3uLh9DKH+Vk6VkYqP1LMymQMZZqxuyaGRPoAiBORAY44Ps008FbUYYyCK+X/Y6Ff0u9SyU0dbdl3hY2lL3F/7hX2S2douYXQZp2eHoBmprrF0sEtzPi9e4dK6yC2FWNeroiXKw7l2M7hNqWN3z3OrOI0aNkK8JTW1lZuavhZDeVhHL89c1YGgxHKdhtc2PmUTGeIVRhK4Zs2tdwUO1Pnub3wGhtn3uL+zEX2igs03CKeYcnnICWUUinqBaDe2/ibkoAWxxfbFzoRQ4p3ASfqMIZNGUZgZTOSHIsxDWxOL9PIlAgiWgNqBD6LB3cotiuRnF/8UGv+paEs67Bqh0x88luo4y1/sEBdAA5CDyQl1tZWvv/+tQ++CfzfhPys6RWn8HJF7FFuFzlqMV+mY/s9zu9eZ3vqPNX8zPBPeJQQaGQnaGQn+r+nNZbfY67ygFJrKLkmESNOIU+nWo06jOHTXEGxxLCqqETiyCBHnID+96KOYBScQl5m/2Oulp2klp2MbPBvex0u7Hwqg/8YCCyH9vz50I9rthpMfvybGIF/7L+jtfQBGNTq2sqvA9/SEG5JjVI0l6RPY9QMNIuHd5kr348mYaEUnuWwM3mWIB39jFPNME3Dct1kl+cBKAxgNeowxPiQu584AZWK9f/pKRkbT4FS7E0sDWXG94W0JtuucWHnE1yvPfrzRymms4uNpYtoK9xt3lSvy+RH/xazd7KeDkopSQCEYHVt5R8A3wn7uO3Zs3gZub9HTQHT9V3O7m1gRLRVqm86HBTT0Bci3ZRSOIV0XPManZom3WJwkgAQx7KxfrUA+itRxzFspusEpm3LdRFjh4X50LbtOxGtmWjsc35vA+sEs8JieHwnQ+tMyGPuwGfyk3+H1a6f+K9qzcvhBpNeCv4H4O+EelDDoH7h9VAPGSda67F6dhU6NS7sfIrdiyaZelBYoGeGmzwU8WNns4YyxurSOBWFkgoAcWzJvyJEWH4UVOL3xXPzhahDEM/hGRYHxYXRn1hr5ioPWCjfQ0kLqVjQQP2l19FmiK1stKa08bs41f1T/XWlZAlAWFbXVgD+EvAvwzxuZ+YM3dII1p9HQY/fO53rdbiw+ynZ9uh7M2jDYLe0JHf0hFOGgZ3LJX8ZAPqtjfXvTkYdhRgPY/ewEJF5L+oAhk4p7Fw26ijEM2hgr3Rm5Ov+jcDn7P5Npuu7sr90jHQnZmnPngvvgFqTe3CDzO790x8ClmUrwPCsrq10gV/U8GloB1WK6sW3h7s7iDgRK/A5t7dBqbE/8qVGtdwUbSfxcxupl45lAMoB9bWooxDjQZ6A4rjWog5g2JxcLlBGCurExpbCDDzyrQqW1x3Ji6LldTm/e51COwVdhMdIYJjULn051D4Q7sEWhbsfDZTkUf1dAGR3nRCtrq0cZLfv/EXlhbeHvJ8rUj9/JbTjicE9ag44W90cyb1d6QC326TUPMA3ZBlA0pm2bZi2nYIqAFLRrFsMTl5UxAttrF81gHejjmPY0pEhHl8KzVx1E+hXA/RMh6ZbpJ6doJkphj6j53abnN27iR30Qj2uGIwG6stv4ofYzM1sVCnd+J0wKjxywDyyFVOoShu/W+jub1J+/WsQ0nXeXLqMe7CNUz8M5XhicAqYqW1jex22pl5Ch5mPP9r+r9AqU2hXyXQbmDoN40EBP2wG2DpM/NaP0gdAHIvMdorjeA2YjjqIYTIsKzAdR66HMaEAx+8y2dzn3P5NLm7+gJnK5om2bHuefKvChd3rMviPoc70Iq2Fl0I7nvK6TH7y7zD80LqRXwjrQOKxZbe8Q+HuJ+Ed0TCoXvlRgjB7SIhQlFplzu/dwAzpmnS7TZb2b3Fx6wcsVB6Q79Rk8J9Cdi4VSz2+trF+VW5q4oVkwCNeSKcgo+jk86gotpUTobACj9naFsvbH+F2m6c/kNZM1nc5u38TQ14QY8d3c1QvfSW80n+tmbj+O1jtRjjHo98HILSDiSP6ZYDcg+u4+5uhHdXP5Kle/LI0gYuhbLfBhd0BdwjQmunqFi/tfEKxXZEeLilnmKZhZ7NJf7AXQL8ddRAi/iQBIF5M6+Sv/8+nIjOceLbf4+z+TVRwime81sxWN5kv35cXxRjSyqB8ZQVtO6EdM/fgBu7hdmjHA1CSAAjdUW8FFFC68TuYrZNv0fgsndklWosJ2b1RqUQNbhyvw4Xd62Q6p0vQFdoVZqubcj8Xj6VhqadGJX7JrhicJADEc22sX0WpZN9MrEwmMCxLroWEsP0e2e7JBghKBywe3mGmti0vizGkgerFL+EVp0I7pl3Zo3Dv49CO94Tw1ieII3r50f8yfI+JTz+AkJb7oBS15TcTsTWgUiQqAQD96q7zezcotE6+drvUPJT7ufgMK5MxlGkm7jp5kkpB024xOBn0iOfSmlngctRxDJOTT35GOG30CUrEjcDn7N5NJprSDOy5Ilwi0zzzMu358JbWq16Hieu/jRpKt/EfDlbF4PpNaNVnfvh2o0Lx9ofhdYs3DCpX3sF3ZRvYODJ0wNL+LSbqeyf6mQeyrE98jlIKJ/m9AL4m29GKF5EEgHiRd0jwbhHKMLCzWbkOEqThFmk5hWN9ren3OL97nXynNuSoxGl1Juepv/RmqOv+Sxu/i9kdYG3xcylpAhiuAjD5+d/Mbt3CCXH5RuC4lF/7mjQFjCkFLJTvMVPbOnYS4LCwgB/y7jBi/KVg0ucisBh1ECLe5M4onkspfjzqGIbJzmUDZcgsQRJ4hsVeaZEHsxePNVi0vQ4Xdj4l02uNILokGP110suVqFxZgRC3A8vu3CVzsBXa8Z5iSbowh0fDEvCFxg8KKG18HyPERI6Xn6By5Z0TVRDFyrjGfUwKmK1usVC+f6wkQMfJcnf+VWqZCWn0KB4zbMswHSfJywAM0O9EHYSIN0kAiBf5WtQBDFMKMsGporTG9HsvfDl0u00u7HyK43dHFNn4U0qFtk/ecfhulvLrP4a27NCOabQbFG7/ILTjPUOJp8xYi9NRWp971p+ZvS7Fm78f3lIAoDs5JzsDxNxEY4+lg9uoF+3UojWW3OPF5yilUtD4WSV68k4MTmYpxDP1117qd6KY+RsFw7IC03EkCZYQVuAxU9tmurZDPVOiXJil6Ra/MCuW7dQ5u3cTU4fUREyELrBsDl9/lyDMNdlHpf9GSHuLP4dBf9Z6b9gnSgX1/CUV7sEm7t5DOnNnwzof7YULmL02+bsfj9fTT6lUvNMpoNgqY+z5PJh5GW2Yn/lzI/ApNfaZbOzheJ3x+hmKkbBzOVqHJ28sOS60TvbknRicDH7Ec+jLoGajjmJYnHwelfCSyTRSaIrtCuf2Nlje/ojJ+i5G0B/05VsVzu3dkMH/KYxqqUxgmBy+/i5+rhjqcTM793AqIxuTSx+A8Dx3VwUFFG//PqoX7kxv4+wrNM9cDPWYw5a2p1m+U+P83o3+/V1r3G6LhcO7XNr8AxYqD3Bl8C+ewTBNw85mk7sMQOl3ZCmaeB75cIjnUInOICa/BCzdFOB6HRbK95mtPKSRmaDQKmNIce9pDT1hrA2DymtfDXW7P+h3/S/e+XCUgwFJAIRF63MvWttu9roU7nxI7dKXw1sHrxT15Tcx/B6ZnXvjMZBMYUI7221yYec6vmGR7dbH4+ckYsHJ5+m1ktkDSKEm6e/gNZS9bsX4kwoA8TxfjTqAYbFcNzAsSz7/KWHqgFLrUAb/AxluO22tFJUr79CdnA/92IW7H2N4o1sLrNHnR3aypFPqmT0AnpTduYtVD7mkVymqF79MZ2Yp3OMOT3JnNJ/D9drkZPAvTsjKZgxlGEm+ZhI9iScGIwMg8VRHe4gm9ubhFKT5nxAnMczJRa0UlVd+lM7UQujHthpVstt3Qz/uc2mONWgVL6aPWU2hgOKdH4TaEBAAw6Dyyo/Sno7/rlpKqSQPZoQIlVIKO5foStDETuKJwUkCQDyLA7wddRBDoRR2NsTmYkKkwZAGF48H/7Nnw88yaH3UyG20lR9KSQIgDBvrV1H9horHYlcPcA63ww/EMKhcWaEzhOqUUKVwCYAQg0j4TlBfO5rME+ILJAEgnkrDG0AiU6N2NhsoI8SNxYVIAaXCL5XUSlG99JX+4H8IrEYF93BrKMd+vuOVrYsXmgZdOO4XK6Bw75PwqwAADJPya1+lMxXrJIA814Q4AdOxDcOyklo58xboTNRBiHiSh4V4KgXvRB3DsCQ84yvEcIQ9OX8089+eH95y+fz961GtC1668TevyvN1cIv6hL0nrEYFp7w7nGgMk/KrXx3KUpWBKYVSw+3TIUTSKKWS/E6YA/VG1EGIeJKHhXiWlagDGAZlmoGVceVzL8QJqRD3GP9M2f+QmO1GRLP/AGRQTEd18qTQcO6kCRwF5DY3hlMFAI+TAHHrCSDr/4U4nSTvCKXhR6OOQcSTDITEsySyAsDJ5VCyTlKIkwvputHKoPLqO0PvrJ7dvIUa1iDwRTQG6HiNEMfQSdb/P8kp72I1a2GH80OGQeXKO7SGmMA6MUkACHEqhmUZpusm8vpR0ghQPIMkAMQXbKxfzWlNIsuG7ARneoUYJqWUN+gxAsOk/NrX6EyfGWrDMtXrkt2+M7TjvzgAUNIHIAynSgAoIPfwRsihfI5hUH3lR2jNX4jF5qJS/i/E6SW4CkAqAMRTyQNDPM0VpZLXANCw7cC0bfnMC3EaAw7YA9Oi/Ma7dEfQRC23eRMj8Id+nhcYm83jY+zUU+yZvQeY7UaYsXyRMqhe+jKtMy8P9zzHCUUSAEKcmp3NJXUXjTc21q9KI0DxBfLAEE+TyIyhlP8LcXpKKeu0L0i+7XD45iq90kzIUX2R8nrkNm8N/TwvokGWAAzu1FUUSmty968PrxfA4xMpastvUT93JdpKAEOWAAhxWoZpGHYmk8RrKKfRr0UdhIgfSQCIp0lkA8AEl3gJMRKnaTTmu1kO31zDK0wOI6QvyG3exPB7IznX86gBZq/FYwMlUbK79zA6zbBieTalaJx/lfrym5ElAYaxTacQaZLUJaIK9ZWoYxDxIwkA8TSJqwAwXSdQpimfdyEGcNIEgJctcPDWe/i54rBC+gzV65J7eHMk5zoGWQIwgI31qzBgAkBpTeH+9XACeuHJFM2lS1Qv/wg6gkqzMHfpECKN7GzWSGSVqNaJnNQTg5EBkfiMG+vftdD6rajjCJuTy0v5vxCDMoxjDzK6hSkO3lojcLPDjOgz8g9vxGL2H2QJQAgcYHbQg2R272G26iGEczztuXOUX/0qgWGO7JwAypAKACEGoZTCzuWSdx0plbhJPTE4SQCIz1CoyyhViDqOsNm50Q1ChEiq41QAaKAzOU/5zR9H2+4Iouozum2yMVj7/4iCxaNZbHE6JRi8Ga3SmsK9T0II57gnVHSnFym/8S6BZY/uvNIDQIiBJXQZwFsb61dlvCc+Qz4Q4vMSt1bIymQCQ8r/hRjYcWYZ23PnKL/2NbQ52ork/P1P49D5/0mz9GexxemEtoTC3XuAVS+Hdbhj6ZVmOHhrDd8ZTfJZlgAIMTjLdQ1lmklLppU0XI46CBEvMigSn/cjUQcQNmn+J0Q4lPHsQYYGGmcvU738I2CM9tFitupkt++O9JzHUACduGqqEQptv0gFFO5+PPwdAT7Hz5U4+NJ79EbQA0OWAAgxOKUUTi5574wK3o46BhEvkgAQn5esm4RS2Fkp/xciDM/qNK6B+vJb1C+8Hsleyvl7n6B0HMc/SvoAnF6o3zunvINd3Q/zkMcSuFkO31qjO+QtMCUBIEQ4EroMIHGTe2IwkgAQjx2tEUpUAsDOZgNljHg6UoiEetogQxsGlSvv0DzzciSDf6teJrP3YOTnPabQZrFTKNQEgAKKdz4ceRUAgLYcDt94l/bM0tC2CZQlAEKEw7Rtw7CspCXUEvVuLwYnAyPxpFkS1rk6iaVcQkTl80sAAsvm8PUfpzO7FMngH60p3PmQGO/vkaj76Shp9ELYx7TqZdz9h2Ef9ngMk8qVFZpnLg4lCaAMwxvCYYVInaPdAKIOI1Qa3r4hjQDFE+TDIAC4sX7VAX6GBH0mlKGwspnE/HuEiNqTgwzfzXLw1hq9ieGWNj+PU97BqexFdv5jkAqAU1JDWD7R7wXwEUTVLFIp6stvUl9+M/QkgFS6CRGepPWOUnBOwTtRxyHiQx4Yok+ziObvRh1GmOxsLlBRzEoKkVDKMCyAXn6Cgy+9h58rRReMDijc+SjOs/8Aoc9ip8hQkidmu0lu6/YwDn08StFcukTlygo6xDG7kvG/EKExLMswbDtJywAM4J/ckK1pxRF5Yog+pS+gkvV5SFoJlxBRU4YRdCbmOHxzlWBE25s9S2bnPnazGmkMxyAVAKc3lO+dAvL3r6O87jAOf2yd2bMcvv4ugWWHcjxJAAgRnoTuBjCtIMKsvYgTeWIIABRqOeIQQqUMI7Ayrny+hQhRY+oM5dd/DB3SoOW0lO9RuPdxpDEch5YEwCCG9r0zvC75+9eHdfhj603McvDWGr47eDJNKSXPOyFClMBJJAf0UtRBiHiQB4Z4ZDnqAMJk57JI+b8Q4dDAfnGB7ZllgxjMNOYebmB221GH8UIKLQmAU9hYv+roIc9U5bZuYbYbwzzFsfi5EgdvvUdvkOU0SgUolaRyZSEiZ1imYTqJWgYAqOWIAxAxEf2bnIiLl6MOIEwJLN0SIhIa2Jk8x17pTDSd/j/H6LbJPdyIOoxjUrNRRzCmCgqGehNXQUD+bjyqSAI3y+Fba3RLp2uoqQzDkAoAIcLV3w0gH3UYYVuOOgARD/LAEI8sRx1AWJRhBKYr5f9CDCpAsTm9TDk/G4vBP0D+7scY/tjseDa7IVsvncY0I3g/yew9wKodDvs0x6Itm8M33qU9c+bEf9eQLQCFGAonF22vm9DpZE32idOTFxPBxvpVtE5OAsDO5aT8X4gBBcrgwexFarmp2Az+rUaV7O69qMM4iYzWw53JTiY9ksoJBRTvfAg67E35TskwqbyyQnP+wom2CVRmf3cOIUS4lGkapuMkZxmASs67vhiMJAAEgKEU56IOIiyJy9gKMWK+Mrg/e4lmJkYNg7WmcOdDVFwGa8egIaOUdF0+hZEtnbCr+7gHm6M63YsZBrVLX6a1+PKxkwDKMKUCQIgh6C8DSFQOdznqAEQ8SAJAAOTQRLsnUkik/F+IwfRn/i/RcgtRh/IZTmUXp7wTdRgnclQ3MR1tFONodL0TFFC48xEE/qhO+WJKUXv5LVqLy8f7ciMGnTmFSKiETSoZG+tXo45BxIA8NAQa3UbhRB1HGKT8X4jT85XB/ZmLsRv8owMKtz9kTK9saQR4YqNZAvCI1W6Q3bozylO+mFLUXv4SzWNUAhimvMoJMSyGZSVrGYAQSAJAAKAuQzISAAnL1AoxMj3D5t7cK7QyxahD+YLMzj3sZjXqME5FSwLgNE7XDn8AhfufoLyYFcIdVQI0zr/63CSAMsyRhSREGiVoGcBrGi1jPyEJAAGg34g6gjAo05TyfyFOoW1nuTt/hY4Tv5cc5XsU7n0SdRinpmQJwCmokX/PDK9H/v71UZ/2xZSice4KlSsr6GcM9JVUAAgxVAmaXCqAuhB1ECJ68tQQKK0SkQCwsxkp/xfiBDRQyU1zd+4KnhXPIqDcww3MbjvqMAYhCYCTi6RqIrd5C7PdiOLUz6cUndmzHLy1hud+MUlnmKaUJwsxRP3dAOxEXGcKXos6BhE9SQAIULwedQhhSFCJlhBDF6DYnjzH1tQFdEx7iBmdFrkHN6IOY1AjL2cfdxodSdJE6aDfEDCmvMIkB29/nc7Uwmd+XxmyDaAQw5Sw3QASMeknBhPPtz4xamOfDVSGgSXl/0IcS9dyuTt/hUphDmJcNVO49wlGnLqzn4KWCoATU6jJqM7t7j/Erh1EdfoX0rZD+bWvUXvpDbTqP/IMU7YBFGLY7GxilgEkYtJPDEYGTCm3sX7VAS5HHceg7Gw2kPJ/IZ6vX/I/xZ35V2O53v9JVqNCZude1GEMTEFkg9kxFlnSRAGF2x+CflHv/QgpRfPsZQ7fWsXPFgKUkgoAIYbMsCzDsJOwDECP/aSfGJwkAMSiRpeiDmJQdnIatAgxFL4y2Zx+ia2plwji3jVcawp3PkS9cAO0sSAVACcXadLErh3gHmxGGcKx9IrT7L/9daOan07GlSJEjCmlEtIMUF3ZWP+ujP9STj4A4jU1rrtrP6JUYLkZ+SwL8RQaaDp57iy8Si03HeuS/0ecyi5OeTfqMMIiFQAncGP9uxZQiDIGBf1eAGOw/ESbFltTL7E5/RK+inliT4gxl5BlALNIYjr1ZNAkxr4UyM5mUUb8BzVCjFqAYq+0xL25V+hZbtThHI8Ojmb/k0GjJQFwAgo1qWPwbmK1G2S370QdxvEoRS03ze2F12i4xaijESKxDNs2DMsa92UAhkZdiToIEa3IH7IiWlrrV6OOYVAJycgKEaq2neHu/BUOSgtjMev/SGb3PnajGnUYoYmyod040lqX4vJpLdz7FOX1og7j2DzL4f7sJbYnzhIoeb0TImxKqUS8c8pWgEKeECmn1JhnAZXCzmaijkKI2NDAfnGeu2PQ6O8LfI/C3U+ijiJspY31q/KsPSYVo9JUw+uSH7dtKJWiXJznzvyrtMbt+hdiDCSj59T4T/6JwchLSerpsU4AWK4bKCOmm5gLMWJdy+Xu3CvsTZx9vEXYOMlt3sLstqIOI2wGEa9pHytKxaopbW7zJkZn/D6TXTvD3bkr7JbOECRmQY0Q0TMdx1CmOebLAMZ88k8MbPzeEEVoNtavloDFqOMYRDIysUIMRgMHhTluz79K2x3Psabqdck/uB51GOHrt2eXZQDHFLddaVTgU7g3plUpSnFQWuTu/BXatjwrhQiDSkTl6XhP/onBSQIg3ZZBOVEHMYgkrMUSYhBd0+He7GV2J8+h476933Pk73+K4XtRhxE+BcRsUBtnSscvWZLZvYc1xn0pOk6OO/NX2CstoqUaQIiBjf+7p1reWL861u//YjCSAEi3sc4Amo4TGKYpn2GRSho4LMxye+E1Wpnx7vxttBvktm5HHcbQaOJV1h5rMVsCAKC0pnD3I9A66lBOTxnsl85wR6oBhBiYlckY49Rc9ylywFLUQYjoyOAp1fTlqCMYxPhnYIU4na7lcm/uMjuT58d61v+Rwr1PUHrMl1Q+h4LYDWpjS+tYrmFxDrexawdRhzGwJ6sBpDeAEKejlMLOZMb9oTXWYwAxGEkApJp6JeoIBhH4nhEE437/FeL4nlzr30rIft9Wo0Jm90HUYQyV1tIE8NiUmog6hKdRQOHOmFcBPHJUDdDvDSA7BQhxUr7noXUw7mOosa4CFoOxog5ARGqss3/deoNes4VbLOIWCyjZDEAkWMdy2Zq6QNvJM+alhz+kNYW7H6NIwKDqOZSSHgAnENtkiV07wD3YojNzJupQQvGoGmC6ts1MbQsjCckNIYYo8Dza1Rrdej3qUMIw1pOAYjCSAEipo32pL0Ydx6B0ENCuVOjUamRKJZxCXhIBIlH6s/7z7E+cGcut/Z7Hrh3gHG5HHcYIqNgOamMotskSBeTvfUxnegGSci0e7RRQz06weHiXTLcpCwOE+JzA9+lUa3Tq9WRUAfWN/RhAnF5CnmDiFHLo5DQA0UFAq1ymurlFp1ZDJ+cGLVKsbWe4O3+FvcmziRv8ozWFOx+lZLARz3XtMRXr75XdrCVyyUrXznJ37gq7E0sESbvXCHFKge/TKleoPtykU6slafAPcHlj/btRxyAiIhUAqaWXUcl7ymvfp3VYpl2tkZko4eTzqKSUS4vUCFAcFBc4KC0kb+B/xDncSURTteNRyWjYMBqxTgBAv2lle3YJEtCA8zOU4rC4QD0zweLhPbLdekoSdEJ8VuD7dGp1usmeUFoGZQEJ3H9XvEgy3yzFC2lUokt/tO/TOjik9nCTTr2e5Bu4SBANtO0sd+evJLLk/zGtKdz7OE2Di9gPamMk9l3pzE6T7PbdqMMYmp6dOdpl5Bx+Uu9BQjzFoxn/2sNNOtVq0t8dcxoWow5CREMqAFJLXyYFr9/BUSKgXamSKRX7FQHSI0DEUKAU+8VFDooLyWny9wzu/kOsRiXqMEZGo2M/qI0PXRiHZ1P+/qe058+jzYS+RilFuTBHPVNi8fAeuU5tDH4qQpzOoxn/BJb5P5fq9wG4H3UcYvRkJJRa6lLUEYzSo6UB1c0t2tUaWrYPFDGhgaaT5878axyUFhM/+EcHFO59kqrBhJImgCegxiJZYvY6ZLduRx3G0HmWy/3ZS2xNXcBXCVvyIFIvePRueDTjn6bB/5FEVwOLZ0to6lq8iErpRa99n3a5TKdale0DReQCZbBbOkO5MJf8gf+RzO4DrFYitlA6ibEY1EbtRr8h1dh8r/IPbtBaeAlt2VGHMlxKUc3P0MwUmT+8T6FdSVUCTyTP4+38Go00DvqflKrJQPFDkgBIr+WoA4jS4+0Dq1WcYgG3WMQwZXZDjIYGmm6B7akL9C', '<ol><li>A. Cevap A\r\n</li><li>B. Cevap B\r\n</li><li>C. Cevap C\r\n</li><li>D. Cevap D</li></ol>', 'D', 'f0453498-bd1c-4d03-b255-cc000b9f27fc', 5, '2019-10-08 09:03:10', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `town`
--

CREATE TABLE `town` (
  `TownID` int(11) NOT NULL,
  `CityID` int(11) NOT NULL,
  `TownName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `town`
--

INSERT INTO `town` (`TownID`, `CityID`, `TownName`) VALUES
(1, 1, 'ALADAĞ'),
(2, 1, 'CEYHAN'),
(3, 1, 'ÇUKUROVA'),
(4, 1, 'FEKE'),
(5, 1, 'İMAMOĞLU'),
(6, 1, 'KARAİSALI'),
(7, 1, 'KARATAŞ'),
(8, 1, 'KOZAN'),
(9, 1, 'POZANTI'),
(10, 1, 'SAİMBEYLİ'),
(11, 1, 'SARIÇAM'),
(12, 1, 'SEYHAN'),
(13, 1, 'TUFANBEYLİ'),
(14, 1, 'YUMURTALIK'),
(15, 1, 'YÜREĞİR'),
(16, 2, 'BESNİ'),
(17, 2, 'ÇELİKHAN'),
(18, 2, 'GERGER'),
(19, 2, 'GÖLBAŞI'),
(20, 2, 'KAHTA'),
(21, 2, 'MERKEZ'),
(22, 2, 'SAMSAT'),
(23, 2, 'SİNCİK'),
(24, 2, 'TUT'),
(25, 3, 'BAŞMAKÇI'),
(26, 3, 'BAYAT'),
(27, 3, 'BOLVADİN'),
(28, 3, 'ÇAY'),
(29, 3, 'ÇOBANLAR'),
(30, 3, 'DAZKIRI'),
(31, 3, 'DİNAR'),
(32, 3, 'EMİRDAĞ'),
(33, 3, 'EVCİLER'),
(34, 3, 'HOCALAR'),
(35, 3, 'İHSANİYE'),
(36, 3, 'İSCEHİSAR'),
(37, 3, 'KIZILÖREN'),
(38, 3, 'MERKEZ'),
(39, 3, 'SANDIKLI'),
(40, 3, 'SİNANPAŞA'),
(41, 3, 'SULTANDAĞI'),
(42, 3, 'ŞUHUT'),
(43, 4, 'DİYADİN'),
(44, 4, 'DOĞUBAYAZIT'),
(45, 4, 'ELEŞKİRT'),
(46, 4, 'HAMUR'),
(47, 4, 'MERKEZ'),
(48, 4, 'PATNOS'),
(49, 4, 'TAŞLIÇAY'),
(50, 4, 'TUTAK'),
(51, 5, 'AĞAÇÖREN'),
(52, 5, 'ESKİL'),
(53, 5, 'GÜLAĞAÇ'),
(54, 5, 'GÜZELYURT'),
(55, 5, 'MERKEZ'),
(56, 5, 'ORTAKÖY'),
(57, 5, 'SARIYAHŞİ'),
(58, 5, 'SULTANHANI'),
(59, 6, 'GÖYNÜCEK'),
(60, 6, 'GÜMÜŞHACIKÖY'),
(61, 6, 'HAMAMÖZÜ'),
(62, 6, 'MERKEZ'),
(63, 6, 'MERZİFON'),
(64, 6, 'SULUOVA'),
(65, 6, 'TAŞOVA'),
(66, 7, 'AKYURT'),
(67, 7, 'ALTINDAĞ'),
(68, 7, 'AYAŞ'),
(69, 7, 'BALA'),
(70, 7, 'BEYPAZARI'),
(71, 7, 'ÇAMLIDERE'),
(72, 7, 'ÇANKAYA'),
(73, 7, 'ÇUBUK'),
(74, 7, 'ELMADAĞ'),
(75, 7, 'ETİMESGUT'),
(76, 7, 'EVREN'),
(77, 7, 'GÖLBAŞI'),
(78, 7, 'GÜDÜL'),
(79, 7, 'HAYMANA'),
(80, 7, 'KAHRAMANKAZAN'),
(81, 7, 'KALECİK'),
(82, 7, 'KEÇİÖREN'),
(83, 7, 'KIZILCAHAMAM'),
(84, 7, 'MAMAK'),
(85, 7, 'NALLIHAN'),
(86, 7, 'POLATLI'),
(87, 7, 'PURSAKLAR'),
(88, 7, 'SİNCAN'),
(89, 7, 'ŞEREFLİKOÇHİSAR'),
(90, 7, 'YENİMAHALLE'),
(91, 8, 'AKSEKİ'),
(92, 8, 'AKSU'),
(93, 8, 'ALANYA'),
(94, 8, 'DEMRE'),
(95, 8, 'DÖŞEMEALTI'),
(96, 8, 'ELMALI'),
(97, 8, 'FİNİKE'),
(98, 8, 'GAZİPAŞA'),
(99, 8, 'GÜNDOĞMUŞ'),
(100, 8, 'İBRADI'),
(101, 8, 'KAŞ'),
(102, 8, 'KEMER'),
(103, 8, 'KEPEZ'),
(104, 8, 'KONYAALTI'),
(105, 8, 'KORKUTELİ'),
(106, 8, 'KUMLUCA'),
(107, 8, 'MANAVGAT'),
(108, 8, 'MURATPAŞA'),
(109, 8, 'SERİK'),
(110, 9, 'ÇILDIR'),
(111, 9, 'DAMAL'),
(112, 9, 'GÖLE'),
(113, 9, 'HANAK'),
(114, 9, 'MERKEZ'),
(115, 9, 'POSOF'),
(116, 10, 'ARDANUÇ'),
(117, 10, 'ARHAVİ'),
(118, 10, 'BORÇKA'),
(119, 10, 'HOPA'),
(120, 10, 'KEMALPAŞA'),
(121, 10, 'MERKEZ'),
(122, 10, 'MURGUL'),
(123, 10, 'ŞAVŞAT'),
(124, 10, 'YUSUFELİ'),
(125, 11, 'BOZDOĞAN'),
(126, 11, 'BUHARKENT'),
(127, 11, 'ÇİNE'),
(128, 11, 'DİDİM'),
(129, 11, 'EFELER'),
(130, 11, 'GERMENCİK'),
(131, 11, 'İNCİRLİOVA'),
(132, 11, 'KARACASU'),
(133, 11, 'KARPUZLU'),
(134, 11, 'KOÇARLI'),
(135, 11, 'KÖŞK'),
(136, 11, 'KUŞADASI'),
(137, 11, 'KUYUCAK'),
(138, 11, 'NAZİLLİ'),
(139, 11, 'SÖKE'),
(140, 11, 'SULTANHİSAR'),
(141, 11, 'YENİPAZAR'),
(142, 12, 'ALTIEYLÜL'),
(143, 12, 'AYVALIK'),
(144, 12, 'BALYA'),
(145, 12, 'BANDIRMA'),
(146, 12, 'BİGADİÇ'),
(147, 12, 'BURHANİYE'),
(148, 12, 'DURSUNBEY'),
(149, 12, 'EDREMİT'),
(150, 12, 'ERDEK'),
(151, 12, 'GÖMEÇ'),
(152, 12, 'GÖNEN'),
(153, 12, 'HAVRAN'),
(154, 12, 'İVRİNDİ'),
(155, 12, 'KARESİ'),
(156, 12, 'KEPSUT'),
(157, 12, 'MANYAS'),
(158, 12, 'MARMARA'),
(159, 12, 'SAVAŞTEPE'),
(160, 12, 'SINDIRGI'),
(161, 12, 'SUSURLUK'),
(162, 13, 'AMASRA'),
(163, 13, 'KURUCAŞİLE'),
(164, 13, 'MERKEZ'),
(165, 13, 'ULUS'),
(166, 14, 'BEŞİRİ'),
(167, 14, 'GERCÜŞ'),
(168, 14, 'HASANKEYF'),
(169, 14, 'KOZLUK'),
(170, 14, 'MERKEZ'),
(171, 14, 'SASON'),
(172, 15, 'AYDINTEPE'),
(173, 15, 'DEMİRÖZÜ'),
(174, 15, 'MERKEZ'),
(175, 16, 'BOZÜYÜK'),
(176, 16, 'GÖLPAZARI'),
(177, 16, 'İNHİSAR'),
(178, 16, 'MERKEZ'),
(179, 16, 'OSMANELİ'),
(180, 16, 'PAZARYERİ'),
(181, 16, 'SÖĞÜT'),
(182, 16, 'YENİPAZAR'),
(183, 17, 'ADAKLI'),
(184, 17, 'GENÇ'),
(185, 17, 'KARLIOVA'),
(186, 17, 'KİĞI'),
(187, 17, 'MERKEZ'),
(188, 17, 'SOLHAN'),
(189, 17, 'YAYLADERE'),
(190, 17, 'YEDİSU'),
(191, 18, 'ADİLCEVAZ'),
(192, 18, 'AHLAT'),
(193, 18, 'GÜROYMAK'),
(194, 18, 'HİZAN'),
(195, 18, 'MERKEZ'),
(196, 18, 'MUTKİ'),
(197, 18, 'TATVAN'),
(198, 19, 'DÖRTDİVAN'),
(199, 19, 'GEREDE'),
(200, 19, 'GÖYNÜK'),
(201, 19, 'KIBRISCIK'),
(202, 19, 'MENGEN'),
(203, 19, 'MERKEZ'),
(204, 19, 'MUDURNU'),
(205, 19, 'SEBEN'),
(206, 19, 'YENİÇAĞA'),
(207, 20, 'AĞLASUN'),
(208, 20, 'ALTINYAYLA'),
(209, 20, 'BUCAK'),
(210, 20, 'ÇAVDIR'),
(211, 20, 'ÇELTİKÇİ'),
(212, 20, 'GÖLHİSAR'),
(213, 20, 'KARAMANLI'),
(214, 20, 'KEMER'),
(215, 20, 'MERKEZ'),
(216, 20, 'TEFENNİ'),
(217, 20, 'YEŞİLOVA'),
(218, 21, 'BÜYÜKORHAN'),
(219, 21, 'GEMLİK'),
(220, 21, 'GÜRSU'),
(221, 21, 'HARMANCIK'),
(222, 21, 'İNEGÖL'),
(223, 21, 'İZNİK'),
(224, 21, 'KARACABEY'),
(225, 21, 'KELES'),
(226, 21, 'KESTEL'),
(227, 21, 'MUDANYA'),
(228, 21, 'MUSTAFAKEMALPAŞA'),
(229, 21, 'NİLÜFER'),
(230, 21, 'ORHANELİ'),
(231, 21, 'ORHANGAZİ'),
(232, 21, 'OSMANGAZİ'),
(233, 21, 'YENİŞEHİR'),
(234, 21, 'YILDIRIM'),
(235, 22, 'AYVACIK'),
(236, 22, 'BAYRAMİÇ'),
(237, 22, 'BİGA'),
(238, 22, 'BOZCAADA'),
(239, 22, 'ÇAN'),
(240, 22, 'ECEABAT'),
(241, 22, 'EZİNE'),
(242, 22, 'GELİBOLU'),
(243, 22, 'GÖKÇEADA'),
(244, 22, 'LAPSEKİ'),
(245, 22, 'MERKEZ'),
(246, 22, 'YENİCE'),
(247, 23, 'ATKARACALAR'),
(248, 23, 'BAYRAMÖREN'),
(249, 23, 'ÇERKEŞ'),
(250, 23, 'ELDİVAN'),
(251, 23, 'ILGAZ'),
(252, 23, 'KIZILIRMAK'),
(253, 23, 'KORGUN'),
(254, 23, 'KURŞUNLU'),
(255, 23, 'MERKEZ'),
(256, 23, 'ORTA'),
(257, 23, 'ŞABANÖZÜ'),
(258, 23, 'YAPRAKLI'),
(259, 24, 'ALACA'),
(260, 24, 'BAYAT'),
(261, 24, 'BOĞAZKALE'),
(262, 24, 'DODURGA'),
(263, 24, 'İSKİLİP'),
(264, 24, 'KARGI'),
(265, 24, 'LAÇİN'),
(266, 24, 'MECİTÖZÜ'),
(267, 24, 'MERKEZ'),
(268, 24, 'OĞUZLAR'),
(269, 24, 'ORTAKÖY'),
(270, 24, 'OSMANCIK'),
(271, 24, 'SUNGURLU'),
(272, 24, 'UĞURLUDAĞ'),
(273, 25, 'ACIPAYAM'),
(274, 25, 'BABADAĞ'),
(275, 25, 'BAKLAN'),
(276, 25, 'BEKİLLİ'),
(277, 25, 'BEYAĞAÇ'),
(278, 25, 'BOZKURT'),
(279, 25, 'BULDAN'),
(280, 25, 'ÇAL'),
(281, 25, 'ÇAMELİ'),
(282, 25, 'ÇARDAK'),
(283, 25, 'ÇİVRİL'),
(284, 25, 'GÜNEY'),
(285, 25, 'HONAZ'),
(286, 25, 'KALE'),
(287, 25, 'MERKEZEFENDİ'),
(288, 25, 'PAMUKKALE'),
(289, 25, 'SARAYKÖY'),
(290, 25, 'SERİNHİSAR'),
(291, 25, 'TAVAS'),
(292, 26, 'BAĞLAR'),
(293, 26, 'BİSMİL'),
(294, 26, 'ÇERMİK'),
(295, 26, 'ÇINAR'),
(296, 26, 'ÇÜNGÜŞ'),
(297, 26, 'DİCLE'),
(298, 26, 'EĞİL'),
(299, 26, 'ERGANİ'),
(300, 26, 'HANİ'),
(301, 26, 'HAZRO'),
(302, 26, 'KAYAPINAR'),
(303, 26, 'KOCAKÖY'),
(304, 26, 'KULP'),
(305, 26, 'LİCE'),
(306, 26, 'SİLVAN'),
(307, 26, 'SUR'),
(308, 26, 'YENİŞEHİR'),
(309, 27, 'AKÇAKOCA'),
(310, 27, 'CUMAYERİ'),
(311, 27, 'ÇİLİMLİ'),
(312, 27, 'GÖLYAKA'),
(313, 27, 'GÜMÜŞOVA'),
(314, 27, 'KAYNAŞLI'),
(315, 27, 'MERKEZ'),
(316, 27, 'YIĞILCA'),
(317, 28, 'ENEZ'),
(318, 28, 'HAVSA'),
(319, 28, 'İPSALA'),
(320, 28, 'KEŞAN'),
(321, 28, 'LALAPAŞA'),
(322, 28, 'MERİÇ'),
(323, 28, 'MERKEZ'),
(324, 28, 'SÜLOĞLU'),
(325, 28, 'UZUNKÖPRÜ'),
(326, 29, 'AĞIN'),
(327, 29, 'ALACAKAYA'),
(328, 29, 'ARICAK'),
(329, 29, 'BASKİL'),
(330, 29, 'KARAKOÇAN'),
(331, 29, 'KEBAN'),
(332, 29, 'KOVANCILAR'),
(333, 29, 'MADEN'),
(334, 29, 'MERKEZ'),
(335, 29, 'PALU'),
(336, 29, 'SİVRİCE'),
(337, 30, 'ÇAYIRLI'),
(338, 30, 'İLİÇ'),
(339, 30, 'KEMAH'),
(340, 30, 'KEMALİYE'),
(341, 30, 'MERKEZ'),
(342, 30, 'OTLUKBELİ'),
(343, 30, 'REFAHİYE'),
(344, 30, 'TERCAN'),
(345, 30, 'ÜZÜMLÜ'),
(346, 31, 'AŞKALE'),
(347, 31, 'AZİZİYE'),
(348, 31, 'ÇAT'),
(349, 31, 'HINIS'),
(350, 31, 'HORASAN'),
(351, 31, 'İSPİR'),
(352, 31, 'KARAÇOBAN'),
(353, 31, 'KARAYAZI'),
(354, 31, 'KÖPRÜKÖY'),
(355, 31, 'NARMAN'),
(356, 31, 'OLTU'),
(357, 31, 'OLUR'),
(358, 31, 'PALANDÖKEN'),
(359, 31, 'PASİNLER'),
(360, 31, 'PAZARYOLU'),
(361, 31, 'ŞENKAYA'),
(362, 31, 'TEKMAN'),
(363, 31, 'TORTUM'),
(364, 31, 'UZUNDERE'),
(365, 31, 'YAKUTİYE'),
(366, 32, 'ALPU'),
(367, 32, 'BEYLİKOVA'),
(368, 32, 'ÇİFTELER'),
(369, 32, 'GÜNYÜZÜ'),
(370, 32, 'HAN'),
(371, 32, 'İNÖNÜ'),
(372, 32, 'MAHMUDİYE'),
(373, 32, 'MİHALGAZİ'),
(374, 32, 'MİHALIÇÇIK'),
(375, 32, 'ODUNPAZARI'),
(376, 32, 'SARICAKAYA'),
(377, 32, 'SEYİTGAZİ'),
(378, 32, 'SİVRİHİSAR'),
(379, 32, 'TEPEBAŞI'),
(380, 33, 'ARABAN'),
(381, 33, 'İSLAHİYE'),
(382, 33, 'KARKAMIŞ'),
(383, 33, 'NİZİP'),
(384, 33, 'NURDAĞI'),
(385, 33, 'OĞUZELİ'),
(386, 33, 'ŞAHİNBEY'),
(387, 33, 'ŞEHİTKAMİL'),
(388, 33, 'YAVUZELİ'),
(389, 34, 'ALUCRA'),
(390, 34, 'BULANCAK'),
(391, 34, 'ÇAMOLUK'),
(392, 34, 'ÇANAKÇI'),
(393, 34, 'DERELİ'),
(394, 34, 'DOĞANKENT'),
(395, 34, 'ESPİYE'),
(396, 34, 'EYNESİL'),
(397, 34, 'GÖRELE'),
(398, 34, 'GÜCE'),
(399, 34, 'KEŞAP'),
(400, 34, 'MERKEZ'),
(401, 34, 'PİRAZİZ'),
(402, 34, 'ŞEBİNKARAHİSAR'),
(403, 34, 'TİREBOLU'),
(404, 34, 'YAĞLIDERE'),
(405, 35, 'KELKİT'),
(406, 35, 'KÖSE'),
(407, 35, 'KÜRTÜN'),
(408, 35, 'MERKEZ'),
(409, 35, 'ŞİRAN'),
(410, 35, 'TORUL'),
(411, 36, 'ÇUKURCA'),
(412, 36, 'MERKEZ'),
(413, 36, 'ŞEMDİNLİ'),
(414, 36, 'YÜKSEKOVA'),
(415, 37, 'ALTINÖZÜ'),
(416, 37, 'ANTAKYA'),
(417, 37, 'ARSUZ'),
(418, 37, 'BELEN'),
(419, 37, 'DEFNE'),
(420, 37, 'DÖRTYOL'),
(421, 37, 'ERZİN'),
(422, 37, 'HASSA'),
(423, 37, 'İSKENDERUN'),
(424, 37, 'KIRIKHAN'),
(425, 37, 'KUMLU'),
(426, 37, 'PAYAS'),
(427, 37, 'REYHANLI'),
(428, 37, 'SAMANDAĞ'),
(429, 37, 'YAYLADAĞI'),
(430, 38, 'ARALIK'),
(431, 38, 'KARAKOYUNLU'),
(432, 38, 'MERKEZ'),
(433, 38, 'TUZLUCA'),
(434, 39, 'AKSU'),
(435, 39, 'ATABEY'),
(436, 39, 'EĞİRDİR'),
(437, 39, 'GELENDOST'),
(438, 39, 'GÖNEN'),
(439, 39, 'KEÇİBORLU'),
(440, 39, 'MERKEZ'),
(441, 39, 'SENİRKENT'),
(442, 39, 'SÜTÇÜLER'),
(443, 39, 'ŞARKİKARAAĞAÇ'),
(444, 39, 'ULUBORLU'),
(445, 39, 'YALVAÇ'),
(446, 39, 'YENİŞARBADEMLİ'),
(447, 40, 'ADALAR'),
(448, 40, 'ARNAVUTKÖY'),
(449, 40, 'ATAŞEHİR'),
(450, 40, 'AVCILAR'),
(451, 40, 'BAĞCILAR'),
(452, 40, 'BAHÇELİEVLER'),
(453, 40, 'BAKIRKÖY'),
(454, 40, 'BAŞAKŞEHİR'),
(455, 40, 'BAYRAMPAŞA'),
(456, 40, 'BEŞİKTAŞ'),
(457, 40, 'BEYKOZ'),
(458, 40, 'BEYLİKDÜZÜ'),
(459, 40, 'BEYOĞLU'),
(460, 40, 'BÜYÜKÇEKMECE'),
(461, 40, 'ÇATALCA'),
(462, 40, 'ÇEKMEKÖY'),
(463, 40, 'ESENLER'),
(464, 40, 'ESENYURT'),
(465, 40, 'EYÜPSULTAN'),
(466, 40, 'FATİH'),
(467, 40, 'GAZİOSMANPAŞA'),
(468, 40, 'GÜNGÖREN'),
(469, 40, 'KADIKÖY'),
(470, 40, 'KAĞITHANE'),
(471, 40, 'KARTAL'),
(472, 40, 'KÜÇÜKÇEKMECE'),
(473, 40, 'MALTEPE'),
(474, 40, 'PENDİK'),
(475, 40, 'SANCAKTEPE'),
(476, 40, 'SARIYER'),
(477, 40, 'SİLİVRİ'),
(478, 40, 'SULTANBEYLİ'),
(479, 40, 'SULTANGAZİ'),
(480, 40, 'ŞİLE'),
(481, 40, 'ŞİŞLİ'),
(482, 40, 'TUZLA'),
(483, 40, 'ÜMRANİYE'),
(484, 40, 'ÜSKÜDAR'),
(485, 40, 'ZEYTİNBURNU'),
(486, 41, 'ALİAĞA'),
(487, 41, 'BALÇOVA'),
(488, 41, 'BAYINDIR'),
(489, 41, 'BAYRAKLI'),
(490, 41, 'BERGAMA'),
(491, 41, 'BEYDAĞ'),
(492, 41, 'BORNOVA'),
(493, 41, 'BUCA'),
(494, 41, 'ÇEŞME'),
(495, 41, 'ÇİĞLİ'),
(496, 41, 'DİKİLİ'),
(497, 41, 'FOÇA'),
(498, 41, 'GAZİEMİR'),
(499, 41, 'GÜZELBAHÇE'),
(500, 41, 'KARABAĞLAR'),
(501, 41, 'KARABURUN'),
(502, 41, 'KARŞIYAKA'),
(503, 41, 'KEMALPAŞA'),
(504, 41, 'KINIK'),
(505, 41, 'KİRAZ'),
(506, 41, 'KONAK'),
(507, 41, 'MENDERES'),
(508, 41, 'MENEMEN'),
(509, 41, 'NARLIDERE'),
(510, 41, 'ÖDEMİŞ'),
(511, 41, 'SEFERİHİSAR'),
(512, 41, 'SELÇUK'),
(513, 41, 'TİRE'),
(514, 41, 'TORBALI'),
(515, 41, 'URLA'),
(516, 42, 'AFŞİN'),
(517, 42, 'ANDIRIN'),
(518, 42, 'ÇAĞLAYANCERİT'),
(519, 42, 'DULKADİROĞLU'),
(520, 42, 'EKİNÖZÜ'),
(521, 42, 'ELBİSTAN'),
(522, 42, 'GÖKSUN'),
(523, 42, 'NURHAK'),
(524, 42, 'ONİKİŞUBAT'),
(525, 42, 'PAZARCIK'),
(526, 42, 'TÜRKOĞLU'),
(527, 43, 'EFLANİ'),
(528, 43, 'ESKİPAZAR'),
(529, 43, 'MERKEZ'),
(530, 43, 'OVACIK'),
(531, 43, 'SAFRANBOLU'),
(532, 43, 'YENİCE'),
(533, 44, 'AYRANCI'),
(534, 44, 'BAŞYAYLA'),
(535, 44, 'ERMENEK'),
(536, 44, 'KAZIMKARABEKİR'),
(537, 44, 'MERKEZ'),
(538, 44, 'SARIVELİLER'),
(539, 45, 'AKYAKA'),
(540, 45, 'ARPAÇAY'),
(541, 45, 'DİGOR'),
(542, 45, 'KAĞIZMAN'),
(543, 45, 'MERKEZ'),
(544, 45, 'SARIKAMIŞ'),
(545, 45, 'SELİM'),
(546, 45, 'SUSUZ'),
(547, 46, 'ABANA'),
(548, 46, 'AĞLI'),
(549, 46, 'ARAÇ'),
(550, 46, 'AZDAVAY'),
(551, 46, 'BOZKURT'),
(552, 46, 'CİDE'),
(553, 46, 'ÇATALZEYTİN'),
(554, 46, 'DADAY'),
(555, 46, 'DEVREKANİ'),
(556, 46, 'DOĞANYURT'),
(557, 46, 'HANÖNÜ'),
(558, 46, 'İHSANGAZİ'),
(559, 46, 'İNEBOLU'),
(560, 46, 'KÜRE'),
(561, 46, 'MERKEZ'),
(562, 46, 'PINARBAŞI'),
(563, 46, 'SEYDİLER'),
(564, 46, 'ŞENPAZAR'),
(565, 46, 'TAŞKÖPRÜ'),
(566, 46, 'TOSYA'),
(567, 47, 'AKKIŞLA'),
(568, 47, 'BÜNYAN'),
(569, 47, 'DEVELİ'),
(570, 47, 'FELAHİYE'),
(571, 47, 'HACILAR'),
(572, 47, 'İNCESU'),
(573, 47, 'KOCASİNAN'),
(574, 47, 'MELİKGAZİ'),
(575, 47, 'ÖZVATAN'),
(576, 47, 'PINARBAŞI'),
(577, 47, 'SARIOĞLAN'),
(578, 47, 'SARIZ'),
(579, 47, 'TALAS'),
(580, 47, 'TOMARZA'),
(581, 47, 'YAHYALI'),
(582, 47, 'YEŞİLHİSAR'),
(583, 48, 'BAHŞİLİ'),
(584, 48, 'BALIŞEYH'),
(585, 48, 'ÇELEBİ'),
(586, 48, 'DELİCE'),
(587, 48, 'KARAKEÇİLİ'),
(588, 48, 'KESKİN'),
(589, 48, 'MERKEZ'),
(590, 48, 'SULAKYURT'),
(591, 48, 'YAHŞİHAN'),
(592, 49, 'BABAESKİ'),
(593, 49, 'DEMİRKÖY'),
(594, 49, 'KOFÇAZ'),
(595, 49, 'LÜLEBURGAZ'),
(596, 49, 'MERKEZ'),
(597, 49, 'PEHLİVANKÖY'),
(598, 49, 'PINARHİSAR'),
(599, 49, 'VİZE'),
(600, 50, 'AKÇAKENT'),
(601, 50, 'AKPINAR'),
(602, 50, 'BOZTEPE'),
(603, 50, 'ÇİÇEKDAĞI'),
(604, 50, 'KAMAN'),
(605, 50, 'MERKEZ'),
(606, 50, 'MUCUR'),
(607, 51, 'ELBEYLİ'),
(608, 51, 'MERKEZ'),
(609, 51, 'MUSABEYLİ'),
(610, 51, 'POLATELİ'),
(611, 52, 'BAŞİSKELE'),
(612, 52, 'ÇAYIROVA'),
(613, 52, 'DARICA'),
(614, 52, 'DERİNCE'),
(615, 52, 'DİLOVASI'),
(616, 52, 'GEBZE'),
(617, 52, 'GÖLCÜK'),
(618, 52, 'İZMİT'),
(619, 52, 'KANDIRA'),
(620, 52, 'KARAMÜRSEL'),
(621, 52, 'KARTEPE'),
(622, 52, 'KÖRFEZ'),
(623, 53, 'AHIRLI'),
(624, 53, 'AKÖREN'),
(625, 53, 'AKŞEHİR'),
(626, 53, 'ALTINEKİN'),
(627, 53, 'BEYŞEHİR'),
(628, 53, 'BOZKIR'),
(629, 53, 'CİHANBEYLİ'),
(630, 53, 'ÇELTİK'),
(631, 53, 'ÇUMRA'),
(632, 53, 'DERBENT'),
(633, 53, 'DEREBUCAK'),
(634, 53, 'DOĞANHİSAR'),
(635, 53, 'EMİRGAZİ'),
(636, 53, 'EREĞLİ'),
(637, 53, 'GÜNEYSINIR'),
(638, 53, 'HADİM'),
(639, 53, 'HALKAPINAR'),
(640, 53, 'HÜYÜK'),
(641, 53, 'ILGIN'),
(642, 53, 'KADINHANI'),
(643, 53, 'KARAPINAR'),
(644, 53, 'KARATAY'),
(645, 53, 'KULU'),
(646, 53, 'MERAM'),
(647, 53, 'SARAYÖNÜ'),
(648, 53, 'SELÇUKLU'),
(649, 53, 'SEYDİŞEHİR'),
(650, 53, 'TAŞKENT'),
(651, 53, 'TUZLUKÇU'),
(652, 53, 'YALIHÜYÜK'),
(653, 53, 'YUNAK'),
(654, 54, 'ALTINTAŞ'),
(655, 54, 'ASLANAPA'),
(656, 54, 'ÇAVDARHİSAR'),
(657, 54, 'DOMANİÇ'),
(658, 54, 'DUMLUPINAR'),
(659, 54, 'EMET'),
(660, 54, 'GEDİZ'),
(661, 54, 'HİSARCIK'),
(662, 54, 'MERKEZ'),
(663, 54, 'PAZARLAR'),
(664, 54, 'SİMAV'),
(665, 54, 'ŞAPHANE'),
(666, 54, 'TAVŞANLI'),
(667, 55, 'AKÇADAĞ'),
(668, 55, 'ARAPGİR'),
(669, 55, 'ARGUVAN'),
(670, 55, 'BATTALGAZİ'),
(671, 55, 'DARENDE'),
(672, 55, 'DOĞANŞEHİR'),
(673, 55, 'DOĞANYOL'),
(674, 55, 'HEKİMHAN'),
(675, 55, 'KALE'),
(676, 55, 'KULUNCAK'),
(677, 55, 'PÜTÜRGE'),
(678, 55, 'YAZIHAN'),
(679, 55, 'YEŞİLYURT'),
(680, 56, 'AHMETLİ'),
(681, 56, 'AKHİSAR'),
(682, 56, 'ALAŞEHİR'),
(683, 56, 'DEMİRCİ'),
(684, 56, 'GÖLMARMARA'),
(685, 56, 'GÖRDES'),
(686, 56, 'KIRKAĞAÇ'),
(687, 56, 'KÖPRÜBAŞI'),
(688, 56, 'KULA'),
(689, 56, 'SALİHLİ'),
(690, 56, 'SARIGÖL'),
(691, 56, 'SARUHANLI'),
(692, 56, 'SELENDİ'),
(693, 56, 'SOMA'),
(694, 56, 'ŞEHZADELER'),
(695, 56, 'TURGUTLU'),
(696, 56, 'YUNUSEMRE'),
(697, 57, 'ARTUKLU'),
(698, 57, 'DARGEÇİT'),
(699, 57, 'DERİK'),
(700, 57, 'KIZILTEPE'),
(701, 57, 'MAZIDAĞI'),
(702, 57, 'MİDYAT'),
(703, 57, 'NUSAYBİN'),
(704, 57, 'ÖMERLİ'),
(705, 57, 'SAVUR'),
(706, 57, 'YEŞİLLİ'),
(707, 58, 'AKDENİZ'),
(708, 58, 'ANAMUR'),
(709, 58, 'AYDINCIK'),
(710, 58, 'BOZYAZI'),
(711, 58, 'ÇAMLIYAYLA'),
(712, 58, 'ERDEMLİ'),
(713, 58, 'GÜLNAR'),
(714, 58, 'MEZİTLİ'),
(715, 58, 'MUT'),
(716, 58, 'SİLİFKE'),
(717, 58, 'TARSUS'),
(718, 58, 'TOROSLAR'),
(719, 58, 'YENİŞEHİR'),
(720, 59, 'BODRUM'),
(721, 59, 'DALAMAN'),
(722, 59, 'DATÇA'),
(723, 59, 'FETHİYE'),
(724, 59, 'KAVAKLIDERE'),
(725, 59, 'KÖYCEĞİZ'),
(726, 59, 'MARMARİS'),
(727, 59, 'MENTEŞE'),
(728, 59, 'MİLAS'),
(729, 59, 'ORTACA'),
(730, 59, 'SEYDİKEMER'),
(731, 59, 'ULA'),
(732, 59, 'YATAĞAN'),
(733, 60, 'BULANIK'),
(734, 60, 'HASKÖY'),
(735, 60, 'KORKUT'),
(736, 60, 'MALAZGİRT'),
(737, 60, 'MERKEZ'),
(738, 60, 'VARTO'),
(739, 61, 'ACIGÖL'),
(740, 61, 'AVANOS'),
(741, 61, 'DERİNKUYU'),
(742, 61, 'GÜLŞEHİR'),
(743, 61, 'HACIBEKTAŞ'),
(744, 61, 'KOZAKLI'),
(745, 61, 'MERKEZ'),
(746, 61, 'ÜRGÜP'),
(747, 62, 'ALTUNHİSAR'),
(748, 62, 'BOR'),
(749, 62, 'ÇAMARDI'),
(750, 62, 'ÇİFTLİK'),
(751, 62, 'MERKEZ'),
(752, 62, 'ULUKIŞLA'),
(753, 63, 'AKKUŞ'),
(754, 63, 'ALTINORDU'),
(755, 63, 'AYBASTI'),
(756, 63, 'ÇAMAŞ'),
(757, 63, 'ÇATALPINAR'),
(758, 63, 'ÇAYBAŞI'),
(759, 63, 'FATSA'),
(760, 63, 'GÖLKÖY'),
(761, 63, 'GÜLYALI'),
(762, 63, 'GÜRGENTEPE'),
(763, 63, 'İKİZCE'),
(764, 63, 'KABADÜZ'),
(765, 63, 'KABATAŞ'),
(766, 63, 'KORGAN'),
(767, 63, 'KUMRU'),
(768, 63, 'MESUDİYE'),
(769, 63, 'PERŞEMBE'),
(770, 63, 'ULUBEY'),
(771, 63, 'ÜNYE'),
(772, 64, 'BAHÇE'),
(773, 64, 'DÜZİÇİ'),
(774, 64, 'HASANBEYLİ'),
(775, 64, 'KADİRLİ'),
(776, 64, 'MERKEZ'),
(777, 64, 'SUMBAS'),
(778, 64, 'TOPRAKKALE'),
(779, 65, 'ARDEŞEN'),
(780, 65, 'ÇAMLIHEMŞİN'),
(781, 65, 'ÇAYELİ'),
(782, 65, 'DEREPAZARI'),
(783, 65, 'FINDIKLI'),
(784, 65, 'GÜNEYSU'),
(785, 65, 'HEMŞİN'),
(786, 65, 'İKİZDERE'),
(787, 65, 'İYİDERE'),
(788, 65, 'KALKANDERE'),
(789, 65, 'MERKEZ'),
(790, 65, 'PAZAR'),
(791, 66, 'ADAPAZARI'),
(792, 66, 'AKYAZI'),
(793, 66, 'ARİFİYE'),
(794, 66, 'ERENLER'),
(795, 66, 'FERİZLİ'),
(796, 66, 'GEYVE'),
(797, 66, 'HENDEK'),
(798, 66, 'KARAPÜRÇEK'),
(799, 66, 'KARASU'),
(800, 66, 'KAYNARCA'),
(801, 66, 'KOCAALİ'),
(802, 66, 'PAMUKOVA'),
(803, 66, 'SAPANCA'),
(804, 66, 'SERDİVAN'),
(805, 66, 'SÖĞÜTLÜ'),
(806, 66, 'TARAKLI'),
(807, 67, '19 MAYIS'),
(808, 67, 'ALAÇAM'),
(809, 67, 'ASARCIK'),
(810, 67, 'ATAKUM'),
(811, 67, 'AYVACIK'),
(812, 67, 'BAFRA'),
(813, 67, 'CANİK'),
(814, 67, 'ÇARŞAMBA'),
(815, 67, 'HAVZA'),
(816, 67, 'İLKADIM'),
(817, 67, 'KAVAK'),
(818, 67, 'LADİK'),
(819, 67, 'SALIPAZARI'),
(820, 67, 'TEKKEKÖY'),
(821, 67, 'TERME'),
(822, 67, 'VEZİRKÖPRÜ'),
(823, 67, 'YAKAKENT'),
(824, 68, 'BAYKAN'),
(825, 68, 'ERUH'),
(826, 68, 'KURTALAN'),
(827, 68, 'MERKEZ'),
(828, 68, 'PERVARİ'),
(829, 68, 'ŞİRVAN'),
(830, 68, 'TİLLO'),
(831, 69, 'AYANCIK'),
(832, 69, 'BOYABAT'),
(833, 69, 'DİKMEN'),
(834, 69, 'DURAĞAN'),
(835, 69, 'ERFELEK'),
(836, 69, 'GERZE'),
(837, 69, 'MERKEZ'),
(838, 69, 'SARAYDÜZÜ'),
(839, 69, 'TÜRKELİ'),
(840, 70, 'AKINCILAR'),
(841, 70, 'ALTINYAYLA'),
(842, 70, 'DİVRİĞİ'),
(843, 70, 'DOĞANŞAR'),
(844, 70, 'GEMEREK'),
(845, 70, 'GÖLOVA'),
(846, 70, 'GÜRÜN'),
(847, 70, 'HAFİK'),
(848, 70, 'İMRANLI'),
(849, 70, 'KANGAL'),
(850, 70, 'KOYULHİSAR'),
(851, 70, 'MERKEZ'),
(852, 70, 'SUŞEHRİ'),
(853, 70, 'ŞARKIŞLA'),
(854, 70, 'ULAŞ'),
(855, 70, 'YILDIZELİ'),
(856, 70, 'ZARA'),
(857, 71, 'AKÇAKALE'),
(858, 71, 'BİRECİK'),
(859, 71, 'BOZOVA'),
(860, 71, 'CEYLANPINAR'),
(861, 71, 'EYYÜBİYE'),
(862, 71, 'HALFETİ'),
(863, 71, 'HALİLİYE'),
(864, 71, 'HARRAN'),
(865, 71, 'HİLVAN'),
(866, 71, 'KARAKÖPRÜ'),
(867, 71, 'SİVEREK'),
(868, 71, 'SURUÇ'),
(869, 71, 'VİRANŞEHİR'),
(870, 72, 'BEYTÜŞŞEBAP'),
(871, 72, 'CİZRE'),
(872, 72, 'GÜÇLÜKONAK'),
(873, 72, 'İDİL'),
(874, 72, 'MERKEZ'),
(875, 72, 'SİLOPİ'),
(876, 72, 'ULUDERE'),
(877, 73, 'ÇERKEZKÖY'),
(878, 73, 'ÇORLU'),
(879, 73, 'ERGENE'),
(880, 73, 'HAYRABOLU'),
(881, 73, 'KAPAKLI'),
(882, 73, 'MALKARA'),
(883, 73, 'MARMARAEREĞLİSİ'),
(884, 73, 'MURATLI'),
(885, 73, 'SARAY'),
(886, 73, 'SÜLEYMANPAŞA'),
(887, 73, 'ŞARKÖY'),
(888, 74, 'ALMUS'),
(889, 74, 'ARTOVA'),
(890, 74, 'BAŞÇİFTLİK'),
(891, 74, 'ERBAA'),
(892, 74, 'MERKEZ'),
(893, 74, 'NİKSAR'),
(894, 74, 'PAZAR'),
(895, 74, 'REŞADİYE'),
(896, 74, 'SULUSARAY'),
(897, 74, 'TURHAL'),
(898, 74, 'YEŞİLYURT'),
(899, 74, 'ZİLE'),
(900, 75, 'AKÇAABAT'),
(901, 75, 'ARAKLI'),
(902, 75, 'ARSİN'),
(903, 75, 'BEŞİKDÜZÜ'),
(904, 75, 'ÇARŞIBAŞI'),
(905, 75, 'ÇAYKARA'),
(906, 75, 'DERNEKPAZARI'),
(907, 75, 'DÜZKÖY'),
(908, 75, 'HAYRAT'),
(909, 75, 'KÖPRÜBAŞI'),
(910, 75, 'MAÇKA'),
(911, 75, 'OF'),
(912, 75, 'ORTAHİSAR'),
(913, 75, 'SÜRMENE'),
(914, 75, 'ŞALPAZARI'),
(915, 75, 'TONYA'),
(916, 75, 'VAKFIKEBİR'),
(917, 75, 'YOMRA'),
(918, 76, 'ÇEMİŞGEZEK'),
(919, 76, 'HOZAT'),
(920, 76, 'MAZGİRT'),
(921, 76, 'MERKEZ'),
(922, 76, 'NAZIMİYE'),
(923, 76, 'OVACIK'),
(924, 76, 'PERTEK'),
(925, 76, 'PÜLÜMÜR'),
(926, 77, 'BANAZ'),
(927, 77, 'EŞME'),
(928, 77, 'KARAHALLI'),
(929, 77, 'MERKEZ'),
(930, 77, 'SİVASLI'),
(931, 77, 'ULUBEY'),
(932, 78, 'BAHÇESARAY'),
(933, 78, 'BAŞKALE'),
(934, 78, 'ÇALDIRAN'),
(935, 78, 'ÇATAK'),
(936, 78, 'EDREMİT'),
(937, 78, 'ERCİŞ'),
(938, 78, 'GEVAŞ'),
(939, 78, 'GÜRPINAR'),
(940, 78, 'İPEKYOLU'),
(941, 78, 'MURADİYE'),
(942, 78, 'ÖZALP'),
(943, 78, 'SARAY'),
(944, 78, 'TUŞBA'),
(945, 79, 'ALTINOVA'),
(946, 79, 'ARMUTLU'),
(947, 79, 'ÇINARCIK'),
(948, 79, 'ÇİFTLİKKÖY'),
(949, 79, 'MERKEZ'),
(950, 79, 'TERMAL'),
(951, 80, 'AKDAĞMADENİ'),
(952, 80, 'AYDINCIK'),
(953, 80, 'BOĞAZLIYAN'),
(954, 80, 'ÇANDIR'),
(955, 80, 'ÇAYIRALAN'),
(956, 80, 'ÇEKEREK'),
(957, 80, 'KADIŞEHRİ'),
(958, 80, 'MERKEZ'),
(959, 80, 'SARAYKENT'),
(960, 80, 'SARIKAYA'),
(961, 80, 'SORGUN'),
(962, 80, 'ŞEFAATLİ'),
(963, 80, 'YENİFAKILI'),
(964, 80, 'YERKÖY'),
(965, 81, 'ALAPLI'),
(966, 81, 'ÇAYCUMA'),
(967, 81, 'DEVREK'),
(968, 81, 'EREĞLİ'),
(969, 81, 'GÖKÇEBEY'),
(970, 81, 'KİLİMLİ'),
(971, 81, 'KOZLU'),
(972, 81, 'MERKEZ');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `userlogins`
--

CREATE TABLE `userlogins` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `logDate` datetime NOT NULL,
  `ip` varchar(25) COLLATE utf8_turkish_ci DEFAULT NULL,
  `browser` varchar(25) COLLATE utf8_turkish_ci DEFAULT NULL,
  `platform` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `userlogins`
--

INSERT INTO `userlogins` (`id`, `userId`, `status`, `logDate`, `ip`, `browser`, `platform`, `location`) VALUES
(1, 1, 1, '2019-10-07 21:40:02', '::1', 'Chrome 77.0.3865.90', 'Windows 7', NULL),
(10, 1, 1, '2019-05-21 20:41:34', '::1', 'Chrome 74.0.3729.157', 'Windows 7', NULL),
(11, 1, 1, '2019-10-07 21:13:45', '::1', 'Chrome 77.0.3865.90', 'Windows 7', NULL),
(12, 1, 2, '2019-10-07 21:54:00', '::1', 'Chrome 77.0.3865.90', 'Windows 7', NULL),
(13, 1, 1, '2019-10-07 21:56:36', '::1', 'Chrome 77.0.3865.90', 'Windows 7', NULL),
(14, 1, 1, '2019-10-08 07:30:41', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(15, 1, 2, '2019-10-08 08:59:16', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(16, 1, 1, '2019-10-08 08:59:18', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(17, 1, 2, '2019-10-08 09:01:03', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(18, 2, 1, '2019-10-08 09:01:07', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(19, 2, 2, '2019-10-08 09:06:41', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(20, 1, 1, '2019-10-08 09:06:44', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `userroles`
--

CREATE TABLE `userroles` (
  `id` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RoleId` int(11) NOT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `createDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `userroles`
--

INSERT INTO `userroles` (`id`, `UserId`, `RoleId`, `isActive`, `createDate`) VALUES
(1, 1, 1, 1, '2019-04-22 10:21:45'),
(2, 2, 2, 1, '2019-04-22 10:23:37');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `md5_password` text COLLATE utf8_turkish_ci,
  `name` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `surname` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `email` text COLLATE utf8_turkish_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `registerDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `address` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `md5_password`, `name`, `surname`, `email`, `isActive`, `registerDate`, `address`, `isAdmin`) VALUES
(1, 'admin', '4917', 'cf8d8c66b1212720e569b0bd67695451', 'Emre', 'Bodur', 'emrebodurbto@gmail.com', 1, '2019-10-08 06:59:04', 'Düzce', 1),
(2, 'emre', '4917', 'cf8d8c66b1212720e569b0bd67695451', 'Emre', 'Bodur', 'emrebodur@hotmail.com.tr', 1, '2019-10-08 07:00:57', 'Düzce', 0);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`CityID`) USING BTREE,
  ADD KEY `FK_City_CountryID` (`CountryID`) USING BTREE;

--
-- Tablo için indeksler `ci_session`
--
ALTER TABLE `ci_session`
  ADD KEY `ci_sessions_timestamp` (`timestamp`) USING BTREE;

--
-- Tablo için indeksler `count`
--
ALTER TABLE `count`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`CountryID`) USING BTREE;

--
-- Tablo için indeksler `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `duyurular`
--
ALTER TABLE `duyurular`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `haberler`
--
ALTER TABLE `haberler`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `iletisim`
--
ALTER TABLE `iletisim`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `site_bilgileri`
--
ALTER TABLE `site_bilgileri`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `sorular`
--
ALTER TABLE `sorular`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `town`
--
ALTER TABLE `town`
  ADD PRIMARY KEY (`TownID`) USING BTREE,
  ADD KEY `FK_Town_CityID` (`CityID`) USING BTREE;

--
-- Tablo için indeksler `userlogins`
--
ALTER TABLE `userlogins`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `userroles`
--
ALTER TABLE `userroles`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `sorular`
--
ALTER TABLE `sorular`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `userlogins`
--
ALTER TABLE `userlogins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
