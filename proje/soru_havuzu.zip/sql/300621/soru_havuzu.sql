-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 30 Haz 2021, 20:11:56
-- Sunucu sürümü: 10.4.17-MariaDB
-- PHP Sürümü: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `soru_havuzu`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `city`
--

CREATE TABLE `city` (
  `CityID` int(11) NOT NULL,
  `CountryID` int(11) NOT NULL,
  `CityName` varchar(100) NOT NULL,
  `PlateNo` int(2) NOT NULL,
  `PhoneCode` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `city`
--

INSERT INTO `city` (`CityID`, `CountryID`, `CityName`, `PlateNo`, `PhoneCode`) VALUES
(1, 212, 'ADANA', 1, '322'),
(2, 212, 'ADIYAMAN', 2, '416'),
(3, 212, 'AFYONKARAHİSAR', 3, '272'),
(4, 212, 'AĞRI', 4, '472'),
(5, 212, 'AKSARAY', 68, '382'),
(6, 212, 'AMASYA', 5, '358'),
(7, 212, 'ANKARA', 6, '312'),
(8, 212, 'ANTALYA', 7, '242'),
(9, 212, 'ARDAHAN', 75, '478'),
(10, 212, 'ARTVİN', 8, '466'),
(11, 212, 'AYDIN', 9, '256'),
(12, 212, 'BALIKESİR', 10, '266'),
(13, 212, 'BARTIN', 74, '378'),
(14, 212, 'BATMAN', 72, '488'),
(15, 212, 'BAYBURT', 69, '458'),
(16, 212, 'BİLECİK', 11, '228'),
(17, 212, 'BİNGÖL', 12, '426'),
(18, 212, 'BİTLİS', 13, '434'),
(19, 212, 'BOLU', 14, '374'),
(20, 212, 'BURDUR', 15, '248'),
(21, 212, 'BURSA', 16, '224'),
(22, 212, 'ÇANAKKALE', 17, '286'),
(23, 212, 'ÇANKIRI', 18, '376'),
(24, 212, 'ÇORUM', 19, '364'),
(25, 212, 'DENİZLİ', 20, '258'),
(26, 212, 'DİYARBAKIR', 21, '412'),
(27, 212, 'DÜZCE', 81, '380'),
(28, 212, 'EDİRNE', 22, '284'),
(29, 212, 'ELAZIĞ', 23, '424'),
(30, 212, 'ERZİNCAN', 24, '446'),
(31, 212, 'ERZURUM', 25, '442'),
(32, 212, 'ESKİŞEHİR', 26, '222'),
(33, 212, 'GAZİANTEP', 27, '342'),
(34, 212, 'GİRESUN', 28, '454'),
(35, 212, 'GÜMÜŞHANE', 29, '456'),
(36, 212, 'HAKKARİ', 30, '438'),
(37, 212, 'HATAY', 31, '326'),
(38, 212, 'IĞDIR', 76, '476'),
(39, 212, 'ISPARTA', 32, '246'),
(40, 212, 'İSTANBUL', 34, '212-216'),
(41, 212, 'İZMİR', 35, '232'),
(42, 212, 'KAHRAMANMARAŞ', 46, '344'),
(43, 212, 'KARABÜK', 78, '370'),
(44, 212, 'KARAMAN', 70, '338'),
(45, 212, 'KARS', 36, '474'),
(46, 212, 'KASTAMONU', 37, '366'),
(47, 212, 'KAYSERİ', 38, '352'),
(48, 212, 'KIRIKKALE', 71, '318'),
(49, 212, 'KIRKLARELİ', 39, '288'),
(50, 212, 'KIRŞEHİR', 40, '386'),
(51, 212, 'KİLİS', 79, '348'),
(52, 212, 'KOCAELİ', 41, '262'),
(53, 212, 'KONYA', 42, '332'),
(54, 212, 'KÜTAHYA', 43, '274'),
(55, 212, 'MALATYA', 44, '422'),
(56, 212, 'MANİSA', 45, '236'),
(57, 212, 'MARDİN', 47, '482'),
(58, 212, 'MERSİN', 33, '324'),
(59, 212, 'MUĞLA', 48, '252'),
(60, 212, 'MUŞ', 49, '436'),
(61, 212, 'NEVŞEHİR', 50, '384'),
(62, 212, 'NİĞDE', 51, '388'),
(63, 212, 'ORDU', 52, '452'),
(64, 212, 'OSMANİYE', 80, '328'),
(65, 212, 'RİZE', 53, '464'),
(66, 212, 'SAKARYA', 54, '264'),
(67, 212, 'SAMSUN', 55, '362'),
(68, 212, 'SİİRT', 56, '484'),
(69, 212, 'SİNOP', 57, '368'),
(70, 212, 'SİVAS', 58, '346'),
(71, 212, 'ŞANLIURFA', 63, '414'),
(72, 212, 'ŞIRNAK', 73, '486'),
(73, 212, 'TEKİRDAĞ', 59, '282'),
(74, 212, 'TOKAT', 60, '356'),
(75, 212, 'TRABZON', 61, '462'),
(76, 212, 'TUNCELİ', 62, '428'),
(77, 212, 'UŞAK', 64, '276'),
(78, 212, 'VAN', 65, '432'),
(79, 212, 'YALOVA', 77, '226'),
(80, 212, 'YOZGAT', 66, '354'),
(81, 212, 'ZONGULDAK', 67, '372');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ci_session`
--

CREATE TABLE `ci_session` (
  `id` varchar(128) COLLATE utf8_turkish_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8_turkish_ci NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `ci_session`
--

INSERT INTO `ci_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('t96c6h3ibp4oj2fkv4m0ev04hnamjq4o', '::1', 1625069984, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353036393938343b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('p5dd6enhmavv1bpf4p40ip2hgn2b0u6h', '::1', 1625070286, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037303238363b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('e7u4mp8sv6kh44677roqs4bk589gqf6g', '::1', 1625070617, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037303631373b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('nikk5hp3mshjbej81bo17qa0s2g2ie6u', '::1', 1625070922, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037303932323b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('7lpihhs93fusodoceme1hfqn9l5rjpq0', '::1', 1625071233, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037313233333b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('h745h2c34kp5gjqnvvkbmiagqe2mdfku', '::1', 1625071633, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037313633333b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('ctrrspbpnbpsvpl7hfg9slvgm3f02fln', '::1', 1625071950, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037313935303b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('ilg6re34vnk3qqkke7bi47cngvfuuoig', '::1', 1625072564, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037323536343b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('s9a4kt23ookndjml5qr5aq918nr5fip7', '::1', 1625073109, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037333130393b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('6derfuvj6haf5f8jhe0v2td4d5tdruop', '::1', 1625073466, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037333436363b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('65b8pafd5tan1irnv0hvvqll0opkue0s', '::1', 1625073816, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037333831363b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('hbg07eecsrjl70gu4pe3bsof1sngolv1', '::1', 1625074156, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037343135363b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b616c6572747c613a333a7b733a353a227469746c65223b733a31393a22c4b0c59f6c656d204261c59f6172c4b16cc4b1223b733a343a2274657874223b733a35323a224b756c6c616ec4b163c4b12047697a6c696c696b205461616868c3bc746e616d6573696e69204b6162756c20457474696e697a21223b733a343a2274797065223b733a373a2273756363657373223b7d5f5f63695f766172737c613a313a7b733a353a22616c657274223b733a333a226f6c64223b7d),
('17e7ppbhc7lajs1eg0hakiuqdtc5k201', '::1', 1625074471, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037343437313b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('fda569u1ah77jd218509c8vgjubrob98', '::1', 1625074775, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037343737353b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('5s4mc5d5fasjq8287gcj2qoglaevg1tk', '::1', 1625075103, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037353130333b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('h0pbmp7n3p9umoqcggk7bqkjivuti13b', '::1', 1625075421, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037353432313b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('codeerdfdoq787595p7dkj6mmrgj0r91', '::1', 1625075834, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037353833343b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('evlpumqhj09k82rtreq1mp2dc03e7ei5', '::1', 1625076145, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037363134353b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('25slictbn3v7vi7v2sa126bju6mvvcm4', '::1', 1625076518, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037363531383b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b),
('unng7dkndlalju33gofrb30bsku89rlb', '::1', 1625076708, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632353037363531383b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c4e3b6c6f67446174657c733a31393a22323032312d30362d33302031393a30373a3030223b69735f6c6f676765645f696e7c623a313b);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `country`
--

CREATE TABLE `country` (
  `CountryID` int(11) NOT NULL,
  `BinaryCode` varchar(2) NOT NULL,
  `TripleCode` varchar(3) NOT NULL,
  `CountryName` varchar(100) NOT NULL,
  `PhoneCode` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `country`
--

INSERT INTO `country` (`CountryID`, `BinaryCode`, `TripleCode`, `CountryName`, `PhoneCode`) VALUES
(1, 'AF', 'AFG', 'Afghanistan', '93'),
(2, 'AL', 'ALB', 'Albania', '355'),
(3, 'DZ', 'DZA', 'Algeria', '213'),
(4, 'AS', 'ASM', 'American Samoa', '684'),
(5, 'AD', 'AND', 'Andorra', '376'),
(6, 'AO', 'AGO', 'Angola', '244'),
(7, 'AI', 'AIA', 'Anguilla', '264'),
(8, 'AQ', 'ATA', 'Antarctica', '672'),
(9, 'AG', 'ATG', 'Antigua and Barbuda', '268'),
(10, 'AR', 'ARG', 'Argentina', '54'),
(11, 'AM', 'ARM', 'Armenia', '374'),
(12, 'AW', 'ABW', 'Aruba', '297'),
(13, 'AU', 'AUS', 'Australia', '61'),
(14, 'AT', 'AUT', 'Austria', '43'),
(15, 'AZ', 'AZE', 'Azerbaijan', '994'),
(16, 'BS', 'BHS', 'Bahamas', '242'),
(17, 'BH', 'BHR', 'Bahrain', '973'),
(18, 'BD', 'BGD', 'Bangladesh', '880'),
(19, 'BB', 'BRB', 'Barbados', '246'),
(20, 'BY', 'BLR', 'Belarus', '375'),
(21, 'BE', 'BEL', 'Belgium', '32'),
(22, 'BZ', 'BLZ', 'Belize', '501'),
(23, 'BJ', 'BEN', 'Benin', '229'),
(24, 'BM', 'BMU', 'Bermuda', '441'),
(25, 'BT', 'BTN', 'Bhutan', '975'),
(26, 'BO', 'BOL', 'Bolivia', '591'),
(27, 'BA', 'BIH', 'Bosnia and Herzegovina', '387'),
(28, 'BW', 'BWA', 'Botswana', '267'),
(29, 'BR', 'BRA', 'Brazil', '55'),
(30, 'VG', 'VGB', 'British Virgin Islands', '284'),
(31, 'BN', 'BRN', 'Brunei', '673'),
(32, 'BG', 'BGR', 'Bulgaria', '359'),
(33, 'BF', 'BFA', 'Burkina Faso', '226'),
(34, 'BI', 'BDI', 'Burundi', '257'),
(35, 'KH', 'KHM', 'Cambodia', '855'),
(36, 'CM', 'CMR', 'Cameroon', '237'),
(37, 'CA', 'CAN', 'Canada', '1'),
(38, 'CV', 'CPV', 'Cape Verde', '238'),
(39, 'KY', 'CYM', 'Cayman Islands', '345'),
(40, 'CF', 'CAF', 'Central African Republic', '236'),
(41, 'TD', 'TCD', 'Chad', '235'),
(42, 'CL', 'CHL', 'Chile', '56'),
(43, 'CN', 'CHN', 'China', '86'),
(44, 'CX', 'CXR', 'Christmas Island', '61'),
(45, 'CC', 'CCK', 'Cocos [Keeling] Islands', '61'),
(46, 'CO', 'COL', 'Colombia', '57'),
(47, 'KM', 'COM', 'Comoros', '269'),
(48, 'CD', 'COD', 'Congo [DRC]', '242'),
(49, 'CG', 'COG', 'Congo [Republic]', '682'),
(50, 'CK', 'COK', 'Cook Islands', '506'),
(51, 'CR', 'CRI', 'Costa Rica', '385'),
(52, 'HR', 'HRV', 'Croatia', '53'),
(53, 'CU', 'CUB', 'Cuba', '599'),
(54, 'CY', 'CYP', 'Cyprus', '357'),
(55, 'CZ', 'CZE', 'Czech Republic', '420'),
(56, 'DK', 'DNK', 'Denmark', '45'),
(57, 'DJ', 'DJI', 'Djibouti', '253'),
(58, 'DM', 'DMA', 'Dominica', '767'),
(59, 'DO', 'DOM', 'Dominican Republic', '809'),
(60, 'TL', 'TLS', 'East Timor', '56'),
(61, 'EC', 'ECU', 'Ecuador', '593'),
(62, 'EG', 'EGY', 'Egypt', '20'),
(63, 'SV', 'SLV', 'El Salvador', '503'),
(64, 'GQ', 'GNQ', 'Equatorial Guinea', '240'),
(65, 'ER', 'ERI', 'Eritrea', '291'),
(66, 'EE', 'EST', 'Estonia', '372'),
(67, 'ET', 'ETH', 'Ethiopia', '251'),
(68, 'FK', 'FLK', 'Falkland Islands', '500'),
(69, 'FO', 'FRO', 'Faroe Islands', '298'),
(70, 'FJ', 'FJI', 'Fiji', '679'),
(71, 'FI', 'FIN', 'Finland', '358'),
(72, 'FR', 'FRA', 'France', '33'),
(73, 'GF', 'GUF', 'French Guiana', '596'),
(74, 'PF', 'PYF', 'French Polynesia', '594'),
(75, 'TF', 'ATF', 'French Southern Territories', '689'),
(76, 'GA', 'GAB', 'Gabon', '241'),
(77, 'GM', 'GMB', 'Gambia', '220'),
(78, 'GE', 'GEO', 'Georgia', '995'),
(79, 'DE', 'DEU', 'Germany', '49'),
(80, 'GH', 'GHA', 'Ghana', '233'),
(81, 'GI', 'GIB', 'Gibraltar', '350'),
(82, 'GR', 'GRC', 'Greece', '30'),
(83, 'GL', 'GRL', 'Greenland', '299'),
(84, 'GD', 'GRD', 'Grenada', '473'),
(85, 'GP', 'GLP', 'Guadeloupe', '590'),
(86, 'GU', 'GUM', 'Guam', '671'),
(87, 'GT', 'GTM', 'Guatemala', '502'),
(88, 'GN', 'GIN', 'Guinea', '594'),
(89, 'GW', 'GNB', 'Guinea-Bissau', '245'),
(90, 'GY', 'GUY', 'Guyana', '592'),
(91, 'HT', 'HTI', 'Haiti', '509'),
(92, 'HN', 'HND', 'Honduras', '504'),
(93, 'HK', 'HKG', 'Hong Kong', '852'),
(94, 'HU', 'HUN', 'Hungary', '36'),
(95, 'IS', 'ISL', 'Iceland', '354'),
(96, 'IN', 'IND', 'India', '91'),
(97, 'ID', 'IDN', 'Indonesia', '62'),
(98, 'IR', 'IRN', 'Iran', '98'),
(99, 'IQ', 'IRQ', 'Iraq', '964'),
(100, 'IE', 'IRL', 'Ireland', '353'),
(101, 'IM', 'IMN', 'Isle of Man', '44'),
(102, 'IL', 'ISR', 'Israel', '972'),
(103, 'IT', 'ITA', 'Italy', '39'),
(104, 'CI', 'CIV', 'Ivory Coast', '225'),
(105, 'JM', 'JAM', 'Jamaica', '876'),
(106, 'JP', 'JPN', 'Japan', '81'),
(107, 'JO', 'JOR', 'Jordan', '962'),
(108, 'KZ', 'KAZ', 'Kazakhstan', '7'),
(109, 'KE', 'KEN', 'Kenya', '254'),
(110, 'KI', 'KIR', 'Kiribati', '686'),
(111, 'XK', 'XKX', 'Kosovo', '381'),
(112, 'KW', 'KWT', 'Kuwait', '965'),
(113, 'KG', 'KGZ', 'Kyrgyzstan', '996'),
(114, 'LA', 'LAO', 'Laos', '856'),
(115, 'LV', 'LVA', 'Latvia', '371'),
(116, 'LB', 'LBN', 'Lebanon', '961'),
(117, 'LS', 'LSO', 'Lesotho', '266'),
(118, 'LR', 'LBR', 'Liberia', '231'),
(119, 'LY', 'LBY', 'Libya', '218'),
(120, 'LI', 'LIE', 'Liechtenstein', '423'),
(121, 'LT', 'LTU', 'Lithuania', '370'),
(122, 'LU', 'LUX', 'Luxembourg', '352'),
(123, 'MO', 'MAC', 'Macau', '853'),
(124, 'MK', 'MKD', 'Macedonia', '389'),
(125, 'MG', 'MDG', 'Madagascar', '261'),
(126, 'MW', 'MWI', 'Malawi', '265'),
(127, 'MY', 'MYS', 'Malaysia', '60'),
(128, 'MV', 'MDV', 'Maldives', '960'),
(129, 'ML', 'MLI', 'Mali', '223'),
(130, 'MT', 'MLT', 'Malta', '356'),
(131, 'MH', 'MHL', 'Marshall Islands', '692'),
(132, 'MQ', 'MTQ', 'Martinique', '670'),
(133, 'MR', 'MRT', 'Mauritania', '222'),
(134, 'MU', 'MUS', 'Mauritius', '230'),
(135, 'YT', 'MYT', 'Mayotte', '269'),
(136, 'MX', 'MEX', 'Mexico', '52'),
(137, 'FM', 'FSM', 'Micronesia', '691'),
(138, 'MD', 'MDA', 'Moldova', '373'),
(139, 'MC', 'MCO', 'Monaco', '377'),
(140, 'MN', 'MNG', 'Mongolia', '976'),
(141, 'MS', 'MSR', 'Montserrat', '664'),
(142, 'MA', 'MAR', 'Morocco', '212'),
(143, 'MZ', 'MOZ', 'Mozambique', '258'),
(144, 'MM', 'MMR', 'Myanmar [Burma]', '95'),
(145, 'NA', 'NAM', 'Namibia', '264'),
(146, 'NR', 'NRU', 'Nauru', '674'),
(147, 'NP', 'NPL', 'Nepal', '977'),
(148, 'NL', 'NLD', 'Netherlands', '31'),
(149, 'AN', 'ANT', 'Netherlands Antilles', '599'),
(150, 'NC', 'NCL', 'New Caledonia', '687'),
(151, 'NZ', 'NZL', 'New Zealand', '64'),
(152, 'NI', 'NIC', 'Nicaragua', '505'),
(153, 'NE', 'NER', 'Niger', '227'),
(154, 'NG', 'NGA', 'Nigeria', '234'),
(155, 'NU', 'NIU', 'Niue', '683'),
(156, 'NF', 'NFK', 'Norfolk Island', '672'),
(157, 'KP', 'PRK', 'North Korea', '850'),
(158, 'NO', 'NOR', 'Norway', '47'),
(159, 'OM', 'OMN', 'Oman', '968'),
(160, 'PK', 'PAK', 'Pakistan', '92'),
(161, 'PW', 'PLW', 'Palau', '680'),
(162, 'PA', 'PAN', 'Panama', '507'),
(163, 'PG', 'PNG', 'Papua New Guinea', '675'),
(164, 'PY', 'PRY', 'Paraguay', '595'),
(165, 'PE', 'PER', 'Peru', '51'),
(166, 'PH', 'PHL', 'Philippines', '63'),
(167, 'PN', 'PCN', 'Pitcairn Islands', '48'),
(168, 'PL', 'POL', 'Poland', '351'),
(169, 'PT', 'PRT', 'Portugal', '239'),
(170, 'PR', 'PRI', 'Puerto Rico', '787'),
(171, 'QA', 'QAT', 'Qatar', '974'),
(172, 'RE', 'REU', 'R', '262'),
(173, 'RO', 'ROU', 'Romania', '40'),
(174, 'RU', 'RUS', 'Russia', '7'),
(175, 'RW', 'RWA', 'Rwanda', '250'),
(176, 'SH', 'SHN', 'Saint Helena', '290'),
(177, 'KN', 'KNA', 'Saint Kitts and Nevis', '869'),
(178, 'LC', 'LCA', 'Saint Lucia', '758'),
(179, 'PM', 'SPM', 'Saint Pierre and Miquelon', '508'),
(180, 'VC', 'VCT', 'Saint Vincent and the Grenadines', '784'),
(181, 'SM', 'SMR', 'San Marino', '378'),
(182, 'ST', 'STP', 'Sao Tome and Principe', '239'),
(183, 'SA', 'SAU', 'Saudi Arabia', '966'),
(184, 'SN', 'SEN', 'Senegal', '221'),
(185, 'RS', 'SRB', 'Serbia', '381'),
(186, 'SC', 'SYC', 'Seychelles', '248'),
(187, 'SL', 'SLE', 'Sierra Leone', '232'),
(188, 'SG', 'SGP', 'Singapore', '65'),
(189, 'SK', 'SVK', 'Slovakia', '421'),
(190, 'SI', 'SVN', 'Slovenia', '386'),
(191, 'SB', 'SLB', 'Solomon Islands', '677'),
(192, 'SO', 'SOM', 'Somalia', '252'),
(193, 'ZA', 'ZAF', 'South Africa', '27'),
(194, 'KR', 'KOR', 'South Korea', '82'),
(195, 'ES', 'ESP', 'Spain', '34'),
(196, 'LK', 'LKA', 'Sri Lanka', '94'),
(197, 'SD', 'SDN', 'Sudan', '249'),
(198, 'SR', 'SUR', 'Suriname', '597'),
(199, 'SZ', 'SWZ', 'Swaziland', '268'),
(200, 'SE', 'SWE', 'Sweden', '46'),
(201, 'CH', 'CHE', 'Switzerland', '41'),
(202, 'SY', 'SYR', 'Syria', '963'),
(203, 'TW', 'TWN', 'Taiwan', '886'),
(204, 'TJ', 'TJK', 'Tajikistan', '992'),
(205, 'TZ', 'TZA', 'Tanzania', '255'),
(206, 'TH', 'THA', 'Thailand', '66'),
(207, 'TG', 'TGO', 'Togo', '228'),
(208, 'TK', 'TKL', 'Tokelau', '690'),
(209, 'TO', 'TON', 'Tonga', '676'),
(210, 'TT', 'TTO', 'Trinidad and Tobago', '868'),
(211, 'TN', 'TUN', 'Tunisia', '216'),
(212, 'TR', 'TUR', 'Turkey', '90'),
(213, 'TM', 'TKM', 'Turkmenistan', '993'),
(214, 'TC', 'TCA', 'Turks and Caicos Islands', '649'),
(215, 'TV', 'TUV', 'Tuvalu', '688'),
(216, 'VI', 'VIR', 'U.S. Virgin Islands', '340'),
(217, 'UG', 'UGA', 'Uganda', '256'),
(218, 'UA', 'UKR', 'Ukraine', '380'),
(219, 'AE', 'ARE', 'United Arab Emirates', '971'),
(220, 'GB', 'GBR', 'United Kingdom', '44'),
(221, 'US', 'USA', 'United States', '1'),
(222, 'UY', 'URY', 'Uruguay', '598'),
(223, 'UZ', 'UZB', 'Uzbekistan', '998'),
(224, 'VU', 'VUT', 'Vanuatu', '678'),
(225, 'VA', 'VAT', 'Vatican City', '39'),
(226, 'VE', 'VEN', 'Venezuela', '58'),
(227, 'VN', 'VNM', 'Vietnam', '84'),
(228, 'WF', 'WLF', 'Wallis and Futuna', '681'),
(229, 'YE', 'YEM', 'Yemen', '967'),
(230, 'ZM', 'ZMB', 'Zambia', '260'),
(231, 'ZW', 'ZWE', 'Zimbabwe', '263'),
(232, 'CY', 'CYP', 'KKTC', '90');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `currency`
--

CREATE TABLE `currency` (
  `id` int(11) NOT NULL,
  `country` varchar(100) COLLATE utf8_turkish_ci DEFAULT NULL,
  `currency` varchar(100) COLLATE utf8_turkish_ci DEFAULT NULL,
  `code` varchar(100) COLLATE utf8_turkish_ci DEFAULT NULL,
  `symbol` varchar(100) COLLATE utf8_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `currency`
--

INSERT INTO `currency` (`id`, `country`, `currency`, `code`, `symbol`) VALUES
(1, 'Albania', 'Leke', 'ALL', 'Lek'),
(2, 'America', 'Dollars', 'USD', '$'),
(3, 'Afghanistan', 'Afghanis', 'AFN', '؋'),
(4, 'Argentina', 'Pesos', 'ARS', '$'),
(5, 'Aruba', 'Guilders', 'AWG', 'ƒ'),
(6, 'Australia', 'Dollars', 'AUD', '$'),
(7, 'Azerbaijan', 'New Manats', 'AZN', 'ман'),
(8, 'Bahamas', 'Dollars', 'BSD', '$'),
(9, 'Barbados', 'Dollars', 'BBD', '$'),
(10, 'Belarus', 'Rubles', 'BYR', 'p.'),
(11, 'Belgium', 'Euro', 'EUR', '€'),
(12, 'Beliz', 'Dollars', 'BZD', 'BZ$'),
(13, 'Bermuda', 'Dollars', 'BMD', '$'),
(14, 'Bolivia', 'Bolivianos', 'BOB', '$b'),
(15, 'Bosnia and Herzegovina', 'Convertible Marka', 'BAM', 'KM'),
(16, 'Botswana', 'Pula', 'BWP', 'P'),
(17, 'Bulgaria', 'Leva', 'BGN', 'лв'),
(18, 'Brazil', 'Reais', 'BRL', 'R$'),
(19, 'Britain (United Kingdom)', 'Pounds', 'GBP', '£'),
(20, 'Brunei Darussalam', 'Dollars', 'BND', '$'),
(21, 'Cambodia', 'Riels', 'KHR', '៛'),
(22, 'Canada', 'Dollars', 'CAD', '$'),
(23, 'Cayman Islands', 'Dollars', 'KYD', '$'),
(24, 'Chile', 'Pesos', 'CLP', '$'),
(25, 'China', 'Yuan Renminbi', 'CNY', '¥'),
(26, 'Colombia', 'Pesos', 'COP', '$'),
(27, 'Costa Rica', 'Colón', 'CRC', '₡'),
(28, 'Croatia', 'Kuna', 'HRK', 'kn'),
(29, 'Cuba', 'Pesos', 'CUP', '₱'),
(30, 'Cyprus', 'Euro', 'EUR', '€'),
(31, 'Czech Republic', 'Koruny', 'CZK', 'Kč'),
(32, 'Denmark', 'Kroner', 'DKK', 'kr'),
(33, 'Dominican Republic', 'Pesos', 'DOP ', 'RD$'),
(34, 'East Caribbean', 'Dollars', 'XCD', '$'),
(35, 'Egypt', 'Pounds', 'EGP', '£'),
(36, 'El Salvador', 'Colones', 'SVC', '$'),
(37, 'England (United Kingdom)', 'Pounds', 'GBP', '£'),
(38, 'Euro', 'Euro', 'EUR', '€'),
(39, 'Falkland Islands', 'Pounds', 'FKP', '£'),
(40, 'Fiji', 'Dollars', 'FJD', '$'),
(41, 'France', 'Euro', 'EUR', '€'),
(42, 'Ghana', 'Cedis', 'GHC', '¢'),
(43, 'Gibraltar', 'Pounds', 'GIP', '£'),
(44, 'Greece', 'Euro', 'EUR', '€'),
(45, 'Guatemala', 'Quetzales', 'GTQ', 'Q'),
(46, 'Guernsey', 'Pounds', 'GGP', '£'),
(47, 'Guyana', 'Dollars', 'GYD', '$'),
(48, 'Holland (Netherlands)', 'Euro', 'EUR', '€'),
(49, 'Honduras', 'Lempiras', 'HNL', 'L'),
(50, 'Hong Kong', 'Dollars', 'HKD', '$'),
(51, 'Hungary', 'Forint', 'HUF', 'Ft'),
(52, 'Iceland', 'Kronur', 'ISK', 'kr'),
(53, 'India', 'Rupees', 'INR', 'Rp'),
(54, 'Indonesia', 'Rupiahs', 'IDR', 'Rp'),
(55, 'Iran', 'Rials', 'IRR', '﷼'),
(56, 'Ireland', 'Euro', 'EUR', '€'),
(57, 'Isle of Man', 'Pounds', 'IMP', '£'),
(58, 'Israel', 'New Shekels', 'ILS', '₪'),
(59, 'Italy', 'Euro', 'EUR', '€'),
(60, 'Jamaica', 'Dollars', 'JMD', 'J$'),
(61, 'Japan', 'Yen', 'JPY', '¥'),
(62, 'Jersey', 'Pounds', 'JEP', '£'),
(63, 'Kazakhstan', 'Tenge', 'KZT', 'лв'),
(64, 'Korea (North)', 'Won', 'KPW', '₩'),
(65, 'Korea (South)', 'Won', 'KRW', '₩'),
(66, 'Kyrgyzstan', 'Soms', 'KGS', 'лв'),
(67, 'Laos', 'Kips', 'LAK', '₭'),
(68, 'Latvia', 'Lati', 'LVL', 'Ls'),
(69, 'Lebanon', 'Pounds', 'LBP', '£'),
(70, 'Liberia', 'Dollars', 'LRD', '$'),
(71, 'Liechtenstein', 'Switzerland Francs', 'CHF', 'CHF'),
(72, 'Lithuania', 'Litai', 'LTL', 'Lt'),
(73, 'Luxembourg', 'Euro', 'EUR', '€'),
(74, 'Macedonia', 'Denars', 'MKD', 'ден'),
(75, 'Malaysia', 'Ringgits', 'MYR', 'RM'),
(76, 'Malta', 'Euro', 'EUR', '€'),
(77, 'Mauritius', 'Rupees', 'MUR', '₨'),
(78, 'Mexico', 'Pesos', 'MXN', '$'),
(79, 'Mongolia', 'Tugriks', 'MNT', '₮'),
(80, 'Mozambique', 'Meticais', 'MZN', 'MT'),
(81, 'Namibia', 'Dollars', 'NAD', '$'),
(82, 'Nepal', 'Rupees', 'NPR', '₨'),
(83, 'Netherlands Antilles', 'Guilders', 'ANG', 'ƒ'),
(84, 'Netherlands', 'Euro', 'EUR', '€'),
(85, 'New Zealand', 'Dollars', 'NZD', '$'),
(86, 'Nicaragua', 'Cordobas', 'NIO', 'C$'),
(87, 'Nigeria', 'Nairas', 'NGN', '₦'),
(88, 'North Korea', 'Won', 'KPW', '₩'),
(89, 'Norway', 'Krone', 'NOK', 'kr'),
(90, 'Oman', 'Rials', 'OMR', '﷼'),
(91, 'Pakistan', 'Rupees', 'PKR', '₨'),
(92, 'Panama', 'Balboa', 'PAB', 'B/.'),
(93, 'Paraguay', 'Guarani', 'PYG', 'Gs'),
(94, 'Peru', 'Nuevos Soles', 'PEN', 'S/.'),
(95, 'Philippines', 'Pesos', 'PHP', 'Php'),
(96, 'Poland', 'Zlotych', 'PLN', 'zł'),
(97, 'Qatar', 'Rials', 'QAR', '﷼'),
(98, 'Romania', 'New Lei', 'RON', 'lei'),
(99, 'Russia', 'Rubles', 'RUB', 'руб'),
(100, 'Saint Helena', 'Pounds', 'SHP', '£'),
(101, 'Saudi Arabia', 'Riyals', 'SAR', '﷼'),
(102, 'Serbia', 'Dinars', 'RSD', 'Дин.'),
(103, 'Seychelles', 'Rupees', 'SCR', '₨'),
(104, 'Singapore', 'Dollars', 'SGD', '$'),
(105, 'Slovenia', 'Euro', 'EUR', '€'),
(106, 'Solomon Islands', 'Dollars', 'SBD', '$'),
(107, 'Somalia', 'Shillings', 'SOS', 'S'),
(108, 'South Africa', 'Rand', 'ZAR', 'R'),
(109, 'South Korea', 'Won', 'KRW', '₩'),
(110, 'Spain', 'Euro', 'EUR', '€'),
(111, 'Sri Lanka', 'Rupees', 'LKR', '₨'),
(112, 'Sweden', 'Kronor', 'SEK', 'kr'),
(113, 'Switzerland', 'Francs', 'CHF', 'CHF'),
(114, 'Suriname', 'Dollars', 'SRD', '$'),
(115, 'Syria', 'Pounds', 'SYP', '£'),
(116, 'Taiwan', 'New Dollars', 'TWD', 'NT$'),
(117, 'Thailand', 'Baht', 'THB', '฿'),
(118, 'Trinidad and Tobago', 'Dollars', 'TTD', 'TT$'),
(119, 'Turkey', 'Lira', 'TRY', 'TL'),
(120, 'Turkey', 'Lira', 'TRY', '₺'),
(121, 'Tuvalu', 'Dollars', 'TVD', '$'),
(122, 'Ukraine', 'Hryvnia', 'UAH', '₴'),
(123, 'United Kingdom', 'Pounds', 'GBP', '£'),
(124, 'United States of America', 'Dollars', 'USD', '$'),
(125, 'Uruguay', 'Pesos', 'UYU', '$U'),
(126, 'Uzbekistan', 'Sums', 'UZS', 'лв'),
(127, 'Vatican City', 'Euro', 'EUR', '€'),
(128, 'Venezuela', 'Bolivares Fuertes', 'VEF', 'Bs'),
(129, 'Vietnam', 'Dong', 'VND', '₫'),
(130, 'Yemen', 'Rials', 'YER', '﷼'),
(131, 'Zimbabwe', 'Zimbabwe Dollars', 'ZWD', 'Z$');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dersler`
--

CREATE TABLE `dersler` (
  `id` int(11) NOT NULL,
  `adi` text COLLATE utf8_turkish_ci NOT NULL,
  `kisa_kod` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `sinif` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `dersler`
--

INSERT INTO `dersler` (`id`, `adi`, `kisa_kod`, `sinif`) VALUES
(1, 'Bilişim Teknolojileri', 'BIT', 5),
(2, 'Fen Bilimleri', 'FEN', 7),
(3, 'Matematik (İlköğretim)', 'MAT', 5),
(4, 'Türkçe', 'TUR', 5),
(5, 'Sosyal Bilgiler', 'SOS', 5),
(6, 'Lise Matematik', 'LISMAT', 9),
(7, 'Kimya', 'KIM', 9),
(8, 'Biyoloji', 'BIY', 9),
(9, 'Din Kültürü ve Ahlak Bilgisi', 'DKB', 5),
(10, 'İngilizce', 'ING', 5),
(11, 'Tarih', 'TAR', 9),
(12, 'Coğrafya', 'COG', 9),
(13, 'Fizik', 'FIZ', 9),
(14, 'Türk Dili ve Edebiyatı', 'TDE', 9),
(15, 'Bilgisayar Bilimi', 'BIL', 9);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `duyurular`
--

CREATE TABLE `duyurular` (
  `id` int(11) NOT NULL,
  `baslik` varchar(255) NOT NULL,
  `icerik` text NOT NULL,
  `ozet` varchar(255) NOT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `kayit_tarihi` timestamp NOT NULL DEFAULT current_timestamp(),
  `guncelleme_tarihi` timestamp NULL DEFAULT NULL,
  `anahtar_kelimeler` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `duyurular`
--

INSERT INTO `duyurular` (`id`, `baslik`, `icerik`, `ozet`, `aktif`, `kayit_tarihi`, `guncelleme_tarihi`, `anahtar_kelimeler`) VALUES
(1, 'Sistem çalışması', '<p>Sistem çalışması yapılacaktır muhteremler saygılarımızla .</p>\r\n', 'Sistem çalışması yapılacaktır muhteremler saygılarımızla .', 1, '2021-06-30 18:04:16', '2021-06-30 18:08:52', 'Sistem çalışması');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iletisim`
--

CREATE TABLE `iletisim` (
  `id` int(11) NOT NULL,
  `konu` varchar(255) NOT NULL,
  `baslik` varchar(255) DEFAULT NULL,
  `mesaj` text NOT NULL,
  `kayit_tarihi` timestamp NOT NULL DEFAULT current_timestamp(),
  `cevap_tarihi` date NOT NULL,
  `cevaplanma_durumu` tinyint(1) NOT NULL DEFAULT 0,
  `cevap_mesaji` text NOT NULL,
  `okundu_bilgisi` tinyint(1) NOT NULL DEFAULT 0,
  `userID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `iletisim`
--

INSERT INTO `iletisim` (`id`, `konu`, `baslik`, `mesaj`, `kayit_tarihi`, `cevap_tarihi`, `cevaplanma_durumu`, `cevap_mesaji`, `okundu_bilgisi`, `userID`) VALUES
(1, '4', 'Teşekkür', 'Teşekkür', '2019-05-02 07:43:46', '0000-00-00', 0, '', 0, 1),
(3, '1', 'Öneri', 'Öneri', '2019-05-13 10:53:37', '0000-00-00', 0, '', 0, 1),
(4, '2', 'Lorem ipsum', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sed ultricies tortor. Vivamus ut ullamcorper dui, tristique sodales tellus. Proin vel porta ex. Phasellus sodales condimentum massa nec hendrerit. Vivamus ante nulla, sollicitudin a porttitor sit amet, suscipit vel nisl. Maecenas ac pharetra tellus, ornare tincidunt lorem. Maecenas feugiat ante sed neque pretium tempor. Donec pharetra lacus ut sapien gravida tempus.', '2019-05-13 10:53:40', '2021-06-09', 1, '<p>Merhaba hocam şikayetiniz dikkate alınacaktır. İyi günler dileriz.</p>\r\n', 1, 2),
(5, '3', 'Bilgi Edinme', 'Bilgi Edinme', '2019-05-13 10:53:42', '0000-00-00', 0, '', 0, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kazanimlar`
--

CREATE TABLE `kazanimlar` (
  `id` int(11) NOT NULL,
  `kazanim_kodu` text COLLATE utf8_turkish_ci NOT NULL,
  `kazanim_icerik` text COLLATE utf8_turkish_ci NOT NULL,
  `sinif` int(11) NOT NULL,
  `unite_kodu` varchar(15) COLLATE utf8_turkish_ci NOT NULL,
  `konu_kodu` varchar(10) COLLATE utf8_turkish_ci NOT NULL,
  `dersID` int(11) NOT NULL,
  `uniteID` int(11) NOT NULL,
  `konuID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kazanimlar`
--

INSERT INTO `kazanimlar` (`id`, `kazanim_kodu`, `kazanim_icerik`, `sinif`, `unite_kodu`, `konu_kodu`, `dersID`, `uniteID`, `konuID`) VALUES
(1, '01.01.01', 'Uzay teknolojilerini açıklar.', 7, '01', '01.01', 2, 1, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `konular`
--

CREATE TABLE `konular` (
  `id` int(11) NOT NULL,
  `dersID` int(11) NOT NULL,
  `sinif` int(11) NOT NULL,
  `uniteID` int(11) NOT NULL,
  `konu_kodu` text NOT NULL,
  `konu_icerik` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `konular`
--

INSERT INTO `konular` (`id`, `dersID`, `sinif`, `uniteID`, `konu_kodu`, `konu_icerik`) VALUES
(1, 2, 7, 2, '01.01', 'Uzay Araştırmaları'),
(2, 2, 7, 1, '01.02', 'Güneş Sistemi Ötesi: Gök Cisimleri');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `okullar`
--

CREATE TABLE `okullar` (
  `ID` int(11) NOT NULL,
  `IL_ID` int(11) DEFAULT NULL,
  `ILCE_ID` int(11) DEFAULT NULL,
  `GENEL_MUDURLUK` varchar(255) DEFAULT NULL,
  `KURUM_TURU` varchar(255) DEFAULT NULL,
  `KURUM_KODU` varchar(255) DEFAULT NULL,
  `KURUM_ADI` varchar(255) DEFAULT NULL,
  `OGRETIM_SEKLI_ID` enum('Normal Öğretim','İkili Öğretim') DEFAULT NULL,
  `TELEFON` varchar(255) DEFAULT NULL,
  `MUDUR` varchar(255) DEFAULT NULL,
  `MUDUR_CEP` varchar(255) DEFAULT NULL,
  `MUDUR_YRD` varchar(255) DEFAULT NULL,
  `MUDUR_YRD_CEP` varchar(255) DEFAULT NULL,
  `ADRES` varchar(255) DEFAULT NULL,
  `WEB` varchar(255) DEFAULT NULL,
  `EPOSTA2` varchar(255) DEFAULT NULL,
  `EPOSTA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `okullar`
--

INSERT INTO `okullar` (`ID`, `IL_ID`, `ILCE_ID`, `GENEL_MUDURLUK`, `KURUM_TURU`, `KURUM_KODU`, `KURUM_ADI`, `OGRETIM_SEKLI_ID`, `TELEFON`, `MUDUR`, `MUDUR_CEP`, `MUDUR_YRD`, `MUDUR_YRD_CEP`, `ADRES`, `WEB`, `EPOSTA2`, `EPOSTA`) VALUES
(1, 27, 309, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Lisesi', '372946', 'Akçakoca Emine Sevil Anadolu İmam Hatip Lisesi', 'Normal Öğretim', '3806188933', 'Recep Köprücü', '5057734859', 'Mesut Akpınar', '5453643730', 'AYAZLI MAH. EREĞLİ CADDE NO:103 PK:81650 AKÇAKOCA/DÜZCE', 'akcakocaeminesevilaihl.meb.k12.tr', NULL, '372946@meb.k12.tr'),
(2, 27, 309, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '764026', 'Akçakoca İmam Hatip Ortaokulu', 'Normal Öğretim', '3806112125', 'Talip KOCAOĞLU', '5426178596', 'Levent ÖZTÜRK', '5071013930', 'OSMANİYE MAH. KESKİN SK. ANADOLU İMAM HATİP LİSESİ SİTESİ NO: 31 İÇ KAPI NO: 1 AKÇAKOCA / DÜZCE', 'akcakocaiho.meb.k12.tr', NULL, '764026@meb.k12.tr'),
(3, 27, 309, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '132573', 'Akçakoca Fedai Karabıyık Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3806187061', 'Vahdettin ÇALIŞKAN', '5423035663', 'Murat YILDIRIM', '5425777551', 'AYAZLI MAH. DÖNGELLİ CADDE NO:02 PK:81650 AKÇAKOCA/DÜZCE', 'akcakocafkmtal.meb.k12.tr', NULL, '132573@meb.k12.tr'),
(4, 27, 309, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '132585', 'Akçakoca Nene Hatun Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3806114131', 'Yeliz Yalılı', '5056373648', 'Mesut Atar', '5064927538', 'Adres Osmaniye Mahallesi Ozan Sokak No4 AKÇAKOCA/DÜZCE', NULL, NULL, '132585@meb.k12.tr'),
(5, 27, 309, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '132597', 'Akçakoca Piri Reis Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3806114563', 'Özcan KASIM', '5354764745', 'Abdulkadir YAVRU', '5359209877', 'YALI MAH. İSTANBUL CADDE NO:46 PK:81650 AKÇAKOCA/DÜZCE', 'akcakocapirireismtal.meb.k12.tr', NULL, '132597@meb.k12.tr'),
(6, 27, 309, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '879033', 'Akçakoca Süha Güven Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3806119380', 'Sinan BOZKURT', '5307615499', 'Enver TOPÇUOĞLU', '5347958278', 'AYAZLI MAH. DÖNGELLİ CADDE NO:4 PK:81650 AKÇAKOCA/DÜZCE', 'akcakocaaotml.meb.k12.tr', NULL, '879033@meb.k12.tr'),
(7, 27, 309, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '320524', 'Akcakoca Anadolu Lisesi', 'Normal Öğretim', '3806188674', 'Nurettin ÇABUK', '5056104595', 'Mehmet İSMETOĞLU', '5399163632', 'AYAZLI MAH. SALYANCI CADDE NO:71 PK:81650 AKÇAKOCA/DÜZCE', 'akal81.meb.k12.tr', NULL, '320524@meb.k12.tr'),
(8, 27, 309, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '973830', 'Barbaros Anadolu Lisesi', 'Normal Öğretim', '3806114564', 'ALİ YAVUZ', '5057150098', 'RECEP SAY', '5052710216', 'OSMANİYE MAH. TEVFİK İLERİ CADDE NO:24 PK:81650 AKÇAKOCA/DÜZCE', 'barbarosal.meb.k12.tr', NULL, '973830@meb.k12.tr'),
(9, 27, 309, 'Ortaöğretim Genel Müdürlüğü', 'Sosyal Bilimler Lisesi', '758226', 'Akçakoca Sosyal Bilimler Lisesi', 'Normal Öğretim', '3806117823', 'YUNUS KARA', '5057054612', 'ALİ SEMİH DEMİRCİ', '5325497409', 'ORHANGAZİ MAH. SANTRAL CADDE NO:66 PK:81650 AKÇAKOCA/DÜZCE', 'akcakocasbl.meb.k12.tr', NULL, '758226@meb.k12.tr'),
(10, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732060', 'Tepeköy İlkokulu', 'Normal Öğretim', '3806255454', 'Selma Sarıoğlu', '5336489152', 'Kadir Arslan', '5306932166', 'TEPEKÖY KÖYÜ NO: 215 İÇ KAPI NO: 12 AKÇAKOCA / DÜZCE', 'tepekoyio81.meb.k12.tr', NULL, '732060@meb.k12.tr'),
(11, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732066', 'Beyören İlkokulu', 'Normal Öğretim', '3806242022', 'SÜLEYMAN YAPCACIK', '5057190931', 'EMRAH ESEN', '5056847852', 'BEYÖREN KÖYÜ NO: 83 AKÇAKOCA / DÜZCE', 'beyorenioo.meb.k12.tr', NULL, '732066@meb.k12.tr'),
(12, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732068', 'Bahaettin Güçlü İlkokulu', 'Normal Öğretim', '3806115324', 'Rıdvan Şahin', '5054037939', 'Metin Karataş', '5069224592', 'HACI YUSUFLAR MAH. SEDEF SK. NO: 1 AKÇAKOCA / DÜZCE', 'akcakocabahaettingucluio.meb.k12.tr', NULL, '732068@meb.k12.tr'),
(13, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733609', 'Uğurlu İlkokulu', 'Normal Öğretim', '3806292025', 'Salih EKİCİ', '5356791482', 'Recep UĞURLU', '5056373743', 'UĞURLU KÖYÜ NO: 157 AKÇAKOCA / DÜZCE', 'akcakocaugurluilkokulu.meb.k12.tr', NULL, '733609@meb.k12.tr'),
(14, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733613', 'Hamiyet Sevil İlkokulu', 'Normal Öğretim', '3806187066', 'Murat GÜNDOĞDU', '5323927571', 'Zeki GÜNAYDIN', '5326770709', 'AYAZLI MAH. MELİH SK. NO: 1 İÇ KAPI NO: 1 AKÇAKOCA / DÜZCE', 'hamiyetsevilio.meb.k12.tr', NULL, '733613@meb.k12.tr'),
(15, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '734934', 'Osmaniye İlkokulu', 'Normal Öğretim', '3806112556', 'Hasan YILDIRIM', '5355749680', 'Halil SEVİNÇ', '5353502729', 'OSMANİYE MAH. MURATLAR SK. NO: 8 İÇ KAPI NO: 1 AKÇAKOCA / DÜZCE', 'akcakocaosmaniye.meb.k12.tr', NULL, '734934@meb.k12.tr'),
(16, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '734950', 'Cumhuriyet İlkokulu', 'Normal Öğretim', '3806113717', 'Kadir Sönmezoğlu', '5366723337', 'Yusuf Aydın', '5335672517', 'ORHANGAZİ MAH. ZÜMRÜT SK. NO: 1 İÇ KAPI NO: 1 AKÇAKOCA / DÜZCE', 'akcakocacumhuriyet81.meb.k12.tr', NULL, '724950@meb.k12.tr'),
(17, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '734959', 'Gönül Yavuz İlkokulu', 'Normal Öğretim', '3806115576', 'Adnan Kaya', '5354558467', 'Halis Hüsnü Ergül', '5335443445', 'ORHANGAZİ MAH. ALİ SERVET SK. GÖNÜL YAVUZ İLKÖĞRETİM OKULU SİTESİ NO: 10 AKÇAKOCA / DÜZCE', 'gonulyavuzio.meb.k12.tr', NULL, '734959@meb.k12.tr'),
(18, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732059', 'Tepeköy Ortaokulu', 'Normal Öğretim', '3806255454', 'SELMA SARIOĞLU', '5336489152', 'KADİR ARSLAN', '5306932166', 'TEPEKÖY KÖYÜ NO: 215 İÇ KAPI NO: 12 AKÇAKOCA / DÜZCE', 'tepekoyoo81.meb.k12.tr', NULL, '732059@meb.k12.tr'),
(19, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732061', 'Beyören Ortaokulu', 'Normal Öğretim', '3806242022', 'SÜLEYMAN YAPCACIK', '5057190931', 'EMRAH ESEN', '5056847852', 'BEYÖREN KÖYÜ NO: 83 AKÇAKOCA / DÜZCE', 'beyoreno.meb.k12.tr', NULL, '732061@meb.k12.tr'),
(20, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732067', 'Bahaettin Güçlü Ortaokulu', 'Normal Öğretim', '3806115330', 'RIDVAN ŞAHİN', '5054037939', 'ERDAL ODABAŞ', '5056781925', 'HACI YUSUFLAR MAH. SEDEF SK. NO: 1 AKÇAKOCA / DÜZCE', 'akcakocabahaettingucluoo.meb.k12.tr', NULL, '732067@meb.k12.tr'),
(21, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733606', 'Uğurlu Ortaokulu', 'Normal Öğretim', '3806292025', 'Salih EKİCİ', '5356791482', 'Hayrettin ATBAN', '5305103621', 'UĞURLU KÖYÜ NO: 157 AKÇAKOCA / DÜZCE', 'akcakocaugurluortaokulu.meb.k12.tr', NULL, '733606@meb.k12.tr'),
(22, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733610', 'Hamiyet Sevil Ortaokulu', 'Normal Öğretim', '3806187066', 'Murat GÜNDOĞDU', '5323927571', 'Erdal POST', '5079467865', 'AYAZLI MAH. MELİH SK. NO: 1 İÇ KAPI NO: 1 AKÇAKOCA / DÜZCE', 'hamiyetsevil.meb.k12.tr', NULL, '733610@meb.k12.tr'),
(23, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '734923', 'Mustafa Açıkalın Ortaokulu', 'Normal Öğretim', '3806113473', 'Yusuf ALBAYRAK', '5056917939', 'Yakup AKAR', '5535362507', 'OSMANİYE MAH. ASMA SK. MUSTAFA AÇIKALIN İ.Ö.O SİTESİ NO: 1 İÇ KAPI NO: 1 AKÇAKOCA / DÜZCE', 'mustafaacikalin.meb.k12.tr', NULL, '734923@meb.k12.tr'),
(24, 27, 309, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '734942', 'Atatürk Ortaokulu', 'Normal Öğretim', '3806114019', 'Aykan GÜLBAHAR', '5052690811', 'Ahmet Fehmi ÖZVEREN', '5464132758', 'YALI MAH. LİSE SK. NO: 10 İÇ KAPI NO: 1 AKÇAKOCA / DÜZCE', 'akcakocaataturk.meb.k12.tr', NULL, '734942@meb.k12.tr'),
(25, 27, 310, 'Din Öğretimi Genel Müdürlüğü', 'Anadolu İmam Hatip Lisesi', '759035', 'Cumayeri Anadolu İmam Hatip Lisesi', 'Normal Öğretim', '3807353947', 'Abdülhakim Akdoğan', '5394113393', 'Hüseyin Bilgehan Kandemir', '5466110711', 'ÇEVRİK MAH. ŞEHİT MESUT KIROĞLU CAD. KANUNİ İLKÖĞRETİM OKULU SİTESİ NO: 26 CUMAYERİ / DÜZCE', 'cumayeriaihl.meb.k12.tr', NULL, '759035@meb.k12.tr'),
(26, 27, 310, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Çok Programlı Anadolu Lisesi', '323122', 'Cumayeri Çok Programlı Anadolu Lisesi', 'Normal Öğretim', '3807355147', 'Haşim Yılmaz', '5053693894', 'Emre Başkaya', '5557612197', 'MEHMET AKİF MAH. 308. SK. NO: 1 CUMAYERİ / DÜZCE', 'cumayericpal.meb.k12.tr', NULL, '323122@meb.k12.tr'),
(27, 27, 310, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732048', 'İlhami Reyhan Turan İlkokulu', 'Normal Öğretim', '3807354466', 'Bircan ABALI', '5342989501', 'Ayhan İLHAN', '05356891230', 'YUKARIAVLAYAN KÖYÜ NO: 40 CUMAYERİ / DÜZCE', 'irt.meb.k12.tr', NULL, '732048@meb.k12.tr'),
(28, 27, 310, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733506', 'Mehmet Metin İlkokulu', 'Normal Öğretim', '3807354850', 'Mehmet KELEŞ', '5378934478', 'Zehra Koçak', '5542284777', 'YAKA MAH. YEŞİL SK. NO: 21 İÇ KAPI NO: A CUMAYERİ / DÜZCE', 'mehmetmetinio.meb.k12.tr', NULL, '733506@meb.k12.tr'),
(29, 27, 310, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733601', 'Ören Şehit Nusret Akar İlkokulu', 'Normal Öğretim', '3807354970', 'MUSTAFA KELEŞ', '5458419388', 'MEHMET ÖZDEMİR', '5378839632', 'ÖREN KÖYÜ NO: 41 İÇ KAPI NO: 7 CUMAYERİ / DÜZCE', 'sehitnusretakarilkokulu.meb.k12.tr', NULL, '733601@meb.k12.tr'),
(30, 27, 310, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733604', 'Dokuzdeğirmen İlkokulu', 'Normal Öğretim', '3807426310', 'Genç BIÇAK', '5056266510', 'Ömer Ertunç DİNÇER', '5330400902', 'DOKUZDEĞİRMEN Beldesi/ Köyü;MERKEZ Cadde/Sokak:Yok Dış Kapı No:6 CUMAYERİ/DÜZCE', 'dokuzdegirmenio.meb.k12.tr', NULL, '733604@meb.k12.tr'),
(31, 27, 310, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '735053', 'Pakmaya Nimet Pısak İlkokulu', 'Normal Öğretim', '3807354025', 'Abdullah KAYAALTI', '5056378680', 'Eyüp KİNET', '5057014219', 'ÇEVRİK MAH. YILDIRIM SK. NİMET PISAK İLKÖĞRETİM OKULU SİTESİ NO: 3 CUMAYERİ / DÜZCE', 'pakmayanimetpisakilkokulu.meb.k12.tr', NULL, '735053@meb.k12.tr'),
(32, 27, 310, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732047', 'İlhami Reyhan Turan Ortaokulu', 'Normal Öğretim', '3807354466', 'Bircan ABALI', '5342989501', 'Ayhan İLHAN', '05356891230', 'YUKARIAVLAYAN KÖYÜ NO: 40 CUMAYERİ / DÜZCE', 'irto.meb.k12.tr', NULL, '732047@meb.k12.tr'),
(33, 27, 310, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733600', 'Ören Şehit Nusret Akar Ortaokulu', 'Normal Öğretim', '3807354970', 'MUSTAFA KELEŞ', '5458419388', 'MEHMET ÖZDEMİR', '5378839632', 'ÖREN KÖYÜ NO: 41 İÇ KAPI NO: 7 CUMAYERİ / DÜZCE', 'sehitnusretakarortaokulu.meb.k12.tr', NULL, '733600@meb.k12.tr'),
(34, 27, 310, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733602', 'Dokuzdeğirmen Ortaokulu', 'Normal Öğretim', '3807426310', 'Genç BIÇAK', '5056266510', 'Ömer Ertunç DİNÇER', '5330400902', 'DOKUZDEĞİRMEN Beldesi/ Köyü;MERKEZ Cadde/Sokak:Yok Dış Kapı No:6 CUMAYERİ/DÜZCE', 'dokuzdegirmenoo.meb.k12.tr', NULL, '733602@meb.k12.tr'),
(35, 27, 310, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '760476', 'Cumayeri Ortaokulu', 'Normal Öğretim', '3807354222', 'Onur KUNDUZ', '5054033025', 'Ümit KOCABAŞ', '5336254291', 'ORTA MAH. MUALLİM SK. NO: 10/1 CUMAYERİ / DÜZCE', 'cumayeriortaokulu.meb.k12.tr', NULL, '760476@meb.k12.tr'),
(36, 27, 311, 'Din Öğretimi Genel Müdürlüğü', 'Anadolu İmam Hatip Lisesi', '761074', 'Çilimli Anadolu İmam Hatip Lisesi', 'Normal Öğretim', '3806815155', 'Murat Bergut', '5305931864', 'Okan Demir', '5457416684', 'ULUCAMİ MAH. ŞEHİT İSA CEYLAN CADDE NO:60 PK:81750 ÇİLİMLİ/DÜZCE', 'cilimliaihl.meb.k12.tr', NULL, '761074@meb.k12.tr'),
(37, 27, 311, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '746736', 'Çilimli İmam Hatip Ortaokulu', 'Normal Öğretim', '3806816163', 'Murat Bergut', '5305931864', 'Hamza Cihat Tekin', '5422292165', 'ULUCAMİ MAH. ŞHT. İSA CEYLAN CAD. NO: 60 İÇ KAPI NO: 1 ÇİLİMLİ / DÜZCE', 'cilimliimamhatiportaokulu.meb.k12.tr', NULL, '746736@meb.k12.tr'),
(38, 27, 311, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Çok Programlı Anadolu Lisesi', '321721', 'Çilimli Anadolu Kalkınma Vakfı Çok Programlı Anadolu Lisesi', 'Normal Öğretim', '3806815010', 'Ayhan GÜL', '5062738146', 'Serhat TAZEGÜL', '5074876516', 'ULUCAMİ MAH. ŞEHİT FİKRİ ÖZTÜRK CADDE NO:17 PK:81750 ÇİLİMLİ/DÜZCE', 'cilimliakvcpl.meb.k12.tr', NULL, '321721@meb.k12.tr'),
(39, 27, 311, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '751816', 'Çilimli Anadolu Lisesi', 'Normal Öğretim', '3806816129', 'Mevlüt Uçarcı', '5423202827', 'Cevat Gökçe', '5056592468', 'TOPÇULAR MAH. OKUL CADDE NO:1 PK:81750 ÇİLİMLİ/DÜZCE', 'cilimlial.meb.k12.tr', NULL, '751816@meb.k12.tr'),
(40, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732041', 'Dikmeli İlkokulu', 'Normal Öğretim', '3806937065', 'Tuncay MADAK', '5333755257', 'Savaş Mehmet ERCİYAS', '5370550806', 'DİKMELİ KÖYÜ MERKEZ MEVKİİ İsimsiz Köy Sokağı Dış Kapı No:94 ÇİLİMLİ/DÜZCE', 'dikmeliilkokulu.meb.k12.tr', NULL, '732041@meb.k12.tr'),
(41, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732046', 'Pırpır İlkokulu', 'Normal Öğretim', '3806913395', 'İdris AKDUMAN', '5057904938', 'Resul ŞAHİN', '5543758317', 'PIRPIR KÖYÜ ORTA MEVKİİ NO: 177 ÇİLİMLİ / DÜZCE', 'pirpirilkokulu.meb.k12.tr', NULL, '732046@meb.k12.tr'),
(42, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733496', 'Esenli İlkokulu', 'Normal Öğretim', '3806937481', 'Mesut KÖMÜRCÜ', '5312135894', 'Mesut PETEN', '5058105852', 'ESENLİ KÖYÜ SİTESİ NO: 167 ÇİLİMLİ / DÜZCE', 'duzceesenliilkokulu.meb.k12.tr', NULL, '733496@meb.k12.tr'),
(43, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733499', 'Topçular İlkokulu', 'Normal Öğretim', '3806817240', 'İsmail UYSAL', '5057680640', 'İbrahim Sercan TOK', '5019112189', 'TOPÇULAR MAH. ÇİLİMLİ/GÜNEY CAD. İL ÖEZL İDARESİ SİTESİ 12 DERSLİK İLÖĞRETİM OKULU BLOK NO: 17A ÇİLİMLİ / DÜZCE', 'topcularilkokulu.meb.k12.tr', NULL, '733499@meb.k12.tr'),
(44, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733503', 'İbrahim Hoşver İlkokulu', 'Normal Öğretim', '3806815511', 'Hüseyin ÇELEBİ', '5332334531', 'Hasan VURAL', '5335514458', 'ULUCAMİ MAH. OKUL SK. NO: 16 İÇ KAPI NO: A ÇİLİMLİ / DÜZCE', 'ihosverilkokulu.meb.k12.tr', NULL, '733503@meb.k12.tr'),
(45, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733595', 'Yenivakıf İlkokulu', 'Normal Öğretim', '3806817079', 'Hikmet Sezgin', '5077888149', 'Tuba İnce ', '5530835175', 'YENİVAKIF KÖYÜ MERKEZ MEVKİİ NO: 185 ÇİLİMLİ / DÜZCE', 'yenivakifilkokulu.meb.k12.tr', NULL, '733595@meb.k12.tr'),
(46, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733598', 'Şerefiye İlkokulu', 'Normal Öğretim', '3806815040', 'İhsan Durna', '5345244410', 'Kubilay Kiriş', '5423383343', 'ŞEREFİYE MAH. OKUL2 SK. NO: 10 ÇİLİMLİ / DÜZCE', 'serefiyeilkokulu.meb.k12.tr', NULL, '733598@meb.k12.tr'),
(47, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732040', 'Dikmeli Ortaokulu', 'Normal Öğretim', '3806937065', 'Tuncay MADAK', '5333755257', 'Savaş Mehmet ERCİYAS', '5370550806', 'DİKMELİ KÖYÜ MERKEZ MEVKİİ NO: 94 İÇ KAPI NO: 1 ÇİLİMLİ / DÜZCE', 'dikmeliortaokulu.meb.k12.tr', NULL, '732040@meb.k12.tr'),
(48, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732043', 'Pırpır Ortaokulu', 'Normal Öğretim', '3806913395', 'İdris AKDUMAN', '5057904938', 'Resul ŞAHİN', '5543758317', 'PIRPIR KÖYÜ ORTA MEVKİİ NO: 177 ÇİLİMLİ / DÜZCE', 'pirpirortaokulu.meb.k12.tr', NULL, '732043@meb.k12.tr'),
(49, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733495', 'Esenli Ortaokulu', 'Normal Öğretim', '3806937481', 'Mesut KÖMÜRCÜ', '5312135894', 'Mesut PETEN', '5058105852', 'ESENLİ KÖYÜ NO: 167 ÇİLİMLİ / DÜZCE', 'esenliortaokulu.meb.k12.tr', NULL, '733495@meb.k12.tr'),
(50, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733498', 'Topçular Ortaokulu', 'Normal Öğretim', '3806817240', 'İsmail UYSAL', '5057680640', 'İbrahim Sercan TOK', '5019112189', 'TOPÇULAR MAH. ÇİLİMLİ/GÜNEY CAD. İL ÖEZL İDARESİ SİTESİ 12 DERSLİK İLÖĞRETİM OKULU BLOK NO: 17A ÇİLİMLİ / DÜZCE', 'topcularortaokulu.meb.k12.tr', NULL, '733498@meb.k12.tr'),
(51, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733502', 'İbrahim Hoşver Ortaokulu', 'Normal Öğretim', '3806815511', 'Hüseyin ÇELEBİ', '5332334531', 'Hasan VURAL', '5335514458', 'ULUCAMİ MAH. OKUL SK. NO: 16 İÇ KAPI NO: A ÇİLİMLİ / DÜZCE', 'ihosverortaokulu.meb.k12.tr', NULL, '733502@meb.k12.tr'),
(52, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733594', 'Yenivakıf Ortaokulu', 'Normal Öğretim', '3806817079', 'Hikmet Sezgin', '5077888149', 'Tuba İnce ', '5530835175', 'YENİVAKIF KÖYÜ MERKEZ MEVKİİ NO: 185 ÇİLİMLİ / DÜZCE', 'yenivakifortaokulu.meb.k12.tr', NULL, '733594@meb.k12.tr'),
(53, 27, 311, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733596', 'Şerefiye Ortaokulu', 'Normal Öğretim', '3806815725', 'Hasan Karadayı', '5056815527', 'Aydın Daşbunar', '5343581171', 'ŞEREFİYE MAH. OKUL2 SK. YENİ BLOK NO: 10-1 ÇİLİMLİ / DÜZCE', 'serefiyeortaokulu.meb.k12.tr', NULL, '733596@meb.k12.tr'),
(54, 27, 312, 'Din Öğretimi Genel Müdürlüğü', 'Anadolu İmam Hatip Lisesi', '760225', 'Gölyaka Anadolu İmam Hatip Lisesi', 'Normal Öğretim', '3807112961', 'ENGİN POLAT', '5052606362', 'HÜSEYİN DENİZLİ', '5068867972', 'FATİH MAH. KANUNİ CADDE NO:90 PK:81800 GÖLYAKA/DÜZCE', 'golyakaanadoluihl.meb.k12.tr', NULL, '760225@meb.k12.tr'),
(55, 27, 312, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '746734', '15 Temmuz Şehitleri İmam Hatip Ortaokulu', 'Normal Öğretim', '3807112718', 'Hasan Yılmaz', '5446964884', 'Selman Coşkun', '5549217496', 'FATİH MAH. 712. SK. NO: 6 GÖLYAKA / DÜZCE', 'golyakaiho.meb.k12.tr', NULL, '746734@meb.k12.tr'),
(56, 27, 312, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '762903', 'Gölyaka Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3807114081', 'Celalettin Kelen', '5052772607', 'Pınar Öner', '5331409068', 'FATİH MAH. FEHMİ COŞKUN CAD. GÖLYAKA ÇOK PROGRAMLI LİSE SİTESİ NO: 94 GÖLYAKA / DÜZCE', 'golyakamtal.meb.k12.tr', NULL, '762903@meb.k12.tr'),
(57, 27, 312, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '964329', 'Gölyaka Anadolu Lisesi', 'Normal Öğretim', '3807114444', 'AHMET ÇELİK', '5352919147', 'FIRAT AKSAKAL', '5069573001', 'FATİH MAH. KANUNİ CADDE NO:90 PK:81800 GÖLYAKA/DÜZCE', 'golyakaanadolu.meb.k12.tr', NULL, '964329@meb.k12.tr'),
(58, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732034', 'Hacıyakup İlkokulu', 'Normal Öğretim', '3807133073', 'TEMEL AYDOĞAN', '5058298951', 'GÜZİN KANBUR', '5456955565', 'HACIYAKUP KÖYÜ NO: 93 GÖLYAKA / DÜZCE', 'haciyakupilkokulu.meb.k12.tr', NULL, '732034@meb.k12.tr'),
(59, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732037', 'Sarıdere Kemeryanı İlkokulu', 'Normal Öğretim', '3805335505', 'Muhammed Emin Demirer', '5546151454', 'Muhittin Sarıtaş', '5534765950', 'KEMERYANI KÖYÜ NO: 89 GÖLYAKA / DÜZCE', 'sariderekemeryaniio.meb.k12.tr', NULL, '732037@meb.k12.tr'),
(60, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733493', 'Saçmalıpınar İlkokulu', 'Normal Öğretim', '3807145190', 'Gülay Tekpınar', '5551842666', 'Gülay Tekpınar', '5551842666', 'SAÇMALIPINAR KÖYÜ ORTA MEVKİİ NO: 57 GÖLYAKA / DÜZCE', 'sacmalipinarilkokulu.meb.k12.tr', NULL, '733493@meb.k12.tr'),
(61, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733587', 'Hacı Süleymanbey Yeni Yaşam İlkokulu', 'Normal Öğretim', '3807151610', 'Abdurrahman PARLAK', '5055415241', 'Murat DENİZ', '5442413214', 'HACISÜLEYMANBEY KÖYÜ NO: 111 GÖLYAKA / DÜZCE', 'yeniyasamilkokulu.meb.k12.tr', NULL, '733587@meb.k12.tr'),
(62, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733590', 'Yunusefendi Şehit Tarık Demircan İlkokulu', 'Normal Öğretim', '3807161233', 'MUSTAFA ŞEN', '5358536381', 'YOK', '5548852666', 'YUNUSEFENDİ KÖYÜ MERKEZ MEVKİİ NO: 90 GÖLYAKA / DÜZCE', 'yunusefendiilkokulu.meb.k12.tr', NULL, '733590@meb.k12.tr'),
(63, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733592', 'Şehit Ercan Eker İlkokulu', 'Normal Öğretim', '3807112969', 'Yılmaz Maraba', '5423437138', 'Ali Bayrak', '5307775957', 'YAZIPINAR MAH. 401. SK. NO: 1 İÇ KAPI NO: 1 GÖLYAKA / DÜZCE', 'sehitercanekerilkokulu.meb.k12.tr', NULL, '733592@meb.k12.tr'),
(64, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '735168', 'Yunus Emre İlkokulu', 'Normal Öğretim', '3807114032', 'Hidayet TOPCU', '5053986712', 'Abdülgazi KAYMAZ', '5418267216', 'KÜLTÜR MAH. OKUL SK. NO: 19 GÖLYAKA / DÜZCE', 'golyakayunusemreilkokulu.meb.k12.tr', NULL, '735168@meb.k12.tr'),
(65, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '746224', 'İçmeler İlkokulu', 'Normal Öğretim', '3805335527', 'YASEMİN DERTLİ', '5056860518', 'YASEÖİN DERTLİ', '5056860518', 'İÇMELER KÖYÜ NO: 198 GÖLYAKA / DÜZCE', 'golyakaicmeler.meb.k12.tr', NULL, '746224@meb.k12.tr'),
(66, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732032', 'Hacıyakup Ortaokulu', 'Normal Öğretim', '3807133073', 'TEMEL AYDOĞAN', '5058298951', 'GÜZİN KANBUR', '5456955565', 'HACIYAKUP KÖYÜ NO: 92 GÖLYAKA / DÜZCE', 'haciyakuportaokulu.meb.k12.tr', NULL, '732032@meb.k12.tr'),
(67, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732036', 'Sarıdere Kemeryanı Ortaokulu', 'Normal Öğretim', '3805335505', 'Muhammed Emin Demirer', '5546151454', 'Muhittin Sarıtaş', '5534765950', 'KEMERYANI KÖYÜ NO: 89 GÖLYAKA / DÜZCE', 'sariderekemeryanioo.meb.k12.tr', NULL, '732036@meb.k12.tr'),
(68, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733586', 'Hacı Süleymanbey Yeni Yaşam Ortaokulu', 'Normal Öğretim', '3807151610', 'Abdurrahman PARLAK', '5055415241', 'Murat DENİZ', '5442413214', 'HACISÜLEYMANBEY KÖYÜ NO: 111 GÖLYAKA / DÜZCE', 'yeniyasamortaokulu.meb.k12.tr', NULL, '733586@meb.k12.tr'),
(69, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733588', 'Yunusefendi Şehit Tarık Demircan Ortaokulu', 'Normal Öğretim', '3807161233', 'MUSTAFA ŞEN', '5358536381', 'YOK', '5548852666', 'YUNUSEFENDİ KÖYÜ MERKEZ MEVKİİ NO: 90 GÖLYAKA / DÜZCE', 'yunusefendi.meb.k12.tr', NULL, '733588@meb.k12.tr'),
(70, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733591', 'Şehit Ercan Eker Ortaokulu', 'Normal Öğretim', '3807112815', 'Yılmaz Maraba', '5423437138', 'Ali Bayrak', '5307775957', 'YAZIPINAR MAH. ÇINARLI CAD. NO: 168 İÇ KAPI NO: 0 GÖLYAKA / DÜZCE', 'sehitercanekerortaokulu.meb.k12.tr', NULL, '733591@meb.k12.tr'),
(71, 27, 312, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '735156', 'Atatürk Ortaokulu', 'Normal Öğretim', '3807114103', 'SİNAN KAHRAMAN', '5052125417', 'ERAY KEÇELİ', '5054569001', 'İMAMLAR MAH. CUMHURİYET CAD. NO: 60 GÖLYAKA / DÜZCE', 'golyakaataturk.meb.k12.tr', NULL, '735156@meb.k12.tr'),
(72, 27, 313, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Lisesi', '751731', 'Gümüşova Borsa İstanbul Anad. İmam Hatip Lisesi', 'Normal Öğretim', '(380) 731-2164', 'NAZIM BAHADIR', '5548097775', 'EKREM KARADUMAN', '5072838441', 'KÜLTÜR MAH. OKULLAR CAD. NO: 34 GÜMÜŞOVA / DÜZCE', 'gumusovabistaihl.meb.k12.tr', '', '751731@meb.k12.tr'),
(73, 27, 313, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '964328', 'Gümüşova Anadolu Lisesi', 'Normal Öğretim', '3807314271', 'Eyüp Yazıcı', '5303038181', 'Engin Erdemir', '5544147579', 'MERKEZ MAH. 213 SK. İLKÖĞRETİM OKULU SİTESİ DÜZCE İL ÖZEL İDARESİ BLOK NO: 18 GÜMÜŞOVA / DÜZCE', 'gumusovaimkbal.meb.k12.tr', NULL, '964328@meb.k12.tr'),
(74, 27, 313, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732027', 'Hacıkadirler İlkokulu', 'Normal Öğretim', '3807438194', 'Regaip ŞANLI', '5057192208', 'Özgür ETİ', '5392799182', 'HACIKADİRLER KÖYÜ NO: 105 GÜMÜŞOVA / DÜZCE', 'hacikadirlerilkokulu.meb.k12.tr', NULL, '732027@meb.k12.tr'),
(75, 27, 313, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733488', '75. Yıl İlkokulu', 'Normal Öğretim', '3807312330', 'Erol Cigerli', '5057597277', 'Hatice Nur Kuran', '5538743605', 'ÇAYBÜKÜ KÖYÜ ÇAYBÜKÜ MEVKİİ GÜMÜŞABAD CAD. NO: 7 GÜMÜŞOVA / DÜZCE', 'gumusova75yililkokulu.meb.k12.tr', NULL, '733488@meb.k12.tr'),
(76, 27, 313, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733581', 'Fatih İlkokulu', 'Normal Öğretim', '3807312084', 'Asef AKKOYUNLU', '5374299418', 'Şenol BALÇIK', '5363092016', 'FATİH MAH. 103. SK. NO: 8 GÜMÜŞOVA / DÜZCE', 'gumusovafatihilkokulu.meb.k12.tr', NULL, '733581@meb.k12.tr'),
(77, 27, 313, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733584', 'Gümüşova İlkokulu', 'Normal Öğretim', '3807313858', 'Utku ETİ', '5556540981', 'Hüseyin DİNÇ', '5462914237', 'KÜLTÜR MAH. 306. SK. NO: 2 GÜMÜŞOVA / DÜZCE', 'gumusovailkokulu.meb.k12.tr', NULL, '733584@meb.k12.tr'),
(78, 27, 313, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733486', '75. Yıl Ortaokulu', 'Normal Öğretim', '3807313747', 'Yusuf Yaman', '5327207030', 'Muhammed Dalak', '5395164378', 'ÇAYBÜKÜ KÖYÜ ÇAYBÜKÜ MEVKİİ ERENLER CAD. NO: 6 GÜMÜŞOVA / DÜZCE', 'gumusova75yilortaokulu.meb.k12.tr', NULL, '733486@meb.k12.tr'),
(79, 27, 313, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733580', 'Fatih Ortaokulu', 'Normal Öğretim', '3807312084', 'Asef AKKOYUNLU', '5374299418', 'Şenol BALÇIK', '5363092016', 'FATİH MAH. 103. SK. NO: 8 GÜMÜŞOVA / DÜZCE', 'gumusovafatihortaokulu.meb.k12.tr', NULL, '733580@meb.k12.tr'),
(80, 27, 313, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733582', 'Gümüşova Ortaokulu', 'Normal Öğretim', '3807312815', 'Aykut Çelebioğlu', '5546520755', 'İbrahim Melih Özgirgin', '5544305355', 'KÜLTÜR MAH. 306. SK. NO: 4 GÜMÜŞOVA / DÜZCE', 'gumusovaortaokulu.meb.k12.tr', NULL, '733582@meb.k12.tr'),
(81, 27, 314, 'Din Öğretimi Genel Müdürlüğü', 'Anadolu İmam Hatip Lisesi', '757701', 'Kaynaşlı Anadolu İmam Hatip Lisesi', 'Normal Öğretim', '3805442793', 'Hayati Demir', '5055780166', 'Mahir Karabayırlı', '5068913033', 'MERKEZ MAH. TURGUT ÖZAL CAD. NO: 35 KAYNAŞLI / DÜZCE', 'kaynaslianadoluihl.meb.k12.tr', NULL, '757701@meb.k12.tr'),
(82, 27, 314, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '749072', 'Kaynaşlı İmam Hatip Ortaokulu', 'Normal Öğretim', '3805444334', 'Emrullah Karaca', '5058539932', 'Merve İnan', '5398737305', 'SARIYER MAH. IRMAK SK. NO: 1 İÇ KAPI NO: B101 KAYNAŞLI / DÜZCE', 'kaynasliiho.meb.k12.tr', NULL, '749072@meb.k12.tr'),
(83, 27, 314, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '972291', 'Şehit Sabri Altınbaş Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3805442836', 'Ersel Duman', '05053555176', 'Eda Çifçi', '5433515043', 'ŞİMŞİR MAH. YÖRÜKLERKÖYÜYOLU SK. NO: 4 İÇ KAPI NO: 1 KAYNAŞLI / DÜZCE', 'kaynaslisabrimtal.meb.k12.tr', NULL, '972291@meb.k12.tr'),
(84, 27, 314, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '972830', 'Kaynaşlı Anadolu Lisesi', 'Normal Öğretim', '3805442022', 'ERSİN YAYLALİ', '5055758426', 'CAN ASLAN', '5354266765', 'SARIYER MAH. SERÇE SK. NO: 9 KAYNAŞLI / DÜZCE', 'kaynaslianadolulisesi.meb.k12.tr', NULL, '972830@meb.k12.tr'),
(85, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732017', 'Üçköprü İlkokulu', 'Normal Öğretim', '3805488850', 'Adem ALBAYRAK', '5365893618', 'Mustafa GENÇ', '5437110278', 'ÜÇKÖPRÜ KÖYÜ UFUK MEVKİİ 102. SK. NO: 28 KAYNAŞLI / DÜZCE', 'uckopruilkokulu.meb.k12.tr', NULL, '732017@meb.k12.tr'),
(86, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732023', 'Cumhuriyet İlkokulu', 'Normal Öğretim', '3805444327', 'Veysel Kılıç', '5053338829', 'Cengiz Güler', '5058892703', 'ŞİMŞİR MAH. OKUL SK. NO: 54 İÇ KAPI NO: 1 KAYNAŞLI / DÜZCE', 'duzcecumhuriyet.meb.k12.tr', NULL, '732023@meb.k12.tr'),
(87, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733478', 'Dipsizgöl İlkokulu', 'Normal Öğretim', '3805477247', 'ATALAY İNAN', '5309735596', 'KAMİL FAZIL ASARKAYA', '5054573812', 'DİPSİZGÖL KÖYÜ SAĞLIK MEVKİİ NO: 17 İÇ KAPI NO: 1 KAYNAŞLI / DÜZCE', 'dipsizgolio.meb.k12.tr', NULL, '733478@meb.k12.tr'),
(88, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733570', 'Osmangazi İlkokulu', 'Normal Öğretim', '3805488527', 'Mustafa Şahin', '5062674115', 'Mustafa Şahin', '5062674115', 'ÜÇKÖPRÜ KÖYÜ ŞAFAK MEVKİİ 133 SK. NO: 31 İÇ KAPI NO: 31 KAYNAŞLI / DÜZCE', 'osmangaziilkokulu81.meb.k12.tr', NULL, '733570@meb.k12.tr'),
(89, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '735211', 'Darıyeri Hasanbey İlkokulu', 'Normal Öğretim', '3805466500', 'İSMAİL EFE', '5053142866', 'İSMAİL EFE', '5053142866', 'DARIYERİHASANBEY KÖYÜ MERKEZ MEVKİİ NO: 85 KAYNAŞLI / DÜZCE', 'dariyerihasanbeyio.meb.k12.tr', NULL, '735211@meb.k12.tr'),
(90, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '735220', 'Kaynaşlı İlkokulu', 'Normal Öğretim', '3805442051', 'Cihat OY', '5416715035', 'Ahmet UNAN', '5443835821', 'MERKEZ MAH. NECLA CEYHAN SK. NO: 20 KAYNAŞLI / DÜZCE', 'kaynasliilkokulu.meb.k12.tr', NULL, '735220@meb.k12.tr'),
(91, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '735239', 'Sarıçökek İlkokulu', 'Normal Öğretim', '3805444606', 'Osman GENÇ', '5337647249', 'Uğur DUMAN', '5054475244', 'MERKEZ MAH. ÇİLLİOĞLU SK. NO: 24 KAYNAŞLI / DÜZCE', 'saricokekilkokulu.meb.k12.tr', NULL, '735239@meb.k12.tr'),
(92, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '758464', 'Karaçalı Süperlit İlkokulu', 'Normal Öğretim', '3805442014', 'Özden OY', '5309256147', 'Ali Demir', '5368966678', 'KARAÇALI MAH. KURTULUŞ SK. NO: 1 KAYNAŞLI / DÜZCE', 'kaynaslikaracalisuperlitio.meb.k12.tr', NULL, '758464@meb.k12.tr'),
(93, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732020', 'Cumhuriyet Ortaokulu', 'Normal Öğretim', '3805444327', 'Veysel Kılıç', '5053338829', 'Cengiz Güler', '5058892703', 'ŞİMŞİR MAH. OKUL SK. NO: 54 İÇ KAPI NO: 1 KAYNAŞLI / DÜZCE', 'kaynaslicumhuriyetorta.meb.k12.tr', NULL, '732020@meb.k12.tr'),
(94, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733475', 'Dipsizgöl Ortaokulu', 'Normal Öğretim', '3805477244', 'Ali Rıza Hancı', '5332301288', 'Onur Yılmaz', '5068831229', 'DİPSİZGÖL KÖYÜ SAĞLIK MEVKİİ KONTENİR SİTESİ NO: 18 İÇ KAPI NO: 1 KAYNAŞLI / DÜZCE', 'dipsizgoloo.meb.k12.tr', NULL, '733475@meb.k12.tr'),
(95, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733547', 'Üçköprü Ortaokulu', 'Normal Öğretim', '3805488850', 'ADEM ALBAYRAK', '5365893618', 'MESUT KALASOĞLU', '5332651571', 'ÜÇKÖPRÜ KÖYÜ UFUK MEVKİİ 102 SK. NO: 28 KAYNAŞLI / DÜZCE', 'uckopruortaokulu.meb.k12.tr', NULL, '733547@meb.k12.tr'),
(96, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733567', 'Osmangazi Ortaokulu', 'Normal Öğretim', '3805488527', 'Mustafa Şahin', '5062674115', 'Mustafa Şahin', '5062674115', 'ÜÇKÖPRÜ KÖYÜ ŞAFAK MEVKİİ 133 SK. NO: 31 İÇ KAPI NO: 31 KAYNAŞLI / DÜZCE', 'osmangaziortaokulu81.meb.k12.tr', NULL, '733567@meb.k12.tr'),
(97, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '735208', 'Anadolu Kalkınma Vakfı Ortaokulu', 'Normal Öğretim', '3805442228', 'FEYAZ ŞAHİN', '5366748324', 'KADİR KABACI', '5422732978', 'KARAÇALI MAH. BAĞLAR SK. NO: 12 KAYNAŞLI / DÜZCE', 'kaynasliakv.meb.k12.tr', NULL, '735208@meb.k12.tr'),
(98, 27, 314, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '735231', 'Kumluca Ortaokulu', 'Normal Öğretim', '3805442030', 'Metin Akyüz', '5326175180', 'Fatih Fırtına', '5053045063', 'KUMLUCA MAH. 12 SK. NO: 20 KAYNAŞLI / DÜZCE', 'kaynaslikumluca.meb.k12.tr', NULL, '735231@meb.k12.tr'),
(99, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'Anadolu İmam Hatip Lisesi', '764566', 'Düzce Anadolu İmam Hatip Lisesi', 'Normal Öğretim', '3805261564', 'ASIM KELEŞ', '5053541844', 'ERKAN TAŞCI', '5076968999', 'KÖRPEŞLER MAH. 1452. SOKAK NO:4 MERKEZ/DÜZCE', 'duzceanadoluimamhatiplisesi.meb.k12.tr', NULL, '764566@meb.k12.tr'),
(100, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Lisesi', '132859', 'Düzce Ömer Seyfettin Akdoğan Kız Anadolu İmam Hatip Lisesi', 'Normal Öğretim', '3805243014', 'ZEKERİYA GÜZELDAL', '5324464761', 'AYŞE SEİS', '5456801928', 'FEVZİÇAKMAK MAH. 122. SOKAK NO:81 PK:81100 MERKEZ/DÜZCE', 'duzceihl.meb.k12.tr', NULL, '132859@meb.k12.tr'),
(101, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Lisesi', '765980', 'Mehmet Akif İnan Hafız Anadolu İmam Hatip Lisesi', 'Normal Öğretim', '3805262864', 'Gürol ÜN', '5053482340', 'İsrafil GÜNSAL', '5056408578', NULL, NULL, NULL, '765980@meb.k12.tr'),
(102, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Lisesi', '973853', 'Osman Kuyumcu Anadolu İmam Hatip Lisesi', 'Normal Öğretim', '3805232414', 'Varol Tayhan', '5327051414', 'Engin Karagöz', '5325454404', 'NUSRETTİN MAH. İLİM SOKAK NO:3 PK:81100 MERKEZ/DÜZCE', 'osmankuyumcuanadoluihl.meb.k12.tr', NULL, '973853@meb.k12.tr'),
(103, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '746739', 'Hafız Hasan Şen İmam Hatip Ortaokulu', 'Normal Öğretim', '3804116438', 'Bayram Ali YILMAZ', '5057733656', 'Uğur BOSTANCI', '5418216127', 'GÜZELBAHÇE MAH. 55. SK. HAFIZ HASAN ŞEN İMAM HATİP ORTA OKULU BLOK NO: 30 MERKEZ / DÜZCE', 'hafizhasanseniho.meb.k12.tr', NULL, '746739@meb.k12.tr'),
(104, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '752563', 'Mehmet Zahid Kevseri İmam Hatip Ortaokulu', 'Normal Öğretim', '3805141075', 'Ömer BEYHAN', '5053695769', 'İbrahim DİKMEN', '5364850206', 'FEVZİÇAKMAK MAH. BOLU CAD. NO: 244 MERKEZ / DÜZCE', 'mehmetzahidkevseri.meb.k12.tr', NULL, '752563@meb.k12.tr'),
(105, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '758800', 'Tevfik İleri İmam Hatip Ortaokulu', 'Normal Öğretim', '3805261564', 'Fatih YAZICI', '5446395924', 'İsmail KAYIK', '5542224525', 'KÖRPEŞLER MAH. 1452. SOKAK NO:4 PK:81100 MERKEZ/DÜZCE', 'duzcetevfikileriiho.meb.k12.tr', NULL, '758800@meb.k12.tr'),
(106, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '760307', 'Yunus Emre İmam Hatip Ortaokulu', 'Normal Öğretim', '3805235689', 'ÖMER BAĞRIYANIK', '5057239867', 'YENER BAYRAKTAR', '5058203921', 'ÇAY MAH. SEYHAN CAD. / BLOK NO: 29/1 DÜZCE', 'duzceyunusemreiho.meb.k12.tr', NULL, '760307@meb.k12.tr'),
(107, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '760739', 'Mehmet Akif İnan Hafız imam Hatip Ortaokulu', 'Normal Öğretim', '3805262864', 'Gürol ÜN', '5053482340', 'İsrafil GÜNSAL', '5056408578', 'ÇALICUMA KÖYÜ KÖY SK. NO: 101 MERKEZ / DÜZCE', 'http:/makifinaniho.meb.k12.tr/', NULL, '760739@meb.k12.tr'),
(108, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '761763', 'Beyköy İmam Hatip Ortaokulu', 'Normal Öğretim', '3805526115', 'Samet İNCE', '5424245451', 'Sıddık POLAT', '5069720990', 'BEYKÖY BELDESİ BEYTEPE MAH. 14. CAD. TOKİ İLKÖĞRETİM SİTESİ NO: 2 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'beykoyiho.meb.k12.tr', NULL, '761763@meb.k12.tr'),
(109, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '762184', 'Konuralp İmam Hatip Ortaokulu', 'Normal Öğretim', '3805412182', 'HÜSEYİN ALBAYRAK', '5336135625', 'HASAN KAYA', '5418114646', 'ÇİFTEPINARLAR MH. KONURALP CUMHURİYET CADDESİ No:12- MERKEZ/DÜZCE', 'konuralpiho.meb.k12.tr', NULL, '762184@meb.k12.tr'),
(110, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '763940', 'Mustafa Kemal İmam Hatip Ortaokulu', 'Normal Öğretim', '3805142738', 'Volkan Koyuncu', '5428040580', 'Perihan Ökten', '5448258181', 'KÜLTÜR MAH. KUYUMCUZADE BUL. MUSTAFA KEMAL İLK VE ORTA OKULU BLOK NO: 33 MERKEZ / DÜZCE', 'mkiho.meb.k12.tr', NULL, '763940@meb.k12.tr'),
(111, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '763942', 'Toki Mehmet Akif Ersoy İmam Hatip Ortaokulu', 'Normal Öğretim', '3805240663', 'MUHSİN CELEP', '5422554070', 'METİN MAZLUM', '5052796337', 'KOÇYAZI MAH. 2400. SK. METEK TOKİ İLK VE ORTA OKULU BLOK NO: 6 MERKEZ / DÜZCE', 'tokiimamhatip.meb.k12.tr', NULL, '763942@meb.k12.tr'),
(112, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '763943', 'İstilli İmam Hatip Ortaokulu', 'Normal Öğretim', '3805345256', 'TAMER ŞİMŞEK', '5052999595', 'OKTAY YILMAZ', '5321587060', 'İSTİLLİ KÖYÜ MERKEZ MEVKİİ NO: 25 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'istilliiho.meb.k12.tr', NULL, '763943@meb.k12.tr'),
(113, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '763944', 'Hikmet Akın İmam Hatip Ortaokulu', 'Normal Öğretim', '3805249442', 'Muazzez BİLGİN DİKMEN', '5054536299', 'Savaş TATLI', '5056431484', 'HAMİDİYE MAH. ESKİ AKÇAKOCA CAD. NO: 1 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'hikmetakinih.meb.k12.tr', NULL, '763944@meb.k12.tr'),
(114, 27, 315, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '763945', 'Aydınpınar İmam Hatip Ortaokulu', 'Normal Öğretim', '3805313100', 'Hüseyin Görgülü', '5052179713', 'Ahmet Söylemez', '5394318289', 'AYDINPINAR KÖYÜ MERKEZ MEVKİİ NO: 56 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'aydnpnariho.meb.k12.tr', NULL, '763945@meb.k12.tr'),
(115, 27, 315, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '132811', 'Düzce Borsa İstanbul Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3805237227', 'Osman KUTLU', '5052416256', 'Lokman ALEMDAR', '5072322107', 'KARACA MAH. AKÇAKOCA KARAYOLU CADDE NO:38 PK:81100 MERKEZ/DÜZCE', 'duzceeml.meb.k12.tr', NULL, '132811@meb.k12.tr'),
(116, 27, 315, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '966520', 'Düzce İbn-i Sina Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3804114801', 'Ali ÇİÇEK', '5057151065', 'Zeynep ÖZTÜRK', '5069723074', 'Kara Hacımusa Mahallesi 1395.Sokak No 17 MemurSen Konutları Arkası', NULL, NULL, '966520@meb.k12.tr'),
(117, 27, 315, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '132823', 'Düzce Mevlana Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3805248039', 'Şehabettin Yavuz', '5054001081', 'Salih Kerem ÇABUK', '5397316225', 'ŞIRALIK MAH. 5551. SK. KIZ MESLEK LİSESİ BLOK NO: 12 MERKEZ / DÜZCE', 'duzcektml.meb.k12.tr', NULL, '132823@meb.k12.tr'),
(118, 27, 315, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '962502', 'Düzce Fatih Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3805241466', 'FUAT AYDOĞDU', '5374606746', 'DİDEM ÖZBAKIR KORKMAZ', '5075932040', 'FEVZİÇAKMAK MAH. 173. SOKAK NO:2 PK:81020 MERKEZ/DÜZCE', 'fatiheml.meb.k12.tr', NULL, '962502@meb.k12.tr'),
(119, 27, 315, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '966656', 'Düzce Zübeyde Hanım Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3804117529', 'Mehmet ÇELEBİ', '5326449483', 'Mustafa TAŞDEMİR', '5556489948', 'BAHÇELİEVLER MAH. 37. SOKAK NO:3 PK:81630 MERKEZ/DÜZCE', 'duzcezhmtal.meb.k12.tr', NULL, '966656@meb.k12.tr'),
(120, 27, 315, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '967378', 'Düzce Yavuz Selim Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3804117284', 'Şeref Kıldıran', '5322750502', 'Rıdvan Kırca', '5076627100', 'KOÇYAZI MAH. 2233. SK. YAVUZ SELİM MESLEKİ VE TEKNİK ANADOLU LİSESİ BLOK NO: 8 MERKEZ / DÜZCE', 'duzceystml.meb.k12.tr', NULL, '967378@meb.k12.tr'),
(121, 27, 315, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Anadolu Meslek Programı', '974587', 'Düzce Adnan Menderes Mesleki ve Teknik Anadolu Lisesi', 'Normal Öğretim', '3805143217', 'SALİM YILMAZ', '5416671127', 'OKTAY DAĞKIRAN', '5335509414', 'CEDİDİYE MAH. ŞEHİT YALÇIN GÜZELER SOKAK NO:1 PK:81100 MERKEZ/DÜZCE', 'duzcetml.meb.k12.tr', NULL, '974587@meb.k12.tr'),
(122, 27, 315, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Güzel Sanatlar Lisesi', '751995', 'Düzce Güzel Sanatlar Lisesi', 'Normal Öğretim', '3805262704', 'Dursun Ali YAVUZYİĞİT', '5057914300', 'Sibel AYAS', '5057707918', 'BEYCİLER MAH. 1582. SK. MEHMET AKİF ERSOY İLKOKULU BLOK NO: 17 MERKEZ / DÜZCE', 'duzcegsl.meb.k12.tr', NULL, '751995@meb.k12.tr'),
(123, 27, 315, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Spor Lisesi', '765014', 'Düzce Spor Lisesi', 'Normal Öğretim', '3804111617', 'Gökmen ZEKİ', '5052697881', 'Aydın SOYLU', '5068376491', 'BAHÇELİEVLER MAH. 6.DÜZCE BULVARI NO:42 PK:81000 MERKEZ/DÜZCE', 'duzcesporlisesi.meb.k12.tr', NULL, '765014@meb.k12.tr'),
(124, 27, 315, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '223456', 'Düzce Arsal Anadolu Lisesi', 'Normal Öğretim', '3805232186', 'Şenol Bağdat', '5052402447', 'Yasemin Çağır', '5055370107', 'DARICI MAH. 5800. SOKAK NO:52/A MERKEZ/DÜZCE', 'arsalanadolulisesi.meb.k12.tr', NULL, '223456@meb.k12.tr'),
(125, 27, 315, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '751155', 'Atatürk Anadolu Lisesi', 'Normal Öğretim', '3804116777', 'Beşir Evli', '5059268890', 'Mustafa Necati Bozok', '5304261443', 'GÜZELBAHÇE MAH. 52. SK. PANSİYONLU ATATÜRK LİSESİ BLOK NO: 1A MERKEZ / DÜZCE', 'duzceataturkal.meb.k12.tr', NULL, '751155@meb.k12.tr'),
(126, 27, 315, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '757836', 'Düzce Turgut Özal Anadolu Lisesi', 'Normal Öğretim', '3805261420', 'Veysel DİŞÇİ', '5062974097', 'Üzeyir GÖNÜL', '5616123661', 'KARA HACIMUSA MAH. PINARLAR CAD. ANADOLU ÖĞRETMEN LİSESİ LOJMANI BLOK NO: 57/1 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'duzcetoal.meb.k12.tr', NULL, '757836@meb.k12.tr'),
(127, 27, 315, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '764876', 'Beyciler Anadolu Lisesi', 'Normal Öğretim', '3804114801', 'Engin ÇAKIR', '5056483706', 'Ali Tezcan', '5058298928', 'KARA HACIMUSA MAH. 1395. SK. NO: 17 İÇ KAPI NO: 0 MERKEZ / DÜZCE', 'duzcebal.meb.k12.tr', NULL, '764876@meb.k12.tr'),
(128, 27, 315, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '765261', 'Konuralp Anadolu Lisesi', 'Normal Öğretim', NULL, 'Fazıl KIRGIN', '5333242455', 'Burcu ATASEVEN', '5309518085', 'ÇİFTEPINARLAR MAH. KONURALP HİLMİ SÖNMEZ CADDE NO:2 MERKEZ/DÜZCE', 'konuralpal.meb.k12.tr', NULL, '765261@meb.k12.tr'),
(129, 27, 315, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '964330', 'Cumhuriyet Anadolu Lisesi', 'Normal Öğretim', '3805235680', 'İbrahim BAYRAK', '5054033078', 'Seracettin YİĞİT', '5055220019', 'ŞIRALIK MAH. 5503. SOKAK NO:8 PK:81010 MERKEZ/DÜZCE', 'duzcecanal.meb.k12.tr', NULL, '964330@meb.k12.tr'),
(130, 27, 315, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '970661', 'Farabi Anadolu Lisesi', 'Normal Öğretim', '3804113381', 'Ahmet Ablak', '5052280748', 'Fatih Uyman', '5326714014', 'BAHÇELİEVLER MAH. 8.DÜZCE BUL. FARABİ ANADOLU LİSESİ BLOK NO: 23 MERKEZ / DÜZCE', 'farabianadolulisesi.meb.k12.tr', NULL, '970661@meb.k12.tr'),
(131, 27, 315, 'Ortaöğretim Genel Müdürlüğü', 'Anadolu Lisesi', '972831', 'Düzce 15 Temmuz Şehitler Anadolu Lisesi', 'Normal Öğretim', '3805246141', 'Mehmet Karaca', '5056693520', 'Hale Meral', '5056481397', 'AZİZİYE MAH. ŞEHİT RAMAZAN GEL CAD. DÜZCE ANADOLU LİSESİ BLOK NO: 3 MERKEZ / DÜZCE', 'duzce15temmuz.meb.k12.tr', NULL, '972831@meb.k12.tr'),
(132, 27, 315, 'Ortaöğretim Genel Müdürlüğü', 'Fen Lisesi', '887419', 'Düzce Fen Lisesi', 'Normal Öğretim', '3805263154', 'Mehmet GEDİK', '5054939858', 'Türkay KÜÇÜKDURMUŞ', '5055583601', 'KARA HACIMUSA MAH. PINARLAR CAD. FEN LİSESİ YURDU BLOK NO: 57/6 MERKEZ / DÜZCE', 'duzcefenlisesi.meb.k12.tr', NULL, '887419@meb.k12.tr'),
(133, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '709240', 'Gazi Mustafa Kemal İlkokulu', 'Normal Öğretim', '3804114853', 'Mehmet ÖZDEMİR', '5054969223', 'İlknur KILINÇASLAN', '5054309189', 'DEMETEVLER MAH. 4094. SK. GAZİ MUSTAFA KEMAL İLKOKULU BLOK NO: 4 MERKEZ / DÜZCE', 'duzcegmk.meb.k12.tr', NULL, '709240@meb.k12.tr'),
(134, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '709625', 'Cumhuriyet İlkokulu', 'Normal Öğretim', '3804114027', 'ERSİN CARIM', '5332373606', 'OSMAN AYDIN', '5336337498', 'ÇAMLIEVLER MAH. 20. SK. CUMHURİYET İLKOKULU BLOK NO: 1 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'duzcecumhuriyetilkokulu.meb.k12.tr', NULL, '709625@meb.k12.tr'),
(135, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '709688', '23 Nisan İlkokulu', 'Normal Öğretim', '3804115005', 'Murat Gök', '5054952881', 'Sibel Tatoğlu', '5466091237', 'GÜZELBAHÇE MAH. 55. SK. 23 NİSAN İLKOKULU BLOK NO: 1 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'duzce23nisan.meb.k12.tr', NULL, '709688@meb.k12.tr'),
(136, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '709737', 'Necmi Hoşver İlkokulu', 'Normal Öğretim', '3805121019', 'Ömer İŞÇİ', '5306805325', 'Ayhan USLU', '5076975474', 'ÇAY MAH. 640. SK. NECMİ HOŞVER İLKOKULU BLOK NO: 7 İÇ KAPI NO: 0 MERKEZ / DÜZCE', 'necmihosverilkokulu.meb.k12.tr', NULL, '709737@meb.k12.tr'),
(137, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '731986', 'Düzce Türkiye Odalar ve Borsalar Birliği İlkokulu', 'Normal Öğretim', '3805142545', 'SEZAİ ŞAHİN', '5051198664', 'AYŞE DİKMEN', '5323303709', 'NUSRETTİN MAH. İSTİKLAL CAD. NO: 82 İÇ KAPI NO: 0 MERKEZ / DÜZCE', 'duzcetobbilkokulu.meb.k12.tr', NULL, '731986@meb.k12.tr'),
(138, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732070', 'Doğanlı Eşref Taşhan İlkokulu', 'Normal Öğretim', '3805497135', 'OKTAY SİLO', '5054568083', 'CEMİL BAYRAKTAR', '5368535893', 'DOĞANLI KÖYÜ D-100 KARAYOLU CAD. NO: 320 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'doganlietio.meb.k12.tr', NULL, '732070@meb.k12.tr'),
(139, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732072', 'Köprübaşı İlkokulu', 'Normal Öğretim', '3805335020', 'Çiğdem Sıvacı', '5462301550', 'YOK', '5462301550', 'KÖPRÜBAŞI KÖYÜ NO: 177 MERKEZ / DÜZCE', 'duzcekoprubasiilkokulu.meb.k12.tr', NULL, '732072@meb.k12.tr'),
(140, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732078', 'Paşaormanı İlkokulu', 'Normal Öğretim', '3805512856', 'İrfan Durmaz', '5327930293', 'Atay Çokengin', '5072490052', 'PAŞAORMANI KÖYÜ 7170. CAD. OKUL BİNASI SİTESİ NO: 33 MERKEZ / DÜZCE', 'pasaormaniilkokulu.meb.k12.tr', NULL, '732078@meb.k12.tr'),
(141, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732080', 'Gölormanı İlkokulu', 'Normal Öğretim', '3805324254', 'İrfan KARA', '5413694869', 'Anıl ATİK', '5377617947', 'GÖLORMANI KÖYÜ MERKEZ MEVKİİ NO: 6 MERKEZ / DÜZCE', 'golormaniilkokulu.meb.k12.tr', NULL, '732080@meb.k12.tr'),
(142, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732083', 'Şehit Ufuk Baysan İlkokulu', 'Normal Öğretim', '3805526222', 'YILMAZ KARACA', '5065114826', 'EREN DEDEOĞLU', '5342614209', 'BEYTEPE MAHALLESİ 14. CADDE NO:2/1 Merkez/DÜZCE', 'sehitufukbaysanilkokulu.meb.k12.tr', NULL, '732083@meb.k12.tr'),
(143, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732086', 'Akşemsettin İlkokulu', 'Normal Öğretim', '3805260685', 'KERİM AŞIKOĞLU', '5065084408', 'SÜLEYMAN AKGÜL', '5353767941', 'ARAPÇİFTLİĞİ MAH. 3018. SK. ARAPÇİFTLİĞİ İLKÖĞRT. BLOK NO: 2 MERKEZ / DÜZCE', 'aksemsettinilkokulu.meb.k12.tr', NULL, '732086@meb.k12.tr'),
(144, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732092', 'Çamköy İlkokulu', 'Normal Öğretim', '3805262701', 'Yener Ertay', '5057054479', 'Yok', '5057054479', 'ÇAMKÖY MAH. 3274. SK. ÇAMKÖY İLK VE ORTA OKULU BLOK NO: 15 MERKEZ / DÜZCE', 'camkoyilk.meb.k12.tr', NULL, '732092@meb.k12.tr'),
(145, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732095', 'Toki Mehmet Akif Ersoy İlkokulu', 'Normal Öğretim', '3805240663', 'Hasan YEŞİLYURT', '5327456608', 'Jale SIRDAŞ', '5052694988', 'KOÇYAZI MAH. 2400. SK. METEK TOKİ İLK VE ORTA OKULU BLOK NO: 6 MERKEZ / DÜZCE', 'duzcemehmetakifersoy.meb.k12.tr', NULL, '732095@meb.k12.tr'),
(146, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732098', 'Şıralık Vatan İlkokulu', 'Normal Öğretim', '3805232626', 'Ömer Güller', '5079714681', 'Muhammet Gölcür', '5070072316', 'ŞIRALIK MAH. 5503. SK. VATAN İLK VE ORTA OKULU BLOK NO: 4 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'siralikvatanio.meb.k12.tr', NULL, '732098@meb.k12.tr'),
(147, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732102', 'Azmimilli İlkokulu', 'Normal Öğretim', '3805234480', 'Abdüsselam ALTINTAŞ', '5332633830', 'Recep AYAS', '5307774507', 'AZMİMİLLİ MAH. GAZHANE CAD. AZMİMİLLİ İLK VE ORTA OKULU BLOK NO: 68 İÇ KAPI NO: A MERKEZ / DÜZCE', 'duzceazmimilliilkokulu.meb.k12.tr', NULL, '732102@meb.k12.tr'),
(148, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732107', 'Şehit Furkan Kaplanbaba İlkokulu', 'Normal Öğretim', '3804117030', 'MİRAÇ KARAYİĞİT', '5315734001', 'ÜMİT ÇENGEL', '5462957727', 'YEŞİLTEPE MAH. 2.YEŞİLTEPE CAD. ŞHT. FURKAN KAPLANBABA İLKO. YEŞİLTEPE ORTA O. BLOK NO: 4 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'sehitfurkankaplanbabaio.meb.k12.tr', NULL, '732107@meb.k12.tr'),
(149, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733449', 'Yeni Mahalle İlkokulu', 'Normal Öğretim', '3805145998', 'İsa Saka', '5055925025', 'SelimTan', '5423625592', 'KARA HACIMUSA MAH. PINARLAR CAD. NO: 24 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'yenimahalleilkokulu81.meb.k12.tr', NULL, '733449@meb.k12.tr'),
(150, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733458', 'Namık Kemal İlkokulu', 'İkili Öğretim', '3805246342', 'İbrahim Göl', '5326386474', 'İbrahim Çetin', '5416889875', 'KÜLTÜR MAH. 754. SK. NAMIK KEMAL İLKOKULU NO: 4 MERKEZ / DÜZCE', 'namikkemal81.meb.k12.tr', NULL, '733458@meb.k12.tr'),
(151, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733515', 'Çevrem İlkokulu', 'Normal Öğretim', '3805364396', 'Serdar Kaya', '5446309290', 'Muhammet Akbulut', '5543270634', 'ŞAZİYE KÖYÜ NO: 127 MERKEZ / DÜZCE', 'cevrem.meb.k12.tr', NULL, '733515@meb.k12.tr'),
(152, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733517', 'Eskimengencik İlkokulu', 'Normal Öğretim', '3805497846', 'Kenan KAHRAMAN', '5057598266', 'Cansu ZEY', '5454412188', 'ESKİ MENGENCİK KÖYÜ MERKEZ MEVKİİ NO: 47 MERKEZ / DÜZCE', 'eskimengencikilkokulu.meb.k12.tr', NULL, '733517@meb.k12.tr'),
(153, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733520', 'Aydınpınar İlkokulu', 'Normal Öğretim', '3805313100', 'Hüseyin Görgülü', '5052179713', 'Mehmet Yavuz', '5326866858', 'AYDINPINAR KÖYÜ MERKEZ MEVKİİ NO:56 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'aydnpnarilkokulu.meb.k12.tr', NULL, '733520@meb.k12.tr'),
(154, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733523', 'Sancaklar İlkokulu', 'Normal Öğretim', '3805260724', 'Mehmet Albayrak', '5056373617', 'Cemil Koca', '5065025567', 'SANCAKLAR MAH. 2498. SK. SANCAKLAR İLKOKULU BLOK NO: 4 MERKEZ / DÜZCE', 'sancaklarilkokulu.meb.k12.tr', NULL, '733523@meb.k12.tr'),
(155, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733528', 'Konuralp İlkokulu', 'Normal Öğretim', '3805412043', 'Nihar Demircan', '5302529908', 'Emine Koç', '5536200392', 'TERZİALİLER MAH. KONURALP AKÇAKOCA CAD. KONURALP İLKOKULU BLOK NO: 40 MERKEZ / DÜZCE', 'konuralpilkokulu81.meb.k12.tr', NULL, '733528@meb.k12.tr'),
(156, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733529', 'Şehit Metin Kucur İlkokulu', 'Normal Öğretim', '3805235540', 'Rıdvan HIRACA', '5446436613', 'Ümit BALİBEY', '5442007375', 'KARACA MAH. 1348. CAD. 100. YIL İLK VE ORTA OKULU BLOK NO: 17 MERKEZ / DÜZCE', 'sehitmetinkucurio.meb.k12.tr', NULL, '733529@meb.k12.tr');
INSERT INTO `okullar` (`ID`, `IL_ID`, `ILCE_ID`, `GENEL_MUDURLUK`, `KURUM_TURU`, `KURUM_KODU`, `KURUM_ADI`, `OGRETIM_SEKLI_ID`, `TELEFON`, `MUDUR`, `MUDUR_CEP`, `MUDUR_YRD`, `MUDUR_YRD_CEP`, `ADRES`, `WEB`, `EPOSTA2`, `EPOSTA`) VALUES
(157, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733533', 'Pakmaya İlkokulu', 'Normal Öğretim', '3805234925', 'Burhanettin DANIŞ', '5446350967', 'Recep DEMİRCİ', '5055575145', 'DERELİTÜTÜNCÜ MAH. TÜTÜNCÜ CAD. PAKMAYA İLK VE ORTA OKULU BLOK NO: 159 MERKEZ / DÜZCE', 'duzcepakmayailkokulu.meb.k12.tr', NULL, '733533@meb.k12.tr'),
(158, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733538', 'Avni Akyol İlkokulu', 'Normal Öğretim', '3805248793', 'Tanju URASLU', '5055733006', 'Kenan DEMİR', '5054771581', 'AZİZİYE MAH. 893. SK. NO: 82 MERKEZ / DÜZCE', 'avniakyolilkokulu.meb.k12.tr', NULL, '733538@meb.k12.tr'),
(159, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733556', 'Uzunmustafa İlkokulu', 'İkili Öğretim', '3805143227', 'Mehmet Günaydın', '5422329105', 'Gamze Yaykaşlı', '5072341981', 'KÜLTÜR MAH. KANUNİ SK. UZUNMUSTAFA İLKOKULU BLOK NO: 5 MERKEZ / DÜZCE', 'uzunmustafailkokulu.meb.k12.tr', NULL, '733556@meb.k12.tr'),
(160, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733625', 'Gümüşpınar Mehmetçik İlkokulu', 'Normal Öğretim', '3805513109', 'Mehmet UÇAR', '5055235020', 'ramazan ATALAR', '5424004561', 'GÜMÜŞPINAR KÖYÜ 9730. SK. GÜMÜŞPINAR İLKÖĞRETİM BLOK NO: 3 MERKEZ / DÜZCE', 'gumuspinario.meb.k12.tr', NULL, '733625@meb.k12.tr'),
(161, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733647', 'İhsaniye İlkokulu', 'Normal Öğretim', '3805364312', 'Mustafa ACAR', '5362385923', 'Hakan GÖKCE', '5057337780', 'İHSANİYE KÖYÜ ANA OKUL SİTESİ NO: 25 MERKEZ / DÜZCE', 'ihsaniyeilkokulu81.meb.k12.tr', NULL, '733647@meb.k12.tr'),
(162, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733649', 'Nasırlı İlkokulu', 'Normal Öğretim', '3805578725', 'AHMET OKUR', '5459131333', 'SİNAN ŞENTÜRK', '5334172461', 'NASIRLI KÖYÜ MERKEZ MEVKİİ NO: 99 MERKEZ / DÜZCE', 'nasirliilkokulu.meb.k12.tr', NULL, '733649@meb.k12.tr'),
(163, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733652', 'Ömer Dinçer İlkokulu', 'Normal Öğretim', '3805537125', 'Necmettin KARTAL', '5327864395', 'Volkan EFECİOĞLU', '5055855767', 'DURAKLAR KÖYÜ İLKOKUL SİTESİ NO: 181 İÇ KAPI NO: B MERKEZ / DÜZCE', 'duzceomerdincer.meb.k12.tr', NULL, '733652@meb.k12.tr'),
(164, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733655', 'Nejdet Bıçakçıoğlu İlkokulu', 'Normal Öğretim', '3805536816', 'Ömer Otlu', '5333104538', 'Muhammer Yüksel', '5349598924', 'BALLICA KÖYÜ MERKEZ MEVKİİ NO: 115 MERKEZ / DÜZCE', 'nbio.meb.k12.tr', NULL, '733655@meb.k12.tr'),
(165, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733670', 'Şehit Yüzbaşı Beşir Bayraktar İlkokulu', 'Normal Öğretim', '3805434266', 'SEFER AKCABELEN', '5438066932', 'ÖMER LEVENT CİNGİRT', '5358853932', 'KABALAK KÖYÜ MERKEZ MEVKİİ NO: 14 MERKEZ / DÜZCE', 'besirbayraktario.meb.k12.tr', NULL, '733670@meb.k12.tr'),
(166, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733685', 'Boğaziçi İlkokulu', 'Normal Öğretim', '3805434385', 'Yüksel DANIŞ', '5418423110', 'Burak ÇOBAN', '5538700563', 'BOĞAZİÇİ BELDESİ YAZLIK MAH. 101 CAD. NO: 142 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'duzcebogaziciilkokulu.meb.k12.tr', NULL, '733685@meb.k12.tr'),
(167, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733691', 'Perihan Tulan İlkokulu', 'Normal Öğretim', '3805578321', 'Dursun SİLAHDAR', '5054986052', 'Muhammet AK', '5301787200', 'ÇİFTLİK KÖYÜ KÖYÜN KENDİSİ MEVKİİ PERİHAN TULAN İLKOKULU BLOK NO: 97/1 MERKEZ / DÜZCE', 'perihantulanilkokulu.meb.k12.tr', NULL, '733691@meb.k12.tr'),
(168, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733695', 'Çakırlar İlkokulu', 'Normal Öğretim', '3805578032', 'Caner BAĞ', '5342815849', 'Musa MUTLU', '5305289160', 'ÇAKIRLAR MAH. 3696. CAD. ÇAKIRLAR İLKOKULU BLOK NO: 16 MERKEZ / DÜZCE', 'cakirlario.meb.k12.tr', NULL, '733695@meb.k12.tr'),
(169, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733698', 'Beyciler İlkokulu', 'Normal Öğretim', '3805260582', 'Ahmet  ÖZDEMİR', '5053979816', 'Cemil  ÇİFTCİ', '5057453335', 'BEYCİLER MAH. 1753. SK. BEYCİLER İLK VE ORTA OKULU BLOK NO: 2 MERKEZ / DÜZCE', 'beycilerilkokulu.meb.k12.tr', NULL, '733698@meb.k12.tr'),
(170, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733700', '19 Mayıs İlkokulu', 'Normal Öğretim', '3805144569', 'HÜDAİ DEMİREL', '5377885599', 'CENGİZ ALTIOK', '5064189678', 'CUMHURİYET MAH. 1925. SK. 19 MAYIS İLKÖĞRETİM BLOK NO: 18 MERKEZ / DÜZCE', 'duzce19mayisilkokulu.meb.k12.tr', NULL, '733700@meb.k12.tr'),
(171, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733704', 'Fatih İlkokulu', 'İkili Öğretim', '3805142097', 'şafak duman', '5055442699', 'eslem arslan', '5307460206', 'FEVZİÇAKMAK MAH. TEVFİK DEMİR SK. FATİH İLK VE ORTAOKULU OKULU BLOK NO: 7/2 MERKEZ / DÜZCE', 'duzcefatihio.meb.k12.tr', NULL, '733704@meb.k12.tr'),
(172, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733706', 'Aziziye İlkokulu', 'Normal Öğretim', '3805142468', 'Ebubekir YILMAZ', '5053478731', 'Murat EMEKLİ', '5353666879', 'AZİZİYE MAH. 1007. SK. AZİZİYE İLK VE ORTA OKULU BLOK NO: 19 İÇ KAPI NO: 2 MERKEZ / DÜZCE', 'aziziyei.meb.k12.tr', NULL, '733706@meb.k12.tr'),
(173, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733708', 'Rıza Malatyalı İlkokulu', 'Normal Öğretim', '3805243155', 'Naciye Yağmur', '5057593518', 'zeynep olcar', '5415790716', 'AĞAKÖYÜ MAH. 1991. SK. RIZA MALATYALI İ.Ö.O. BLOK NO: 12 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'rizamalatyaliilkokulu.meb.k12.tr', NULL, '733708@meb.k12.tr'),
(174, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '734772', 'Işık İlkokulu', 'Normal Öğretim', '3805142553', 'Sait GÜMÜŞ', '5055770257', 'Tuna Han ERSOY', '5427908481', 'ÇAY MAH. YUNUS EMRE SK. IŞIK İLKOKULU BLOK NO: 16/2 MERKEZ / DÜZCE', 'duzceisikilkokulu.meb.k12.tr', NULL, '734772@meb.k12.tr'),
(175, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '734786', 'İrfan Öztürk İlkokulu', 'Normal Öğretim', '3805239255', 'Ali KOLOĞLU', '5303452969', 'Ramazan KARADUMAN', '5056566805', 'KOÇYAZI MAH. 2307. SK. İRFAN ÖZTÜRK İLKÖĞRETİM OKULU BLOK NO: 24 MERKEZ / DÜZCE', 'irfanozturkio.meb.k12.tr', NULL, '734786@meb.k12.tr'),
(176, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '734797', 'Hamidiye İlkokulu', 'Normal Öğretim', '3805248356', 'Ümit Kemal ŞEN', '5366317467', 'Hülya ATALAY', '5054033138', 'HAMİDİYE MAH. KEMAL KUYUMCU SK. BLOK NO: 24 MERKEZ / DÜZCE', 'duzcehamidiye.meb.k12.tr', NULL, '734797@meb.k12.tr'),
(177, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '734862', 'Şehit Teğmen Uğur Altan İlkokulu', 'Normal Öğretim', '3805261530', 'Şenol BİLEN', '5325250312', 'Rıfat ÜNALAN', '5307656403', 'KARA HACIMUSA MAH. PINARLAR CAD. ŞEHİT TEĞMEN UĞUR ALTAN İ.O. BLOK NO: 50 MERKEZ / DÜZCE', 'stuguraltanio.meb.k12.tr', NULL, '734862@meb.k12.tr'),
(178, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '746172', 'Yahyalar İlkokulu', 'Normal Öğretim', '3804115137', 'Selda Gülmez', '5053900981', 'Birleştirilmiş Sınıf ', '5053900981', 'YAHYALAR MAH. 5163. SK. YAHYALAR İLKOKULU BLOK NO: 33 MERKEZ / DÜZCE', 'duzceyahyalario.meb.k12.tr', NULL, '746172@meb.k12.tr'),
(179, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '746175', 'Soğukpınar İlkokulu', 'Normal Öğretim', '3805238298', 'İLHAN KARAKAYA', '5055262142', 'İLHAN KARAKAYA', '05055262142', 'SOĞUKPINAR MAH. 5372. SK. SOĞUKPINAR İLKOKULU BLOK NO: 11 MERKEZ / DÜZCE', 'sogukpinario.meb.k12.tr', NULL, '746175@meb.k12.tr'),
(180, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '746180', 'Kemerkasım İlkokulu', 'Normal Öğretim', '3805578571', 'ZAFER ÖZGÜREL', '5336217838', NULL, '5537692073', 'KEMERKASIM KÖYÜ KEMER MEVKİİ NO: 1 MERKEZ / DÜZCE', 'kemerkasimilkokulu.meb.k12.tr', NULL, '746180@meb.k12.tr'),
(181, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '746183', 'Çalıcuma İlkokulu', 'Normal Öğretim', '3805525659', 'Olgun Polat', '5342192381', 'Olgun Polat', '5342192381', 'ÇALICUMA KÖYÜ NO: 58 MERKEZ / DÜZCE', 'calicumaio.meb.k12.tr', NULL, '746183@meb.k12.tr'),
(182, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '746191', 'Bostanlık İlkokulu', 'Normal Öğretim', '5378934478', 'Side SERTKAYA', '5553125612', NULL, NULL, 'BOSTANLIK(FEVZİYE) KÖYÜ NO: 122 MERKEZ / DÜZCE', 'bostanlikilkokulu.meb.k12.tr', NULL, '746191@meb.k12.tr'),
(183, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '746192', 'Esentepe İlkokulu', 'Normal Öğretim', '3804118431', 'Sefa KONCA', '5058981657', 'Yok', '5058981657', 'ESENTEPE KÖYÜ NO: 42 MERKEZ / DÜZCE', 'duzceesentepe.meb.k12.tr', NULL, '746192@meb.k12.tr'),
(184, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '746195', 'Çakır Hacı İbrahim İlkokulu', 'Normal Öğretim', '3805313643', 'Ercan HOTAMAN', '5055623637', 'YOK', '5055623637', 'ÇAKIRHACI İBRAHİM KÖYÜ NO: 70 MERKEZ / DÜZCE', 'cakirhaciibrahimilkokulu.meb.k12.tr', NULL, '746195@meb.k12.tr'),
(185, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '746196', 'Büyükaçma İlkokulu', 'Normal Öğretim', '3805525964', 'Yavuz Öztürk', '5337636180', 'Yavuz Öztürk', '5337636180', 'BÜYÜKAÇMA KÖYÜ KÖY SK. NO: 35 MERKEZ / DÜZCE', 'bykamailkokulu.meb.k12.tr', NULL, '746196@meb.k12.tr'),
(186, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '746197', 'Bahçeköy İlkokulu', 'Normal Öğretim', '3805345080', 'ŞABAN GÜNENGİL', '5317941765', '.', '5317941765', 'BAHÇE KÖYÜ MERKEZ MEVKİİ NO: 183 MERKEZ / DÜZCE', 'bahcekoy.meb.k12.tr', NULL, '746197@meb.k12.tr'),
(187, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '758597', 'Nursel Demirel İlkokulu', 'Normal Öğretim', '3805353387', 'Ümit ALTUN', '5057512210', 'Mehmet Sinan ÖZDURMUŞ', '5056842317', 'YENİ TAŞKÖPRÜ KÖYÜ MERKEZ MEVKİİ 18055. CAD. NO: 40 MERKEZ / DÜZCE', 'nurseldemirelilkokulu.meb.k12.tr', NULL, '758597@meb.k12.tr'),
(188, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '709235', 'Gazi Mustafa Kemal Ortaokulu', 'Normal Öğretim', '3804114853', 'Mehmet ÖZDEMİR', '5054969223', 'İlknur KILINÇASLAN', '5054309189', 'DEMETEVLER MAH. 4094. SK. GAZİ MUSTAFA KEMAL İLKOKULU BLOK NO: 4 MERKEZ / DÜZCE', 'duzcegmko.meb.k12.tr', NULL, '709235@meb.k12.tr'),
(189, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '709637', 'Hürriyet Ortaokulu', 'Normal Öğretim', '3804115719', 'Mustafa KARAOĞLU', '5053505811', 'Mustafa EGE', '5464615810', 'BAHÇELİEVLER MAH. 31. SK. HÜRRİYET İLK VE ORTA OKULU VE YAVUZ SELİM TİC.M.L BLOK NO: 2 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'duzcehurriyetortaokulu.meb.k12.tr', NULL, '709637@meb.k12.tr'),
(190, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '709733', 'Necmi Hoşver Ortaokulu', 'Normal Öğretim', '3805239011', 'Celil KAYA', '5367318603', 'Remzi NAMAL', '5422351948', 'ÇAY MAH. 640. SK. NECMİ HOŞVER ORTAOKULU BLOK NO: 7/1 MERKEZ / DÜZCE', 'necmihosverortaokulu.meb.k12.tr', NULL, '709733@meb.k12.tr'),
(191, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '731985', 'Atatürk Ortaokulu', 'Normal Öğretim', '3805142545', 'SEZAİ ŞAHİN', '5051198664', 'YAŞAR KARAÇOBAN', '5467462478', 'NUSRETTİN MAH. İSTİKLAL CAD. NO: 82 MERKEZ / DÜZCE', 'duzceataturk.meb.k12.tr', NULL, '731985@meb.k12.tr'),
(192, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '731987', 'Mustafa Kemal Ortaokulu', 'İkili Öğretim', '3805142738', 'Volkan KOYUNCU', '5428040580', 'Perihan ÖKTEN', '5448258181', 'KÜLTÜR MAH. KUYUMCUZADE BUL. MUSTAFA KEMAL İLK VE ORTA OKULU BLOK NO: 33 MERKEZ / DÜZCE', 'duzcemustafakemaloo.meb.k12.tr', NULL, '731987@meb.k12.tr'),
(193, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732069', 'Doğanlı Eşref Taşhan Ortaokulu', 'Normal Öğretim', '3805497135', 'OKTAY SİLO', '5054568083', 'MUSTAFA ÖMÜR', '5382908581', 'DOĞANLI KÖYÜ KÖY SK. NO: 32 MERKEZ / DÜZCE', 'doganliet.meb.k12.tr', NULL, '732069@meb.k12.tr'),
(194, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732074', 'İstilli Ortaokulu', 'Normal Öğretim', '3805345256', 'TAMER ŞİMŞEK', '5052999595', 'OKTAY YILMAZ', '5321587060', 'İSTİLLİ KÖYÜ MERKEZ MEVKİİ NO: 25 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'istilliortaokulu.meb.k12.tr', NULL, '732074@meb.k12.tr'),
(195, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732079', 'Gölormanı Ortaokulu', 'Normal Öğretim', '3805324254', 'İrfan KARA', '5413694869', 'Şükrü VAROL', '5514032270', 'GÖLORMANI KÖYÜ MERKEZ MEVKİİ NO: 6A MERKEZ / DÜZCE', 'golormaniortaokulu.meb.k12.tr', NULL, '732079@meb.k12.tr'),
(196, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732082', 'Beyköy Ortaokulu', 'Normal Öğretim', '3805526115', 'Samet İNCE', '5424245451', 'Fatih PÜRCÜ', '5436786800', 'BEYKÖY BELDESİ BEYTEPE MAH. 11. CAD. NO: 2 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'duzcebeykoyortaokulu.meb.k12.tr', NULL, '732082@meb.k12.tr'),
(197, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732085', 'Akşemsettin Ortaokulu', 'Normal Öğretim', '3805260685', 'KERİM AŞIKOĞLU', '5065084408', 'SÜLEYMAN AKGÜL', '5353767941', 'ARAPÇİFTLİĞİ MAH. 3018. SK. ARAPÇİFTLİĞİ İLKÖĞRT. BLOK NO: 2 MERKEZ / DÜZCE', 'aksemsettinortaokulu.meb.k12.tr', NULL, '732085@meb.k12.tr'),
(198, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732087', 'Konuralp Ortaokulu', 'Normal Öğretim', '3805412182', 'HÜSEYİN ALBAYRAK', '5336135625', 'MEHMET AVAN', '5053140591', 'ÇİFTEPINARLAR MAH. KONURALP 18. SK. ÜSKÜBÜ ORTA OKULU BLOK NO: 3 MERKEZ / DÜZCE', 'konuralportaokulu.meb.k12.tr', NULL, '732087@meb.k12.tr'),
(199, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732091', 'Çamköy Fatma Gösterişli Ortaokulu', 'Normal Öğretim', '3805262747', 'Burhan KÖSE', '5054937355', 'Kamil KARAKURT', '5303180858', 'ÇAMKÖY MAH. 3274. SK. ÇAMKÖY İLK VE ORTA OKULU EK BİNA BLOK NO: 15/1 MERKEZ / DÜZCE', 'camkoyortaokulu81.meb.k12.tr', NULL, '732091@meb.k12.tr'),
(200, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732093', 'Toki Mehmet Akif Ersoy Ortaokulu', 'Normal Öğretim', '3805240663', 'Muhsin CELEP', '5422554070', 'Metin MAZLUM', '5052796337', 'YAHYALAR MAH. 4993. SK. TOKİ MEHMET AKİF ERSOY ORTAOKULU BLOK NO: 16 İÇ KAPI NO: 0 MERKEZ / DÜZCE', 'maeortaokulu.meb.k12.tr', NULL, '732093@meb.k12.tr'),
(201, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732096', 'Şıralık Vatan Ortaokulu', 'Normal Öğretim', '3805232626', 'Ömer Güller', '5079714681', 'Onur Bağıran', '5359231563', 'ŞIRALIK MAH. 5503. SK. VATAN İLK VE ORTA OKULU BLOK NO: 4 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'siralikvatanortaokulu.meb.k12.tr', NULL, '732096@meb.k12.tr'),
(202, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732103', 'Yeşiltepe Ortaokulu', 'Normal Öğretim', '3804117030', 'MİRAÇ KARAYİĞİT', '5315734001', 'ABDULLAH TAŞ', '5453695206', 'YEŞİLTEPE MAH. 118. SK. FK-1 BLOK NO: 1 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'duzceyesiltepeo.meb.k12.tr', NULL, '732103@meb.k12.tr'),
(203, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '732187', 'Yunus Emre Ortaokulu', 'Normal Öğretim', '3805234366', 'MURAT ZENGİN', '5065168104', 'TANER YEL', '5058074482', 'ÇAY MAH. SEYHAN CAD. YUNUS EMRE OKULU BLOK NO: 29/2 MERKEZ / DÜZCE', 'duzceyunusemre.meb.k12.tr', NULL, '732187@meb.k12.tr'),
(204, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733446', 'Şehit Cihan Aksarı Ortaokulu', 'Normal Öğretim', '3805250223', 'ALAHATTİN ÇALIŞKAN', '5057462871', 'MÜMİN ÇAKAR', '5055884864', 'YENİ MAH. YENİ SK. ŞEHİT CİHAN AKSARI ORTAOKULU BLOK NO: 26 MERKEZ / DÜZCE', 'sehitcihanaksariortaokulu81.meb.k12.tr', NULL, '733446@meb.k12.tr'),
(205, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733513', 'Musababa Ortaokulu', 'Normal Öğretim', '3805381051', 'İsmail TETİK', '5356208772', 'Hacer KARAGÖZ', '5434686098', 'MUSABABA KÖYÜ MUSABABA MÜCAVİR MEVKİİ MUSABABA İLK VE ORTAOKULU BLOK NO: 94 MERKEZ / DÜZCE', 'musababaortaokulu.meb.k12.tr', NULL, '733513@meb.k12.tr'),
(206, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733518', 'Aydınpınar Ortaokulu', 'Normal Öğretim', '3805313100', 'Hüseyin Görgülü', '5052179713', 'Osman Ayhan', '5530858606', 'AYDINPINAR KÖYÜ MERKEZ MEVKİİ NO: 56 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'aydnpnarokul.meb.k12.tr', NULL, '733518@meb.k12.tr'),
(207, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733522', 'Şükran-Sedat Şenkardeşler Ortaokulu', 'Normal Öğretim', '3805260185', 'MUHAMMET SELÇUK', '5375728560', 'SELİM IRMALI', '5544658562', 'SANCAKLAR MAH. 2498. SK. ŞÜKRAN-SEDAT ŞENKARDEŞLER ORTAOKULU BLOK NO: 4/1 MERKEZ / DÜZCE', 'sukransedatsenkardesler.meb.k12.tr', NULL, '733522@meb.k12.tr'),
(208, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733531', '100. Yıl Ortaokulu', 'Normal Öğretim', '3805142071', 'Murat Erol', '5055885646', 'Yasin İmamoğlu', '5457301133', 'KARACA MAH. 1335. SK. 100. YIL ORTAOKULU BLOK NO: 13 MERKEZ / DÜZCE', 'duzce100yilortaokul.meb.k12.tr', NULL, '733531@meb.k12.tr'),
(209, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733532', 'Pakmaya Ortaokulu', 'Normal Öğretim', '3805234925', 'Burhanettin DANIŞ', '5446350967', 'Recep DEMİRCİ', '5055575145', 'DERELİTÜTÜNCÜ MAH. TÜTÜNCÜ CAD. PAKMAYA İLK VE ORTA OKULU BLOK NO: 159 MERKEZ / DÜZCE', 'duzcepakmayaortaokulu.meb.k12.tr', NULL, '733532@meb.k12.tr'),
(210, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733535', 'Avni Akyol Ortaokulu', 'Normal Öğretim', '3805122075', 'İsmail İşbilirler', '5056832648', 'Nurettin Dalda', '5553759686', 'AZİZİYE MAH. 893. SK. AVNİ AKYOL ANAOKULU BLOK NO: 58/1 MERKEZ / DÜZCE', 'avniakyolortaokulu.meb.k12.tr', NULL, '733535@meb.k12.tr'),
(211, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733543', 'Azmimilli Ortaokulu', 'Normal Öğretim', '3805142548', 'Gülşah SARIBABA', '5531853232', 'Ali Kemal BEŞEL', '5555001035', 'AZMİMİLLİ MAH. GAZHANE CAD. NO: 66 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'duzceazmimilliortaokulu.meb.k12.tr', NULL, '733543@meb.k12.tr'),
(212, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733553', 'İsmetpaşa Ortaokulu', 'İkili Öğretim', '3805237871', 'HÜSEYİN İLHAN', '5057153981', 'ŞÜKRÜ ŞAHİN', '5054475375', 'ŞEREFİYE MAH. NECATİBEY SK. İSMETPAŞA İLKÖĞRETİM BLOK NO: 4 MERKEZ / DÜZCE', 'duzceismetpasaortaokulu.meb.k12.tr', NULL, '733553@meb.k12.tr'),
(213, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733633', 'Yenitaşköprü Ortaokulu', 'Normal Öğretim', '3805353100', 'MEHMET YILMAZ', '5053977408', 'HAMDİ BOYRAZ', '5364222607', 'YENİ TAŞKÖPRÜ KÖYÜ MERKEZ MEVKİİ 18055. CAD. NO: 42 MERKEZ / DÜZCE', 'yenitaskopruortaokulu.meb.k12.tr', NULL, '733633@meb.k12.tr'),
(214, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733648', 'Nasırlı Ortaokulu', 'Normal Öğretim', '3805578725', 'AHMET OKUR', '5459131333', 'SİNAN ŞENTÜRK', '5334172461', 'NASIRLI KÖYÜ MERKEZ MEVKİİ NO: 99 MERKEZ / DÜZCE', 'nasirliortaokulu.meb.k12.tr', NULL, '733648@meb.k12.tr'),
(215, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733651', 'Şehit Yalçın Güzeler Ortaokulu', 'Normal Öğretim', '3805536007', 'BURCU GÜVEN', '5393778506', 'NAZMİ TURAN', '5057593720', 'DURAKLAR KÖYÜ NO: 1 MERKEZ / DÜZCE', 'sygortaokulu.meb.k12.tr', NULL, '733651@meb.k12.tr'),
(216, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733675', 'Boğaziçi Ortaokulu', 'Normal Öğretim', '3805434385', 'Yüksel DANIŞ', '5418423110', 'Osman SAĞLAM', '5053977437', 'BOĞAZİÇİ BELDESİ YAZLIK MAH. 101 CAD. NO: 142 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'duzcebogaziciortaokulu.meb.k12.tr', NULL, '733675@meb.k12.tr'),
(217, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733690', 'Perihan Tulan Ortaokulu', 'Normal Öğretim', '3805578321', 'Dursun SİLAHDAR', '5054986052', 'Muhammet AK', '5301787200', 'ÇİFTLİK KÖYÜ KÖYÜN KENDİSİ MEVKİİ PERİHAN TULAN ORTAOKULU BLOK NO: 97/1 MERKEZ / DÜZCE', 'perihantulanortaokulu.meb.k12.tr', NULL, '733690@meb.k12.tr'),
(218, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733692', 'Çakırlar Ortaokulu', 'Normal Öğretim', '3805578032', 'Caner BAĞ', '5342815849', 'Gökhan ŞANLI', '5343629085', 'ÇAKIRLAR MAH. 3696. CAD. ÇAKIRLAR İLKOKULU BLOK NO: 16 MERKEZ / DÜZCE', 'cakirlaroo.meb.k12.tr', NULL, '733692@meb.k12.tr'),
(219, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733696', 'Beyciler Ortaokulu', 'Normal Öğretim', '3805260582', 'Ahmet ÖZDEMİR', '5053979816', 'Mehmet BİLCAN', '5056815538', 'BEYCİLER MAH. 1753. SK. BEYCİLER İLK VE ORTA OKULU BLOK NO: 2 MERKEZ / DÜZCE', 'beycilerortaokulu.meb.k12.tr', NULL, '733696@meb.k12.tr'),
(220, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733699', 'Öztermiyeci Ortaokulu', 'Normal Öğretim', '3805144569', 'HÜDAİ DEMİREL', '5377885599', 'CENGİZ ALTIOK', '5064189678', 'CUMHURİYET MAH. 1925. SK. 19 MAYIS İLKÖĞRETİM BLOK NO: 18 MERKEZ / DÜZCE', 'duzce19mayisortaokulu.meb.k12.tr', NULL, '733699@meb.k12.tr'),
(221, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733702', 'Fatih Ortaokulu', 'İkili Öğretim', '3805245311', 'ŞAFAK DUMAN', '5055442699', 'ENGİN KUZU', '5052125497', 'FEVZİÇAKMAK MAH. TEVFİK DEMİR SK. NO: 7/2 MERKEZ / DÜZCE', 'duzcefatihortaokulu.meb.k12.tr', NULL, '733702@meb.k12.tr'),
(222, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733705', 'Aziziye Ortaokulu', 'Normal Öğretim', '3805142468', 'Ebubekir Yılmaz', '5053478731', 'Hayri Akkurt', '5348245555', 'AZİZİYE MAH. 1007. SK. AZİZİYE İLK VE ORTA OKULU BLOK NO: 19 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'aziziyeo.meb.k12.tr', NULL, '733705@meb.k12.tr'),
(223, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733707', 'Rıza Malatyalı Ortaokulu', 'Normal Öğretim', '3805249680', 'Samet ŞAHİN', '5352663344', 'Bayram Ali FİDAN', '5318459087', 'AĞAKÖYÜ MAH. 1991. SK. RIZA MALATYALI İLKÖĞRETİM OKULU BLOK NO: 14 MERKEZ / DÜZCE', 'rizamalatyaliortaokulu.meb.k12.tr', NULL, '733707@meb.k12.tr'),
(224, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '734801', 'Hikmet Akın Ortaokulu', 'Normal Öğretim', '3805249442', 'MUAZZEZ BİLGİN DİKMEN', '5054536299', 'SUAT PERÇİN', '5055705652', 'HAMİDİYE MAH. KIVILCIM SK. HİKMET AKIN ORTAOKULU BLOK NO: 1 MERKEZ / DÜZCE', 'hikmetakin.meb.k12.tr', NULL, '734801@meb.k12.tr'),
(225, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '745688', 'Bilgi Ortaokulu', 'Normal Öğretim', '3804115222', 'Ayhan Yalçın', '5332235512', 'Gürkan Sinar', '5052666787', 'GÜZELBAHÇE MAH. 78. SK. BİLGİORTA OKULU BLOK NO: 18/1 MERKEZ / DÜZCE', 'bilgiortaokulu.meb.k12.tr', NULL, '745688@meb.k12.tr'),
(226, 27, 315, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '759154', 'Hamit Şerifoğlu Ortaokulu', 'Normal Öğretim', '3805260318', 'Bahattin Yılmaz', '5444269793', 'Kerim Güllü', '5343468510', 'KARA HACIMUSA MAH. PINARLAR CAD. NO: 4 MERKEZ / DÜZCE', 'hamitserifogluoo.meb.k12.tr', NULL, '759154@meb.k12.tr'),
(227, 27, 316, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Lisesi', '974763', 'Yığılca Anadolu İmam Hatip Lisesi', 'Normal Öğretim', '3806515616', 'Samet ŞAHİN', '5352663344', 'Bayram Ali FİDAN', '5318459087', 'ORHANGAZİ MAH. LALE SK. YIĞILCA İMAM HATİP LİSESİ BLOK NO: 13 İÇ KAPI NO: 1 YIĞILCA / DÜZCE', 'yigilcaaihl.meb.k12.tr', NULL, '974763@meb.k12.tr'),
(228, 27, 316, 'Din Öğretimi Genel Müdürlüğü', 'İmam Hatip Ortaokulu', '760802', 'Yığılca İmam Hatip Ortaokulu', 'Normal Öğretim', '3806515393', 'RECEP ATIN', '5056483714', 'YÜCEL KINAY', '5077703807', 'ORHANGAZİ MAH. LALE SK. İMAM HATİP ORTAOKULU BLOK NO: 11 İÇ KAPI NO: 1 YIĞILCA / DÜZCE', 'yigilcaiho.meb.k12.tr', NULL, '760802@meb.k12.tr'),
(229, 27, 316, 'Mesleki ve Teknik Eğitim Genel Müdürlüğü', 'Çok Programlı Anadolu Lisesi', '380101', 'Yığılca Çok Programlı Anadolu Lisesi', 'Normal Öğretim', '3806514035', 'Mehmet Yılmaz', '5052629387', 'Rafet Deveci', '5428296831', 'ATATÜRK MAH. ATATÜRK CAD. ÇPL ANADOLU LİSESİ SİTESİ A BLOK NO: 92/2 YIĞILCA / DÜZCE', 'yigilcacpl.meb.k12.tr', NULL, '380101@meb.k12.tr'),
(230, 27, 316, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '731995', 'Mevlana İlkokulu', 'Normal Öğretim', '3806515115', 'RECEP ALTIN', '5056483714', 'NAZİM KARACA', '5065591338', 'ORHANGAZİ MAH. AHMETÇİLER CAD. MEVLANA İLKOKULU BLOK NO: 11 YIĞILCA / DÜZCE', 'mevlanailkokull.meb.k12.tr', NULL, '731995@meb.k12.tr'),
(231, 27, 316, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '732009', 'Anadolu Kalkınma Vakfı Cumhuriyet İlkokulu', 'Normal Öğretim', '3806516359', 'VELİ VERGİLİ', '5064189664', 'YOK', '5055055050', 'DOĞANLAR KÖYÜ VAYISLAR MEVKİİ NO: 7 YIĞILCA / DÜZCE', 'akvcumhuriyetio.meb.k12.tr', NULL, '732009@meb.k12.tr'),
(232, 27, 316, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733468', 'Kırık İlkokulu', 'Normal Öğretim', '3806641245', 'Alaettin Ergün', '5435609248', 'Sevil Kılıç', '5551840831', 'KIRIK KÖYÜ KARAKİRAZ MEVKİİ NO: 24 YIĞILCA / DÜZCE', 'kirikilkokulu.meb.k12.tr', NULL, '733468@meb.k12.tr'),
(233, 27, 316, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '733562', 'Gazi İlkokulu', 'Normal Öğretim', '3806515120', 'MUSTAFA BAĞCI', '5347992840', 'OKTAY ACAR', '5392169211', 'AHMETÇİLER MAH. AHMETÇİLER CAD. NO: 12-1 İÇ KAPI NO: 12 YIĞILCA / DÜZCE', 'gaziilkokulu81.meb.k12.tr', NULL, '733562@meb.k12.tr'),
(234, 27, 316, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '735294', 'Aksaklar İlkokulu', 'Normal Öğretim', '3806516094', 'Bayram BASKIN', '5056966567', 'Elvan BASKIN', '5057423520', 'AKSAKLAR KÖYÜ ORTA MEVKİİ NO: 18 YIĞILCA / DÜZCE', 'aksaklarilkokulu.meb.k12.tr', NULL, '735294@meb.k12.tr'),
(235, 27, 316, 'Temel Eğitim Genel Müdürlüğü', 'İlkokul', '746147', 'Hacıyeri İlkokulu', 'Normal Öğretim', '3806671020', 'Kerem Bozoğlu', '5454149333', 'Kerem Bozoğlu', '5454149333', 'HACIYERİ KÖYÜ MERKEZ MEVKİİ NO: 1 YIĞILCA / DÜZCE', 'haciyeriio.meb.k12.tr', NULL, '746147@meb.k12.tr'),
(236, 27, 316, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '731991', 'Mevlana Ortaokulu', 'Normal Öğretim', '3806515115', 'Ercan BAŞTÜRK', '5376828549', 'Hacer ÖZTÜRK', '5356458658', 'ORHANGAZİ MAH. AHMETÇİLER CAD. İMAM HATİP ORTA OKULU BLOK NO: 11/1A YIĞILCA / DÜZCE', 'mevlanaortaokul.meb.k12.tr', NULL, '731991@meb.k12.tr'),
(237, 27, 316, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '733466', 'Kırık Ortaokulu', 'Normal Öğretim', '3806641245', 'Alaettin Ergün', '5435609248', 'Sevil Kılıç', '5551840831', 'KIRIK KÖYÜ KARAKİRAZ MEVKİİ NO: 24 YIĞILCA / DÜZCE', 'kirikortaokulu.meb.k12.tr', NULL, '733466@meb.k12.tr'),
(238, 27, 316, 'Temel Eğitim Genel Müdürlüğü', 'Ortaokul', '735289', 'Aksaklar Ortaokulu', 'Normal Öğretim', '3806516094', 'Bayram BASKIN', '5056966567', 'Elvan BASKIN', '5057423520', 'AKSAKLAR KÖYÜ ORTA MEVKİİ NO: 18 YIĞILCA / DÜZCE', 'aksaklarortaokulu.meb.k12.tr', NULL, '735289@meb.k12.tr'),
(239, 27, 316, 'Temel Eğitim Genel Müdürlüğü', 'Yatılı Bölge Ortaokulu', '748379', 'Orhangazi Yatılı Bölge Ortaokulu', 'Normal Öğretim', '3806514004', 'Lütfi Kırmanoğlu', '5056768591', 'Enes KAHRAMAN', '5549389738', 'MAREŞAL FEVZİ ÇAKMAK MAH. İNCİRLER KÜME EVLERİ NO: 58 İÇ KAPI NO: A YIĞILCA / DÜZCE', 'orhangaziybo.meb.k12.tr', NULL, '748379@meb.k12.tr'),
(240, 27, 311, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Mesleki ve Teknik Anadolu Lisesi', '99955011', 'ÖZEL DÜZCE MESLEKİ VE TEKNİK ANADOLU LİSESİ', 'Normal Öğretim', '3805233210', 'AHMET KOÇBAY', '5055833500', 'EBRU YAVUZ GÖK', '5315592616', 'TOPÇULAR MAH. DÜZCE CADDE NO:69 PK:81750 ÇİLİMLİ/DÜZCE', 'www.duzceanadolusaglikmesleklisesi.com', NULL, '99955011@meb.k12.tr'),
(241, 27, 311, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Mesleki ve Teknik Anadolu Lisesi', '99977200', 'ÖZEL DÜZCE MİMAR SİNAN MESLEKİ VE TEKNİK ANADOLU LİSESİ', 'Normal Öğretim', '5322427544', 'METİN ZORLU', '5326508181', 'İKRAMETTİN ŞAHİN', '5055262180', 'TOPÇULAR MAH. DÜZCE CAD. NO: 69-4 ÇİLİMLİ / DÜZCE', NULL, NULL, '99977200@meb.k12.tr'),
(242, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Anadolu Lisesi', '99911836', 'DÜZCE ÖZEL DOĞA ANADOLU LİSESİ', 'Normal Öğretim', '3805248000', 'Elif Özgüner', '5327747656', 'Özgü Direk Ertuğ', '5054426683', 'ŞIRALIK MAH. 5615. CAD. ÖZEL DOĞA KOLEJİ BLOK NO: 34/1 MERKEZ / DÜZCE', NULL, NULL, '99911836@meb.k12.tr'),
(243, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Anadolu Lisesi', '99957291', 'ÖZEL DÜZCE KÜLTÜR ANADOLU LİSESİ', 'Normal Öğretim', '3800000000', 'M.Ali Önder', '5322606968', 'M.Ali Önder', '5322606968', 'NUSRETTİN MAH. BOLU CAD. FİSKOBİRLİK BLOK NO: 95 İÇ KAPI NO: Z 01 MERKEZ / DÜZCE', NULL, NULL, '99957291@meb.k12.tr'),
(244, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Anadolu Lisesi', '99982424', 'ÖZEL DÜZCE BAHÇEŞEHİR KOLEJİ ANADOLU LİSESİ', 'Normal Öğretim', '3805263040', 'Tuğba Ayaz Şahin', '5058185875', 'Yok', '5050000000', 'MERKEZ MAH. KÖY SOKAĞI NO:15 PK:81100 MERKEZ/DÜZCE', 'www.bahcesehir.k12.tr', NULL, '99982424@meb.k12.tr'),
(245, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Anadolu Lisesi', '99986472', 'ÖZEL DÜZCE FİNAL ANADOLU LİSESİ', 'Normal Öğretim', '3805242824', 'Ersin Acar', '5547906099', 'Efe Zorlu', '5344117814', 'ÇAY MAH. 565. SK. NO: 5 İÇ KAPI NO: 0 MERKEZ / DÜZCE', NULL, NULL, '99986472@meb.k12.tr'),
(246, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Anadolu Lisesi', '99987051', 'ÖZEL DÜZCE UĞUR ANADOLU LİSESİ', 'Normal Öğretim', '3805242526', 'Mustafa BAŞORMANCI', '5056839131', 'Metehan IŞIK', '5074493520', 'KÖRPEŞLER MAH. 1425. SK. ÖZEL ÖZUĞUR EĞİTİM HİZMETLERİ BLOK NO: 8 İÇ KAPI NO: 0 MERKEZ / DÜZCE', NULL, NULL, '99987051@meb.k12.tr'),
(247, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Anadolu Lisesi', '99987370', 'ÖZEL DÜZCE FİNAL KAMPÜS ANADOLU LİSESİ', 'Normal Öğretim', '3804111212', 'Hülya Bayram Tuna', '5079725954', 'Hülya Bayram Tuna', '5079725954', 'YAHYALAR MAH. 5099. BUL. NO: 56 MERKEZ / DÜZCE', NULL, NULL, '99987370@meb.k12.tr'),
(248, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Fen Lisesi', '99912608', 'DÜZCE ÖZEL DOĞA FEN LİSESİ', 'Normal Öğretim', '3805248000', 'Elif Özgüner', '5327747656', 'Özgü Direk Ertuğ', '5054426683', 'ŞIRALIK MAH. 5615. CAD. ÖZEL DOĞA KOLEJİ BLOK NO: 34/1 MERKEZ / DÜZCE', NULL, NULL, '99912608@meb.k12.tr'),
(249, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Fen Lisesi', '99961285', 'ÖZEL DÜZCE KÜLTÜR FEN LİSESİ', 'Normal Öğretim', '3805233194', 'Birol Güney', '5323609958', 'Birol Güney', '5323609958', 'NUSRETTİN MAH. BOLU CAD. FİSKOBİRLİK BLOK NO: 95 İÇ KAPI NO: Z 01 MERKEZ / DÜZCE', NULL, NULL, '99961285@meb.k12.tr'),
(250, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Fen Lisesi', '99987052', 'ÖZEL DÜZCE UĞUR FEN LİSESİ', 'Normal Öğretim', '3805242526', 'Mustafa BAŞORMANCI', '5056839131', 'Nurten KARACA', '5355477150', 'KÖRPEŞLER MAH. 1425. SK. ÖZEL ÖZUĞUR EĞİTİM HİZMETLERİ BLOK NO: 8 İÇ KAPI NO: 0 MERKEZ / DÜZCE', NULL, NULL, '99987052@meb.k12.tr'),
(251, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Fen Lisesi', '99987372', 'ÖZEL DÜZCE FİNAL KAMPÜS FEN LİSESİ', 'Normal Öğretim', '3804111212', 'Hülya Bayram Tuna', '5079725954', 'Hülya Bayram Tuna', '5079725954', 'YAHYALAR MAH. 5099. BUL. NO: 56 MERKEZ / DÜZCE', NULL, NULL, '99987372@meb.k12.tr'),
(252, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk İlkokulu', '99911588', 'DÜZCE ÖZEL DOĞA İLKOKULU', 'Normal Öğretim', '3805248000', 'Asude Çelik', '5324946660', 'Fatma Demirtaş', '5055733065', 'ŞIRALIK MAH. 5615. CAD. ÖZEL DOĞA KOLEJİ BLOK NO: 34/1 MERKEZ / DÜZCE', NULL, NULL, '99911588@meb.k12.tr'),
(253, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk İlkokulu', '99912222', 'ÖZEL DÜZCE KÜLTÜR İLKOKULU', 'Normal Öğretim', '3804445581', 'MUSTAFA SARI', '5058060408', 'ÖMER ARABACI', '5543383430', 'KOÇYAZI MAH. 2328. SK. NO: 8 İÇ KAPI NO: 1 MERKEZ / DÜZCE', NULL, NULL, '99912222@meb.k12.tr'),
(254, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk İlkokulu', '99957572', 'ÖZEL SU DAMLASI İLKOKULU', 'Normal Öğretim', '3805145512', 'Elvan ŞAKAR', '5336938395', 'Elvan ŞAKAR', '5336938395', 'ARAPÇİFTLİĞİ MAH. 2890. CAD. ÖZEL SU DAMLASI İLK OKULU BLOK NO: 69 MERKEZ / DÜZCE', NULL, NULL, '99957572@meb.k12.tr'),
(255, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk İlkokulu', '99970891', 'ÖZEL SARAY İLKOKULU', 'Normal Öğretim', '3805142111', 'Mecit GÜNEŞ', '5334246481', 'İdris KARADUMAN', '5415834235', 'PINARLAR KÖYÜ SARAY ÖZEL EĞİTİM SİTESİ NO: 81-1 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'SARAYOKULLARİ.COM', NULL, '99970891@meb.k12.tr'),
(256, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk İlkokulu', '99971366', 'ÖZEL DÜZCE SAFİR İLKOKULU', 'Normal Öğretim', '3805242525', 'Selçuk Şen', '5426545332', 'Mehmet Aloğlu', '5353022054', 'ÇAY MAH. SAATÇİGİL CAD. NO: 69 MERKEZ / DÜZCE', NULL, NULL, '99971366@meb.k12.tr'),
(257, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk İlkokulu', '99982425', 'ÖZEL DÜZCE BAHÇEŞEHİR KOLEJİ İLKOKULU', 'Normal Öğretim', '3805263040', 'Derya Özmen Kansu', '5308941811', 'Derya Özmen Kansu', '5308941811', 'ARAPÇİFTLİĞİ MAH. 3039. SK. NO: 15 İÇ KAPI NO: 0 MERKEZ / DÜZCE', 'www.bahcesehir.k12.tr', NULL, '99982425@meb.k12.tr'),
(258, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk İlkokulu', '99987367', 'ÖZEL DÜZCE FİNAL KAMPÜS İLKOKULU', 'Normal Öğretim', '3804111212', 'Tuğce Sönmez', '5349239849', 'Tuğçe Sönmez', '5349239849', 'YAHYALAR MAH. 5099. BUL. NO: 56 MERKEZ / DÜZCE', NULL, NULL, '99987367@meb.k12.tr'),
(259, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk Ortaokulu', '99952263', 'DÜZCE ÖZEL DOĞA ORTAOKULU', 'Normal Öğretim', '3805248000', 'Elif Özgüner', '5327747656', 'Eda Kaim', '5385639363', 'ŞIRALIK MAH. 5615. CAD. ÖZEL DOĞA KOLEJİ BLOK NO: 34/1 MERKEZ / DÜZCE', NULL, NULL, '99952263@meb.k12.tr'),
(260, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk Ortaokulu', '99952510', 'ÖZEL DÜZCE KÜLTÜR ORTAOKULU', 'Normal Öğretim', '3804445581', 'MURAT SERT', '5438233986', 'SELDA ÖZTÜRK', '5422011472', 'KOÇYAZI MAH. 2328. SK. NO: 8 İÇ KAPI NO: 1 MERKEZ / DÜZCE', NULL, NULL, '99952510@meb.k12.tr'),
(261, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk Ortaokulu', '99970892', 'ÖZEL SARAY ORTAOKULU', 'Normal Öğretim', '3805142111', 'Mecit GÜNEŞ', '5334246481', 'Mustafa HANCI', '5347970363', 'PINARLAR KÖYÜ SARAY ÖZEL EĞİTİM SİTESİ NO: 81-1 İÇ KAPI NO: 1 MERKEZ / DÜZCE', 'sarayokullari.com', NULL, '99970892@meb.k12.tr'),
(262, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk Ortaokulu', '99971370', 'ÖZEL DÜZCE SAFİR ORTAOKULU', 'Normal Öğretim', '3805242525', 'Selçuk Şen', '5426545332', 'Oğuzhan Kayacu', '5071564241', 'ÇAY MAH. SAATÇİGİL CAD. NO: 69 MERKEZ / DÜZCE', NULL, NULL, '99971370@meb.k12.tr'),
(263, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk Ortaokulu', '99977939', 'ÖZEL SU DAMLASI ORTAOKULU', 'Normal Öğretim', '3805145512', 'Melek Özgüner', '5327150388', 'Melek Özgüner', '5327150388', 'ARAPÇİFTLİĞİ MAH. 2890. CAD. NO: 71 İÇ KAPI NO: 0 MERKEZ / DÜZCE', NULL, NULL, '99977939@meb.k12.tr'),
(264, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk Ortaokulu', '99982426', 'ÖZEL DÜZCE BAHÇEŞEHİR KOLEJİ ORTAOKULU', 'Normal Öğretim', '3805263040', 'Tuğba Ayaz Şahin', '5058185875', 'Yok', '5050000000', 'ARAPÇİFTLİĞİ MAH. 3039. SK. NO: 15 İÇ KAPI NO: 0 MERKEZ / DÜZCE', 'www.bahcesehir.k12.tr', NULL, '99982426@meb.k12.tr'),
(265, 27, 315, 'Özel Öğretim Kurumları Genel Müdürlüğü', 'Özel Türk Ortaokulu', '99987368', 'ÖZEL DÜZCE FİNAL KAMPÜS ORTAOKULU', 'Normal Öğretim', '3804111212', 'Tuğçe Sönmez', '5349239849', 'Tuğçe Sönmez', '5349239849', 'YAHYALAR MAH. 5099. BUL. NO: 56 MERKEZ / DÜZCE', NULL, NULL, '99987368@meb.k12.tr');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(128) COLLATE utf8_turkish_ci NOT NULL,
  `description` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `createDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `base_role` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`, `createDate`, `base_role`) VALUES
(1, 'Admin', 'Yöneticiler için tanımlanan roldür.', '2021-06-28 10:19:11', 1),
(2, 'User', 'Kullanıcılar için tanımlanan roldür.', '2019-04-22 10:19:25', 1),
(3, 'Öğretmen', 'Öğretmen kullanıcıları için tanımlanan roldür.', '2020-05-14 14:54:30', 1),
(4, 'Uzman', 'Uzman kullanıcılar için tanımlanan roldür.', '2020-05-14 14:59:24', 1),
(5, 'VHKİ', 'Veri Hazırlama ve Kontrol İşletmeni', '2021-06-30 17:49:51', 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `site_bilgileri`
--

CREATE TABLE `site_bilgileri` (
  `id` int(11) NOT NULL,
  `site_adi` varchar(255) NOT NULL,
  `site_slogani` varchar(255) NOT NULL,
  `site_adresi` varchar(255) NOT NULL,
  `site_aktif` tinyint(1) NOT NULL DEFAULT 1,
  `firma_adi` varchar(255) NOT NULL,
  `firma_tel1` varchar(255) NOT NULL,
  `firma_tel2` varchar(255) NOT NULL,
  `firma_gsm` varchar(255) NOT NULL,
  `firma_eposta` varchar(255) NOT NULL,
  `site_eposta` varchar(255) NOT NULL,
  `firma_sorumlusu` varchar(255) NOT NULL,
  `firma_adres` text NOT NULL,
  `anahtar_kelimeler` varchar(255) NOT NULL,
  `facebook_url` varchar(255) NOT NULL,
  `twitter_url` varchar(255) NOT NULL,
  `instagram_url` varchar(255) NOT NULL,
  `firma_fax` varchar(255) NOT NULL,
  `google_site_verification_code` text NOT NULL,
  `google_analytics_code` varchar(255) NOT NULL,
  `license_number` text DEFAULT NULL,
  `license_start_date` text DEFAULT NULL,
  `license_end_date` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Tablo döküm verisi `site_bilgileri`
--

INSERT INTO `site_bilgileri` (`id`, `site_adi`, `site_slogani`, `site_adresi`, `site_aktif`, `firma_adi`, `firma_tel1`, `firma_tel2`, `firma_gsm`, `firma_eposta`, `site_eposta`, `firma_sorumlusu`, `firma_adres`, `anahtar_kelimeler`, `facebook_url`, `twitter_url`, `instagram_url`, `firma_fax`, `google_site_verification_code`, `google_analytics_code`, `license_number`, `license_start_date`, `license_end_date`) VALUES
(1, 'Düzce ÖDM Soru Havuzu', 'Soru Havuzu Uygulaması', 'soruhavuzu.emrebodur.com', 1, 'Düzce Ölçme Değerlendirme Merkezi Müdürlüğü', '5547293383', '2128764520 ', '5547293383', 'soruhavuzu@emrebodur.com', 'noreply@logista.com.tr ', 'Emre Bodur', 'Kuyumcuzade Bulvarı No:23 Merkez / Düzce\r\n', 'logista kurye ve lojistik hizmetleri, logista, logista.com.tr, logista lojistik, logista kurye', 'https://www.facebook.com/logistatr/', 'https://twitter.com/logistakurye', 'https://www.instagram.com/logistakurye/', '2128764041', 'p6gXJxCfgBz8cJx18wsl9j0kFlGKpaZApdm8PAFhCTs', 'UA-97394039-2', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sorular`
--

CREATE TABLE `sorular` (
  `id` int(11) NOT NULL,
  `no` text NOT NULL,
  `kodu` text NOT NULL,
  `dersID` int(11) NOT NULL,
  `sinifDuzeyi` int(11) NOT NULL,
  `zorlukDerecesi` int(11) NOT NULL,
  `uniteID` int(11) NOT NULL,
  `konuID` int(11) NOT NULL,
  `kazanimID` int(11) NOT NULL,
  `madde_koku` text NOT NULL,
  `dogru_cevap` text NOT NULL,
  `dogrulama_kodu` varchar(255) NOT NULL,
  `onay_durumu` tinyint(4) NOT NULL DEFAULT 1,
  `kayit_tarihi` datetime NOT NULL DEFAULT current_timestamp(),
  `userID` int(11) NOT NULL,
  `onaylayanUserID` int(11) NOT NULL,
  `uzman_yorumu` text NOT NULL,
  `okulTuru` int(11) NOT NULL,
  `cevap_a` text NOT NULL,
  `cevap_b` text NOT NULL,
  `cevap_c` text NOT NULL,
  `cevap_d` text NOT NULL,
  `cevap_e` text DEFAULT NULL,
  `duzenlenebilir` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `town`
--

CREATE TABLE `town` (
  `TownID` int(11) NOT NULL,
  `CityID` int(11) NOT NULL,
  `TownName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `town`
--

INSERT INTO `town` (`TownID`, `CityID`, `TownName`) VALUES
(1, 1, 'ALADAĞ'),
(2, 1, 'CEYHAN'),
(3, 1, 'ÇUKUROVA'),
(4, 1, 'FEKE'),
(5, 1, 'İMAMOĞLU'),
(6, 1, 'KARAİSALI'),
(7, 1, 'KARATAŞ'),
(8, 1, 'KOZAN'),
(9, 1, 'POZANTI'),
(10, 1, 'SAİMBEYLİ'),
(11, 1, 'SARIÇAM'),
(12, 1, 'SEYHAN'),
(13, 1, 'TUFANBEYLİ'),
(14, 1, 'YUMURTALIK'),
(15, 1, 'YÜREĞİR'),
(16, 2, 'BESNİ'),
(17, 2, 'ÇELİKHAN'),
(18, 2, 'GERGER'),
(19, 2, 'GÖLBAŞI'),
(20, 2, 'KAHTA'),
(21, 2, 'MERKEZ'),
(22, 2, 'SAMSAT'),
(23, 2, 'SİNCİK'),
(24, 2, 'TUT'),
(25, 3, 'BAŞMAKÇI'),
(26, 3, 'BAYAT'),
(27, 3, 'BOLVADİN'),
(28, 3, 'ÇAY'),
(29, 3, 'ÇOBANLAR'),
(30, 3, 'DAZKIRI'),
(31, 3, 'DİNAR'),
(32, 3, 'EMİRDAĞ'),
(33, 3, 'EVCİLER'),
(34, 3, 'HOCALAR'),
(35, 3, 'İHSANİYE'),
(36, 3, 'İSCEHİSAR'),
(37, 3, 'KIZILÖREN'),
(38, 3, 'MERKEZ'),
(39, 3, 'SANDIKLI'),
(40, 3, 'SİNANPAŞA'),
(41, 3, 'SULTANDAĞI'),
(42, 3, 'ŞUHUT'),
(43, 4, 'DİYADİN'),
(44, 4, 'DOĞUBAYAZIT'),
(45, 4, 'ELEŞKİRT'),
(46, 4, 'HAMUR'),
(47, 4, 'MERKEZ'),
(48, 4, 'PATNOS'),
(49, 4, 'TAŞLIÇAY'),
(50, 4, 'TUTAK'),
(51, 5, 'AĞAÇÖREN'),
(52, 5, 'ESKİL'),
(53, 5, 'GÜLAĞAÇ'),
(54, 5, 'GÜZELYURT'),
(55, 5, 'MERKEZ'),
(56, 5, 'ORTAKÖY'),
(57, 5, 'SARIYAHŞİ'),
(58, 5, 'SULTANHANI'),
(59, 6, 'GÖYNÜCEK'),
(60, 6, 'GÜMÜŞHACIKÖY'),
(61, 6, 'HAMAMÖZÜ'),
(62, 6, 'MERKEZ'),
(63, 6, 'MERZİFON'),
(64, 6, 'SULUOVA'),
(65, 6, 'TAŞOVA'),
(66, 7, 'AKYURT'),
(67, 7, 'ALTINDAĞ'),
(68, 7, 'AYAŞ'),
(69, 7, 'BALA'),
(70, 7, 'BEYPAZARI'),
(71, 7, 'ÇAMLIDERE'),
(72, 7, 'ÇANKAYA'),
(73, 7, 'ÇUBUK'),
(74, 7, 'ELMADAĞ'),
(75, 7, 'ETİMESGUT'),
(76, 7, 'EVREN'),
(77, 7, 'GÖLBAŞI'),
(78, 7, 'GÜDÜL'),
(79, 7, 'HAYMANA'),
(80, 7, 'KAHRAMANKAZAN'),
(81, 7, 'KALECİK'),
(82, 7, 'KEÇİÖREN'),
(83, 7, 'KIZILCAHAMAM'),
(84, 7, 'MAMAK'),
(85, 7, 'NALLIHAN'),
(86, 7, 'POLATLI'),
(87, 7, 'PURSAKLAR'),
(88, 7, 'SİNCAN'),
(89, 7, 'ŞEREFLİKOÇHİSAR'),
(90, 7, 'YENİMAHALLE'),
(91, 8, 'AKSEKİ'),
(92, 8, 'AKSU'),
(93, 8, 'ALANYA'),
(94, 8, 'DEMRE'),
(95, 8, 'DÖŞEMEALTI'),
(96, 8, 'ELMALI'),
(97, 8, 'FİNİKE'),
(98, 8, 'GAZİPAŞA'),
(99, 8, 'GÜNDOĞMUŞ'),
(100, 8, 'İBRADI'),
(101, 8, 'KAŞ'),
(102, 8, 'KEMER'),
(103, 8, 'KEPEZ'),
(104, 8, 'KONYAALTI'),
(105, 8, 'KORKUTELİ'),
(106, 8, 'KUMLUCA'),
(107, 8, 'MANAVGAT'),
(108, 8, 'MURATPAŞA'),
(109, 8, 'SERİK'),
(110, 9, 'ÇILDIR'),
(111, 9, 'DAMAL'),
(112, 9, 'GÖLE'),
(113, 9, 'HANAK'),
(114, 9, 'MERKEZ'),
(115, 9, 'POSOF'),
(116, 10, 'ARDANUÇ'),
(117, 10, 'ARHAVİ'),
(118, 10, 'BORÇKA'),
(119, 10, 'HOPA'),
(120, 10, 'KEMALPAŞA'),
(121, 10, 'MERKEZ'),
(122, 10, 'MURGUL'),
(123, 10, 'ŞAVŞAT'),
(124, 10, 'YUSUFELİ'),
(125, 11, 'BOZDOĞAN'),
(126, 11, 'BUHARKENT'),
(127, 11, 'ÇİNE'),
(128, 11, 'DİDİM'),
(129, 11, 'EFELER'),
(130, 11, 'GERMENCİK'),
(131, 11, 'İNCİRLİOVA'),
(132, 11, 'KARACASU'),
(133, 11, 'KARPUZLU'),
(134, 11, 'KOÇARLI'),
(135, 11, 'KÖŞK'),
(136, 11, 'KUŞADASI'),
(137, 11, 'KUYUCAK'),
(138, 11, 'NAZİLLİ'),
(139, 11, 'SÖKE'),
(140, 11, 'SULTANHİSAR'),
(141, 11, 'YENİPAZAR'),
(142, 12, 'ALTIEYLÜL'),
(143, 12, 'AYVALIK'),
(144, 12, 'BALYA'),
(145, 12, 'BANDIRMA'),
(146, 12, 'BİGADİÇ'),
(147, 12, 'BURHANİYE'),
(148, 12, 'DURSUNBEY'),
(149, 12, 'EDREMİT'),
(150, 12, 'ERDEK'),
(151, 12, 'GÖMEÇ'),
(152, 12, 'GÖNEN'),
(153, 12, 'HAVRAN'),
(154, 12, 'İVRİNDİ'),
(155, 12, 'KARESİ'),
(156, 12, 'KEPSUT'),
(157, 12, 'MANYAS'),
(158, 12, 'MARMARA'),
(159, 12, 'SAVAŞTEPE'),
(160, 12, 'SINDIRGI'),
(161, 12, 'SUSURLUK'),
(162, 13, 'AMASRA'),
(163, 13, 'KURUCAŞİLE'),
(164, 13, 'MERKEZ'),
(165, 13, 'ULUS'),
(166, 14, 'BEŞİRİ'),
(167, 14, 'GERCÜŞ'),
(168, 14, 'HASANKEYF'),
(169, 14, 'KOZLUK'),
(170, 14, 'MERKEZ'),
(171, 14, 'SASON'),
(172, 15, 'AYDINTEPE'),
(173, 15, 'DEMİRÖZÜ'),
(174, 15, 'MERKEZ'),
(175, 16, 'BOZÜYÜK'),
(176, 16, 'GÖLPAZARI'),
(177, 16, 'İNHİSAR'),
(178, 16, 'MERKEZ'),
(179, 16, 'OSMANELİ'),
(180, 16, 'PAZARYERİ'),
(181, 16, 'SÖĞÜT'),
(182, 16, 'YENİPAZAR'),
(183, 17, 'ADAKLI'),
(184, 17, 'GENÇ'),
(185, 17, 'KARLIOVA'),
(186, 17, 'KİĞI'),
(187, 17, 'MERKEZ'),
(188, 17, 'SOLHAN'),
(189, 17, 'YAYLADERE'),
(190, 17, 'YEDİSU'),
(191, 18, 'ADİLCEVAZ'),
(192, 18, 'AHLAT'),
(193, 18, 'GÜROYMAK'),
(194, 18, 'HİZAN'),
(195, 18, 'MERKEZ'),
(196, 18, 'MUTKİ'),
(197, 18, 'TATVAN'),
(198, 19, 'DÖRTDİVAN'),
(199, 19, 'GEREDE'),
(200, 19, 'GÖYNÜK'),
(201, 19, 'KIBRISCIK'),
(202, 19, 'MENGEN'),
(203, 19, 'MERKEZ'),
(204, 19, 'MUDURNU'),
(205, 19, 'SEBEN'),
(206, 19, 'YENİÇAĞA'),
(207, 20, 'AĞLASUN'),
(208, 20, 'ALTINYAYLA'),
(209, 20, 'BUCAK'),
(210, 20, 'ÇAVDIR'),
(211, 20, 'ÇELTİKÇİ'),
(212, 20, 'GÖLHİSAR'),
(213, 20, 'KARAMANLI'),
(214, 20, 'KEMER'),
(215, 20, 'MERKEZ'),
(216, 20, 'TEFENNİ'),
(217, 20, 'YEŞİLOVA'),
(218, 21, 'BÜYÜKORHAN'),
(219, 21, 'GEMLİK'),
(220, 21, 'GÜRSU'),
(221, 21, 'HARMANCIK'),
(222, 21, 'İNEGÖL'),
(223, 21, 'İZNİK'),
(224, 21, 'KARACABEY'),
(225, 21, 'KELES'),
(226, 21, 'KESTEL'),
(227, 21, 'MUDANYA'),
(228, 21, 'MUSTAFAKEMALPAŞA'),
(229, 21, 'NİLÜFER'),
(230, 21, 'ORHANELİ'),
(231, 21, 'ORHANGAZİ'),
(232, 21, 'OSMANGAZİ'),
(233, 21, 'YENİŞEHİR'),
(234, 21, 'YILDIRIM'),
(235, 22, 'AYVACIK'),
(236, 22, 'BAYRAMİÇ'),
(237, 22, 'BİGA'),
(238, 22, 'BOZCAADA'),
(239, 22, 'ÇAN'),
(240, 22, 'ECEABAT'),
(241, 22, 'EZİNE'),
(242, 22, 'GELİBOLU'),
(243, 22, 'GÖKÇEADA'),
(244, 22, 'LAPSEKİ'),
(245, 22, 'MERKEZ'),
(246, 22, 'YENİCE'),
(247, 23, 'ATKARACALAR'),
(248, 23, 'BAYRAMÖREN'),
(249, 23, 'ÇERKEŞ'),
(250, 23, 'ELDİVAN'),
(251, 23, 'ILGAZ'),
(252, 23, 'KIZILIRMAK'),
(253, 23, 'KORGUN'),
(254, 23, 'KURŞUNLU'),
(255, 23, 'MERKEZ'),
(256, 23, 'ORTA'),
(257, 23, 'ŞABANÖZÜ'),
(258, 23, 'YAPRAKLI'),
(259, 24, 'ALACA'),
(260, 24, 'BAYAT'),
(261, 24, 'BOĞAZKALE'),
(262, 24, 'DODURGA'),
(263, 24, 'İSKİLİP'),
(264, 24, 'KARGI'),
(265, 24, 'LAÇİN'),
(266, 24, 'MECİTÖZÜ'),
(267, 24, 'MERKEZ'),
(268, 24, 'OĞUZLAR'),
(269, 24, 'ORTAKÖY'),
(270, 24, 'OSMANCIK'),
(271, 24, 'SUNGURLU'),
(272, 24, 'UĞURLUDAĞ'),
(273, 25, 'ACIPAYAM'),
(274, 25, 'BABADAĞ'),
(275, 25, 'BAKLAN'),
(276, 25, 'BEKİLLİ'),
(277, 25, 'BEYAĞAÇ'),
(278, 25, 'BOZKURT'),
(279, 25, 'BULDAN'),
(280, 25, 'ÇAL'),
(281, 25, 'ÇAMELİ'),
(282, 25, 'ÇARDAK'),
(283, 25, 'ÇİVRİL'),
(284, 25, 'GÜNEY'),
(285, 25, 'HONAZ'),
(286, 25, 'KALE'),
(287, 25, 'MERKEZEFENDİ'),
(288, 25, 'PAMUKKALE'),
(289, 25, 'SARAYKÖY'),
(290, 25, 'SERİNHİSAR'),
(291, 25, 'TAVAS'),
(292, 26, 'BAĞLAR'),
(293, 26, 'BİSMİL'),
(294, 26, 'ÇERMİK'),
(295, 26, 'ÇINAR'),
(296, 26, 'ÇÜNGÜŞ'),
(297, 26, 'DİCLE'),
(298, 26, 'EĞİL'),
(299, 26, 'ERGANİ'),
(300, 26, 'HANİ'),
(301, 26, 'HAZRO'),
(302, 26, 'KAYAPINAR'),
(303, 26, 'KOCAKÖY'),
(304, 26, 'KULP'),
(305, 26, 'LİCE'),
(306, 26, 'SİLVAN'),
(307, 26, 'SUR'),
(308, 26, 'YENİŞEHİR'),
(309, 27, 'AKÇAKOCA'),
(310, 27, 'CUMAYERİ'),
(311, 27, 'ÇİLİMLİ'),
(312, 27, 'GÖLYAKA'),
(313, 27, 'GÜMÜŞOVA'),
(314, 27, 'KAYNAŞLI'),
(315, 27, 'MERKEZ'),
(316, 27, 'YIĞILCA'),
(317, 28, 'ENEZ'),
(318, 28, 'HAVSA'),
(319, 28, 'İPSALA'),
(320, 28, 'KEŞAN'),
(321, 28, 'LALAPAŞA'),
(322, 28, 'MERİÇ'),
(323, 28, 'MERKEZ'),
(324, 28, 'SÜLOĞLU'),
(325, 28, 'UZUNKÖPRÜ'),
(326, 29, 'AĞIN'),
(327, 29, 'ALACAKAYA'),
(328, 29, 'ARICAK'),
(329, 29, 'BASKİL'),
(330, 29, 'KARAKOÇAN'),
(331, 29, 'KEBAN'),
(332, 29, 'KOVANCILAR'),
(333, 29, 'MADEN'),
(334, 29, 'MERKEZ'),
(335, 29, 'PALU'),
(336, 29, 'SİVRİCE'),
(337, 30, 'ÇAYIRLI'),
(338, 30, 'İLİÇ'),
(339, 30, 'KEMAH'),
(340, 30, 'KEMALİYE'),
(341, 30, 'MERKEZ'),
(342, 30, 'OTLUKBELİ'),
(343, 30, 'REFAHİYE'),
(344, 30, 'TERCAN'),
(345, 30, 'ÜZÜMLÜ'),
(346, 31, 'AŞKALE'),
(347, 31, 'AZİZİYE'),
(348, 31, 'ÇAT'),
(349, 31, 'HINIS'),
(350, 31, 'HORASAN'),
(351, 31, 'İSPİR'),
(352, 31, 'KARAÇOBAN'),
(353, 31, 'KARAYAZI'),
(354, 31, 'KÖPRÜKÖY'),
(355, 31, 'NARMAN'),
(356, 31, 'OLTU'),
(357, 31, 'OLUR'),
(358, 31, 'PALANDÖKEN'),
(359, 31, 'PASİNLER'),
(360, 31, 'PAZARYOLU'),
(361, 31, 'ŞENKAYA'),
(362, 31, 'TEKMAN'),
(363, 31, 'TORTUM'),
(364, 31, 'UZUNDERE'),
(365, 31, 'YAKUTİYE'),
(366, 32, 'ALPU'),
(367, 32, 'BEYLİKOVA'),
(368, 32, 'ÇİFTELER'),
(369, 32, 'GÜNYÜZÜ'),
(370, 32, 'HAN'),
(371, 32, 'İNÖNÜ'),
(372, 32, 'MAHMUDİYE'),
(373, 32, 'MİHALGAZİ'),
(374, 32, 'MİHALIÇÇIK'),
(375, 32, 'ODUNPAZARI'),
(376, 32, 'SARICAKAYA'),
(377, 32, 'SEYİTGAZİ'),
(378, 32, 'SİVRİHİSAR'),
(379, 32, 'TEPEBAŞI'),
(380, 33, 'ARABAN'),
(381, 33, 'İSLAHİYE'),
(382, 33, 'KARKAMIŞ'),
(383, 33, 'NİZİP'),
(384, 33, 'NURDAĞI'),
(385, 33, 'OĞUZELİ'),
(386, 33, 'ŞAHİNBEY'),
(387, 33, 'ŞEHİTKAMİL'),
(388, 33, 'YAVUZELİ'),
(389, 34, 'ALUCRA'),
(390, 34, 'BULANCAK'),
(391, 34, 'ÇAMOLUK'),
(392, 34, 'ÇANAKÇI'),
(393, 34, 'DERELİ'),
(394, 34, 'DOĞANKENT'),
(395, 34, 'ESPİYE'),
(396, 34, 'EYNESİL'),
(397, 34, 'GÖRELE'),
(398, 34, 'GÜCE'),
(399, 34, 'KEŞAP'),
(400, 34, 'MERKEZ'),
(401, 34, 'PİRAZİZ'),
(402, 34, 'ŞEBİNKARAHİSAR'),
(403, 34, 'TİREBOLU'),
(404, 34, 'YAĞLIDERE'),
(405, 35, 'KELKİT'),
(406, 35, 'KÖSE'),
(407, 35, 'KÜRTÜN'),
(408, 35, 'MERKEZ'),
(409, 35, 'ŞİRAN'),
(410, 35, 'TORUL'),
(411, 36, 'ÇUKURCA'),
(412, 36, 'MERKEZ'),
(413, 36, 'ŞEMDİNLİ'),
(414, 36, 'YÜKSEKOVA'),
(415, 37, 'ALTINÖZÜ'),
(416, 37, 'ANTAKYA'),
(417, 37, 'ARSUZ'),
(418, 37, 'BELEN'),
(419, 37, 'DEFNE'),
(420, 37, 'DÖRTYOL'),
(421, 37, 'ERZİN'),
(422, 37, 'HASSA'),
(423, 37, 'İSKENDERUN'),
(424, 37, 'KIRIKHAN'),
(425, 37, 'KUMLU'),
(426, 37, 'PAYAS'),
(427, 37, 'REYHANLI'),
(428, 37, 'SAMANDAĞ'),
(429, 37, 'YAYLADAĞI'),
(430, 38, 'ARALIK'),
(431, 38, 'KARAKOYUNLU'),
(432, 38, 'MERKEZ'),
(433, 38, 'TUZLUCA'),
(434, 39, 'AKSU'),
(435, 39, 'ATABEY'),
(436, 39, 'EĞİRDİR'),
(437, 39, 'GELENDOST'),
(438, 39, 'GÖNEN'),
(439, 39, 'KEÇİBORLU'),
(440, 39, 'MERKEZ'),
(441, 39, 'SENİRKENT'),
(442, 39, 'SÜTÇÜLER'),
(443, 39, 'ŞARKİKARAAĞAÇ'),
(444, 39, 'ULUBORLU'),
(445, 39, 'YALVAÇ'),
(446, 39, 'YENİŞARBADEMLİ'),
(447, 40, 'ADALAR'),
(448, 40, 'ARNAVUTKÖY'),
(449, 40, 'ATAŞEHİR'),
(450, 40, 'AVCILAR'),
(451, 40, 'BAĞCILAR'),
(452, 40, 'BAHÇELİEVLER'),
(453, 40, 'BAKIRKÖY'),
(454, 40, 'BAŞAKŞEHİR'),
(455, 40, 'BAYRAMPAŞA'),
(456, 40, 'BEŞİKTAŞ'),
(457, 40, 'BEYKOZ'),
(458, 40, 'BEYLİKDÜZÜ'),
(459, 40, 'BEYOĞLU'),
(460, 40, 'BÜYÜKÇEKMECE'),
(461, 40, 'ÇATALCA'),
(462, 40, 'ÇEKMEKÖY'),
(463, 40, 'ESENLER'),
(464, 40, 'ESENYURT'),
(465, 40, 'EYÜPSULTAN'),
(466, 40, 'FATİH'),
(467, 40, 'GAZİOSMANPAŞA'),
(468, 40, 'GÜNGÖREN'),
(469, 40, 'KADIKÖY'),
(470, 40, 'KAĞITHANE'),
(471, 40, 'KARTAL'),
(472, 40, 'KÜÇÜKÇEKMECE'),
(473, 40, 'MALTEPE'),
(474, 40, 'PENDİK'),
(475, 40, 'SANCAKTEPE'),
(476, 40, 'SARIYER'),
(477, 40, 'SİLİVRİ'),
(478, 40, 'SULTANBEYLİ'),
(479, 40, 'SULTANGAZİ'),
(480, 40, 'ŞİLE'),
(481, 40, 'ŞİŞLİ'),
(482, 40, 'TUZLA'),
(483, 40, 'ÜMRANİYE'),
(484, 40, 'ÜSKÜDAR'),
(485, 40, 'ZEYTİNBURNU'),
(486, 41, 'ALİAĞA'),
(487, 41, 'BALÇOVA'),
(488, 41, 'BAYINDIR'),
(489, 41, 'BAYRAKLI'),
(490, 41, 'BERGAMA'),
(491, 41, 'BEYDAĞ'),
(492, 41, 'BORNOVA'),
(493, 41, 'BUCA'),
(494, 41, 'ÇEŞME'),
(495, 41, 'ÇİĞLİ'),
(496, 41, 'DİKİLİ'),
(497, 41, 'FOÇA'),
(498, 41, 'GAZİEMİR'),
(499, 41, 'GÜZELBAHÇE'),
(500, 41, 'KARABAĞLAR'),
(501, 41, 'KARABURUN'),
(502, 41, 'KARŞIYAKA'),
(503, 41, 'KEMALPAŞA'),
(504, 41, 'KINIK'),
(505, 41, 'KİRAZ'),
(506, 41, 'KONAK'),
(507, 41, 'MENDERES'),
(508, 41, 'MENEMEN'),
(509, 41, 'NARLIDERE'),
(510, 41, 'ÖDEMİŞ'),
(511, 41, 'SEFERİHİSAR'),
(512, 41, 'SELÇUK'),
(513, 41, 'TİRE'),
(514, 41, 'TORBALI'),
(515, 41, 'URLA'),
(516, 42, 'AFŞİN'),
(517, 42, 'ANDIRIN'),
(518, 42, 'ÇAĞLAYANCERİT'),
(519, 42, 'DULKADİROĞLU'),
(520, 42, 'EKİNÖZÜ'),
(521, 42, 'ELBİSTAN'),
(522, 42, 'GÖKSUN'),
(523, 42, 'NURHAK'),
(524, 42, 'ONİKİŞUBAT'),
(525, 42, 'PAZARCIK'),
(526, 42, 'TÜRKOĞLU'),
(527, 43, 'EFLANİ'),
(528, 43, 'ESKİPAZAR'),
(529, 43, 'MERKEZ'),
(530, 43, 'OVACIK'),
(531, 43, 'SAFRANBOLU'),
(532, 43, 'YENİCE'),
(533, 44, 'AYRANCI'),
(534, 44, 'BAŞYAYLA'),
(535, 44, 'ERMENEK'),
(536, 44, 'KAZIMKARABEKİR'),
(537, 44, 'MERKEZ'),
(538, 44, 'SARIVELİLER'),
(539, 45, 'AKYAKA'),
(540, 45, 'ARPAÇAY'),
(541, 45, 'DİGOR'),
(542, 45, 'KAĞIZMAN'),
(543, 45, 'MERKEZ'),
(544, 45, 'SARIKAMIŞ'),
(545, 45, 'SELİM'),
(546, 45, 'SUSUZ'),
(547, 46, 'ABANA'),
(548, 46, 'AĞLI'),
(549, 46, 'ARAÇ'),
(550, 46, 'AZDAVAY'),
(551, 46, 'BOZKURT'),
(552, 46, 'CİDE'),
(553, 46, 'ÇATALZEYTİN'),
(554, 46, 'DADAY'),
(555, 46, 'DEVREKANİ'),
(556, 46, 'DOĞANYURT'),
(557, 46, 'HANÖNÜ'),
(558, 46, 'İHSANGAZİ'),
(559, 46, 'İNEBOLU'),
(560, 46, 'KÜRE'),
(561, 46, 'MERKEZ'),
(562, 46, 'PINARBAŞI'),
(563, 46, 'SEYDİLER'),
(564, 46, 'ŞENPAZAR'),
(565, 46, 'TAŞKÖPRÜ'),
(566, 46, 'TOSYA'),
(567, 47, 'AKKIŞLA'),
(568, 47, 'BÜNYAN'),
(569, 47, 'DEVELİ'),
(570, 47, 'FELAHİYE'),
(571, 47, 'HACILAR'),
(572, 47, 'İNCESU'),
(573, 47, 'KOCASİNAN'),
(574, 47, 'MELİKGAZİ'),
(575, 47, 'ÖZVATAN'),
(576, 47, 'PINARBAŞI'),
(577, 47, 'SARIOĞLAN'),
(578, 47, 'SARIZ'),
(579, 47, 'TALAS'),
(580, 47, 'TOMARZA'),
(581, 47, 'YAHYALI'),
(582, 47, 'YEŞİLHİSAR'),
(583, 48, 'BAHŞİLİ'),
(584, 48, 'BALIŞEYH'),
(585, 48, 'ÇELEBİ'),
(586, 48, 'DELİCE'),
(587, 48, 'KARAKEÇİLİ'),
(588, 48, 'KESKİN'),
(589, 48, 'MERKEZ'),
(590, 48, 'SULAKYURT'),
(591, 48, 'YAHŞİHAN'),
(592, 49, 'BABAESKİ'),
(593, 49, 'DEMİRKÖY'),
(594, 49, 'KOFÇAZ'),
(595, 49, 'LÜLEBURGAZ'),
(596, 49, 'MERKEZ'),
(597, 49, 'PEHLİVANKÖY'),
(598, 49, 'PINARHİSAR'),
(599, 49, 'VİZE'),
(600, 50, 'AKÇAKENT'),
(601, 50, 'AKPINAR'),
(602, 50, 'BOZTEPE'),
(603, 50, 'ÇİÇEKDAĞI'),
(604, 50, 'KAMAN'),
(605, 50, 'MERKEZ'),
(606, 50, 'MUCUR'),
(607, 51, 'ELBEYLİ'),
(608, 51, 'MERKEZ'),
(609, 51, 'MUSABEYLİ'),
(610, 51, 'POLATELİ'),
(611, 52, 'BAŞİSKELE'),
(612, 52, 'ÇAYIROVA'),
(613, 52, 'DARICA'),
(614, 52, 'DERİNCE'),
(615, 52, 'DİLOVASI'),
(616, 52, 'GEBZE'),
(617, 52, 'GÖLCÜK'),
(618, 52, 'İZMİT'),
(619, 52, 'KANDIRA'),
(620, 52, 'KARAMÜRSEL'),
(621, 52, 'KARTEPE'),
(622, 52, 'KÖRFEZ'),
(623, 53, 'AHIRLI'),
(624, 53, 'AKÖREN'),
(625, 53, 'AKŞEHİR'),
(626, 53, 'ALTINEKİN'),
(627, 53, 'BEYŞEHİR'),
(628, 53, 'BOZKIR'),
(629, 53, 'CİHANBEYLİ'),
(630, 53, 'ÇELTİK'),
(631, 53, 'ÇUMRA'),
(632, 53, 'DERBENT'),
(633, 53, 'DEREBUCAK'),
(634, 53, 'DOĞANHİSAR'),
(635, 53, 'EMİRGAZİ'),
(636, 53, 'EREĞLİ'),
(637, 53, 'GÜNEYSINIR'),
(638, 53, 'HADİM'),
(639, 53, 'HALKAPINAR'),
(640, 53, 'HÜYÜK'),
(641, 53, 'ILGIN'),
(642, 53, 'KADINHANI'),
(643, 53, 'KARAPINAR'),
(644, 53, 'KARATAY'),
(645, 53, 'KULU'),
(646, 53, 'MERAM'),
(647, 53, 'SARAYÖNÜ'),
(648, 53, 'SELÇUKLU'),
(649, 53, 'SEYDİŞEHİR'),
(650, 53, 'TAŞKENT'),
(651, 53, 'TUZLUKÇU'),
(652, 53, 'YALIHÜYÜK'),
(653, 53, 'YUNAK'),
(654, 54, 'ALTINTAŞ'),
(655, 54, 'ASLANAPA'),
(656, 54, 'ÇAVDARHİSAR'),
(657, 54, 'DOMANİÇ'),
(658, 54, 'DUMLUPINAR'),
(659, 54, 'EMET'),
(660, 54, 'GEDİZ'),
(661, 54, 'HİSARCIK'),
(662, 54, 'MERKEZ'),
(663, 54, 'PAZARLAR'),
(664, 54, 'SİMAV'),
(665, 54, 'ŞAPHANE'),
(666, 54, 'TAVŞANLI'),
(667, 55, 'AKÇADAĞ'),
(668, 55, 'ARAPGİR'),
(669, 55, 'ARGUVAN'),
(670, 55, 'BATTALGAZİ'),
(671, 55, 'DARENDE'),
(672, 55, 'DOĞANŞEHİR'),
(673, 55, 'DOĞANYOL'),
(674, 55, 'HEKİMHAN'),
(675, 55, 'KALE'),
(676, 55, 'KULUNCAK'),
(677, 55, 'PÜTÜRGE'),
(678, 55, 'YAZIHAN'),
(679, 55, 'YEŞİLYURT'),
(680, 56, 'AHMETLİ'),
(681, 56, 'AKHİSAR'),
(682, 56, 'ALAŞEHİR'),
(683, 56, 'DEMİRCİ'),
(684, 56, 'GÖLMARMARA'),
(685, 56, 'GÖRDES'),
(686, 56, 'KIRKAĞAÇ'),
(687, 56, 'KÖPRÜBAŞI'),
(688, 56, 'KULA'),
(689, 56, 'SALİHLİ'),
(690, 56, 'SARIGÖL'),
(691, 56, 'SARUHANLI'),
(692, 56, 'SELENDİ'),
(693, 56, 'SOMA'),
(694, 56, 'ŞEHZADELER'),
(695, 56, 'TURGUTLU'),
(696, 56, 'YUNUSEMRE'),
(697, 57, 'ARTUKLU'),
(698, 57, 'DARGEÇİT'),
(699, 57, 'DERİK'),
(700, 57, 'KIZILTEPE'),
(701, 57, 'MAZIDAĞI'),
(702, 57, 'MİDYAT'),
(703, 57, 'NUSAYBİN'),
(704, 57, 'ÖMERLİ'),
(705, 57, 'SAVUR'),
(706, 57, 'YEŞİLLİ'),
(707, 58, 'AKDENİZ'),
(708, 58, 'ANAMUR'),
(709, 58, 'AYDINCIK'),
(710, 58, 'BOZYAZI'),
(711, 58, 'ÇAMLIYAYLA'),
(712, 58, 'ERDEMLİ'),
(713, 58, 'GÜLNAR'),
(714, 58, 'MEZİTLİ'),
(715, 58, 'MUT'),
(716, 58, 'SİLİFKE'),
(717, 58, 'TARSUS'),
(718, 58, 'TOROSLAR'),
(719, 58, 'YENİŞEHİR'),
(720, 59, 'BODRUM'),
(721, 59, 'DALAMAN'),
(722, 59, 'DATÇA'),
(723, 59, 'FETHİYE'),
(724, 59, 'KAVAKLIDERE'),
(725, 59, 'KÖYCEĞİZ'),
(726, 59, 'MARMARİS'),
(727, 59, 'MENTEŞE'),
(728, 59, 'MİLAS'),
(729, 59, 'ORTACA'),
(730, 59, 'SEYDİKEMER'),
(731, 59, 'ULA'),
(732, 59, 'YATAĞAN'),
(733, 60, 'BULANIK'),
(734, 60, 'HASKÖY'),
(735, 60, 'KORKUT'),
(736, 60, 'MALAZGİRT'),
(737, 60, 'MERKEZ'),
(738, 60, 'VARTO'),
(739, 61, 'ACIGÖL'),
(740, 61, 'AVANOS'),
(741, 61, 'DERİNKUYU'),
(742, 61, 'GÜLŞEHİR'),
(743, 61, 'HACIBEKTAŞ'),
(744, 61, 'KOZAKLI'),
(745, 61, 'MERKEZ'),
(746, 61, 'ÜRGÜP'),
(747, 62, 'ALTUNHİSAR'),
(748, 62, 'BOR'),
(749, 62, 'ÇAMARDI'),
(750, 62, 'ÇİFTLİK'),
(751, 62, 'MERKEZ'),
(752, 62, 'ULUKIŞLA'),
(753, 63, 'AKKUŞ'),
(754, 63, 'ALTINORDU'),
(755, 63, 'AYBASTI'),
(756, 63, 'ÇAMAŞ'),
(757, 63, 'ÇATALPINAR'),
(758, 63, 'ÇAYBAŞI'),
(759, 63, 'FATSA'),
(760, 63, 'GÖLKÖY'),
(761, 63, 'GÜLYALI'),
(762, 63, 'GÜRGENTEPE'),
(763, 63, 'İKİZCE'),
(764, 63, 'KABADÜZ'),
(765, 63, 'KABATAŞ'),
(766, 63, 'KORGAN'),
(767, 63, 'KUMRU'),
(768, 63, 'MESUDİYE'),
(769, 63, 'PERŞEMBE'),
(770, 63, 'ULUBEY'),
(771, 63, 'ÜNYE'),
(772, 64, 'BAHÇE'),
(773, 64, 'DÜZİÇİ'),
(774, 64, 'HASANBEYLİ'),
(775, 64, 'KADİRLİ'),
(776, 64, 'MERKEZ'),
(777, 64, 'SUMBAS'),
(778, 64, 'TOPRAKKALE'),
(779, 65, 'ARDEŞEN'),
(780, 65, 'ÇAMLIHEMŞİN'),
(781, 65, 'ÇAYELİ'),
(782, 65, 'DEREPAZARI'),
(783, 65, 'FINDIKLI'),
(784, 65, 'GÜNEYSU'),
(785, 65, 'HEMŞİN'),
(786, 65, 'İKİZDERE'),
(787, 65, 'İYİDERE'),
(788, 65, 'KALKANDERE'),
(789, 65, 'MERKEZ'),
(790, 65, 'PAZAR'),
(791, 66, 'ADAPAZARI'),
(792, 66, 'AKYAZI'),
(793, 66, 'ARİFİYE'),
(794, 66, 'ERENLER'),
(795, 66, 'FERİZLİ'),
(796, 66, 'GEYVE'),
(797, 66, 'HENDEK'),
(798, 66, 'KARAPÜRÇEK'),
(799, 66, 'KARASU'),
(800, 66, 'KAYNARCA'),
(801, 66, 'KOCAALİ'),
(802, 66, 'PAMUKOVA'),
(803, 66, 'SAPANCA'),
(804, 66, 'SERDİVAN'),
(805, 66, 'SÖĞÜTLÜ'),
(806, 66, 'TARAKLI'),
(807, 67, '19 MAYIS'),
(808, 67, 'ALAÇAM'),
(809, 67, 'ASARCIK'),
(810, 67, 'ATAKUM'),
(811, 67, 'AYVACIK'),
(812, 67, 'BAFRA'),
(813, 67, 'CANİK'),
(814, 67, 'ÇARŞAMBA'),
(815, 67, 'HAVZA'),
(816, 67, 'İLKADIM'),
(817, 67, 'KAVAK'),
(818, 67, 'LADİK'),
(819, 67, 'SALIPAZARI'),
(820, 67, 'TEKKEKÖY'),
(821, 67, 'TERME'),
(822, 67, 'VEZİRKÖPRÜ'),
(823, 67, 'YAKAKENT'),
(824, 68, 'BAYKAN'),
(825, 68, 'ERUH'),
(826, 68, 'KURTALAN'),
(827, 68, 'MERKEZ'),
(828, 68, 'PERVARİ'),
(829, 68, 'ŞİRVAN'),
(830, 68, 'TİLLO'),
(831, 69, 'AYANCIK'),
(832, 69, 'BOYABAT'),
(833, 69, 'DİKMEN'),
(834, 69, 'DURAĞAN'),
(835, 69, 'ERFELEK'),
(836, 69, 'GERZE'),
(837, 69, 'MERKEZ'),
(838, 69, 'SARAYDÜZÜ'),
(839, 69, 'TÜRKELİ'),
(840, 70, 'AKINCILAR'),
(841, 70, 'ALTINYAYLA'),
(842, 70, 'DİVRİĞİ'),
(843, 70, 'DOĞANŞAR'),
(844, 70, 'GEMEREK'),
(845, 70, 'GÖLOVA'),
(846, 70, 'GÜRÜN'),
(847, 70, 'HAFİK'),
(848, 70, 'İMRANLI'),
(849, 70, 'KANGAL'),
(850, 70, 'KOYULHİSAR'),
(851, 70, 'MERKEZ'),
(852, 70, 'SUŞEHRİ'),
(853, 70, 'ŞARKIŞLA'),
(854, 70, 'ULAŞ'),
(855, 70, 'YILDIZELİ'),
(856, 70, 'ZARA'),
(857, 71, 'AKÇAKALE'),
(858, 71, 'BİRECİK'),
(859, 71, 'BOZOVA'),
(860, 71, 'CEYLANPINAR'),
(861, 71, 'EYYÜBİYE'),
(862, 71, 'HALFETİ'),
(863, 71, 'HALİLİYE'),
(864, 71, 'HARRAN'),
(865, 71, 'HİLVAN'),
(866, 71, 'KARAKÖPRÜ'),
(867, 71, 'SİVEREK'),
(868, 71, 'SURUÇ'),
(869, 71, 'VİRANŞEHİR'),
(870, 72, 'BEYTÜŞŞEBAP'),
(871, 72, 'CİZRE'),
(872, 72, 'GÜÇLÜKONAK'),
(873, 72, 'İDİL'),
(874, 72, 'MERKEZ'),
(875, 72, 'SİLOPİ'),
(876, 72, 'ULUDERE'),
(877, 73, 'ÇERKEZKÖY'),
(878, 73, 'ÇORLU'),
(879, 73, 'ERGENE'),
(880, 73, 'HAYRABOLU'),
(881, 73, 'KAPAKLI'),
(882, 73, 'MALKARA'),
(883, 73, 'MARMARAEREĞLİSİ'),
(884, 73, 'MURATLI'),
(885, 73, 'SARAY'),
(886, 73, 'SÜLEYMANPAŞA'),
(887, 73, 'ŞARKÖY'),
(888, 74, 'ALMUS'),
(889, 74, 'ARTOVA'),
(890, 74, 'BAŞÇİFTLİK'),
(891, 74, 'ERBAA'),
(892, 74, 'MERKEZ'),
(893, 74, 'NİKSAR'),
(894, 74, 'PAZAR'),
(895, 74, 'REŞADİYE'),
(896, 74, 'SULUSARAY'),
(897, 74, 'TURHAL'),
(898, 74, 'YEŞİLYURT'),
(899, 74, 'ZİLE'),
(900, 75, 'AKÇAABAT'),
(901, 75, 'ARAKLI'),
(902, 75, 'ARSİN'),
(903, 75, 'BEŞİKDÜZÜ'),
(904, 75, 'ÇARŞIBAŞI'),
(905, 75, 'ÇAYKARA'),
(906, 75, 'DERNEKPAZARI'),
(907, 75, 'DÜZKÖY'),
(908, 75, 'HAYRAT'),
(909, 75, 'KÖPRÜBAŞI'),
(910, 75, 'MAÇKA'),
(911, 75, 'OF'),
(912, 75, 'ORTAHİSAR'),
(913, 75, 'SÜRMENE'),
(914, 75, 'ŞALPAZARI'),
(915, 75, 'TONYA'),
(916, 75, 'VAKFIKEBİR'),
(917, 75, 'YOMRA'),
(918, 76, 'ÇEMİŞGEZEK'),
(919, 76, 'HOZAT'),
(920, 76, 'MAZGİRT'),
(921, 76, 'MERKEZ'),
(922, 76, 'NAZIMİYE'),
(923, 76, 'OVACIK'),
(924, 76, 'PERTEK'),
(925, 76, 'PÜLÜMÜR'),
(926, 77, 'BANAZ'),
(927, 77, 'EŞME'),
(928, 77, 'KARAHALLI'),
(929, 77, 'MERKEZ'),
(930, 77, 'SİVASLI'),
(931, 77, 'ULUBEY'),
(932, 78, 'BAHÇESARAY'),
(933, 78, 'BAŞKALE'),
(934, 78, 'ÇALDIRAN'),
(935, 78, 'ÇATAK'),
(936, 78, 'EDREMİT'),
(937, 78, 'ERCİŞ'),
(938, 78, 'GEVAŞ'),
(939, 78, 'GÜRPINAR'),
(940, 78, 'İPEKYOLU'),
(941, 78, 'MURADİYE'),
(942, 78, 'ÖZALP'),
(943, 78, 'SARAY'),
(944, 78, 'TUŞBA'),
(945, 79, 'ALTINOVA'),
(946, 79, 'ARMUTLU'),
(947, 79, 'ÇINARCIK'),
(948, 79, 'ÇİFTLİKKÖY'),
(949, 79, 'MERKEZ'),
(950, 79, 'TERMAL'),
(951, 80, 'AKDAĞMADENİ'),
(952, 80, 'AYDINCIK'),
(953, 80, 'BOĞAZLIYAN'),
(954, 80, 'ÇANDIR'),
(955, 80, 'ÇAYIRALAN'),
(956, 80, 'ÇEKEREK'),
(957, 80, 'KADIŞEHRİ'),
(958, 80, 'MERKEZ'),
(959, 80, 'SARAYKENT'),
(960, 80, 'SARIKAYA'),
(961, 80, 'SORGUN'),
(962, 80, 'ŞEFAATLİ'),
(963, 80, 'YENİFAKILI'),
(964, 80, 'YERKÖY'),
(965, 81, 'ALAPLI'),
(966, 81, 'ÇAYCUMA'),
(967, 81, 'DEVREK'),
(968, 81, 'EREĞLİ'),
(969, 81, 'GÖKÇEBEY'),
(970, 81, 'KİLİMLİ'),
(971, 81, 'KOZLU'),
(972, 81, 'MERKEZ');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `uniteler`
--

CREATE TABLE `uniteler` (
  `id` int(11) NOT NULL,
  `dersID` int(11) NOT NULL,
  `sinif` int(11) NOT NULL,
  `unite_kodu` text NOT NULL,
  `unite_icerik` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `uniteler`
--

INSERT INTO `uniteler` (`id`, `dersID`, `sinif`, `unite_kodu`, `unite_icerik`) VALUES
(1, 2, 7, '01', 'Güneş Sistemi ve Ötesi / Dünya ve Evren'),
(2, 2, 7, '02', 'Hücre ve Bölünmeler / Canlılar ve Yaşam'),
(3, 2, 7, '03', 'Kuvvet ve Enerji / Fiziksel Olaylar');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `userlogins`
--

CREATE TABLE `userlogins` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `logDate` datetime NOT NULL,
  `ip` varchar(25) COLLATE utf8_turkish_ci DEFAULT NULL,
  `browser` varchar(25) COLLATE utf8_turkish_ci DEFAULT NULL,
  `platform` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `userlogins`
--

INSERT INTO `userlogins` (`id`, `userId`, `status`, `logDate`, `ip`, `browser`, `platform`, `location`) VALUES
(1, 2, 1, '2021-06-30 19:06:36', '::1', 'Chrome 91.0.4472.114', 'Windows 10', NULL),
(2, 2, 2, '2021-06-30 19:06:57', '::1', 'Chrome 91.0.4472.114', 'Windows 10', NULL),
(3, 1, 1, '2021-06-30 19:07:00', '::1', 'Chrome 91.0.4472.114', 'Windows 10', NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `userroles`
--

CREATE TABLE `userroles` (
  `id` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RoleId` int(11) NOT NULL,
  `isActive` tinyint(1) DEFAULT 1,
  `createDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `userroles`
--

INSERT INTO `userroles` (`id`, `UserId`, `RoleId`, `isActive`, `createDate`) VALUES
(1, 1, 1, 1, '2019-04-22 10:21:45'),
(2, 2, 2, 1, '2019-04-22 10:23:37');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `md5_password` text COLLATE utf8_turkish_ci DEFAULT NULL,
  `name` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `surname` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `tel` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `registerDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `address` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT 0,
  `bransID` int(11) NOT NULL,
  `kurum_kodu` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `gizlilik_taahhut_onay` tinyint(4) NOT NULL DEFAULT 0,
  `gizlilik_taahhut_onay_tarihi` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `md5_password`, `name`, `surname`, `email`, `tel`, `isActive`, `registerDate`, `address`, `isAdmin`, `bransID`, `kurum_kodu`, `gizlilik_taahhut_onay`, `gizlilik_taahhut_onay_tarihi`) VALUES
(1, 'admin', '4917', 'cf8d8c66b1212720e569b0bd67695451', 'Emre', 'Bodur', 'emrebodurbto@gmail.com', '05547293383', 1, '2019-10-08 06:59:04', 'Körpeşler Mah. 1452. SOK No:4, 81100 Merkez/Düzce', 1, 1, '758800', 1, '2021-06-30 17:28:27'),
(2, 'begum', '4917', 'cf8d8c66b1212720e569b0bd67695451', 'Begüm', 'Öztemür', 'begum.oztemur@soruhavuzu.emrebodur.com', '05551234567', 1, '2021-03-30 09:59:48', 'Düzce Borsa İstanbul Mesleki ve Teknik Anadolu Lisesi', 0, 6, '132811', 0, NULL);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`CityID`) USING BTREE,
  ADD KEY `FK_City_CountryID` (`CountryID`) USING BTREE;

--
-- Tablo için indeksler `ci_session`
--
ALTER TABLE `ci_session`
  ADD KEY `ci_sessions_timestamp` (`timestamp`) USING BTREE;

--
-- Tablo için indeksler `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`CountryID`) USING BTREE;

--
-- Tablo için indeksler `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `dersler`
--
ALTER TABLE `dersler`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kisa_kod` (`kisa_kod`);

--
-- Tablo için indeksler `duyurular`
--
ALTER TABLE `duyurular`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `iletisim`
--
ALTER TABLE `iletisim`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `userID` (`userID`);

--
-- Tablo için indeksler `kazanimlar`
--
ALTER TABLE `kazanimlar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dersID` (`dersID`),
  ADD KEY `konuID` (`konuID`),
  ADD KEY `uniteID` (`uniteID`);

--
-- Tablo için indeksler `konular`
--
ALTER TABLE `konular`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uniteID` (`uniteID`),
  ADD KEY `dersID` (`dersID`);

--
-- Tablo için indeksler `okullar`
--
ALTER TABLE `okullar`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IL_ID` (`IL_ID`),
  ADD KEY `ILCE_ID` (`ILCE_ID`),
  ADD KEY `KURUM_KODU` (`KURUM_KODU`);

--
-- Tablo için indeksler `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `site_bilgileri`
--
ALTER TABLE `site_bilgileri`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `sorular`
--
ALTER TABLE `sorular`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `dogrulama_kodu_2` (`dogrulama_kodu`),
  ADD KEY `userID` (`userID`),
  ADD KEY `dersID` (`dersID`),
  ADD KEY `kazanimID` (`kazanimID`),
  ADD KEY `konuID` (`konuID`),
  ADD KEY `uniteID` (`uniteID`),
  ADD KEY `onaylayanUserID` (`onaylayanUserID`),
  ADD KEY `dogrulama_kodu` (`dogrulama_kodu`);

--
-- Tablo için indeksler `town`
--
ALTER TABLE `town`
  ADD PRIMARY KEY (`TownID`),
  ADD KEY `CityID` (`CityID`);

--
-- Tablo için indeksler `uniteler`
--
ALTER TABLE `uniteler`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dersID` (`dersID`);

--
-- Tablo için indeksler `userlogins`
--
ALTER TABLE `userlogins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Tablo için indeksler `userroles`
--
ALTER TABLE `userroles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `RoleId` (`RoleId`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_2` (`email`),
  ADD UNIQUE KEY `tel_2` (`tel`),
  ADD KEY `bransID` (`bransID`),
  ADD KEY `kurum_kodu` (`kurum_kodu`),
  ADD KEY `email` (`email`),
  ADD KEY `tel` (`tel`),
  ADD KEY `isAdmin` (`isAdmin`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `duyurular`
--
ALTER TABLE `duyurular`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `kazanimlar`
--
ALTER TABLE `kazanimlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `konular`
--
ALTER TABLE `konular`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `okullar`
--
ALTER TABLE `okullar`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=266;

--
-- Tablo için AUTO_INCREMENT değeri `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tablo için AUTO_INCREMENT değeri `sorular`
--
ALTER TABLE `sorular`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `town`
--
ALTER TABLE `town`
  MODIFY `TownID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=973;

--
-- Tablo için AUTO_INCREMENT değeri `uniteler`
--
ALTER TABLE `uniteler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Tablo için AUTO_INCREMENT değeri `userlogins`
--
ALTER TABLE `userlogins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Tablo için AUTO_INCREMENT değeri `userroles`
--
ALTER TABLE `userroles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `city`
--
ALTER TABLE `city`
  ADD CONSTRAINT `city_ibfk_1` FOREIGN KEY (`CountryID`) REFERENCES `country` (`CountryID`);

--
-- Tablo kısıtlamaları `iletisim`
--
ALTER TABLE `iletisim`
  ADD CONSTRAINT `iletisim_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Tablo kısıtlamaları `kazanimlar`
--
ALTER TABLE `kazanimlar`
  ADD CONSTRAINT `kazanimlar_ibfk_1` FOREIGN KEY (`dersID`) REFERENCES `dersler` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `kazanimlar_ibfk_2` FOREIGN KEY (`konuID`) REFERENCES `konular` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `kazanimlar_ibfk_3` FOREIGN KEY (`uniteID`) REFERENCES `uniteler` (`id`);

--
-- Tablo kısıtlamaları `konular`
--
ALTER TABLE `konular`
  ADD CONSTRAINT `konular_ibfk_1` FOREIGN KEY (`dersID`) REFERENCES `dersler` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `konular_ibfk_2` FOREIGN KEY (`uniteID`) REFERENCES `uniteler` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Tablo kısıtlamaları `okullar`
--
ALTER TABLE `okullar`
  ADD CONSTRAINT `okullar_ibfk_1` FOREIGN KEY (`IL_ID`) REFERENCES `city` (`CityID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `okullar_ibfk_2` FOREIGN KEY (`ILCE_ID`) REFERENCES `town` (`TownID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Tablo kısıtlamaları `sorular`
--
ALTER TABLE `sorular`
  ADD CONSTRAINT `sorular_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `sorular_ibfk_2` FOREIGN KEY (`dersID`) REFERENCES `dersler` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `sorular_ibfk_3` FOREIGN KEY (`kazanimID`) REFERENCES `kazanimlar` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `sorular_ibfk_4` FOREIGN KEY (`konuID`) REFERENCES `konular` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `sorular_ibfk_5` FOREIGN KEY (`uniteID`) REFERENCES `uniteler` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `sorular_ibfk_6` FOREIGN KEY (`onaylayanUserID`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Tablo kısıtlamaları `town`
--
ALTER TABLE `town`
  ADD CONSTRAINT `town_ibfk_1` FOREIGN KEY (`CityID`) REFERENCES `city` (`CityID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Tablo kısıtlamaları `uniteler`
--
ALTER TABLE `uniteler`
  ADD CONSTRAINT `uniteler_ibfk_1` FOREIGN KEY (`dersID`) REFERENCES `dersler` (`id`);

--
-- Tablo kısıtlamaları `userlogins`
--
ALTER TABLE `userlogins`
  ADD CONSTRAINT `userlogins_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Tablo kısıtlamaları `userroles`
--
ALTER TABLE `userroles`
  ADD CONSTRAINT `userroles_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `userroles_ibfk_2` FOREIGN KEY (`RoleId`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Tablo kısıtlamaları `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`bransID`) REFERENCES `dersler` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`kurum_kodu`) REFERENCES `okullar` (`KURUM_KODU`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
