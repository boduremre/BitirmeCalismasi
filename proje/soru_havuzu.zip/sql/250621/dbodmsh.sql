-- phpMyAdmin SQL Dump
-- version 4.6.0
-- http://www.phpmyadmin.net
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 25 Haz 2021, 19:30:39
-- Sunucu sürümü: 5.6.26
-- PHP Sürümü: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `dbodmsh`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `city`
--

CREATE TABLE `city` (
  `CityID` int(11) NOT NULL,
  `CountryID` int(11) NOT NULL,
  `CityName` varchar(100) NOT NULL,
  `PlateNo` int(2) NOT NULL,
  `PhoneCode` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `city`
--

INSERT INTO `city` (`CityID`, `CountryID`, `CityName`, `PlateNo`, `PhoneCode`) VALUES
(1, 212, 'ADANA', 1, '322'),
(2, 212, 'ADIYAMAN', 2, '416'),
(3, 212, 'AFYONKARAHİSAR', 3, '272'),
(4, 212, 'AĞRI', 4, '472'),
(5, 212, 'AKSARAY', 68, '382'),
(6, 212, 'AMASYA', 5, '358'),
(7, 212, 'ANKARA', 6, '312'),
(8, 212, 'ANTALYA', 7, '242'),
(9, 212, 'ARDAHAN', 75, '478'),
(10, 212, 'ARTVİN', 8, '466'),
(11, 212, 'AYDIN', 9, '256'),
(12, 212, 'BALIKESİR', 10, '266'),
(13, 212, 'BARTIN', 74, '378'),
(14, 212, 'BATMAN', 72, '488'),
(15, 212, 'BAYBURT', 69, '458'),
(16, 212, 'BİLECİK', 11, '228'),
(17, 212, 'BİNGÖL', 12, '426'),
(18, 212, 'BİTLİS', 13, '434'),
(19, 212, 'BOLU', 14, '374'),
(20, 212, 'BURDUR', 15, '248'),
(21, 212, 'BURSA', 16, '224'),
(22, 212, 'ÇANAKKALE', 17, '286'),
(23, 212, 'ÇANKIRI', 18, '376'),
(24, 212, 'ÇORUM', 19, '364'),
(25, 212, 'DENİZLİ', 20, '258'),
(26, 212, 'DİYARBAKIR', 21, '412'),
(27, 212, 'DÜZCE', 81, '380'),
(28, 212, 'EDİRNE', 22, '284'),
(29, 212, 'ELAZIĞ', 23, '424'),
(30, 212, 'ERZİNCAN', 24, '446'),
(31, 212, 'ERZURUM', 25, '442'),
(32, 212, 'ESKİŞEHİR', 26, '222'),
(33, 212, 'GAZİANTEP', 27, '342'),
(34, 212, 'GİRESUN', 28, '454'),
(35, 212, 'GÜMÜŞHANE', 29, '456'),
(36, 212, 'HAKKARİ', 30, '438'),
(37, 212, 'HATAY', 31, '326'),
(38, 212, 'IĞDIR', 76, '476'),
(39, 212, 'ISPARTA', 32, '246'),
(40, 212, 'İSTANBUL', 34, '212-216'),
(41, 212, 'İZMİR', 35, '232'),
(42, 212, 'KAHRAMANMARAŞ', 46, '344'),
(43, 212, 'KARABÜK', 78, '370'),
(44, 212, 'KARAMAN', 70, '338'),
(45, 212, 'KARS', 36, '474'),
(46, 212, 'KASTAMONU', 37, '366'),
(47, 212, 'KAYSERİ', 38, '352'),
(48, 212, 'KIRIKKALE', 71, '318'),
(49, 212, 'KIRKLARELİ', 39, '288'),
(50, 212, 'KIRŞEHİR', 40, '386'),
(51, 212, 'KİLİS', 79, '348'),
(52, 212, 'KOCAELİ', 41, '262'),
(53, 212, 'KONYA', 42, '332'),
(54, 212, 'KÜTAHYA', 43, '274'),
(55, 212, 'MALATYA', 44, '422'),
(56, 212, 'MANİSA', 45, '236'),
(57, 212, 'MARDİN', 47, '482'),
(58, 212, 'MERSİN', 33, '324'),
(59, 212, 'MUĞLA', 48, '252'),
(60, 212, 'MUŞ', 49, '436'),
(61, 212, 'NEVŞEHİR', 50, '384'),
(62, 212, 'NİĞDE', 51, '388'),
(63, 212, 'ORDU', 52, '452'),
(64, 212, 'OSMANİYE', 80, '328'),
(65, 212, 'RİZE', 53, '464'),
(66, 212, 'SAKARYA', 54, '264'),
(67, 212, 'SAMSUN', 55, '362'),
(68, 212, 'SİİRT', 56, '484'),
(69, 212, 'SİNOP', 57, '368'),
(70, 212, 'SİVAS', 58, '346'),
(71, 212, 'ŞANLIURFA', 63, '414'),
(72, 212, 'ŞIRNAK', 73, '486'),
(73, 212, 'TEKİRDAĞ', 59, '282'),
(74, 212, 'TOKAT', 60, '356'),
(75, 212, 'TRABZON', 61, '462'),
(76, 212, 'TUNCELİ', 62, '428'),
(77, 212, 'UŞAK', 64, '276'),
(78, 212, 'VAN', 65, '432'),
(79, 212, 'YALOVA', 77, '226'),
(80, 212, 'YOZGAT', 66, '354'),
(81, 212, 'ZONGULDAK', 67, '372');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ci_session`
--

CREATE TABLE `ci_session` (
  `id` varchar(128) COLLATE utf8_turkish_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8_turkish_ci NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `ci_session`
--

INSERT INTO `ci_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('ibd7951oeas1mo0hnal5mb6pvn7ap18p', '93.89.225.254', 1624534905, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632343533343839373b69647c733a313a2231223b757365726e616d657c733a353a2261646d696e223b6e616d657c733a343a22456d7265223b7375726e616d657c733a353a22426f647572223b69735f61646d696e7c733a313a2231223b757365725f6f6b756c7c733a34303a2244c3bc7a636520c3966cc3a76d65207665204465c49f65726c656e6469726d65204d65726b657a69223b6c6f67446174657c733a31393a22323032312d30362d32342031343a34313a3431223b69735f6c6f676765645f696e7c623a313b),
('4rmque68odr6g443q3hfhvjivisjnmfa', '93.89.225.254', 1624536326, 0x5f5f63695f6c6173745f726567656e65726174657c693a313632343533363332323b);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `count`
--

CREATE TABLE `count` (
  `id` int(10) NOT NULL,
  `total` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `count`
--

INSERT INTO `count` (`id`, `total`, `date`, `ip`) VALUES
(5, 7, '2019-05-21', '::1');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `country`
--

CREATE TABLE `country` (
  `CountryID` int(11) NOT NULL,
  `BinaryCode` varchar(2) NOT NULL,
  `TripleCode` varchar(3) NOT NULL,
  `CountryName` varchar(100) NOT NULL,
  `PhoneCode` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `country`
--

INSERT INTO `country` (`CountryID`, `BinaryCode`, `TripleCode`, `CountryName`, `PhoneCode`) VALUES
(1, 'AF', 'AFG', 'Afghanistan', '93'),
(2, 'AL', 'ALB', 'Albania', '355'),
(3, 'DZ', 'DZA', 'Algeria', '213'),
(4, 'AS', 'ASM', 'American Samoa', '684'),
(5, 'AD', 'AND', 'Andorra', '376'),
(6, 'AO', 'AGO', 'Angola', '244'),
(7, 'AI', 'AIA', 'Anguilla', '264'),
(8, 'AQ', 'ATA', 'Antarctica', '672'),
(9, 'AG', 'ATG', 'Antigua and Barbuda', '268'),
(10, 'AR', 'ARG', 'Argentina', '54'),
(11, 'AM', 'ARM', 'Armenia', '374'),
(12, 'AW', 'ABW', 'Aruba', '297'),
(13, 'AU', 'AUS', 'Australia', '61'),
(14, 'AT', 'AUT', 'Austria', '43'),
(15, 'AZ', 'AZE', 'Azerbaijan', '994'),
(16, 'BS', 'BHS', 'Bahamas', '242'),
(17, 'BH', 'BHR', 'Bahrain', '973'),
(18, 'BD', 'BGD', 'Bangladesh', '880'),
(19, 'BB', 'BRB', 'Barbados', '246'),
(20, 'BY', 'BLR', 'Belarus', '375'),
(21, 'BE', 'BEL', 'Belgium', '32'),
(22, 'BZ', 'BLZ', 'Belize', '501'),
(23, 'BJ', 'BEN', 'Benin', '229'),
(24, 'BM', 'BMU', 'Bermuda', '441'),
(25, 'BT', 'BTN', 'Bhutan', '975'),
(26, 'BO', 'BOL', 'Bolivia', '591'),
(27, 'BA', 'BIH', 'Bosnia and Herzegovina', '387'),
(28, 'BW', 'BWA', 'Botswana', '267'),
(29, 'BR', 'BRA', 'Brazil', '55'),
(30, 'VG', 'VGB', 'British Virgin Islands', '284'),
(31, 'BN', 'BRN', 'Brunei', '673'),
(32, 'BG', 'BGR', 'Bulgaria', '359'),
(33, 'BF', 'BFA', 'Burkina Faso', '226'),
(34, 'BI', 'BDI', 'Burundi', '257'),
(35, 'KH', 'KHM', 'Cambodia', '855'),
(36, 'CM', 'CMR', 'Cameroon', '237'),
(37, 'CA', 'CAN', 'Canada', '1'),
(38, 'CV', 'CPV', 'Cape Verde', '238'),
(39, 'KY', 'CYM', 'Cayman Islands', '345'),
(40, 'CF', 'CAF', 'Central African Republic', '236'),
(41, 'TD', 'TCD', 'Chad', '235'),
(42, 'CL', 'CHL', 'Chile', '56'),
(43, 'CN', 'CHN', 'China', '86'),
(44, 'CX', 'CXR', 'Christmas Island', '61'),
(45, 'CC', 'CCK', 'Cocos [Keeling] Islands', '61'),
(46, 'CO', 'COL', 'Colombia', '57'),
(47, 'KM', 'COM', 'Comoros', '269'),
(48, 'CD', 'COD', 'Congo [DRC]', '242'),
(49, 'CG', 'COG', 'Congo [Republic]', '682'),
(50, 'CK', 'COK', 'Cook Islands', '506'),
(51, 'CR', 'CRI', 'Costa Rica', '385'),
(52, 'HR', 'HRV', 'Croatia', '53'),
(53, 'CU', 'CUB', 'Cuba', '599'),
(54, 'CY', 'CYP', 'Cyprus', '357'),
(55, 'CZ', 'CZE', 'Czech Republic', '420'),
(56, 'DK', 'DNK', 'Denmark', '45'),
(57, 'DJ', 'DJI', 'Djibouti', '253'),
(58, 'DM', 'DMA', 'Dominica', '767'),
(59, 'DO', 'DOM', 'Dominican Republic', '809'),
(60, 'TL', 'TLS', 'East Timor', '56'),
(61, 'EC', 'ECU', 'Ecuador', '593'),
(62, 'EG', 'EGY', 'Egypt', '20'),
(63, 'SV', 'SLV', 'El Salvador', '503'),
(64, 'GQ', 'GNQ', 'Equatorial Guinea', '240'),
(65, 'ER', 'ERI', 'Eritrea', '291'),
(66, 'EE', 'EST', 'Estonia', '372'),
(67, 'ET', 'ETH', 'Ethiopia', '251'),
(68, 'FK', 'FLK', 'Falkland Islands', '500'),
(69, 'FO', 'FRO', 'Faroe Islands', '298'),
(70, 'FJ', 'FJI', 'Fiji', '679'),
(71, 'FI', 'FIN', 'Finland', '358'),
(72, 'FR', 'FRA', 'France', '33'),
(73, 'GF', 'GUF', 'French Guiana', '596'),
(74, 'PF', 'PYF', 'French Polynesia', '594'),
(75, 'TF', 'ATF', 'French Southern Territories', '689'),
(76, 'GA', 'GAB', 'Gabon', '241'),
(77, 'GM', 'GMB', 'Gambia', '220'),
(78, 'GE', 'GEO', 'Georgia', '995'),
(79, 'DE', 'DEU', 'Germany', '49'),
(80, 'GH', 'GHA', 'Ghana', '233'),
(81, 'GI', 'GIB', 'Gibraltar', '350'),
(82, 'GR', 'GRC', 'Greece', '30'),
(83, 'GL', 'GRL', 'Greenland', '299'),
(84, 'GD', 'GRD', 'Grenada', '473'),
(85, 'GP', 'GLP', 'Guadeloupe', '590'),
(86, 'GU', 'GUM', 'Guam', '671'),
(87, 'GT', 'GTM', 'Guatemala', '502'),
(88, 'GN', 'GIN', 'Guinea', '594'),
(89, 'GW', 'GNB', 'Guinea-Bissau', '245'),
(90, 'GY', 'GUY', 'Guyana', '592'),
(91, 'HT', 'HTI', 'Haiti', '509'),
(92, 'HN', 'HND', 'Honduras', '504'),
(93, 'HK', 'HKG', 'Hong Kong', '852'),
(94, 'HU', 'HUN', 'Hungary', '36'),
(95, 'IS', 'ISL', 'Iceland', '354'),
(96, 'IN', 'IND', 'India', '91'),
(97, 'ID', 'IDN', 'Indonesia', '62'),
(98, 'IR', 'IRN', 'Iran', '98'),
(99, 'IQ', 'IRQ', 'Iraq', '964'),
(100, 'IE', 'IRL', 'Ireland', '353'),
(101, 'IM', 'IMN', 'Isle of Man', '44'),
(102, 'IL', 'ISR', 'Israel', '972'),
(103, 'IT', 'ITA', 'Italy', '39'),
(104, 'CI', 'CIV', 'Ivory Coast', '225'),
(105, 'JM', 'JAM', 'Jamaica', '876'),
(106, 'JP', 'JPN', 'Japan', '81'),
(107, 'JO', 'JOR', 'Jordan', '962'),
(108, 'KZ', 'KAZ', 'Kazakhstan', '7'),
(109, 'KE', 'KEN', 'Kenya', '254'),
(110, 'KI', 'KIR', 'Kiribati', '686'),
(111, 'XK', 'XKX', 'Kosovo', '381'),
(112, 'KW', 'KWT', 'Kuwait', '965'),
(113, 'KG', 'KGZ', 'Kyrgyzstan', '996'),
(114, 'LA', 'LAO', 'Laos', '856'),
(115, 'LV', 'LVA', 'Latvia', '371'),
(116, 'LB', 'LBN', 'Lebanon', '961'),
(117, 'LS', 'LSO', 'Lesotho', '266'),
(118, 'LR', 'LBR', 'Liberia', '231'),
(119, 'LY', 'LBY', 'Libya', '218'),
(120, 'LI', 'LIE', 'Liechtenstein', '423'),
(121, 'LT', 'LTU', 'Lithuania', '370'),
(122, 'LU', 'LUX', 'Luxembourg', '352'),
(123, 'MO', 'MAC', 'Macau', '853'),
(124, 'MK', 'MKD', 'Macedonia', '389'),
(125, 'MG', 'MDG', 'Madagascar', '261'),
(126, 'MW', 'MWI', 'Malawi', '265'),
(127, 'MY', 'MYS', 'Malaysia', '60'),
(128, 'MV', 'MDV', 'Maldives', '960'),
(129, 'ML', 'MLI', 'Mali', '223'),
(130, 'MT', 'MLT', 'Malta', '356'),
(131, 'MH', 'MHL', 'Marshall Islands', '692'),
(132, 'MQ', 'MTQ', 'Martinique', '670'),
(133, 'MR', 'MRT', 'Mauritania', '222'),
(134, 'MU', 'MUS', 'Mauritius', '230'),
(135, 'YT', 'MYT', 'Mayotte', '269'),
(136, 'MX', 'MEX', 'Mexico', '52'),
(137, 'FM', 'FSM', 'Micronesia', '691'),
(138, 'MD', 'MDA', 'Moldova', '373'),
(139, 'MC', 'MCO', 'Monaco', '377'),
(140, 'MN', 'MNG', 'Mongolia', '976'),
(141, 'MS', 'MSR', 'Montserrat', '664'),
(142, 'MA', 'MAR', 'Morocco', '212'),
(143, 'MZ', 'MOZ', 'Mozambique', '258'),
(144, 'MM', 'MMR', 'Myanmar [Burma]', '95'),
(145, 'NA', 'NAM', 'Namibia', '264'),
(146, 'NR', 'NRU', 'Nauru', '674'),
(147, 'NP', 'NPL', 'Nepal', '977'),
(148, 'NL', 'NLD', 'Netherlands', '31'),
(149, 'AN', 'ANT', 'Netherlands Antilles', '599'),
(150, 'NC', 'NCL', 'New Caledonia', '687'),
(151, 'NZ', 'NZL', 'New Zealand', '64'),
(152, 'NI', 'NIC', 'Nicaragua', '505'),
(153, 'NE', 'NER', 'Niger', '227'),
(154, 'NG', 'NGA', 'Nigeria', '234'),
(155, 'NU', 'NIU', 'Niue', '683'),
(156, 'NF', 'NFK', 'Norfolk Island', '672'),
(157, 'KP', 'PRK', 'North Korea', '850'),
(158, 'NO', 'NOR', 'Norway', '47'),
(159, 'OM', 'OMN', 'Oman', '968'),
(160, 'PK', 'PAK', 'Pakistan', '92'),
(161, 'PW', 'PLW', 'Palau', '680'),
(162, 'PA', 'PAN', 'Panama', '507'),
(163, 'PG', 'PNG', 'Papua New Guinea', '675'),
(164, 'PY', 'PRY', 'Paraguay', '595'),
(165, 'PE', 'PER', 'Peru', '51'),
(166, 'PH', 'PHL', 'Philippines', '63'),
(167, 'PN', 'PCN', 'Pitcairn Islands', '48'),
(168, 'PL', 'POL', 'Poland', '351'),
(169, 'PT', 'PRT', 'Portugal', '239'),
(170, 'PR', 'PRI', 'Puerto Rico', '787'),
(171, 'QA', 'QAT', 'Qatar', '974'),
(172, 'RE', 'REU', 'R', '262'),
(173, 'RO', 'ROU', 'Romania', '40'),
(174, 'RU', 'RUS', 'Russia', '7'),
(175, 'RW', 'RWA', 'Rwanda', '250'),
(176, 'SH', 'SHN', 'Saint Helena', '290'),
(177, 'KN', 'KNA', 'Saint Kitts and Nevis', '869'),
(178, 'LC', 'LCA', 'Saint Lucia', '758'),
(179, 'PM', 'SPM', 'Saint Pierre and Miquelon', '508'),
(180, 'VC', 'VCT', 'Saint Vincent and the Grenadines', '784'),
(181, 'SM', 'SMR', 'San Marino', '378'),
(182, 'ST', 'STP', 'Sao Tome and Principe', '239'),
(183, 'SA', 'SAU', 'Saudi Arabia', '966'),
(184, 'SN', 'SEN', 'Senegal', '221'),
(185, 'RS', 'SRB', 'Serbia', '381'),
(186, 'SC', 'SYC', 'Seychelles', '248'),
(187, 'SL', 'SLE', 'Sierra Leone', '232'),
(188, 'SG', 'SGP', 'Singapore', '65'),
(189, 'SK', 'SVK', 'Slovakia', '421'),
(190, 'SI', 'SVN', 'Slovenia', '386'),
(191, 'SB', 'SLB', 'Solomon Islands', '677'),
(192, 'SO', 'SOM', 'Somalia', '252'),
(193, 'ZA', 'ZAF', 'South Africa', '27'),
(194, 'KR', 'KOR', 'South Korea', '82'),
(195, 'ES', 'ESP', 'Spain', '34'),
(196, 'LK', 'LKA', 'Sri Lanka', '94'),
(197, 'SD', 'SDN', 'Sudan', '249'),
(198, 'SR', 'SUR', 'Suriname', '597'),
(199, 'SZ', 'SWZ', 'Swaziland', '268'),
(200, 'SE', 'SWE', 'Sweden', '46'),
(201, 'CH', 'CHE', 'Switzerland', '41'),
(202, 'SY', 'SYR', 'Syria', '963'),
(203, 'TW', 'TWN', 'Taiwan', '886'),
(204, 'TJ', 'TJK', 'Tajikistan', '992'),
(205, 'TZ', 'TZA', 'Tanzania', '255'),
(206, 'TH', 'THA', 'Thailand', '66'),
(207, 'TG', 'TGO', 'Togo', '228'),
(208, 'TK', 'TKL', 'Tokelau', '690'),
(209, 'TO', 'TON', 'Tonga', '676'),
(210, 'TT', 'TTO', 'Trinidad and Tobago', '868'),
(211, 'TN', 'TUN', 'Tunisia', '216'),
(212, 'TR', 'TUR', 'Turkey', '90'),
(213, 'TM', 'TKM', 'Turkmenistan', '993'),
(214, 'TC', 'TCA', 'Turks and Caicos Islands', '649'),
(215, 'TV', 'TUV', 'Tuvalu', '688'),
(216, 'VI', 'VIR', 'U.S. Virgin Islands', '340'),
(217, 'UG', 'UGA', 'Uganda', '256'),
(218, 'UA', 'UKR', 'Ukraine', '380'),
(219, 'AE', 'ARE', 'United Arab Emirates', '971'),
(220, 'GB', 'GBR', 'United Kingdom', '44'),
(221, 'US', 'USA', 'United States', '1'),
(222, 'UY', 'URY', 'Uruguay', '598'),
(223, 'UZ', 'UZB', 'Uzbekistan', '998'),
(224, 'VU', 'VUT', 'Vanuatu', '678'),
(225, 'VA', 'VAT', 'Vatican City', '39'),
(226, 'VE', 'VEN', 'Venezuela', '58'),
(227, 'VN', 'VNM', 'Vietnam', '84'),
(228, 'WF', 'WLF', 'Wallis and Futuna', '681'),
(229, 'YE', 'YEM', 'Yemen', '967'),
(230, 'ZM', 'ZMB', 'Zambia', '260'),
(231, 'ZW', 'ZWE', 'Zimbabwe', '263'),
(232, 'CY', 'CYP', 'KKTC', '90');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `currency`
--

CREATE TABLE `currency` (
  `id` int(11) NOT NULL,
  `country` varchar(100) COLLATE utf8_turkish_ci DEFAULT NULL,
  `currency` varchar(100) COLLATE utf8_turkish_ci DEFAULT NULL,
  `code` varchar(100) COLLATE utf8_turkish_ci DEFAULT NULL,
  `symbol` varchar(100) COLLATE utf8_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `currency`
--

INSERT INTO `currency` (`id`, `country`, `currency`, `code`, `symbol`) VALUES
(1, 'Albania', 'Leke', 'ALL', 'Lek'),
(2, 'America', 'Dollars', 'USD', '$'),
(3, 'Afghanistan', 'Afghanis', 'AFN', '؋'),
(4, 'Argentina', 'Pesos', 'ARS', '$'),
(5, 'Aruba', 'Guilders', 'AWG', 'ƒ'),
(6, 'Australia', 'Dollars', 'AUD', '$'),
(7, 'Azerbaijan', 'New Manats', 'AZN', 'ман'),
(8, 'Bahamas', 'Dollars', 'BSD', '$'),
(9, 'Barbados', 'Dollars', 'BBD', '$'),
(10, 'Belarus', 'Rubles', 'BYR', 'p.'),
(11, 'Belgium', 'Euro', 'EUR', '€'),
(12, 'Beliz', 'Dollars', 'BZD', 'BZ$'),
(13, 'Bermuda', 'Dollars', 'BMD', '$'),
(14, 'Bolivia', 'Bolivianos', 'BOB', '$b'),
(15, 'Bosnia and Herzegovina', 'Convertible Marka', 'BAM', 'KM'),
(16, 'Botswana', 'Pula', 'BWP', 'P'),
(17, 'Bulgaria', 'Leva', 'BGN', 'лв'),
(18, 'Brazil', 'Reais', 'BRL', 'R$'),
(19, 'Britain (United Kingdom)', 'Pounds', 'GBP', '£'),
(20, 'Brunei Darussalam', 'Dollars', 'BND', '$'),
(21, 'Cambodia', 'Riels', 'KHR', '៛'),
(22, 'Canada', 'Dollars', 'CAD', '$'),
(23, 'Cayman Islands', 'Dollars', 'KYD', '$'),
(24, 'Chile', 'Pesos', 'CLP', '$'),
(25, 'China', 'Yuan Renminbi', 'CNY', '¥'),
(26, 'Colombia', 'Pesos', 'COP', '$'),
(27, 'Costa Rica', 'Colón', 'CRC', '₡'),
(28, 'Croatia', 'Kuna', 'HRK', 'kn'),
(29, 'Cuba', 'Pesos', 'CUP', '₱'),
(30, 'Cyprus', 'Euro', 'EUR', '€'),
(31, 'Czech Republic', 'Koruny', 'CZK', 'Kč'),
(32, 'Denmark', 'Kroner', 'DKK', 'kr'),
(33, 'Dominican Republic', 'Pesos', 'DOP ', 'RD$'),
(34, 'East Caribbean', 'Dollars', 'XCD', '$'),
(35, 'Egypt', 'Pounds', 'EGP', '£'),
(36, 'El Salvador', 'Colones', 'SVC', '$'),
(37, 'England (United Kingdom)', 'Pounds', 'GBP', '£'),
(38, 'Euro', 'Euro', 'EUR', '€'),
(39, 'Falkland Islands', 'Pounds', 'FKP', '£'),
(40, 'Fiji', 'Dollars', 'FJD', '$'),
(41, 'France', 'Euro', 'EUR', '€'),
(42, 'Ghana', 'Cedis', 'GHC', '¢'),
(43, 'Gibraltar', 'Pounds', 'GIP', '£'),
(44, 'Greece', 'Euro', 'EUR', '€'),
(45, 'Guatemala', 'Quetzales', 'GTQ', 'Q'),
(46, 'Guernsey', 'Pounds', 'GGP', '£'),
(47, 'Guyana', 'Dollars', 'GYD', '$'),
(48, 'Holland (Netherlands)', 'Euro', 'EUR', '€'),
(49, 'Honduras', 'Lempiras', 'HNL', 'L'),
(50, 'Hong Kong', 'Dollars', 'HKD', '$'),
(51, 'Hungary', 'Forint', 'HUF', 'Ft'),
(52, 'Iceland', 'Kronur', 'ISK', 'kr'),
(53, 'India', 'Rupees', 'INR', 'Rp'),
(54, 'Indonesia', 'Rupiahs', 'IDR', 'Rp'),
(55, 'Iran', 'Rials', 'IRR', '﷼'),
(56, 'Ireland', 'Euro', 'EUR', '€'),
(57, 'Isle of Man', 'Pounds', 'IMP', '£'),
(58, 'Israel', 'New Shekels', 'ILS', '₪'),
(59, 'Italy', 'Euro', 'EUR', '€'),
(60, 'Jamaica', 'Dollars', 'JMD', 'J$'),
(61, 'Japan', 'Yen', 'JPY', '¥'),
(62, 'Jersey', 'Pounds', 'JEP', '£'),
(63, 'Kazakhstan', 'Tenge', 'KZT', 'лв'),
(64, 'Korea (North)', 'Won', 'KPW', '₩'),
(65, 'Korea (South)', 'Won', 'KRW', '₩'),
(66, 'Kyrgyzstan', 'Soms', 'KGS', 'лв'),
(67, 'Laos', 'Kips', 'LAK', '₭'),
(68, 'Latvia', 'Lati', 'LVL', 'Ls'),
(69, 'Lebanon', 'Pounds', 'LBP', '£'),
(70, 'Liberia', 'Dollars', 'LRD', '$'),
(71, 'Liechtenstein', 'Switzerland Francs', 'CHF', 'CHF'),
(72, 'Lithuania', 'Litai', 'LTL', 'Lt'),
(73, 'Luxembourg', 'Euro', 'EUR', '€'),
(74, 'Macedonia', 'Denars', 'MKD', 'ден'),
(75, 'Malaysia', 'Ringgits', 'MYR', 'RM'),
(76, 'Malta', 'Euro', 'EUR', '€'),
(77, 'Mauritius', 'Rupees', 'MUR', '₨'),
(78, 'Mexico', 'Pesos', 'MXN', '$'),
(79, 'Mongolia', 'Tugriks', 'MNT', '₮'),
(80, 'Mozambique', 'Meticais', 'MZN', 'MT'),
(81, 'Namibia', 'Dollars', 'NAD', '$'),
(82, 'Nepal', 'Rupees', 'NPR', '₨'),
(83, 'Netherlands Antilles', 'Guilders', 'ANG', 'ƒ'),
(84, 'Netherlands', 'Euro', 'EUR', '€'),
(85, 'New Zealand', 'Dollars', 'NZD', '$'),
(86, 'Nicaragua', 'Cordobas', 'NIO', 'C$'),
(87, 'Nigeria', 'Nairas', 'NGN', '₦'),
(88, 'North Korea', 'Won', 'KPW', '₩'),
(89, 'Norway', 'Krone', 'NOK', 'kr'),
(90, 'Oman', 'Rials', 'OMR', '﷼'),
(91, 'Pakistan', 'Rupees', 'PKR', '₨'),
(92, 'Panama', 'Balboa', 'PAB', 'B/.'),
(93, 'Paraguay', 'Guarani', 'PYG', 'Gs'),
(94, 'Peru', 'Nuevos Soles', 'PEN', 'S/.'),
(95, 'Philippines', 'Pesos', 'PHP', 'Php'),
(96, 'Poland', 'Zlotych', 'PLN', 'zł'),
(97, 'Qatar', 'Rials', 'QAR', '﷼'),
(98, 'Romania', 'New Lei', 'RON', 'lei'),
(99, 'Russia', 'Rubles', 'RUB', 'руб'),
(100, 'Saint Helena', 'Pounds', 'SHP', '£'),
(101, 'Saudi Arabia', 'Riyals', 'SAR', '﷼'),
(102, 'Serbia', 'Dinars', 'RSD', 'Дин.'),
(103, 'Seychelles', 'Rupees', 'SCR', '₨'),
(104, 'Singapore', 'Dollars', 'SGD', '$'),
(105, 'Slovenia', 'Euro', 'EUR', '€'),
(106, 'Solomon Islands', 'Dollars', 'SBD', '$'),
(107, 'Somalia', 'Shillings', 'SOS', 'S'),
(108, 'South Africa', 'Rand', 'ZAR', 'R'),
(109, 'South Korea', 'Won', 'KRW', '₩'),
(110, 'Spain', 'Euro', 'EUR', '€'),
(111, 'Sri Lanka', 'Rupees', 'LKR', '₨'),
(112, 'Sweden', 'Kronor', 'SEK', 'kr'),
(113, 'Switzerland', 'Francs', 'CHF', 'CHF'),
(114, 'Suriname', 'Dollars', 'SRD', '$'),
(115, 'Syria', 'Pounds', 'SYP', '£'),
(116, 'Taiwan', 'New Dollars', 'TWD', 'NT$'),
(117, 'Thailand', 'Baht', 'THB', '฿'),
(118, 'Trinidad and Tobago', 'Dollars', 'TTD', 'TT$'),
(119, 'Turkey', 'Lira', 'TRY', 'TL'),
(120, 'Turkey', 'Lira', 'TRY', '₺'),
(121, 'Tuvalu', 'Dollars', 'TVD', '$'),
(122, 'Ukraine', 'Hryvnia', 'UAH', '₴'),
(123, 'United Kingdom', 'Pounds', 'GBP', '£'),
(124, 'United States of America', 'Dollars', 'USD', '$'),
(125, 'Uruguay', 'Pesos', 'UYU', '$U'),
(126, 'Uzbekistan', 'Sums', 'UZS', 'лв'),
(127, 'Vatican City', 'Euro', 'EUR', '€'),
(128, 'Venezuela', 'Bolivares Fuertes', 'VEF', 'Bs'),
(129, 'Vietnam', 'Dong', 'VND', '₫'),
(130, 'Yemen', 'Rials', 'YER', '﷼'),
(131, 'Zimbabwe', 'Zimbabwe Dollars', 'ZWD', 'Z$');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dersler`
--

CREATE TABLE `dersler` (
  `id` int(11) NOT NULL,
  `bransKodu` int(11) NOT NULL,
  `adi` text COLLATE utf8_turkish_ci NOT NULL,
  `kisa_kod` text COLLATE utf8_turkish_ci NOT NULL,
  `sinif` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `dersler`
--

INSERT INTO `dersler` (`id`, `bransKodu`, `adi`, `kisa_kod`, `sinif`) VALUES
(1, 0, 'Bilişim Teknolojileri', 'BIT', 5),
(2, 0, 'Fen Bilimleri', 'FEN', 7),
(3, 0, 'İlköğretim Matematik', 'MAT', 5),
(4, 0, 'Türkçe', 'TUR', 5),
(5, 0, 'Sosyal Bilgiler', 'SOS', 5),
(6, 0, 'Lise Matematik', 'LISMAT', 9),
(7, 0, 'Kimya', 'KIM', 9),
(8, 0, 'Biyoloji', 'BIY', 9),
(9, 0, 'Din Kültürü ve Ahlak Bilgisi', 'DKB', 5),
(10, 0, 'İngilizce', 'ING', 5),
(11, 0, 'Tarih', 'TAR', 9),
(12, 0, 'Coğrafya', 'COG', 9),
(13, 0, 'Fizik', 'FIZ', 9),
(14, 0, 'Türk Dili ve Edebiyatı', 'TDE', 9),
(15, 0, 'Bilgisayar Bilimi', 'BIL', 9);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `duyurular`
--

CREATE TABLE `duyurular` (
  `id` int(11) NOT NULL,
  `baslik` varchar(255) NOT NULL,
  `icerik` text NOT NULL,
  `ozet` varchar(255) NOT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT '1',
  `kayit_tarihi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `guncelleme_tarihi` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `anahtar_kelimeler` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `haberler`
--

CREATE TABLE `haberler` (
  `id` int(11) NOT NULL,
  `baslik` varchar(255) NOT NULL,
  `icerik` text NOT NULL,
  `ozet` varchar(255) NOT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT '1',
  `kayit_tarihi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `guncelleme_tarihi` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `anahtar_kelimeler` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iletisim`
--

CREATE TABLE `iletisim` (
  `id` int(11) NOT NULL,
  `konu` varchar(255) NOT NULL,
  `mesaj` text NOT NULL,
  `ad` varchar(255) NOT NULL,
  `soyad` varchar(255) NOT NULL,
  `eposta` varchar(255) NOT NULL,
  `kayit_tarihi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cevap_tarihi` date NOT NULL,
  `cevaplanma_durumu` tinyint(1) NOT NULL DEFAULT '0',
  `cevap_mesaji` text NOT NULL,
  `spam_mesaj` tinyint(1) NOT NULL DEFAULT '0',
  `okundu_bilgisi` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `iletisim`
--

INSERT INTO `iletisim` (`id`, `konu`, `mesaj`, `ad`, `soyad`, `eposta`, `kayit_tarihi`, `cevap_tarihi`, `cevaplanma_durumu`, `cevap_mesaji`, `spam_mesaj`, `okundu_bilgisi`) VALUES
(1, '4', 'Teşekkür', 'Emre', 'Bodur', 'emrebodurbto@gmail.com', '2019-05-02 07:43:46', '0000-00-00', 0, '', 0, 0),
(3, '1', 'Öneri', 'Emre', 'Bodur', 'emrebodurbto@gmail.com', '2019-05-13 10:53:37', '0000-00-00', 0, '', 0, 0),
(4, '2', 'Şikayet', 'Elif', 'Bodur', 'elifkarakusbodur@gmail.com', '2019-05-13 10:53:40', '0000-00-00', 0, '', 0, 0),
(5, '3', 'Bilgi Edinme', 'Ahmet Tuna', 'Bodur', 'ahmettunabodur@gmail.com', '2019-05-13 10:53:42', '0000-00-00', 1, 'Merhaba Ahmet Tuna canım oğlum :)', 0, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kazanimlar`
--

CREATE TABLE `kazanimlar` (
  `id` int(11) NOT NULL,
  `kazanim_kodu` text COLLATE utf8_turkish_ci NOT NULL,
  `kazanim_icerik` text COLLATE utf8_turkish_ci NOT NULL,
  `sinif` int(11) NOT NULL,
  `unite_kodu` varchar(15) COLLATE utf8_turkish_ci NOT NULL,
  `konu_kodu` varchar(10) COLLATE utf8_turkish_ci NOT NULL,
  `dersID` int(11) NOT NULL,
  `uniteID` int(11) NOT NULL,
  `konuID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kazanimlar`
--

INSERT INTO `kazanimlar` (`id`, `kazanim_kodu`, `kazanim_icerik`, `sinif`, `unite_kodu`, `konu_kodu`, `dersID`, `uniteID`, `konuID`) VALUES
(1, '01.01.01', 'Uzay teknolojilerini açıklar.', 7, '01', '01.01', 2, 1, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `konular`
--

CREATE TABLE `konular` (
  `id` int(11) NOT NULL,
  `dersID` int(11) NOT NULL,
  `sinif` int(11) NOT NULL,
  `uniteID` int(11) NOT NULL,
  `konu_kodu` text NOT NULL,
  `konu_icerik` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `konular`
--

INSERT INTO `konular` (`id`, `dersID`, `sinif`, `uniteID`, `konu_kodu`, `konu_icerik`) VALUES
(1, 2, 7, 2, '01.01', 'Uzay Araştırmaları'),
(2, 2, 7, 1, '01.02', 'Güneş Sistemi Ötesi: Gök Cisimleri');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(128) COLLATE utf8_turkish_ci NOT NULL,
  `description` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `createDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`, `createDate`) VALUES
(1, 'Admin', 'Yöneticiler için tanımlanan roldür.', '2019-04-22 10:19:11'),
(2, 'User', 'Kullanıcılar için tanımlanan roldür.', '2019-04-22 10:19:25'),
(3, 'Öğretmen', 'Öğretmen kullanıcıları için tanımlanan roldür.', '2020-05-14 14:54:30'),
(4, 'Uzman', 'Uzman kullanıcılar için tanımlanan roldür.', '2020-05-14 14:59:24');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `site_bilgileri`
--

CREATE TABLE `site_bilgileri` (
  `id` int(11) NOT NULL,
  `site_adi` varchar(255) NOT NULL,
  `site_slogani` varchar(255) NOT NULL,
  `site_adresi` varchar(255) NOT NULL,
  `site_aktif` tinyint(1) NOT NULL DEFAULT '1',
  `firma_adi` varchar(255) NOT NULL,
  `firma_tel1` varchar(255) NOT NULL,
  `firma_tel2` varchar(255) NOT NULL,
  `firma_gsm` varchar(255) NOT NULL,
  `firma_eposta` varchar(255) NOT NULL,
  `site_eposta` varchar(255) NOT NULL,
  `firma_sorumlusu` varchar(255) NOT NULL,
  `firma_adres` text NOT NULL,
  `anahtar_kelimeler` varchar(255) NOT NULL,
  `facebook_url` varchar(255) NOT NULL,
  `twitter_url` varchar(255) NOT NULL,
  `instagram_url` varchar(255) NOT NULL,
  `firma_fax` varchar(255) NOT NULL,
  `google_site_verification_code` text NOT NULL,
  `google_analytics_code` varchar(255) NOT NULL,
  `license_number` text,
  `license_start_date` text,
  `license_end_date` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `site_bilgileri`
--

INSERT INTO `site_bilgileri` (`id`, `site_adi`, `site_slogani`, `site_adresi`, `site_aktif`, `firma_adi`, `firma_tel1`, `firma_tel2`, `firma_gsm`, `firma_eposta`, `site_eposta`, `firma_sorumlusu`, `firma_adres`, `anahtar_kelimeler`, `facebook_url`, `twitter_url`, `instagram_url`, `firma_fax`, `google_site_verification_code`, `google_analytics_code`, `license_number`, `license_start_date`, `license_end_date`) VALUES
(1, 'Düzce ÖDM Soru Havuzu', 'Soru Havuzu', 'soruhavuzu.emrebodur.com', 1, 'Düzce ÖDM', '2128763020', '2128764520 ', '5325245804 ', 'info@logista.com.tr ', 'noreply@logista.com.tr ', 'Emre Bodur', 'Kuyumcuzade Bulvarı No:23<br/> \r\nMerkez / Düzce\r\n', 'logista kurye ve lojistik hizmetleri, logista, logista.com.tr, logista lojistik, logista kurye', 'https://www.facebook.com/logistatr/', 'https://twitter.com/logistakurye', 'https://www.instagram.com/logistakurye/', '2128764041', 'p6gXJxCfgBz8cJx18wsl9j0kFlGKpaZApdm8PAFhCTs', 'UA-97394039-2', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sorular`
--

CREATE TABLE `sorular` (
  `id` int(11) NOT NULL,
  `no` text NOT NULL,
  `kodu` text NOT NULL,
  `dersAdi` text NOT NULL,
  `dersID` int(11) NOT NULL,
  `sinifDuzeyi` int(11) NOT NULL,
  `zorlukDerecesi` int(11) NOT NULL,
  `unite` text NOT NULL,
  `konuAltKonuAlani` text NOT NULL,
  `kazanim_no` text NOT NULL,
  `kazanim_icerik` text NOT NULL,
  `madde_koku` text NOT NULL,
  `dogru_cevap` text NOT NULL,
  `dogrulama_kodu` text NOT NULL,
  `onay_durumu` tinyint(4) NOT NULL DEFAULT '1',
  `kayit_tarihi` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userID` int(11) NOT NULL,
  `onaylayanUserID` int(11) NOT NULL,
  `uzman_yorumu` text NOT NULL,
  `okulTuru` int(11) NOT NULL,
  `cevap_a` text NOT NULL,
  `cevap_b` text NOT NULL,
  `cevap_c` text NOT NULL,
  `cevap_d` text NOT NULL,
  `cevap_e` text,
  `duzenlenebilir` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `sorular`
--

INSERT INTO `sorular` (`id`, `no`, `kodu`, `dersAdi`, `dersID`, `sinifDuzeyi`, `zorlukDerecesi`, `unite`, `konuAltKonuAlani`, `kazanim_no`, `kazanim_icerik`, `madde_koku`, `dogru_cevap`, `dogrulama_kodu`, `onay_durumu`, `kayit_tarihi`, `userID`, `onaylayanUserID`, `uzman_yorumu`, `okulTuru`, `cevap_a`, `cevap_b`, `cevap_c`, `cevap_d`, `cevap_e`, `duzenlenebilir`) VALUES
(5, '314370', '21-SOS-7-314370', 'Sosyal Bilgiler', 5, 7, 1, 'Ülkemizi Tanıyalım', '', '7.1.1.1.', 'Ülkemizi Tanıyalım', '<p><strong>Türkiye\'nin başkenti neresidir?</strong></p>\r\n', 'A', 'cc473059-a60f-4901-8e12-86d479ad87e6', 5, '2021-03-30 16:47:19', 2, 1, '', 2, '<p>Ankara</p>\r\n', '<p>Bolu</p>\r\n', '<p>Düzce</p>\r\n', '<p>Kastamonu</p>\r\n', NULL, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `town`
--

CREATE TABLE `town` (
  `TownID` int(11) NOT NULL,
  `CityID` int(11) NOT NULL,
  `TownName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `town`
--

INSERT INTO `town` (`TownID`, `CityID`, `TownName`) VALUES
(1, 1, 'ALADAĞ'),
(2, 1, 'CEYHAN'),
(3, 1, 'ÇUKUROVA'),
(4, 1, 'FEKE'),
(5, 1, 'İMAMOĞLU'),
(6, 1, 'KARAİSALI'),
(7, 1, 'KARATAŞ'),
(8, 1, 'KOZAN'),
(9, 1, 'POZANTI'),
(10, 1, 'SAİMBEYLİ'),
(11, 1, 'SARIÇAM'),
(12, 1, 'SEYHAN'),
(13, 1, 'TUFANBEYLİ'),
(14, 1, 'YUMURTALIK'),
(15, 1, 'YÜREĞİR'),
(16, 2, 'BESNİ'),
(17, 2, 'ÇELİKHAN'),
(18, 2, 'GERGER'),
(19, 2, 'GÖLBAŞI'),
(20, 2, 'KAHTA'),
(21, 2, 'MERKEZ'),
(22, 2, 'SAMSAT'),
(23, 2, 'SİNCİK'),
(24, 2, 'TUT'),
(25, 3, 'BAŞMAKÇI'),
(26, 3, 'BAYAT'),
(27, 3, 'BOLVADİN'),
(28, 3, 'ÇAY'),
(29, 3, 'ÇOBANLAR'),
(30, 3, 'DAZKIRI'),
(31, 3, 'DİNAR'),
(32, 3, 'EMİRDAĞ'),
(33, 3, 'EVCİLER'),
(34, 3, 'HOCALAR'),
(35, 3, 'İHSANİYE'),
(36, 3, 'İSCEHİSAR'),
(37, 3, 'KIZILÖREN'),
(38, 3, 'MERKEZ'),
(39, 3, 'SANDIKLI'),
(40, 3, 'SİNANPAŞA'),
(41, 3, 'SULTANDAĞI'),
(42, 3, 'ŞUHUT'),
(43, 4, 'DİYADİN'),
(44, 4, 'DOĞUBAYAZIT'),
(45, 4, 'ELEŞKİRT'),
(46, 4, 'HAMUR'),
(47, 4, 'MERKEZ'),
(48, 4, 'PATNOS'),
(49, 4, 'TAŞLIÇAY'),
(50, 4, 'TUTAK'),
(51, 5, 'AĞAÇÖREN'),
(52, 5, 'ESKİL'),
(53, 5, 'GÜLAĞAÇ'),
(54, 5, 'GÜZELYURT'),
(55, 5, 'MERKEZ'),
(56, 5, 'ORTAKÖY'),
(57, 5, 'SARIYAHŞİ'),
(58, 5, 'SULTANHANI'),
(59, 6, 'GÖYNÜCEK'),
(60, 6, 'GÜMÜŞHACIKÖY'),
(61, 6, 'HAMAMÖZÜ'),
(62, 6, 'MERKEZ'),
(63, 6, 'MERZİFON'),
(64, 6, 'SULUOVA'),
(65, 6, 'TAŞOVA'),
(66, 7, 'AKYURT'),
(67, 7, 'ALTINDAĞ'),
(68, 7, 'AYAŞ'),
(69, 7, 'BALA'),
(70, 7, 'BEYPAZARI'),
(71, 7, 'ÇAMLIDERE'),
(72, 7, 'ÇANKAYA'),
(73, 7, 'ÇUBUK'),
(74, 7, 'ELMADAĞ'),
(75, 7, 'ETİMESGUT'),
(76, 7, 'EVREN'),
(77, 7, 'GÖLBAŞI'),
(78, 7, 'GÜDÜL'),
(79, 7, 'HAYMANA'),
(80, 7, 'KAHRAMANKAZAN'),
(81, 7, 'KALECİK'),
(82, 7, 'KEÇİÖREN'),
(83, 7, 'KIZILCAHAMAM'),
(84, 7, 'MAMAK'),
(85, 7, 'NALLIHAN'),
(86, 7, 'POLATLI'),
(87, 7, 'PURSAKLAR'),
(88, 7, 'SİNCAN'),
(89, 7, 'ŞEREFLİKOÇHİSAR'),
(90, 7, 'YENİMAHALLE'),
(91, 8, 'AKSEKİ'),
(92, 8, 'AKSU'),
(93, 8, 'ALANYA'),
(94, 8, 'DEMRE'),
(95, 8, 'DÖŞEMEALTI'),
(96, 8, 'ELMALI'),
(97, 8, 'FİNİKE'),
(98, 8, 'GAZİPAŞA'),
(99, 8, 'GÜNDOĞMUŞ'),
(100, 8, 'İBRADI'),
(101, 8, 'KAŞ'),
(102, 8, 'KEMER'),
(103, 8, 'KEPEZ'),
(104, 8, 'KONYAALTI'),
(105, 8, 'KORKUTELİ'),
(106, 8, 'KUMLUCA'),
(107, 8, 'MANAVGAT'),
(108, 8, 'MURATPAŞA'),
(109, 8, 'SERİK'),
(110, 9, 'ÇILDIR'),
(111, 9, 'DAMAL'),
(112, 9, 'GÖLE'),
(113, 9, 'HANAK'),
(114, 9, 'MERKEZ'),
(115, 9, 'POSOF'),
(116, 10, 'ARDANUÇ'),
(117, 10, 'ARHAVİ'),
(118, 10, 'BORÇKA'),
(119, 10, 'HOPA'),
(120, 10, 'KEMALPAŞA'),
(121, 10, 'MERKEZ'),
(122, 10, 'MURGUL'),
(123, 10, 'ŞAVŞAT'),
(124, 10, 'YUSUFELİ'),
(125, 11, 'BOZDOĞAN'),
(126, 11, 'BUHARKENT'),
(127, 11, 'ÇİNE'),
(128, 11, 'DİDİM'),
(129, 11, 'EFELER'),
(130, 11, 'GERMENCİK'),
(131, 11, 'İNCİRLİOVA'),
(132, 11, 'KARACASU'),
(133, 11, 'KARPUZLU'),
(134, 11, 'KOÇARLI'),
(135, 11, 'KÖŞK'),
(136, 11, 'KUŞADASI'),
(137, 11, 'KUYUCAK'),
(138, 11, 'NAZİLLİ'),
(139, 11, 'SÖKE'),
(140, 11, 'SULTANHİSAR'),
(141, 11, 'YENİPAZAR'),
(142, 12, 'ALTIEYLÜL'),
(143, 12, 'AYVALIK'),
(144, 12, 'BALYA'),
(145, 12, 'BANDIRMA'),
(146, 12, 'BİGADİÇ'),
(147, 12, 'BURHANİYE'),
(148, 12, 'DURSUNBEY'),
(149, 12, 'EDREMİT'),
(150, 12, 'ERDEK'),
(151, 12, 'GÖMEÇ'),
(152, 12, 'GÖNEN'),
(153, 12, 'HAVRAN'),
(154, 12, 'İVRİNDİ'),
(155, 12, 'KARESİ'),
(156, 12, 'KEPSUT'),
(157, 12, 'MANYAS'),
(158, 12, 'MARMARA'),
(159, 12, 'SAVAŞTEPE'),
(160, 12, 'SINDIRGI'),
(161, 12, 'SUSURLUK'),
(162, 13, 'AMASRA'),
(163, 13, 'KURUCAŞİLE'),
(164, 13, 'MERKEZ'),
(165, 13, 'ULUS'),
(166, 14, 'BEŞİRİ'),
(167, 14, 'GERCÜŞ'),
(168, 14, 'HASANKEYF'),
(169, 14, 'KOZLUK'),
(170, 14, 'MERKEZ'),
(171, 14, 'SASON'),
(172, 15, 'AYDINTEPE'),
(173, 15, 'DEMİRÖZÜ'),
(174, 15, 'MERKEZ'),
(175, 16, 'BOZÜYÜK'),
(176, 16, 'GÖLPAZARI'),
(177, 16, 'İNHİSAR'),
(178, 16, 'MERKEZ'),
(179, 16, 'OSMANELİ'),
(180, 16, 'PAZARYERİ'),
(181, 16, 'SÖĞÜT'),
(182, 16, 'YENİPAZAR'),
(183, 17, 'ADAKLI'),
(184, 17, 'GENÇ'),
(185, 17, 'KARLIOVA'),
(186, 17, 'KİĞI'),
(187, 17, 'MERKEZ'),
(188, 17, 'SOLHAN'),
(189, 17, 'YAYLADERE'),
(190, 17, 'YEDİSU'),
(191, 18, 'ADİLCEVAZ'),
(192, 18, 'AHLAT'),
(193, 18, 'GÜROYMAK'),
(194, 18, 'HİZAN'),
(195, 18, 'MERKEZ'),
(196, 18, 'MUTKİ'),
(197, 18, 'TATVAN'),
(198, 19, 'DÖRTDİVAN'),
(199, 19, 'GEREDE'),
(200, 19, 'GÖYNÜK'),
(201, 19, 'KIBRISCIK'),
(202, 19, 'MENGEN'),
(203, 19, 'MERKEZ'),
(204, 19, 'MUDURNU'),
(205, 19, 'SEBEN'),
(206, 19, 'YENİÇAĞA'),
(207, 20, 'AĞLASUN'),
(208, 20, 'ALTINYAYLA'),
(209, 20, 'BUCAK'),
(210, 20, 'ÇAVDIR'),
(211, 20, 'ÇELTİKÇİ'),
(212, 20, 'GÖLHİSAR'),
(213, 20, 'KARAMANLI'),
(214, 20, 'KEMER'),
(215, 20, 'MERKEZ'),
(216, 20, 'TEFENNİ'),
(217, 20, 'YEŞİLOVA'),
(218, 21, 'BÜYÜKORHAN'),
(219, 21, 'GEMLİK'),
(220, 21, 'GÜRSU'),
(221, 21, 'HARMANCIK'),
(222, 21, 'İNEGÖL'),
(223, 21, 'İZNİK'),
(224, 21, 'KARACABEY'),
(225, 21, 'KELES'),
(226, 21, 'KESTEL'),
(227, 21, 'MUDANYA'),
(228, 21, 'MUSTAFAKEMALPAŞA'),
(229, 21, 'NİLÜFER'),
(230, 21, 'ORHANELİ'),
(231, 21, 'ORHANGAZİ'),
(232, 21, 'OSMANGAZİ'),
(233, 21, 'YENİŞEHİR'),
(234, 21, 'YILDIRIM'),
(235, 22, 'AYVACIK'),
(236, 22, 'BAYRAMİÇ'),
(237, 22, 'BİGA'),
(238, 22, 'BOZCAADA'),
(239, 22, 'ÇAN'),
(240, 22, 'ECEABAT'),
(241, 22, 'EZİNE'),
(242, 22, 'GELİBOLU'),
(243, 22, 'GÖKÇEADA'),
(244, 22, 'LAPSEKİ'),
(245, 22, 'MERKEZ'),
(246, 22, 'YENİCE'),
(247, 23, 'ATKARACALAR'),
(248, 23, 'BAYRAMÖREN'),
(249, 23, 'ÇERKEŞ'),
(250, 23, 'ELDİVAN'),
(251, 23, 'ILGAZ'),
(252, 23, 'KIZILIRMAK'),
(253, 23, 'KORGUN'),
(254, 23, 'KURŞUNLU'),
(255, 23, 'MERKEZ'),
(256, 23, 'ORTA'),
(257, 23, 'ŞABANÖZÜ'),
(258, 23, 'YAPRAKLI'),
(259, 24, 'ALACA'),
(260, 24, 'BAYAT'),
(261, 24, 'BOĞAZKALE'),
(262, 24, 'DODURGA'),
(263, 24, 'İSKİLİP'),
(264, 24, 'KARGI'),
(265, 24, 'LAÇİN'),
(266, 24, 'MECİTÖZÜ'),
(267, 24, 'MERKEZ'),
(268, 24, 'OĞUZLAR'),
(269, 24, 'ORTAKÖY'),
(270, 24, 'OSMANCIK'),
(271, 24, 'SUNGURLU'),
(272, 24, 'UĞURLUDAĞ'),
(273, 25, 'ACIPAYAM'),
(274, 25, 'BABADAĞ'),
(275, 25, 'BAKLAN'),
(276, 25, 'BEKİLLİ'),
(277, 25, 'BEYAĞAÇ'),
(278, 25, 'BOZKURT'),
(279, 25, 'BULDAN'),
(280, 25, 'ÇAL'),
(281, 25, 'ÇAMELİ'),
(282, 25, 'ÇARDAK'),
(283, 25, 'ÇİVRİL'),
(284, 25, 'GÜNEY'),
(285, 25, 'HONAZ'),
(286, 25, 'KALE'),
(287, 25, 'MERKEZEFENDİ'),
(288, 25, 'PAMUKKALE'),
(289, 25, 'SARAYKÖY'),
(290, 25, 'SERİNHİSAR'),
(291, 25, 'TAVAS'),
(292, 26, 'BAĞLAR'),
(293, 26, 'BİSMİL'),
(294, 26, 'ÇERMİK'),
(295, 26, 'ÇINAR'),
(296, 26, 'ÇÜNGÜŞ'),
(297, 26, 'DİCLE'),
(298, 26, 'EĞİL'),
(299, 26, 'ERGANİ'),
(300, 26, 'HANİ'),
(301, 26, 'HAZRO'),
(302, 26, 'KAYAPINAR'),
(303, 26, 'KOCAKÖY'),
(304, 26, 'KULP'),
(305, 26, 'LİCE'),
(306, 26, 'SİLVAN'),
(307, 26, 'SUR'),
(308, 26, 'YENİŞEHİR'),
(309, 27, 'AKÇAKOCA'),
(310, 27, 'CUMAYERİ'),
(311, 27, 'ÇİLİMLİ'),
(312, 27, 'GÖLYAKA'),
(313, 27, 'GÜMÜŞOVA'),
(314, 27, 'KAYNAŞLI'),
(315, 27, 'MERKEZ'),
(316, 27, 'YIĞILCA'),
(317, 28, 'ENEZ'),
(318, 28, 'HAVSA'),
(319, 28, 'İPSALA'),
(320, 28, 'KEŞAN'),
(321, 28, 'LALAPAŞA'),
(322, 28, 'MERİÇ'),
(323, 28, 'MERKEZ'),
(324, 28, 'SÜLOĞLU'),
(325, 28, 'UZUNKÖPRÜ'),
(326, 29, 'AĞIN'),
(327, 29, 'ALACAKAYA'),
(328, 29, 'ARICAK'),
(329, 29, 'BASKİL'),
(330, 29, 'KARAKOÇAN'),
(331, 29, 'KEBAN'),
(332, 29, 'KOVANCILAR'),
(333, 29, 'MADEN'),
(334, 29, 'MERKEZ'),
(335, 29, 'PALU'),
(336, 29, 'SİVRİCE'),
(337, 30, 'ÇAYIRLI'),
(338, 30, 'İLİÇ'),
(339, 30, 'KEMAH'),
(340, 30, 'KEMALİYE'),
(341, 30, 'MERKEZ'),
(342, 30, 'OTLUKBELİ'),
(343, 30, 'REFAHİYE'),
(344, 30, 'TERCAN'),
(345, 30, 'ÜZÜMLÜ'),
(346, 31, 'AŞKALE'),
(347, 31, 'AZİZİYE'),
(348, 31, 'ÇAT'),
(349, 31, 'HINIS'),
(350, 31, 'HORASAN'),
(351, 31, 'İSPİR'),
(352, 31, 'KARAÇOBAN'),
(353, 31, 'KARAYAZI'),
(354, 31, 'KÖPRÜKÖY'),
(355, 31, 'NARMAN'),
(356, 31, 'OLTU'),
(357, 31, 'OLUR'),
(358, 31, 'PALANDÖKEN'),
(359, 31, 'PASİNLER'),
(360, 31, 'PAZARYOLU'),
(361, 31, 'ŞENKAYA'),
(362, 31, 'TEKMAN'),
(363, 31, 'TORTUM'),
(364, 31, 'UZUNDERE'),
(365, 31, 'YAKUTİYE'),
(366, 32, 'ALPU'),
(367, 32, 'BEYLİKOVA'),
(368, 32, 'ÇİFTELER'),
(369, 32, 'GÜNYÜZÜ'),
(370, 32, 'HAN'),
(371, 32, 'İNÖNÜ'),
(372, 32, 'MAHMUDİYE'),
(373, 32, 'MİHALGAZİ'),
(374, 32, 'MİHALIÇÇIK'),
(375, 32, 'ODUNPAZARI'),
(376, 32, 'SARICAKAYA'),
(377, 32, 'SEYİTGAZİ'),
(378, 32, 'SİVRİHİSAR'),
(379, 32, 'TEPEBAŞI'),
(380, 33, 'ARABAN'),
(381, 33, 'İSLAHİYE'),
(382, 33, 'KARKAMIŞ'),
(383, 33, 'NİZİP'),
(384, 33, 'NURDAĞI'),
(385, 33, 'OĞUZELİ'),
(386, 33, 'ŞAHİNBEY'),
(387, 33, 'ŞEHİTKAMİL'),
(388, 33, 'YAVUZELİ'),
(389, 34, 'ALUCRA'),
(390, 34, 'BULANCAK'),
(391, 34, 'ÇAMOLUK'),
(392, 34, 'ÇANAKÇI'),
(393, 34, 'DERELİ'),
(394, 34, 'DOĞANKENT'),
(395, 34, 'ESPİYE'),
(396, 34, 'EYNESİL'),
(397, 34, 'GÖRELE'),
(398, 34, 'GÜCE'),
(399, 34, 'KEŞAP'),
(400, 34, 'MERKEZ'),
(401, 34, 'PİRAZİZ'),
(402, 34, 'ŞEBİNKARAHİSAR'),
(403, 34, 'TİREBOLU'),
(404, 34, 'YAĞLIDERE'),
(405, 35, 'KELKİT'),
(406, 35, 'KÖSE'),
(407, 35, 'KÜRTÜN'),
(408, 35, 'MERKEZ'),
(409, 35, 'ŞİRAN'),
(410, 35, 'TORUL'),
(411, 36, 'ÇUKURCA'),
(412, 36, 'MERKEZ'),
(413, 36, 'ŞEMDİNLİ'),
(414, 36, 'YÜKSEKOVA'),
(415, 37, 'ALTINÖZÜ'),
(416, 37, 'ANTAKYA'),
(417, 37, 'ARSUZ'),
(418, 37, 'BELEN'),
(419, 37, 'DEFNE'),
(420, 37, 'DÖRTYOL'),
(421, 37, 'ERZİN'),
(422, 37, 'HASSA'),
(423, 37, 'İSKENDERUN'),
(424, 37, 'KIRIKHAN'),
(425, 37, 'KUMLU'),
(426, 37, 'PAYAS'),
(427, 37, 'REYHANLI'),
(428, 37, 'SAMANDAĞ'),
(429, 37, 'YAYLADAĞI'),
(430, 38, 'ARALIK'),
(431, 38, 'KARAKOYUNLU'),
(432, 38, 'MERKEZ'),
(433, 38, 'TUZLUCA'),
(434, 39, 'AKSU'),
(435, 39, 'ATABEY'),
(436, 39, 'EĞİRDİR'),
(437, 39, 'GELENDOST'),
(438, 39, 'GÖNEN'),
(439, 39, 'KEÇİBORLU'),
(440, 39, 'MERKEZ'),
(441, 39, 'SENİRKENT'),
(442, 39, 'SÜTÇÜLER'),
(443, 39, 'ŞARKİKARAAĞAÇ'),
(444, 39, 'ULUBORLU'),
(445, 39, 'YALVAÇ'),
(446, 39, 'YENİŞARBADEMLİ'),
(447, 40, 'ADALAR'),
(448, 40, 'ARNAVUTKÖY'),
(449, 40, 'ATAŞEHİR'),
(450, 40, 'AVCILAR'),
(451, 40, 'BAĞCILAR'),
(452, 40, 'BAHÇELİEVLER'),
(453, 40, 'BAKIRKÖY'),
(454, 40, 'BAŞAKŞEHİR'),
(455, 40, 'BAYRAMPAŞA'),
(456, 40, 'BEŞİKTAŞ'),
(457, 40, 'BEYKOZ'),
(458, 40, 'BEYLİKDÜZÜ'),
(459, 40, 'BEYOĞLU'),
(460, 40, 'BÜYÜKÇEKMECE'),
(461, 40, 'ÇATALCA'),
(462, 40, 'ÇEKMEKÖY'),
(463, 40, 'ESENLER'),
(464, 40, 'ESENYURT'),
(465, 40, 'EYÜPSULTAN'),
(466, 40, 'FATİH'),
(467, 40, 'GAZİOSMANPAŞA'),
(468, 40, 'GÜNGÖREN'),
(469, 40, 'KADIKÖY'),
(470, 40, 'KAĞITHANE'),
(471, 40, 'KARTAL'),
(472, 40, 'KÜÇÜKÇEKMECE'),
(473, 40, 'MALTEPE'),
(474, 40, 'PENDİK'),
(475, 40, 'SANCAKTEPE'),
(476, 40, 'SARIYER'),
(477, 40, 'SİLİVRİ'),
(478, 40, 'SULTANBEYLİ'),
(479, 40, 'SULTANGAZİ'),
(480, 40, 'ŞİLE'),
(481, 40, 'ŞİŞLİ'),
(482, 40, 'TUZLA'),
(483, 40, 'ÜMRANİYE'),
(484, 40, 'ÜSKÜDAR'),
(485, 40, 'ZEYTİNBURNU'),
(486, 41, 'ALİAĞA'),
(487, 41, 'BALÇOVA'),
(488, 41, 'BAYINDIR'),
(489, 41, 'BAYRAKLI'),
(490, 41, 'BERGAMA'),
(491, 41, 'BEYDAĞ'),
(492, 41, 'BORNOVA'),
(493, 41, 'BUCA'),
(494, 41, 'ÇEŞME'),
(495, 41, 'ÇİĞLİ'),
(496, 41, 'DİKİLİ'),
(497, 41, 'FOÇA'),
(498, 41, 'GAZİEMİR'),
(499, 41, 'GÜZELBAHÇE'),
(500, 41, 'KARABAĞLAR'),
(501, 41, 'KARABURUN'),
(502, 41, 'KARŞIYAKA'),
(503, 41, 'KEMALPAŞA'),
(504, 41, 'KINIK'),
(505, 41, 'KİRAZ'),
(506, 41, 'KONAK'),
(507, 41, 'MENDERES'),
(508, 41, 'MENEMEN'),
(509, 41, 'NARLIDERE'),
(510, 41, 'ÖDEMİŞ'),
(511, 41, 'SEFERİHİSAR'),
(512, 41, 'SELÇUK'),
(513, 41, 'TİRE'),
(514, 41, 'TORBALI'),
(515, 41, 'URLA'),
(516, 42, 'AFŞİN'),
(517, 42, 'ANDIRIN'),
(518, 42, 'ÇAĞLAYANCERİT'),
(519, 42, 'DULKADİROĞLU'),
(520, 42, 'EKİNÖZÜ'),
(521, 42, 'ELBİSTAN'),
(522, 42, 'GÖKSUN'),
(523, 42, 'NURHAK'),
(524, 42, 'ONİKİŞUBAT'),
(525, 42, 'PAZARCIK'),
(526, 42, 'TÜRKOĞLU'),
(527, 43, 'EFLANİ'),
(528, 43, 'ESKİPAZAR'),
(529, 43, 'MERKEZ'),
(530, 43, 'OVACIK'),
(531, 43, 'SAFRANBOLU'),
(532, 43, 'YENİCE'),
(533, 44, 'AYRANCI'),
(534, 44, 'BAŞYAYLA'),
(535, 44, 'ERMENEK'),
(536, 44, 'KAZIMKARABEKİR'),
(537, 44, 'MERKEZ'),
(538, 44, 'SARIVELİLER'),
(539, 45, 'AKYAKA'),
(540, 45, 'ARPAÇAY'),
(541, 45, 'DİGOR'),
(542, 45, 'KAĞIZMAN'),
(543, 45, 'MERKEZ'),
(544, 45, 'SARIKAMIŞ'),
(545, 45, 'SELİM'),
(546, 45, 'SUSUZ'),
(547, 46, 'ABANA'),
(548, 46, 'AĞLI'),
(549, 46, 'ARAÇ'),
(550, 46, 'AZDAVAY'),
(551, 46, 'BOZKURT'),
(552, 46, 'CİDE'),
(553, 46, 'ÇATALZEYTİN'),
(554, 46, 'DADAY'),
(555, 46, 'DEVREKANİ'),
(556, 46, 'DOĞANYURT'),
(557, 46, 'HANÖNÜ'),
(558, 46, 'İHSANGAZİ'),
(559, 46, 'İNEBOLU'),
(560, 46, 'KÜRE'),
(561, 46, 'MERKEZ'),
(562, 46, 'PINARBAŞI'),
(563, 46, 'SEYDİLER'),
(564, 46, 'ŞENPAZAR'),
(565, 46, 'TAŞKÖPRÜ'),
(566, 46, 'TOSYA'),
(567, 47, 'AKKIŞLA'),
(568, 47, 'BÜNYAN'),
(569, 47, 'DEVELİ'),
(570, 47, 'FELAHİYE'),
(571, 47, 'HACILAR'),
(572, 47, 'İNCESU'),
(573, 47, 'KOCASİNAN'),
(574, 47, 'MELİKGAZİ'),
(575, 47, 'ÖZVATAN'),
(576, 47, 'PINARBAŞI'),
(577, 47, 'SARIOĞLAN'),
(578, 47, 'SARIZ'),
(579, 47, 'TALAS'),
(580, 47, 'TOMARZA'),
(581, 47, 'YAHYALI'),
(582, 47, 'YEŞİLHİSAR'),
(583, 48, 'BAHŞİLİ'),
(584, 48, 'BALIŞEYH'),
(585, 48, 'ÇELEBİ'),
(586, 48, 'DELİCE'),
(587, 48, 'KARAKEÇİLİ'),
(588, 48, 'KESKİN'),
(589, 48, 'MERKEZ'),
(590, 48, 'SULAKYURT'),
(591, 48, 'YAHŞİHAN'),
(592, 49, 'BABAESKİ'),
(593, 49, 'DEMİRKÖY'),
(594, 49, 'KOFÇAZ'),
(595, 49, 'LÜLEBURGAZ'),
(596, 49, 'MERKEZ'),
(597, 49, 'PEHLİVANKÖY'),
(598, 49, 'PINARHİSAR'),
(599, 49, 'VİZE'),
(600, 50, 'AKÇAKENT'),
(601, 50, 'AKPINAR'),
(602, 50, 'BOZTEPE'),
(603, 50, 'ÇİÇEKDAĞI'),
(604, 50, 'KAMAN'),
(605, 50, 'MERKEZ'),
(606, 50, 'MUCUR'),
(607, 51, 'ELBEYLİ'),
(608, 51, 'MERKEZ'),
(609, 51, 'MUSABEYLİ'),
(610, 51, 'POLATELİ'),
(611, 52, 'BAŞİSKELE'),
(612, 52, 'ÇAYIROVA'),
(613, 52, 'DARICA'),
(614, 52, 'DERİNCE'),
(615, 52, 'DİLOVASI'),
(616, 52, 'GEBZE'),
(617, 52, 'GÖLCÜK'),
(618, 52, 'İZMİT'),
(619, 52, 'KANDIRA'),
(620, 52, 'KARAMÜRSEL'),
(621, 52, 'KARTEPE'),
(622, 52, 'KÖRFEZ'),
(623, 53, 'AHIRLI'),
(624, 53, 'AKÖREN'),
(625, 53, 'AKŞEHİR'),
(626, 53, 'ALTINEKİN'),
(627, 53, 'BEYŞEHİR'),
(628, 53, 'BOZKIR'),
(629, 53, 'CİHANBEYLİ'),
(630, 53, 'ÇELTİK'),
(631, 53, 'ÇUMRA'),
(632, 53, 'DERBENT'),
(633, 53, 'DEREBUCAK'),
(634, 53, 'DOĞANHİSAR'),
(635, 53, 'EMİRGAZİ'),
(636, 53, 'EREĞLİ'),
(637, 53, 'GÜNEYSINIR'),
(638, 53, 'HADİM'),
(639, 53, 'HALKAPINAR'),
(640, 53, 'HÜYÜK'),
(641, 53, 'ILGIN'),
(642, 53, 'KADINHANI'),
(643, 53, 'KARAPINAR'),
(644, 53, 'KARATAY'),
(645, 53, 'KULU'),
(646, 53, 'MERAM'),
(647, 53, 'SARAYÖNÜ'),
(648, 53, 'SELÇUKLU'),
(649, 53, 'SEYDİŞEHİR'),
(650, 53, 'TAŞKENT'),
(651, 53, 'TUZLUKÇU'),
(652, 53, 'YALIHÜYÜK'),
(653, 53, 'YUNAK'),
(654, 54, 'ALTINTAŞ'),
(655, 54, 'ASLANAPA'),
(656, 54, 'ÇAVDARHİSAR'),
(657, 54, 'DOMANİÇ'),
(658, 54, 'DUMLUPINAR'),
(659, 54, 'EMET'),
(660, 54, 'GEDİZ'),
(661, 54, 'HİSARCIK'),
(662, 54, 'MERKEZ'),
(663, 54, 'PAZARLAR'),
(664, 54, 'SİMAV'),
(665, 54, 'ŞAPHANE'),
(666, 54, 'TAVŞANLI'),
(667, 55, 'AKÇADAĞ'),
(668, 55, 'ARAPGİR'),
(669, 55, 'ARGUVAN'),
(670, 55, 'BATTALGAZİ'),
(671, 55, 'DARENDE'),
(672, 55, 'DOĞANŞEHİR'),
(673, 55, 'DOĞANYOL'),
(674, 55, 'HEKİMHAN'),
(675, 55, 'KALE'),
(676, 55, 'KULUNCAK'),
(677, 55, 'PÜTÜRGE'),
(678, 55, 'YAZIHAN'),
(679, 55, 'YEŞİLYURT'),
(680, 56, 'AHMETLİ'),
(681, 56, 'AKHİSAR'),
(682, 56, 'ALAŞEHİR'),
(683, 56, 'DEMİRCİ'),
(684, 56, 'GÖLMARMARA'),
(685, 56, 'GÖRDES'),
(686, 56, 'KIRKAĞAÇ'),
(687, 56, 'KÖPRÜBAŞI'),
(688, 56, 'KULA'),
(689, 56, 'SALİHLİ'),
(690, 56, 'SARIGÖL'),
(691, 56, 'SARUHANLI'),
(692, 56, 'SELENDİ'),
(693, 56, 'SOMA'),
(694, 56, 'ŞEHZADELER'),
(695, 56, 'TURGUTLU'),
(696, 56, 'YUNUSEMRE'),
(697, 57, 'ARTUKLU'),
(698, 57, 'DARGEÇİT'),
(699, 57, 'DERİK'),
(700, 57, 'KIZILTEPE'),
(701, 57, 'MAZIDAĞI'),
(702, 57, 'MİDYAT'),
(703, 57, 'NUSAYBİN'),
(704, 57, 'ÖMERLİ'),
(705, 57, 'SAVUR'),
(706, 57, 'YEŞİLLİ'),
(707, 58, 'AKDENİZ'),
(708, 58, 'ANAMUR'),
(709, 58, 'AYDINCIK'),
(710, 58, 'BOZYAZI'),
(711, 58, 'ÇAMLIYAYLA'),
(712, 58, 'ERDEMLİ'),
(713, 58, 'GÜLNAR'),
(714, 58, 'MEZİTLİ'),
(715, 58, 'MUT'),
(716, 58, 'SİLİFKE'),
(717, 58, 'TARSUS'),
(718, 58, 'TOROSLAR'),
(719, 58, 'YENİŞEHİR'),
(720, 59, 'BODRUM'),
(721, 59, 'DALAMAN'),
(722, 59, 'DATÇA'),
(723, 59, 'FETHİYE'),
(724, 59, 'KAVAKLIDERE'),
(725, 59, 'KÖYCEĞİZ'),
(726, 59, 'MARMARİS'),
(727, 59, 'MENTEŞE'),
(728, 59, 'MİLAS'),
(729, 59, 'ORTACA'),
(730, 59, 'SEYDİKEMER'),
(731, 59, 'ULA'),
(732, 59, 'YATAĞAN'),
(733, 60, 'BULANIK'),
(734, 60, 'HASKÖY'),
(735, 60, 'KORKUT'),
(736, 60, 'MALAZGİRT'),
(737, 60, 'MERKEZ'),
(738, 60, 'VARTO'),
(739, 61, 'ACIGÖL'),
(740, 61, 'AVANOS'),
(741, 61, 'DERİNKUYU'),
(742, 61, 'GÜLŞEHİR'),
(743, 61, 'HACIBEKTAŞ'),
(744, 61, 'KOZAKLI'),
(745, 61, 'MERKEZ'),
(746, 61, 'ÜRGÜP'),
(747, 62, 'ALTUNHİSAR'),
(748, 62, 'BOR'),
(749, 62, 'ÇAMARDI'),
(750, 62, 'ÇİFTLİK'),
(751, 62, 'MERKEZ'),
(752, 62, 'ULUKIŞLA'),
(753, 63, 'AKKUŞ'),
(754, 63, 'ALTINORDU'),
(755, 63, 'AYBASTI'),
(756, 63, 'ÇAMAŞ'),
(757, 63, 'ÇATALPINAR'),
(758, 63, 'ÇAYBAŞI'),
(759, 63, 'FATSA'),
(760, 63, 'GÖLKÖY'),
(761, 63, 'GÜLYALI'),
(762, 63, 'GÜRGENTEPE'),
(763, 63, 'İKİZCE'),
(764, 63, 'KABADÜZ'),
(765, 63, 'KABATAŞ'),
(766, 63, 'KORGAN'),
(767, 63, 'KUMRU'),
(768, 63, 'MESUDİYE'),
(769, 63, 'PERŞEMBE'),
(770, 63, 'ULUBEY'),
(771, 63, 'ÜNYE'),
(772, 64, 'BAHÇE'),
(773, 64, 'DÜZİÇİ'),
(774, 64, 'HASANBEYLİ'),
(775, 64, 'KADİRLİ'),
(776, 64, 'MERKEZ'),
(777, 64, 'SUMBAS'),
(778, 64, 'TOPRAKKALE'),
(779, 65, 'ARDEŞEN'),
(780, 65, 'ÇAMLIHEMŞİN'),
(781, 65, 'ÇAYELİ'),
(782, 65, 'DEREPAZARI'),
(783, 65, 'FINDIKLI'),
(784, 65, 'GÜNEYSU'),
(785, 65, 'HEMŞİN'),
(786, 65, 'İKİZDERE'),
(787, 65, 'İYİDERE'),
(788, 65, 'KALKANDERE'),
(789, 65, 'MERKEZ'),
(790, 65, 'PAZAR'),
(791, 66, 'ADAPAZARI'),
(792, 66, 'AKYAZI'),
(793, 66, 'ARİFİYE'),
(794, 66, 'ERENLER'),
(795, 66, 'FERİZLİ'),
(796, 66, 'GEYVE'),
(797, 66, 'HENDEK'),
(798, 66, 'KARAPÜRÇEK'),
(799, 66, 'KARASU'),
(800, 66, 'KAYNARCA'),
(801, 66, 'KOCAALİ'),
(802, 66, 'PAMUKOVA'),
(803, 66, 'SAPANCA'),
(804, 66, 'SERDİVAN'),
(805, 66, 'SÖĞÜTLÜ'),
(806, 66, 'TARAKLI'),
(807, 67, '19 MAYIS'),
(808, 67, 'ALAÇAM'),
(809, 67, 'ASARCIK'),
(810, 67, 'ATAKUM'),
(811, 67, 'AYVACIK'),
(812, 67, 'BAFRA'),
(813, 67, 'CANİK'),
(814, 67, 'ÇARŞAMBA'),
(815, 67, 'HAVZA'),
(816, 67, 'İLKADIM'),
(817, 67, 'KAVAK'),
(818, 67, 'LADİK'),
(819, 67, 'SALIPAZARI'),
(820, 67, 'TEKKEKÖY'),
(821, 67, 'TERME'),
(822, 67, 'VEZİRKÖPRÜ'),
(823, 67, 'YAKAKENT'),
(824, 68, 'BAYKAN'),
(825, 68, 'ERUH'),
(826, 68, 'KURTALAN'),
(827, 68, 'MERKEZ'),
(828, 68, 'PERVARİ'),
(829, 68, 'ŞİRVAN'),
(830, 68, 'TİLLO'),
(831, 69, 'AYANCIK'),
(832, 69, 'BOYABAT'),
(833, 69, 'DİKMEN'),
(834, 69, 'DURAĞAN'),
(835, 69, 'ERFELEK'),
(836, 69, 'GERZE'),
(837, 69, 'MERKEZ'),
(838, 69, 'SARAYDÜZÜ'),
(839, 69, 'TÜRKELİ'),
(840, 70, 'AKINCILAR'),
(841, 70, 'ALTINYAYLA'),
(842, 70, 'DİVRİĞİ'),
(843, 70, 'DOĞANŞAR'),
(844, 70, 'GEMEREK'),
(845, 70, 'GÖLOVA'),
(846, 70, 'GÜRÜN'),
(847, 70, 'HAFİK'),
(848, 70, 'İMRANLI'),
(849, 70, 'KANGAL'),
(850, 70, 'KOYULHİSAR'),
(851, 70, 'MERKEZ'),
(852, 70, 'SUŞEHRİ'),
(853, 70, 'ŞARKIŞLA'),
(854, 70, 'ULAŞ'),
(855, 70, 'YILDIZELİ'),
(856, 70, 'ZARA'),
(857, 71, 'AKÇAKALE'),
(858, 71, 'BİRECİK'),
(859, 71, 'BOZOVA'),
(860, 71, 'CEYLANPINAR'),
(861, 71, 'EYYÜBİYE'),
(862, 71, 'HALFETİ'),
(863, 71, 'HALİLİYE'),
(864, 71, 'HARRAN'),
(865, 71, 'HİLVAN'),
(866, 71, 'KARAKÖPRÜ'),
(867, 71, 'SİVEREK'),
(868, 71, 'SURUÇ'),
(869, 71, 'VİRANŞEHİR'),
(870, 72, 'BEYTÜŞŞEBAP'),
(871, 72, 'CİZRE'),
(872, 72, 'GÜÇLÜKONAK'),
(873, 72, 'İDİL'),
(874, 72, 'MERKEZ'),
(875, 72, 'SİLOPİ'),
(876, 72, 'ULUDERE'),
(877, 73, 'ÇERKEZKÖY'),
(878, 73, 'ÇORLU'),
(879, 73, 'ERGENE'),
(880, 73, 'HAYRABOLU'),
(881, 73, 'KAPAKLI'),
(882, 73, 'MALKARA'),
(883, 73, 'MARMARAEREĞLİSİ'),
(884, 73, 'MURATLI'),
(885, 73, 'SARAY'),
(886, 73, 'SÜLEYMANPAŞA'),
(887, 73, 'ŞARKÖY'),
(888, 74, 'ALMUS'),
(889, 74, 'ARTOVA'),
(890, 74, 'BAŞÇİFTLİK'),
(891, 74, 'ERBAA'),
(892, 74, 'MERKEZ'),
(893, 74, 'NİKSAR'),
(894, 74, 'PAZAR'),
(895, 74, 'REŞADİYE'),
(896, 74, 'SULUSARAY'),
(897, 74, 'TURHAL'),
(898, 74, 'YEŞİLYURT'),
(899, 74, 'ZİLE'),
(900, 75, 'AKÇAABAT'),
(901, 75, 'ARAKLI'),
(902, 75, 'ARSİN'),
(903, 75, 'BEŞİKDÜZÜ'),
(904, 75, 'ÇARŞIBAŞI'),
(905, 75, 'ÇAYKARA'),
(906, 75, 'DERNEKPAZARI'),
(907, 75, 'DÜZKÖY'),
(908, 75, 'HAYRAT'),
(909, 75, 'KÖPRÜBAŞI'),
(910, 75, 'MAÇKA'),
(911, 75, 'OF'),
(912, 75, 'ORTAHİSAR'),
(913, 75, 'SÜRMENE'),
(914, 75, 'ŞALPAZARI'),
(915, 75, 'TONYA'),
(916, 75, 'VAKFIKEBİR'),
(917, 75, 'YOMRA'),
(918, 76, 'ÇEMİŞGEZEK'),
(919, 76, 'HOZAT'),
(920, 76, 'MAZGİRT'),
(921, 76, 'MERKEZ'),
(922, 76, 'NAZIMİYE'),
(923, 76, 'OVACIK'),
(924, 76, 'PERTEK'),
(925, 76, 'PÜLÜMÜR'),
(926, 77, 'BANAZ'),
(927, 77, 'EŞME'),
(928, 77, 'KARAHALLI'),
(929, 77, 'MERKEZ'),
(930, 77, 'SİVASLI'),
(931, 77, 'ULUBEY'),
(932, 78, 'BAHÇESARAY'),
(933, 78, 'BAŞKALE'),
(934, 78, 'ÇALDIRAN'),
(935, 78, 'ÇATAK'),
(936, 78, 'EDREMİT'),
(937, 78, 'ERCİŞ'),
(938, 78, 'GEVAŞ'),
(939, 78, 'GÜRPINAR'),
(940, 78, 'İPEKYOLU'),
(941, 78, 'MURADİYE'),
(942, 78, 'ÖZALP'),
(943, 78, 'SARAY'),
(944, 78, 'TUŞBA'),
(945, 79, 'ALTINOVA'),
(946, 79, 'ARMUTLU'),
(947, 79, 'ÇINARCIK'),
(948, 79, 'ÇİFTLİKKÖY'),
(949, 79, 'MERKEZ'),
(950, 79, 'TERMAL'),
(951, 80, 'AKDAĞMADENİ'),
(952, 80, 'AYDINCIK'),
(953, 80, 'BOĞAZLIYAN'),
(954, 80, 'ÇANDIR'),
(955, 80, 'ÇAYIRALAN'),
(956, 80, 'ÇEKEREK'),
(957, 80, 'KADIŞEHRİ'),
(958, 80, 'MERKEZ'),
(959, 80, 'SARAYKENT'),
(960, 80, 'SARIKAYA'),
(961, 80, 'SORGUN'),
(962, 80, 'ŞEFAATLİ'),
(963, 80, 'YENİFAKILI'),
(964, 80, 'YERKÖY'),
(965, 81, 'ALAPLI'),
(966, 81, 'ÇAYCUMA'),
(967, 81, 'DEVREK'),
(968, 81, 'EREĞLİ'),
(969, 81, 'GÖKÇEBEY'),
(970, 81, 'KİLİMLİ'),
(971, 81, 'KOZLU'),
(972, 81, 'MERKEZ');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `uniteler`
--

CREATE TABLE `uniteler` (
  `id` int(11) NOT NULL,
  `dersID` int(11) NOT NULL,
  `sinif` int(11) NOT NULL,
  `unite_kodu` text NOT NULL,
  `unite_icerik` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `uniteler`
--

INSERT INTO `uniteler` (`id`, `dersID`, `sinif`, `unite_kodu`, `unite_icerik`) VALUES
(1, 2, 7, '01', 'Güneş Sistemi ve Ötesi / Dünya ve Evren'),
(2, 2, 7, '02', 'Hücre ve Bölünmeler / Canlılar ve Yaşam'),
(3, 2, 7, '03', 'Kuvvet ve Enerji / Fiziksel Olaylar');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `userlogins`
--

CREATE TABLE `userlogins` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `logDate` datetime NOT NULL,
  `ip` varchar(25) COLLATE utf8_turkish_ci DEFAULT NULL,
  `browser` varchar(25) COLLATE utf8_turkish_ci DEFAULT NULL,
  `platform` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `userlogins`
--

INSERT INTO `userlogins` (`id`, `userId`, `status`, `logDate`, `ip`, `browser`, `platform`, `location`) VALUES
(1, 1, 2, '2019-10-09 13:38:06', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(2, 1, 1, '2019-10-09 13:38:08', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(3, 1, 2, '2019-10-09 13:48:14', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(4, 2, 1, '2019-10-09 13:48:17', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(5, 2, 2, '2019-10-09 14:01:21', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(6, 1, 1, '2019-10-09 14:01:24', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(7, 1, 2, '2019-10-09 14:11:27', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(8, 3, 1, '2019-10-09 14:11:35', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(9, 3, 2, '2019-10-09 14:17:37', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(10, 1, 1, '2019-10-09 14:17:41', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(11, 1, 2, '2019-10-09 14:41:54', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(12, 1, 1, '2019-10-09 14:41:55', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(13, 1, 2, '2019-10-09 14:41:57', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(14, 1, 1, '2019-10-09 14:41:58', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(15, 1, 2, '2019-10-09 14:41:59', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(16, 1, 1, '2019-10-09 14:42:00', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(17, 1, 2, '2019-10-09 14:42:01', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(18, 1, 1, '2019-10-09 14:42:01', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(19, 1, 2, '2019-10-09 14:42:03', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(20, 1, 1, '2019-10-09 14:42:03', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(21, 1, 2, '2019-10-09 14:42:04', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(22, 1, 1, '2019-10-09 14:42:05', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(23, 1, 2, '2019-10-09 14:42:06', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(24, 1, 1, '2019-10-09 14:42:07', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(25, 1, 2, '2019-10-09 14:42:11', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(26, 1, 1, '2019-10-09 14:42:12', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(27, 1, 2, '2019-10-09 14:42:18', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(28, 1, 1, '2019-10-09 14:42:19', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(29, 1, 1, '2019-10-09 14:43:14', '::1', 'Firefox 69.0', 'Windows 10', NULL),
(30, 1, 2, '2019-10-09 14:43:45', '::1', 'Firefox 69.0', 'Windows 10', NULL),
(31, 1, 2, '2019-10-09 14:48:57', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(32, 1, 1, '2019-10-09 15:26:06', '::1', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(33, 1, 1, '2019-10-09 17:46:05', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 7', NULL),
(34, 1, 2, '2019-10-09 17:52:46', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 7', NULL),
(35, 2, 1, '2019-10-09 17:52:53', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 7', NULL),
(36, 2, 2, '2019-10-09 18:15:07', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 7', NULL),
(37, 2, 1, '2019-10-09 18:15:30', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 7', NULL),
(38, 2, 2, '2019-10-09 18:21:31', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 7', NULL),
(39, 1, 1, '2019-10-09 18:21:41', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 7', NULL),
(40, 1, 1, '2019-10-09 18:34:12', '93.89.225.254', 'Safari 604.1', 'iOS', NULL),
(41, 1, 1, '2019-10-10 08:26:13', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(42, 1, 2, '2019-10-10 08:28:15', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(43, 1, 1, '2019-10-10 08:28:41', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(44, 1, 2, '2019-10-10 08:34:01', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(45, 4, 1, '2019-10-10 08:34:10', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(46, 4, 2, '2019-10-10 09:00:14', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(47, 1, 1, '2019-10-10 09:00:17', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(48, 1, 2, '2019-10-10 09:02:32', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(49, 5, 1, '2019-10-10 09:02:38', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(50, 5, 2, '2019-10-10 09:11:35', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(51, 1, 1, '2019-10-10 09:11:38', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(52, 1, 2, '2019-10-10 09:37:28', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(53, 6, 1, '2019-10-10 09:37:33', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(54, 6, 1, '2019-10-10 10:28:26', '93.89.225.254', 'Safari 604.1', 'iOS', NULL),
(55, 6, 2, '2019-10-10 10:29:12', '93.89.225.254', 'Safari 604.1', 'iOS', NULL),
(56, 6, 1, '2019-10-10 10:33:15', '93.89.225.254', 'Safari 604.1', 'iOS', NULL),
(57, 6, 2, '2019-10-10 13:53:05', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(58, 1, 1, '2019-10-10 13:53:09', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(59, 6, 1, '2019-10-10 13:56:51', '93.89.225.254', 'Chrome 67.0.3396.87', 'Android', NULL),
(60, 1, 2, '2019-10-10 15:16:08', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(61, 1, 1, '2019-10-10 15:24:05', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(62, 6, 1, '2019-10-10 21:19:35', '93.89.225.254', 'Safari 604.1', 'iOS', NULL),
(63, 6, 2, '2019-10-10 21:22:15', '93.89.225.254', 'Safari 604.1', 'iOS', NULL),
(64, 1, 1, '2019-10-11 11:35:23', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(65, 1, 2, '2019-10-11 11:36:10', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(66, 6, 1, '2019-10-11 11:36:18', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(67, 6, 2, '2019-10-11 11:36:32', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 10', NULL),
(68, 6, 1, '2019-10-11 14:39:38', '93.89.225.254', 'Chrome 67.0.3396.87', 'Android', NULL),
(69, 6, 1, '2019-10-11 14:40:01', '93.89.225.254', 'Chrome 67.0.3396.87', 'Android', NULL),
(70, 6, 1, '2019-10-11 14:40:27', '93.89.225.254', 'Chrome 67.0.3396.87', 'Android', NULL),
(71, 6, 1, '2019-10-11 14:43:32', '93.89.225.254', 'Chrome 63.0.3239.84', 'Windows 7', NULL),
(72, 6, 1, '2019-10-11 15:10:30', '93.89.225.254', 'Chrome 77.0.3865.90', 'Windows 7', NULL),
(73, 6, 1, '2019-10-11 16:12:00', '93.89.225.254', 'Safari 604.1', 'iOS', NULL),
(74, 6, 1, '2019-10-11 19:47:55', '93.89.225.254', 'Safari 604.1', 'iOS', NULL),
(75, 6, 2, '2019-10-11 19:48:05', '93.89.225.254', 'Safari 604.1', 'iOS', NULL),
(76, 1, 1, '2019-10-16 15:17:58', '93.89.225.254', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(77, 1, 2, '2019-10-16 15:18:09', '93.89.225.254', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(78, 6, 1, '2019-10-16 15:18:24', '93.89.225.254', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(79, 6, 2, '2019-10-16 15:18:32', '93.89.225.254', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(80, 1, 1, '2019-10-16 23:43:24', '93.89.225.254', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(81, 1, 2, '2019-10-16 23:58:57', '85.108.0.122', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(82, 1, 1, '2019-10-16 23:59:01', '85.108.0.122', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(83, 1, 2, '2019-10-16 23:59:13', '85.108.0.122', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(84, 1, 1, '2019-10-17 00:00:04', '94.235.44.69', 'Safari 604.1', 'iOS', NULL),
(85, 1, 1, '2019-10-17 00:02:52', '85.108.0.122', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(86, 1, 2, '2019-10-17 00:09:27', '85.108.0.122', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(87, 1, 2, '2019-10-17 00:18:32', '94.235.44.69', 'Safari 604.1', 'iOS', NULL),
(88, 1, 1, '2019-10-17 00:43:36', '85.108.0.122', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(89, 1, 1, '2019-10-17 14:26:30', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(90, 1, 1, '2019-10-18 10:15:08', '151.135.181.222', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(91, 1, 2, '2019-10-18 10:16:09', '151.135.181.222', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(92, 2, 1, '2019-10-18 10:16:21', '151.135.181.222', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(93, 2, 2, '2019-10-18 10:21:35', '151.135.181.222', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(94, 1, 1, '2019-10-18 10:21:39', '151.135.181.222', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(95, 1, 2, '2019-10-18 10:28:08', '151.135.181.222', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(96, 1, 1, '2019-10-18 10:28:11', '151.135.181.222', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(97, 1, 2, '2019-10-18 10:28:16', '151.135.181.222', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(98, 2, 1, '2019-10-18 10:28:21', '151.135.181.222', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(99, 2, 2, '2019-10-18 10:30:01', '151.135.181.222', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(100, 1, 1, '2019-10-18 10:30:04', '151.135.181.222', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(101, 1, 2, '2019-10-18 10:36:34', '151.135.181.222', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(102, 2, 1, '2019-10-18 15:47:36', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(103, 2, 2, '2019-10-18 15:53:40', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(104, 1, 1, '2019-10-18 15:53:43', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(105, 1, 2, '2019-10-18 16:21:21', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(106, 2, 1, '2019-10-18 16:21:26', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(107, 2, 2, '2019-10-18 16:24:47', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(108, 1, 1, '2019-10-18 16:24:51', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(109, 1, 2, '2019-10-18 16:27:23', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(110, 6, 1, '2019-10-18 16:27:32', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(111, 6, 2, '2019-10-18 16:45:42', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(112, 1, 1, '2019-10-18 16:45:49', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(113, 1, 2, '2019-10-18 16:50:58', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(114, 6, 1, '2019-10-18 16:51:02', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(115, 6, 2, '2019-10-18 16:57:37', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(116, 1, 1, '2019-10-22 10:03:09', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(117, 1, 2, '2019-10-22 10:05:50', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(118, 2, 1, '2019-10-22 10:05:53', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(119, 2, 2, '2019-10-22 10:08:48', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(120, 1, 1, '2019-10-22 21:04:45', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(121, 1, 2, '2019-10-22 21:53:36', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(122, 6, 1, '2019-10-22 21:53:50', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(123, 6, 2, '2019-10-22 22:12:08', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(124, 1, 1, '2019-10-22 22:12:13', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(125, 1, 2, '2019-10-22 23:49:22', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(126, 1, 1, '2019-10-23 11:54:34', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(127, 1, 2, '2019-10-23 13:50:06', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(128, 1, 1, '2019-10-24 13:56:10', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(129, 1, 2, '2019-10-24 13:57:10', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(130, 1, 1, '2019-10-24 18:23:03', '5.177.182.76', 'Safari 604.1', 'iOS', NULL),
(131, 1, 1, '2019-10-24 21:51:29', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(132, 1, 2, '2019-10-24 22:18:43', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(133, 6, 1, '2019-10-24 22:18:47', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(134, 6, 2, '2019-10-24 22:23:20', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(135, 1, 1, '2019-10-24 22:23:24', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(136, 1, 2, '2019-10-24 22:30:42', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(137, 2, 1, '2019-10-24 22:30:45', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(138, 2, 2, '2019-10-24 22:32:10', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(139, 1, 1, '2019-10-24 22:32:14', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(140, 1, 2, '2019-10-24 22:32:48', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(141, 2, 1, '2019-10-24 22:32:55', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(142, 1, 1, '2019-10-24 22:45:09', '78.166.47.165', 'Safari 604.1', 'iOS', NULL),
(143, 1, 1, '2019-10-24 22:47:00', '78.166.47.165', 'Safari 604.1', 'iOS', NULL),
(144, 2, 2, '2019-10-24 23:08:57', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(145, 1, 1, '2019-10-24 23:09:00', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(146, 1, 2, '2019-10-24 23:09:48', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(147, 2, 1, '2019-10-24 23:11:55', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(148, 2, 2, '2019-10-24 23:13:16', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(149, 1, 1, '2019-10-24 23:13:20', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(150, 1, 2, '2019-10-24 23:13:48', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(151, 1, 1, '2019-10-24 23:16:33', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(152, 1, 2, '2019-10-24 23:39:08', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(153, 2, 1, '2019-10-24 23:39:13', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(154, 2, 2, '2019-10-24 23:51:24', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(155, 1, 1, '2019-10-24 23:51:27', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(156, 1, 2, '2019-10-24 23:53:05', '78.166.47.165', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(157, 1, 2, '2019-10-24 23:53:43', '78.166.47.165', 'Safari 604.1', 'iOS', NULL),
(158, 1, 1, '2019-10-24 23:53:54', '78.166.47.165', 'Safari 604.1', 'iOS', NULL),
(159, 1, 2, '2019-10-24 23:54:41', '78.166.47.165', 'Safari 604.1', 'iOS', NULL),
(160, 1, 1, '2019-10-25 16:04:04', '88.225.101.16', 'Chrome 77.0.3865.120', 'Windows 10', NULL),
(161, 1, 1, '2019-11-03 13:22:59', '78.166.43.189', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(162, 1, 2, '2019-11-03 13:37:49', '78.166.43.189', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(163, 6, 1, '2019-11-03 13:37:52', '78.166.43.189', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(164, 6, 2, '2019-11-03 13:41:12', '78.166.43.189', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(165, 1, 1, '2019-11-03 13:41:16', '78.166.43.189', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(166, 1, 2, '2019-11-03 13:58:52', '78.166.43.189', 'Chrome 77.0.3865.120', 'Windows 7', NULL),
(167, 1, 1, '2019-11-11 14:29:37', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(168, 1, 2, '2019-11-11 14:58:44', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(169, 1, 1, '2019-11-12 13:34:50', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(170, 1, 2, '2019-11-12 13:35:34', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(171, 1, 1, '2019-11-13 09:46:29', '5.177.144.2', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(172, 1, 2, '2019-11-13 09:50:40', '5.177.144.2', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(173, 2, 1, '2019-11-13 09:50:48', '5.177.144.2', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(174, 2, 2, '2019-11-13 09:54:43', '5.177.144.2', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(175, 1, 1, '2019-11-14 09:38:39', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(176, 1, 2, '2019-11-14 09:41:21', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(177, 8, 1, '2019-11-14 09:41:27', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(178, 1, 1, '2019-11-14 09:47:14', '88.225.101.16', 'Firefox 70.0', 'Windows 10', NULL),
(179, 8, 2, '2019-11-14 10:19:11', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(180, 1, 2, '2019-11-14 11:34:58', '88.225.101.16', 'Firefox 70.0', 'Windows 10', NULL),
(181, 1, 1, '2019-11-14 14:47:18', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(182, 1, 2, '2019-11-14 14:48:07', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(183, 1, 1, '2019-11-19 19:30:36', '5.46.102.58', 'Safari 604.1', 'iOS', NULL),
(184, 1, 1, '2019-11-19 21:45:33', '95.10.198.2', 'Chrome 78.0.3904.97', 'Windows 7', NULL),
(185, 1, 2, '2019-11-19 22:39:58', '95.10.198.2', 'Chrome 78.0.3904.97', 'Windows 7', NULL),
(186, 2, 1, '2019-11-19 22:40:06', '95.10.198.2', 'Chrome 78.0.3904.97', 'Windows 7', NULL),
(187, 2, 2, '2019-11-19 23:12:17', '95.10.198.2', 'Chrome 78.0.3904.97', 'Windows 7', NULL),
(188, 1, 1, '2019-11-19 23:12:21', '95.10.198.2', 'Chrome 78.0.3904.97', 'Windows 7', NULL),
(189, 1, 2, '2019-11-19 23:41:16', '95.10.198.2', 'Chrome 78.0.3904.97', 'Windows 7', NULL),
(190, 1, 1, '2019-11-22 09:27:02', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(191, 1, 2, '2019-11-22 09:27:36', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(192, 2, 1, '2019-11-22 09:27:42', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(193, 2, 2, '2019-11-22 09:30:13', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(194, 1, 1, '2019-11-22 09:30:15', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(195, 1, 2, '2019-11-22 09:30:21', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(196, 2, 1, '2019-11-22 09:30:24', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(197, 2, 2, '2019-11-22 09:30:39', '88.225.101.16', 'Chrome 78.0.3904.97', 'Windows 10', NULL),
(198, 1, 1, '2019-12-03 21:05:10', '88.240.70.176', 'Safari 604.1', 'iOS', NULL),
(199, 1, 1, '2019-12-09 20:41:01', '78.160.250.127', 'Safari 604.1', 'iOS', NULL),
(200, 1, 1, '2019-12-09 20:46:24', '78.160.250.127', 'Chrome 78.0.3904.108', 'Windows 7', NULL),
(201, 1, 1, '2019-12-16 17:33:06', '88.225.101.16', 'Chrome 79.0.3945.79', 'Windows 10', NULL),
(202, 1, 1, '2019-12-17 17:08:23', '88.225.101.16', 'Chrome 79.0.3945.79', 'Windows 10', NULL),
(203, 1, 1, '2019-12-18 13:09:08', '88.225.101.16', 'Chrome 79.0.3945.79', 'Windows 10', NULL),
(204, 1, 2, '2019-12-18 13:18:28', '88.225.101.16', 'Chrome 79.0.3945.79', 'Windows 10', NULL),
(205, 2, 1, '2019-12-18 13:18:33', '88.225.101.16', 'Chrome 79.0.3945.79', 'Windows 10', NULL),
(206, 1, 1, '2019-12-20 14:02:48', '88.225.101.16', 'Chrome 79.0.3945.88', 'Windows 10', NULL),
(207, 1, 2, '2019-12-20 14:04:24', '88.225.101.16', 'Chrome 79.0.3945.88', 'Windows 10', NULL),
(208, 1, 1, '2019-12-28 20:53:09', '5.46.96.228', 'Chrome 79.0.3945.93', 'Android', NULL),
(209, 1, 1, '2020-01-01 20:34:57', '88.235.157.245', 'Chrome 79.0.3945.93', 'Android', NULL),
(210, 1, 1, '2020-01-02 10:14:04', '88.225.101.16', 'Chrome 79.0.3945.88', 'Windows 10', NULL),
(211, 1, 1, '2020-01-08 21:18:23', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(212, 1, 2, '2020-01-08 23:10:40', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(213, 1, 1, '2020-01-08 23:11:01', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(214, 1, 2, '2020-01-08 23:11:18', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(215, 2, 1, '2020-01-08 23:12:30', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(216, 2, 2, '2020-01-08 23:14:01', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(217, 1, 1, '2020-01-08 23:14:05', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(218, 1, 2, '2020-01-08 23:14:30', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(219, 2, 1, '2020-01-08 23:14:34', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(220, 2, 2, '2020-01-08 23:45:12', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(221, 2, 1, '2020-01-08 23:45:18', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(222, 2, 2, '2020-01-08 23:46:02', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(223, 1, 1, '2020-01-08 23:46:05', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(224, 1, 2, '2020-01-09 00:15:30', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(225, 1, 1, '2020-01-09 00:15:35', '81.214.16.149', 'Chrome 79.0.3945.88', 'Windows 7', NULL),
(226, 1, 1, '2020-01-20 09:36:36', '5.177.147.69', 'Chrome 79.0.3945.116', 'Android', NULL),
(227, 1, 1, '2020-01-29 19:22:16', '88.232.124.9', 'Chrome 79.0.3945.136', 'Android', NULL),
(228, 1, 1, '2020-01-30 22:58:36', '88.232.124.9', 'Chrome 79.0.3945.136', 'Android', NULL),
(229, 1, 1, '2020-02-25 12:56:52', '88.225.101.16', 'Chrome 79.0.3945.130', 'Windows 10', NULL),
(230, 1, 1, '2020-05-06 22:08:46', '95.5.215.227', 'Chrome 81.0.4044.117', 'Android', NULL),
(231, 1, 1, '2020-05-14 15:33:29', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(232, 1, 2, '2020-05-14 16:40:00', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(233, 1, 1, '2020-05-14 16:42:23', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(234, 1, 2, '2020-05-14 16:52:45', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(235, 1, 1, '2020-05-14 17:01:23', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(236, 1, 2, '2020-05-14 17:01:25', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(237, 1, 1, '2020-05-14 17:51:04', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(238, 1, 2, '2020-05-14 17:51:21', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(239, 1, 1, '2020-05-14 17:52:05', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(240, 1, 1, '2020-05-14 20:38:26', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(241, 1, 2, '2020-05-14 20:51:36', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(242, 1, 1, '2020-05-14 20:51:42', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(243, 1, 2, '2020-05-14 21:18:20', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(244, 1, 1, '2020-05-14 21:18:25', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(245, 1, 2, '2020-05-14 21:21:09', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(246, 1, 1, '2020-05-14 21:21:13', '78.166.40.221', 'Chrome 81.0.4044.138', 'Windows 10', NULL),
(247, 1, 1, '2020-05-14 23:29:26', '78.166.40.221', 'Chrome 81.0.4044.138', 'Android', NULL),
(248, 1, 2, '2020-05-14 23:45:54', '78.166.40.221', 'Chrome 81.0.4044.138', 'Android', NULL),
(249, 1, 1, '2020-06-17 13:02:41', '78.171.121.143', 'Chrome 83.0.4103.97', 'Windows 10', NULL),
(250, 1, 2, '2020-06-17 13:13:10', '78.171.121.143', 'Chrome 83.0.4103.97', 'Windows 10', NULL),
(251, 1, 1, '2020-06-25 00:31:36', '81.214.180.168', 'Chrome 83.0.4103.106', 'Android', NULL),
(252, 1, 1, '2020-06-25 00:33:14', '31.141.87.29', 'Chrome 77.0.3865.116', 'Android', NULL),
(253, 1, 1, '2021-03-30 09:45:49', '88.225.101.16', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(254, 1, 1, '2021-03-30 09:48:02', '78.181.124.133', 'Chrome 89.0.4389.82', 'Windows 8.1', NULL),
(255, 1, 1, '2021-03-30 12:15:02', '88.225.101.16', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(256, 1, 2, '2021-03-30 12:22:14', '88.225.101.16', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(257, 1, 1, '2021-03-30 12:33:02', '88.225.101.16', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(258, 1, 2, '2021-03-30 13:00:14', '88.225.101.16', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(259, 1, 1, '2021-03-30 13:01:08', '88.225.101.16', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(260, 1, 2, '2021-03-30 13:01:29', '88.225.101.16', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(261, 2, 1, '2021-03-30 13:03:58', '81.214.183.253', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(262, 2, 2, '2021-03-30 13:06:48', '81.214.183.253', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(263, 2, 1, '2021-03-30 13:06:54', '81.214.183.253', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(264, 2, 2, '2021-03-30 15:05:06', '81.214.183.253', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(265, 1, 1, '2021-03-30 15:05:09', '81.214.183.253', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(266, 2, 1, '2021-03-30 15:26:59', '81.214.183.253', 'Firefox 87.0', 'Windows 10', NULL),
(267, 1, 2, '2021-03-30 16:13:30', '81.214.183.253', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(268, 1, 1, '2021-03-30 16:13:33', '81.214.183.253', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(269, 2, 2, '2021-03-30 16:14:32', '81.214.183.253', 'Firefox 87.0', 'Windows 10', NULL),
(270, 2, 1, '2021-03-30 16:14:40', '81.214.183.253', 'Firefox 87.0', 'Windows 10', NULL),
(271, 1, 2, '2021-03-30 16:48:21', '81.214.183.253', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(272, 1, 1, '2021-03-30 16:48:25', '81.214.183.253', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(273, 2, 2, '2021-03-30 16:50:57', '81.214.183.253', 'Firefox 87.0', 'Windows 10', NULL),
(274, 2, 1, '2021-03-30 16:54:15', '81.214.183.253', 'Firefox 87.0', 'Windows 10', NULL),
(275, 1, 2, '2021-03-30 17:22:48', '81.214.183.253', 'Chrome 89.0.4389.90', 'Windows 10', NULL),
(276, 2, 2, '2021-03-30 17:23:13', '81.214.183.253', 'Firefox 87.0', 'Windows 10', NULL),
(277, 2, 1, '2021-03-30 18:22:17', '78.168.208.163', 'Chrome 83.0.4103.106', 'Android', NULL),
(278, 2, 2, '2021-03-30 18:24:05', '78.168.208.163', 'Chrome 83.0.4103.106', 'Android', NULL),
(279, 1, 1, '2021-03-30 18:24:15', '78.168.208.163', 'Chrome 83.0.4103.106', 'Android', NULL),
(280, 1, 2, '2021-03-30 18:25:51', '78.168.208.163', 'Chrome 83.0.4103.106', 'Android', NULL),
(281, 1, 1, '2021-03-31 15:13:57', '81.214.183.253', 'Firefox 87.0', 'Windows 10', NULL),
(282, 1, 2, '2021-03-31 15:47:51', '81.214.183.253', 'Firefox 87.0', 'Windows 10', NULL),
(283, 1, 1, '2021-04-02 15:00:16', '81.214.183.253', 'Chrome 89.0.4389.114', 'Windows 10', NULL),
(284, 2, 1, '2021-05-22 22:25:17', '178.241.127.169', 'Chrome 90.0.4430.212', 'Windows 10', NULL),
(285, 2, 1, '2021-05-22 22:29:52', '141.196.180.109', 'Chrome 90.0.4430.210', 'Android', NULL),
(286, 1, 1, '2021-06-09 00:11:53', '78.168.214.173', 'Chrome 91.0.4472.77', 'Windows 10', NULL),
(287, 1, 2, '2021-06-09 00:14:26', '78.168.214.173', 'Chrome 91.0.4472.77', 'Windows 10', NULL),
(288, 1, 1, '2021-06-22 10:56:23', '85.103.96.165', 'Chrome 91.0.4472.114', 'Windows 10', NULL),
(289, 1, 1, '2021-06-24 14:41:41', '85.103.96.165', 'Chrome 91.0.4472.114', 'Windows 10', NULL),
(290, 1, 2, '2021-06-24 14:58:08', '85.103.96.165', 'Chrome 91.0.4472.114', 'Windows 10', NULL),
(291, 1, 1, '2021-06-24 14:58:50', '85.103.96.165', 'Chrome 91.0.4472.114', 'Windows 10', NULL),
(292, 1, 2, '2021-06-24 15:00:44', '85.103.96.165', 'Chrome 91.0.4472.114', 'Windows 10', NULL),
(293, 1, 1, '2021-06-24 15:04:28', '85.103.96.165', 'Chrome 91.0.4472.114', 'Windows 10', NULL),
(294, 1, 2, '2021-06-24 15:05:22', '85.103.96.165', 'Chrome 91.0.4472.114', 'Windows 10', NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `userroles`
--

CREATE TABLE `userroles` (
  `id` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RoleId` int(11) NOT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `createDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `userroles`
--

INSERT INTO `userroles` (`id`, `UserId`, `RoleId`, `isActive`, `createDate`) VALUES
(1, 1, 1, 1, '2019-04-22 10:21:45'),
(2, 2, 2, 1, '2019-04-22 10:23:37');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `md5_password` text COLLATE utf8_turkish_ci,
  `name` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `surname` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `email` text COLLATE utf8_turkish_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `registerDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `address` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT '0',
  `brans` text COLLATE utf8_turkish_ci NOT NULL,
  `bransID` int(11) NOT NULL,
  `okul` text COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `md5_password`, `name`, `surname`, `email`, `isActive`, `registerDate`, `address`, `isAdmin`, `brans`, `bransID`, `okul`) VALUES
(1, 'admin', '4917', 'cf8d8c66b1212720e569b0bd67695451', 'Emre', 'Bodur', 'emrebodurbto@gmail.com', 1, '2019-10-08 06:59:04', 'Düzce', 1, 'Bilişim Teknolojileri', 1, 'Düzce Ölçme ve Değerlendirme Merkezi'),
(2, 'begum', '4917', 'cf8d8c66b1212720e569b0bd67695451', 'Begüm', 'Öztemür', 'begum.oztemur@soruhavuzu.emrebodur.com', 1, '2021-03-30 09:59:48', 'Düzce Borsa İstanbul Mesleki ve Teknik Anadolu Lisesi', 0, 'Lise Matematik', 6, 'Düzce Borsa İstanbul Mesleki ve Teknik Anadolu Lisesi');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`CityID`) USING BTREE,
  ADD KEY `FK_City_CountryID` (`CountryID`) USING BTREE;

--
-- Tablo için indeksler `ci_session`
--
ALTER TABLE `ci_session`
  ADD KEY `ci_sessions_timestamp` (`timestamp`) USING BTREE;

--
-- Tablo için indeksler `count`
--
ALTER TABLE `count`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`CountryID`) USING BTREE;

--
-- Tablo için indeksler `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `dersler`
--
ALTER TABLE `dersler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `duyurular`
--
ALTER TABLE `duyurular`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `haberler`
--
ALTER TABLE `haberler`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `iletisim`
--
ALTER TABLE `iletisim`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `kazanimlar`
--
ALTER TABLE `kazanimlar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `konular`
--
ALTER TABLE `konular`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `site_bilgileri`
--
ALTER TABLE `site_bilgileri`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `sorular`
--
ALTER TABLE `sorular`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `town`
--
ALTER TABLE `town`
  ADD PRIMARY KEY (`TownID`) USING BTREE,
  ADD KEY `FK_Town_CityID` (`CityID`) USING BTREE;

--
-- Tablo için indeksler `uniteler`
--
ALTER TABLE `uniteler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `userlogins`
--
ALTER TABLE `userlogins`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `userroles`
--
ALTER TABLE `userroles`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `dersler`
--
ALTER TABLE `dersler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- Tablo için AUTO_INCREMENT değeri `kazanimlar`
--
ALTER TABLE `kazanimlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `konular`
--
ALTER TABLE `konular`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Tablo için AUTO_INCREMENT değeri `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Tablo için AUTO_INCREMENT değeri `sorular`
--
ALTER TABLE `sorular`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Tablo için AUTO_INCREMENT değeri `uniteler`
--
ALTER TABLE `uniteler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Tablo için AUTO_INCREMENT değeri `userlogins`
--
ALTER TABLE `userlogins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=295;
--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
