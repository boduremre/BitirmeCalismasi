$(document).ready(function () {
    // telefon numarası için intputları formatlıyor
    $('.phone').inputmask("(599) 999-9999");

    // datetimpicker initalize
    $('#tarihdatetimepicker').datetimepicker({
        language: 'tr'
    });

    // datatable classına sahip tablolar
    // dataTable'a dönüştürülüyor.
    $('.datatable').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Turkish.json"
        }
    });

    // ckeditor css sınıfına ait tüm elementleri ckeditor olarak ayarlar.
    CKEDITOR.replaceClass = 'ckeditor';

    // sil butonlarına tıklandığında alert dialog çıkartarak
    // kullanıcının işlemi onaylamasını ister
    // kullanıcı silme işlemini onayladıktan sonra
    // ilgili öge silinir.
    $("body").on('click', '.remove-btn', function () {
        var $data_url = $(this).data("url");
        Swal.fire({
            title: 'Emin misiniz?',
            text: 'Bir ögeyi silmek üzeresiniz. Bu işlem geri alınamaz!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Evet, sil!',
            cancelButtonText: 'İptal'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = $data_url;
            }
        });
    });

    $("body").on('click', '.logout-btn', function () {
        var $data_url = $(this).data("url");
        Swal.fire({
            title: 'Çıkış',
            text: 'Çıkış yapmak istiyor musunuz?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Evet',
            cancelButtonText: 'Hayır'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = $data_url;
            }
        });
    });

    // aktif checkbox check edildiğinde veritabanında
    // ilgili alan true/false şeklinde set edilir.
    $("body").on('change', '.isActive', function () {
        var $data = $(this).prop("checked");
        var $data_url = $(this).data("url");

        if (typeof $data !== "undefined" && typeof $data_url !== "undefined") {
            $.post($data_url, {data: $data}, function (response) {
                location.reload();
            });
        }
    });

    $("#search-form").submit(function (e) {
        //prevent Default functionality
        e.preventDefault();
        form_data = $("#search-form").serialize();
        $('#search_results_container').empty();
        //get the action-url of the form
        var action_url = e.currentTarget.action;

        //do your own request an handle the results
        $.ajax({
            url: action_url,
            type: 'POST',
            dataType: "text",
            cache: false,
            data: form_data,
            success: function (response) {
                $('#search_results_container').html(response);
            },
        });
    });
});

function printDiv(dogrulama_kodu) {
    w = window.open();
    w.document.write("<p style='text-align: center; font-weight: bold; text-transform: uppercase'>Soru Havuzu - Soru Bilgileri</p>");
    w.document.write($('#printableArea').html());
    w.document.write("<br/><p style=\"text-align: justify; font-size: 12px; margin: 5px;\">Düzce İl Milli Eğitim Müdürlüğü bünyesinde yürütülmekte olan sınavlarda\n" +
        "                    kullanılmak üzere hazırlamış olduğum madde tamamıyla bana aittir. Yukarıda yer alan maddenin\n" +
        "                    herhangi bir kaynaktan alınmadığını ve üçüncü şahıslarla paylaşmayacağımı <b>taahhüt ederim.</b> Maddenin\n" +
        "                    gerektiğinde düzeltmeye tabii tutulabileceğini <b>kabul ederim.</b></p>");
    w.document.write("<br/><p style=\"text-align: right; font-size: 12px; margin-right: 15px;\"><b>İmza</b></p>");
    w.print();
    w.close();
}
